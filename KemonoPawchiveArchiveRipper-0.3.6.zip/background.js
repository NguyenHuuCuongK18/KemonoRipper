const H = ["https://kemono.cr", "https://pawchive.pw"], sa = H.map((t) => `img.${new URL(t).hostname}`);
function _t(t) {
  return /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*(?:kemono\.cr|pawchive\.pw)$/.test(t);
}
function Nt(t) {
  return new URL(t).pathname.startsWith("/thumbnail/data/");
}
function Ot(t) {
  try {
    const e = new URL(t), n = /^\/discord\/server\/(\d+)(?:\/(\d+))?\/?$/.exec(e.pathname);
    return !H.includes(e.origin) || e.username || e.password || !n ? null : { serverId: n[1], channelId: n[2] || null, serverName: null, channelName: null };
  } catch {
    return null;
  }
}
function we(t) {
  const e = Ot(t);
  return e?.channelId ? { ...e, channelId: e.channelId } : null;
}
function X(t) {
  if (typeof t != "string" || !/^\d+$/.test(t)) throw new Error("Expected a Discord ID encoded as a string");
  return t;
}
const ia = /^\/([0-9a-f]{2})\/([0-9a-f]{2})\/([0-9a-f]{64})\.(png|jpe?g|webp|gif|avif)$/i;
function Lt(t) {
  if (typeof t != "string") return null;
  const e = ia.exec(t);
  return e ? { path: t, hash: e[3].toLowerCase() } : null;
}
function oa(t, e = H[0]) {
  const n = Lt(t);
  return n && H.includes(e) ? `https://img.${new URL(e).hostname}/thumbnail/data${n.path}` : null;
}
function Q(t) {
  if (typeof t != "string") return null;
  try {
    const e = new URL(t);
    if (e.protocol !== "https:" || e.username || e.password || e.port) return null;
    const n = e.hostname;
    return _t(n) && e.pathname.startsWith("/thumbnail/data/") && Lt(e.pathname.slice(15)) || _t(n) && e.pathname.startsWith("/data/") && Lt(e.pathname.slice(5)) || (n === "cdn.discordapp.com" || n === "media.discordapp.net") && /^\/attachments\/\d+\/\d+\/[^/]+\.(png|jpe?g|webp|gif|avif)$/i.test(e.pathname) ? (e.hash = "", e.href) : null;
  } catch {
    return null;
  }
}
class O extends Error {
  constructor(e, n, a = 0) {
    super(e), this.status = n, this.retryAfterMs = a, this.name = "RequestError";
  }
  status;
  retryAfterMs;
  get retryable() {
    return this.status === 0 || this.status === 429 || this.status >= 500;
  }
}
function ca(t, e = Date.now()) {
  if (!t) return 0;
  const n = Number(t);
  return Math.max(0, Number.isFinite(n) ? n * 1e3 : Date.parse(t) - e || 0);
}
class qe {
  constructor(e = (n, a) => fetch(n, a)) {
    this.transport = e;
  }
  transport;
  async json(e, n = H[0]) {
    if (!H.includes(n)) throw new Error("Unsupported archive origin");
    let a;
    try {
      a = await this.transport(`${n}/api/v1${e}`, {
        headers: { Accept: "text/css" },
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(2e4)
      });
    } catch {
      throw new O("API network request failed or timed out. Open the channel to check site access.", 0);
    }
    if (!a.ok) {
      const r = a.status === 403 ? " Access denied; the required Accept: text/css header was sent. Check access in the site tab." : "";
      throw new O(`API HTTP ${a.status}.${r}`, a.status, ca(a.headers.get("retry-after")));
    }
    try {
      return JSON.parse(await a.text());
    } catch {
      throw new O("API returned invalid JSON; this page is incomplete.", 422);
    }
  }
  async channel(e, n, a = H[0]) {
    if (X(e), !Number.isSafeInteger(n) || n < 0) throw new Error("Invalid page offset");
    const r = await this.json(`/discord/channel/${e}?o=${n}`, a);
    if (!Array.isArray(r)) throw new O("Channel response is not an array", 422);
    for (const s of r) {
      if (!s || typeof s != "object") throw new O("Invalid message object", 422);
      if (X(s.id), s.channel !== void 0 && X(s.channel) !== e) throw new O("Channel response contains a different channel", 422);
      if (s.server !== void 0 && X(s.server), s.attachments != null && (!Array.isArray(s.attachments) || s.attachments.some((i) => !i || typeof i != "object" || Array.isArray(i)))) throw new O("Invalid attachment list", 422);
    }
    return r;
  }
  async server(e, n = H[0]) {
    X(e);
    const a = await this.json(`/discord/server/${e}`, n);
    if (!a || X(a.id) !== e || !Array.isArray(a.channels)) throw new O("Invalid server metadata", 422);
    return {
      id: e,
      name: typeof a.name == "string" ? a.name : e,
      channels: a.channels.map((r) => ({
        id: X(r.id),
        name: typeof r.name == "string" ? r.name : r.id,
        parentId: typeof r.parent_channel_id == "string" ? X(r.parent_channel_id) : null,
        type: typeof r.type == "number" ? r.type : null,
        postCount: Number.isSafeInteger(r.post_count) && r.post_count >= 0 ? r.post_count : null
      }))
    };
  }
}
function la(t, e, n) {
  const a = /* @__PURE__ */ new Map();
  for (const s of e?.channels || []) a.set(s.id, { ...s, sources: ["api"] });
  let r = e?.name || null;
  for (const s of n)
    if (s.serverId === t) {
      r ||= typeof s.serverName == "string" ? s.serverName : null;
      for (const i of s.channels) {
        try {
          X(i.id);
        } catch {
          continue;
        }
        const o = a.get(i.id);
        o ? o.sources = [.../* @__PURE__ */ new Set([...o.sources || [], "dom"])] : a.set(i.id, { id: i.id, name: typeof i.name == "string" ? i.name : i.id, parentId: null, type: null, postCount: null, sources: ["dom"] });
      }
    }
  return e || a.size ? { id: t, name: r || t, channels: [...a.values()] } : null;
}
function oe(t) {
  let e = 0xcbf29ce484222325n;
  for (const n of t) e = BigInt.asUintN(64, (e ^ BigInt(n.codePointAt(0))) * 0x100000001b3n);
  return e.toString(16).padStart(16, "0");
}
function Fe(t) {
  if (typeof t != "string") return null;
  const e = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$/.exec(t);
  if (!e) return null;
  const [, n, a, r, s, i, o, c, d] = e, h = Number(n), y = Number(a), u = Number(r);
  if (y < 1 || y > 12 || u < 1 || u > new Date(Date.UTC(h, y, 0)).getUTCDate() || Number(s) > 23 || Number(i) > 59 || Number(o) > 59) return null;
  const f = `${n}-${a}-${r}T${s}:${i}:${o}.${(c || "").padEnd(3, "0").slice(0, 3)}${d || "Z"}`, g = Date.parse(f);
  return Number.isFinite(g) ? new Date(g).toISOString() : null;
}
function me(t, e, n, a, r) {
  return {
    ...t,
    jobId: e,
    id: `${t.serverId}:${t.channelId}:${n || "dom"}:${a}:${oe(r)}`,
    messageId: n,
    attachmentIndex: a,
    attachmentId: null,
    publishedRaw: null,
    publishedAtUtc: null,
    originalFilename: null,
    kemonoPath: null,
    kemonoFileHash: null,
    originalUrl: null,
    discordCdnUrl: null,
    thumbnailUrl: null,
    resolvedUrl: null,
    mediaType: "unknown",
    sourceType: "api",
    provenance: [],
    warnings: [],
    status: "discovered",
    savedPath: null,
    errorMessage: null,
    attempts: 0,
    nextAttemptAt: 0,
    downloadId: null,
    blobUrl: null,
    quality: null,
    bytes: null,
    sha256: null,
    mime: null,
    width: null,
    height: null,
    candidateFailures: []
  };
}
function da(t, e, n, a = H[0]) {
  const r = [];
  for (const s of t) {
    if (s.server && s.server !== e.serverId) throw new Error("Message belongs to a different server");
    const i = (h) => (h.publishedRaw = typeof s.published == "string" ? s.published : null, h.publishedAtUtc = Fe(h.publishedRaw), h.provenance = ["api"], h.publishedAtUtc ? /(Z|[+-]\d\d:\d\d)$/.test(h.publishedRaw) || h.warnings.push("Archive timestamp has no timezone; interpreted as UTC") : h.warnings.push("Missing or invalid publication timestamp"), h), o = s.attachments || [];
    o.forEach((h, y) => {
      const u = typeof h.path == "string" ? h.path : null, f = i(me(e, n, s.id, y + 1, u || h.name || `attachment-${y}`));
      f.originalFilename = typeof h.name == "string" ? h.name : null;
      const g = Lt(u);
      g ? (f.kemonoPath = g.path, f.kemonoFileHash = g.hash, f.thumbnailUrl = oa(g.path, a), f.mediaType = "image") : (f.discordCdnUrl = Q(u), f.discordCdnUrl?.includes("discordapp.") ? f.mediaType = "image" : (f.discordCdnUrl = null, f.warnings.push("Unsupported attachment path; needs an observed image URL"))), r.push(f);
    });
    const c = typeof s.content == "string" ? s.content.match(/https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\/[^\s<>"')]+/g) || [] : [];
    [...new Set(c.map(Q).filter((h) => !!h))].forEach((h, y) => {
      const u = i(me(e, n, s.id, o.length + y + 1, h));
      u.discordCdnUrl = h, u.mediaType = "image", u.originalFilename = new URL(h).pathname.split("/").at(-1);
      try {
        u.originalFilename = decodeURIComponent(u.originalFilename);
      } catch {
      }
      u.provenance.push("inline-content"), r.push(u);
    });
  }
  return r;
}
function He(t, e) {
  const n = new Map(t.map((a) => [a.id, a]));
  for (const a of e) {
    let r = n.get(a.id);
    if (!r && a.messageId) {
      const o = [...n.values()].filter((c) => (c.sourceType === "dom" || a.sourceType === "dom") && c.sourceType !== a.sourceType && c.serverId === a.serverId && c.channelId === a.channelId && c.messageId === a.messageId && (c.kemonoPath && c.kemonoPath === a.kemonoPath || c.discordCdnUrl && c.discordCdnUrl === a.discordCdnUrl));
      r = o.find((c) => c.attachmentIndex === a.attachmentIndex) || (o.length === 1 ? o[0] : void 0);
    }
    if (!r) {
      n.set(a.id, a);
      continue;
    }
    const s = a.sourceType === "api" && r.sourceType === "dom" ? a : r, i = {
      ...r,
      id: s.id,
      attachmentIndex: s.attachmentIndex,
      publishedRaw: s.publishedRaw || r.publishedRaw || a.publishedRaw,
      publishedAtUtc: s.publishedAtUtc || r.publishedAtUtc || a.publishedAtUtc,
      originalFilename: s.originalFilename || r.originalFilename || a.originalFilename,
      kemonoPath: r.kemonoPath || a.kemonoPath,
      kemonoFileHash: r.kemonoFileHash || a.kemonoFileHash,
      thumbnailUrl: r.thumbnailUrl || a.thumbnailUrl,
      originalUrl: r.originalUrl || a.originalUrl,
      discordCdnUrl: r.discordCdnUrl || a.discordCdnUrl,
      mediaType: r.mediaType === "unknown" ? a.mediaType : r.mediaType,
      sourceType: r.sourceType === a.sourceType ? r.sourceType : "merged",
      provenance: [.../* @__PURE__ */ new Set([...r.provenance, ...a.provenance])],
      warnings: [.../* @__PURE__ */ new Set([...r.warnings, ...a.warnings])]
    };
    n.delete(r.id), n.set(i.id, i);
  }
  return [...n.values()];
}
const ua = 150;
function fa(t, e) {
  const n = structuredClone(t);
  if (n.attempts = 0, n.nextAttemptAt = 0, n.error = null, !e.length)
    return n.pages++, n.coverage = "complete", n.terminal = "empty-page", n;
  const a = oe(e.map((r) => r.id).join(","));
  if (n.pageFingerprints.includes(a)) throw new Error("API repeated an earlier page; pagination stopped with incomplete coverage");
  if (n.pages >= 1e4) throw new Error("Safety page limit reached; coverage is incomplete");
  return n.pageFingerprints.push(a), n.pages++, n.messageIds = [.../* @__PURE__ */ new Set([...n.messageIds, ...e.map((r) => r.id)])], n.offset += ua, n.coverage = "scanning", n;
}
function tt(t, e = "unnamed") {
  let n = (t || e).normalize("NFKC").replace(/[<>:"/\\|?*\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "_").replace(/^[. ]+|[. ]+$/g, "").slice(0, 40).trim().replace(/[. ]+$/g, "");
  return (!n || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(n)) && (n = "_" + (n || e)), n;
}
function zt(t) {
  return `ArchiveRoot/${t.service === "discord" ? "discord/" : ""}${t.serverId}_${tt(t.serverName, "server")}`;
}
function $t(t) {
  return `${zt(t)}/${t.channelId}_${tt(t.channelName, "channel")}`;
}
function pa(t, e) {
  if (!/^(png|jpg|webp|gif|avif)$/.test(e)) throw new Error("Unvalidated image format");
  const n = t.publishedAtUtc ? t.publishedAtUtc.slice(0, 19).replace("T", "_").replace(/:(\d{2})/g, "$1") + "Z" : "unknown-date";
  return `${$t(t)}/${n}_${t.messageId || "unknown-message"}_${String(t.attachmentIndex).padStart(3, "0")}_${oe(t.id).slice(0, 8)}.${e}`;
}
let Ct;
function Y() {
  return Ct || (Ct = new Promise((t, e) => {
    const n = indexedDB.open("kemono-archive", 3);
    n.onupgradeneeded = () => {
      n.result.objectStoreNames.contains("jobs") || (n.result.createObjectStore("jobs", { keyPath: "id" }), n.result.createObjectStore("media", { keyPath: ["jobId", "id"] }).createIndex("jobId", "jobId")), n.result.objectStoreNames.contains("postJobs") || n.result.createObjectStore("postJobs", { keyPath: "id" });
      for (const a of ["jobs", "postJobs"]) {
        const r = n.transaction.objectStore(a);
        r.indexNames.contains("status") || r.createIndex("status", "status"), r.indexNames.contains("archiveState") || r.createIndex("archiveState", "archive.state");
      }
      n.result.objectStoreNames.contains("settings") || n.result.createObjectStore("settings");
    }, n.onsuccess = () => t(n.result), n.onerror = () => {
      Ct = void 0, e(n.error);
    };
  })), Ct;
}
function it(t) {
  return new Promise((e, n) => {
    t.onsuccess = () => e(t.result), t.onerror = () => n(t.error);
  });
}
function lt(t) {
  return new Promise((e, n) => {
    t.oncomplete = () => e(), t.onerror = t.onabort = () => n(t.error || new Error("Database transaction aborted"));
  });
}
async function ce(t, e, n = []) {
  const a = (await Y()).transaction(t).objectStore(t);
  return e ? (await Promise.all(n.map((r) => it(a.index(e).getAll(r))))).flat() : it(a.getAll());
}
async function W(t) {
  return ce("jobs", t ? "status" : void 0, t);
}
async function Ze(t) {
  return it((await Y()).transaction("jobs").objectStore("jobs").get(t));
}
async function N(t) {
  return it((await Y()).transaction("media").objectStore("media").index("jobId").getAll(t));
}
async function R(t) {
  const e = (await Y()).transaction("jobs", "readwrite"), n = lt(e);
  e.objectStore("jobs").put(t), await n;
}
async function z(t) {
  const e = (await Y()).transaction("media", "readwrite"), n = lt(e);
  e.objectStore("media").put(t), await n;
}
async function dt(t) {
  return ce("postJobs", t ? "status" : void 0, t);
}
async function ha() {
  return ce("postJobs", "archiveState", ["saving"]);
}
async function We() {
  return await it((await Y()).transaction("settings").objectStore("settings").get("cache-maintenance")) || { retentionMinutes: 5, lastCheckAt: 0, removedCaches: 0 };
}
async function Ye(t) {
  const e = (await Y()).transaction("settings", "readwrite"), n = lt(e);
  e.objectStore("settings").put(t, "cache-maintenance"), await n;
}
async function wa(t) {
  return it((await Y()).transaction("postJobs").objectStore("postJobs").get(t));
}
async function D(t) {
  t.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const e = (await Y()).transaction("postJobs", "readwrite"), n = lt(e);
  e.objectStore("postJobs").put(t), await n;
}
async function ma(t) {
  const e = t === void 0 ? ["jobs", "media", "postJobs", "settings"] : ["jobs", "media", "postJobs"], n = (await Y()).transaction(e, "readwrite"), a = lt(n);
  if (t === void 0)
    for (const r of e) n.objectStore(r).clear();
  else {
    n.objectStore("jobs").delete(t), n.objectStore("postJobs").delete(t);
    const r = n.objectStore("media"), s = r.index("jobId").openKeyCursor(IDBKeyRange.only(t));
    s.onsuccess = () => {
      const i = s.result;
      i && (r.delete(i.primaryKey), i.continue());
    };
  }
  await a;
}
async function at(t, e) {
  const n = (await Y()).transaction(["jobs", "media"], "readwrite"), a = lt(n);
  n.objectStore("jobs").put(t);
  const r = n.objectStore("media"), s = r.index("jobId").openKeyCursor(IDBKeyRange.only(t.id));
  s.onsuccess = () => {
    const i = s.result;
    if (i)
      r.delete(i.primaryKey), i.continue();
    else for (const o of e) r.put(o);
  }, await a;
}
function te(t, e) {
  return {
    discovered: e.length,
    downloaded: e.filter((n) => n.status === "downloaded").length,
    staged: e.filter((n) => n.status === "staged").length,
    failed: e.filter((n) => n.status === "failed").length,
    skipped: e.filter((n) => n.status === "skipped").length,
    queued: e.filter((n) => n.status === "queued" || n.status === "transferring").length,
    pages: t.channels.reduce((n, a) => n + a.pages, 0),
    messages: t.channels.reduce((n, a) => n + a.messageIds.length, 0),
    incomplete: t.scope === "server" && t.channelDiscovery === "dom" || t.channels.some((n) => n.coverage !== "complete") || e.some((n) => ["failed", "skipped", "queued", "transferring", "staged"].includes(n.status) || n.mediaType === "unknown" || !n.messageId || !(n.thumbnailUrl || n.originalUrl || n.discordCdnUrl)) || t.status === "cancelled"
  };
}
function ht(t, e, n) {
  const a = n ? e.filter((s) => s.channelId === n) : e, r = n ? { ...t, channels: t.channels.filter((s) => s.channelId === n) } : t;
  return JSON.stringify({
    schemaVersion: 1,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    job: { ...r, archive: r.archive ? { ...r.archive, blobUrl: void 0 } : void 0, manifestDownloads: r.manifestDownloads.map(({ blobUrl: s, ...i }) => i) },
    totals: te(r, a),
    coverageNote: "Complete means every requested API page reached a validated empty array. DOM coverage is limited to observed messages. Indexed links are not a claim that every image is available.",
    timestampPolicy: "Timezone-less archive publication times are interpreted as UTC; raw values are retained.",
    media: a.map(({ blobUrl: s, ...i }) => i)
  }, null, 2);
}
const ge = ["serverId", "serverName", "channelId", "channelName", "messageId", "publishedRaw", "publishedAtUtc", "attachmentIndex", "originalFilename", "kemonoPath", "kemonoFileHash", "originalUrl", "discordCdnUrl", "thumbnailUrl", "resolvedUrl", "quality", "sourceType", "status", "savedPath", "sha256", "errorMessage"];
function ga(t) {
  const e = (n) => {
    let a = n == null ? "" : String(n);
    return /^[\s]*[=+\-@\t\r]/.test(a) && (a = "'" + a), '"' + a.replaceAll('"', '""') + '"';
  };
  return "\uFEFF" + [ge.join(","), ...t.map((n) => ge.map((a) => e(n[a])).join(","))].join(`\r
`);
}
function ya(t, e) {
  const n = [t.originalUrl, t.discordCdnUrl].map(Q).filter((i) => !!i).map((i) => ({ url: i, quality: "original" })), a = Q(t.thumbnailUrl), r = a ? [{ url: a, quality: "thumbnail" }] : [], s = e.mode === "original" ? n : e.mode === "best" && e.tryOriginal ? [...n, ...r] : r;
  return s.filter((i, o) => s.findIndex((c) => c.url === i.url) === o);
}
function V(t) {
  return t.destination?.kind === "folder" && t.destination.directoryId || t.id;
}
let ye;
async function Xe() {
  return ye ||= new Promise((t, e) => {
    const n = indexedDB.open("kemono-archive-destinations", 1);
    n.onupgradeneeded = () => n.result.createObjectStore("folders"), n.onsuccess = () => t(n.result), n.onerror = () => {
      ye = void 0, e(n.error);
    };
  });
}
async function ba(t) {
  const e = await Xe();
  return new Promise((n, a) => {
    const r = e.transaction("folders").objectStore("folders").get(t);
    r.onsuccess = () => n(r.result), r.onerror = () => a(r.error);
  });
}
async function be(t) {
  const e = (await Xe()).transaction("folders", "readwrite"), n = new Promise((r, s) => {
    e.oncomplete = () => r(), e.onerror = e.onabort = () => s(e.error);
  }), a = e.objectStore("folders");
  if (t === void 0) a.clear();
  else for (const r of t) a.delete(r);
  await n;
}
class J extends Error {
  constructor() {
    super("Folder access is required. Choose folder, click Allow folder access, then Resume.");
  }
}
async function mt(t) {
  const e = await ba(t);
  try {
    if (!e || await e.queryPermission({ mode: "readwrite" }) !== "granted") throw new J();
  } catch {
    throw new J();
  }
  return e;
}
function ot(t) {
  const e = t.split("/");
  if (!t || e.some((n) => !n || n === "." || n === ".." || /[\\:\x00-\x1f<>"|?*]/.test(n))) throw new Error("Unsafe archive path");
  return e;
}
function va(t) {
  const e = ot(t);
  if (e[0] !== "ArchiveRoot" || e.length < 2) throw new Error("Unsafe archive path");
  return e;
}
async function Ia(t, e, n, a = !1) {
  const r = a ? ot(e) : va(e);
  let s = await mt(t);
  for (const i of r.slice(0, -1)) s = await s.getDirectoryHandle(i, { create: n });
  return { directory: s, name: r.at(-1) };
}
async function Sa(t) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", await t.arrayBuffer()))].map((e) => e.toString(16).padStart(2, "0")).join("");
}
async function Ve(t, e, n, a) {
  try {
    const { directory: r, name: s } = await Ia(t, e, !1), i = await (await r.getFileHandle(s)).getFile();
    return i.size === a && await Sa(i) === n;
  } catch (r) {
    if (r instanceof DOMException && r.name === "NotFoundError") return !1;
    throw r instanceof DOMException && ["NotAllowedError", "SecurityError"].includes(r.name) ? new J() : r;
  }
}
Promise.resolve();
const M = void 0, $ = "undefined", It = "function", ee = "string", Je = new Uint8Array(), Aa = "Invalid option (must be a function)";
function Ua(t) {
  if (t && typeof t != It)
    throw new Error(Aa);
  return t;
}
function xa(t) {
  return typeof t == ee && t.trim() ? Number(t) : t;
}
const Ea = 256 * 1024, Ra = 1, Ca = "Invalid maxWorkers (must be an integer greater than 0)", ka = "Invalid baseURI (must be a string)", Pa = "Invalid URI (must be a string or a function returning a string)";
let Ge = 2;
try {
  typeof navigator != $ && navigator.hardwareConcurrency && (Ge = navigator.hardwareConcurrency);
} catch {
}
const Ke = {
  workerURI: "./core/web-worker-wasm.js",
  wasmURI: "./core/streams/zlib-wasm/zlib-streams.wasm",
  chunkSize: Ea,
  maxWorkers: Ge,
  terminateWorkerTimeout: 5e3,
  workerStarvationTimeout: 5e3,
  workerStartupTimeout: 5e3,
  useWebWorkers: !0,
  useCompressionStream: !0,
  CompressionStream: typeof CompressionStream != $ && CompressionStream,
  DecompressionStream: typeof DecompressionStream != $ && DecompressionStream
}, je = "maxWorkers", Qe = "baseURI", _e = [
  "wasmURI",
  "workerURI"
], Ta = [
  "useCompressionStream",
  "useWebWorkers"
], $e = [
  "chunkSize",
  je,
  "terminateWorkerTimeout",
  "workerStarvationTimeout",
  "workerStartupTimeout"
], tn = [
  "createWorker",
  "CompressionStream",
  "DecompressionStream",
  "CompressionStreamFallback",
  "DecompressionStreamFallback"
], Da = [
  Qe,
  ..._e,
  ...Ta,
  ...$e,
  ...tn
], Na = { ...Ke };
function Oa(t) {
  const e = {};
  for (const n of Da) {
    const a = t[n];
    a !== M && (e[n] = La(n, a));
  }
  return e;
}
function La(t, e) {
  if ($e.includes(t)) {
    if (e = xa(e), t == je && (!Number.isInteger(e) || e < Ra))
      throw new Error(Ca);
  } else if (tn.includes(t))
    Ua(e);
  else if (t == Qe) {
    if (e && typeof e != ee)
      throw new Error(ka);
  } else if (_e.includes(t) && e && typeof e != ee && typeof e != It)
    throw new Error(Pa);
  return e;
}
function za(t) {
  t = t || {};
  const { CompressionStreamZlib: e, DecompressionStreamZlib: n } = t;
  if (e === M && n === M)
    return t;
  const a = Object.assign({}, t);
  return a.CompressionStreamFallback === M && (a.CompressionStreamFallback = e), a.DecompressionStreamFallback === M && (a.DecompressionStreamFallback = n), a;
}
function Yt(t) {
  const e = Oa(za(t));
  Object.assign(Ke, e), Object.assign(Na, e);
}
const kt = new Uint8Array(288);
kt.fill(8, 0, 144), kt.fill(9, 144, 256), kt.fill(7, 256, 280), kt.fill(8, 280, 288), new Uint8Array(30).fill(5);
const G = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Ma = (t) => t({ workerURI: (e) => {
  const n = "text/javascript";
  let a = `!function(t){"function"==typeof define&&define.amd?define(t):t()}(function(){"use strict";const{Array:t,Object:n,Number:e,Math:o,Error:r,Uint8Array:c,Uint16Array:s,Uint32Array:a,Int32Array:i,Map:f,DataView:u,Promise:w,TextEncoder:l,crypto:d,postMessage:p,TransformStream:h,ReadableStream:y,WritableStream:m,CompressionStream:S,DecompressionStream:g}=self,v=void 0,b="undefined",k="function",z=new c,C=[[],[],[],[],[],[],[],[]];for(let t=0;t<256;t++){let n=t;for(let t=0;t<8;t++)n=1&n?n>>>1^3988292384:n>>>1;C[0][t]=n}for(let t=0;t<256;t++)for(let n=1;n<8;n++){const e=C[n-1][t];C[n][t]=e>>>8^C[0][255&e]}const[I,M,A,E,R,x,P,D]=C;class F{constructor(t){this.o=t||-1}append(t){let n=0|this.o;const e=0|t.length;let o=0;if(e>=8&&t.buffer){const r=new u(t.buffer,t.byteOffset,e),c=e-8;for(;o<=c;o+=8){const t=n^r.getInt32(o,!0),e=r.getInt32(o+4,!0);n=D[255&t]^P[t>>>8&255]^x[t>>>16&255]^R[t>>>24&255]^E[255&e]^A[e>>>8&255]^M[e>>>16&255]^I[e>>>24&255]}}for(;o<e;o++)n=n>>>8^I[255&(n^t[o])];this.o=n}get(){return~this.o}}class U extends h{constructor(){let t;const n=new F;super({transform(t,e){n.append(t),e.enqueue(t)},flush(){const e=new c(4);new u(e.buffer).setUint32(0,n.get()),t.value=e}}),t=this}}function B(t,n){const e=new c(t.length+n.length);return e.set(t),e.set(n,t.length),e}function W(t){return new u(t.buffer,t.byteOffset,t.byteLength)}const O=64,V=20,K=new c([128]),T=new c(1),_=new i([1732584193,4023233417,2562383102,271733878,3285377520]),j=new c(256),H=new i(256),L=new i(256),Z=new i(256),N=new i(256);let q=!1;function G(t,n){!function(){if(!q){let t=1,n=1;do{t=255&(t^t<<1^(128&t?27:0)),n=255&(n^n<<1),n=255&(n^n<<2),n=255&(n^n<<4),128&n&&(n^=9),j[t]=255&(n^(n<<1|n>>7)^(n<<2|n>>6)^(n<<3|n>>5)^(n<<4|n>>4)^99)}while(1!=t);j[0]=99;for(let t=0;t<256;t++){const n=j[t],e=Y(n),o=e<<24|n<<16|n<<8|e^n;H[t]=o,L[t]=o>>>8|o<<24,Z[t]=o>>>16|o<<16,N[t]=o>>>24|o<<8}q=!0}}();const e=new i(60),o=function(t,n){const e=t.length>>2,o=e+6,r=4*(o+1);let c=1;for(let o=0;o<e;o++)n[o]=t[4*o]<<24|t[4*o+1]<<16|t[4*o+2]<<8|t[4*o+3];for(let t=e;t<r;t++){let o=n[t-1];t%e==0?(o=Q(o<<8|o>>>24)^c<<24,c=Y(c)):e>6&&t%e==4&&(o=Q(o)),n[t]=n[t-e]^o}return o}(t,e),r=new i(4),c=J(n);let s=0,a=0,f=0,w=0;return{process(t,n){n&&c.update(t,0,t.length),function(t){const n=new u(t.buffer,t.byteOffset,t.byteLength),e=t.length;let o=0;for(;o+16<=e;o+=16)l(),n.setInt32(o,n.getInt32(o)^r[0]),n.setInt32(o+4,n.getInt32(o+4)^r[1]),n.setInt32(o+8,n.getInt32(o+8)^r[2]),n.setInt32(o+12,n.getInt32(o+12)^r[3]);if(o<e){l();for(let n=0;o<e;o++,n++)t[o]^=r[n>>2]>>>24-8*(3&n)}}(t),n||c.update(t,0,t.length)},digest:()=>c.digest()};function l(){s=s+1|0,s||(a=a+1|0,a||(f=f+1|0,f||(w=w+1|0)));let t=X(s)^e[0],n=X(a)^e[1],c=X(f)^e[2],i=X(w)^e[3],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[4],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[5],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[6],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[7];t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[8],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[9],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[10],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[11],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[12],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[13],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[14],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[15],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[16],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[17],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[18],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[19],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[20],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[21],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[22],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[23],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[24],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[25],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[26],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[27],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[28],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[29],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[30],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[31],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[32],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[33],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[34],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[35],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[36],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[37],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[38],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[39];let h=40;o>10&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[40],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[41],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[42],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[43],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[44],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[45],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[46],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[47],h=48),o>12&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[48],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[49],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[50],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[51],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[52],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[53],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[54],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[55],h=56),r[0]=(j[u>>>24]<<24|j[l>>>16&255]<<16|j[d>>>8&255]<<8|j[255&p])^e[h],r[1]=(j[l>>>24]<<24|j[d>>>16&255]<<16|j[p>>>8&255]<<8|j[255&u])^e[h+1],r[2]=(j[d>>>24]<<24|j[p>>>16&255]<<16|j[u>>>8&255]<<8|j[255&l])^e[h+2],r[3]=(j[p>>>24]<<24|j[u>>>16&255]<<16|j[l>>>8&255]<<8|j[255&d])^e[h+3]}}function J(t){const n=function(){const t=new i(_),n=new i(16),e=new c(O),r=new u(e.buffer),s=new c(8);let a=0,f=0;return{update:w,digest:function(){const n=8*f,e=o.floor(n/4294967296),r=n>>>0;for(w(K,0,1);56!=a;)w(T,0,1);s[0]=e>>>24,s[1]=e>>>16,s[2]=e>>>8,s[3]=e,s[4]=r>>>24,s[5]=r>>>16,s[6]=r>>>8,s[7]=r,w(s,0,8);const i=new c(V),l=new u(i.buffer);for(let n=0;n<t.length;n++)l.setInt32(4*n,t[n]);return t.set(_),a=0,f=0,i}};function w(t,n,o){const c=n+o;if(f+=o,a){for(;n<c&&a<O;)e[a++]=t[n++];a==O&&(l(r,0),a=0)}if(n+O<=c){const e=new u(t.buffer,t.byteOffset,t.byteLength);for(;n+O<=c;n+=O)l(e,n)}for(;n<c;)e[a++]=t[n++]}function l(e,o){for(let t=0;t<16;t++)n[t]=e.getInt32(o+4*t);let r,c=t[0],s=t[1],a=t[2],i=t[3],f=t[4];for(let t=0;t<15;t+=5)f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[t]|0,s=s<<30|s>>>2,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+n[t+1]|0,c=c<<30|c>>>2,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+n[t+2]|0,f=f<<30|f>>>2,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+n[t+3]|0,i=i<<30|i>>>2,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+n[t+4]|0,a=a<<30|a>>>2;f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[15]|0,s=s<<30|s>>>2,r=n[13]^n[8]^n[2]^n[0],r=r<<1|r>>>31,n[0]=r,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+r|0,c=c<<30|c>>>2,r=n[14]^n[9]^n[3]^n[1],r=r<<1|r>>>31,n[1]=r,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+r|0,f=f<<30|f>>>2,r=n[15]^n[10]^n[4]^n[2],r=r<<1|r>>>31,n[2]=r,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+r|0,i=i<<30|i>>>2,r=n[0]^n[11]^n[5]^n[3],r=r<<1|r>>>31,n[3]=r,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+r|0,a=a<<30|a>>>2;for(let t=20;t<40;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+1859775393+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+1859775393+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+1859775393+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+1859775393+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+1859775393+r|0,a=a<<30|a>>>2;for(let t=40;t<60;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s&a|(s|a)&i)+f+2400959708+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c&s|(c|s)&a)+i+2400959708+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f&c|(f|c)&s)+a+2400959708+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i&f|(i|f)&c)+s+2400959708+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a&i|(a|i)&f)+c+2400959708+r|0,a=a<<30|a>>>2;for(let t=60;t<80;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+3395469782+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+3395469782+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+3395469782+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+3395469782+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+3395469782+r|0,a=a<<30|a>>>2;t[0]=t[0]+c|0,t[1]=t[1]+s|0,t[2]=t[2]+a|0,t[3]=t[3]+i|0,t[4]=t[4]+f|0}}(),e=new c(O),r=new c(O);t.length>O&&(n.update(t,0,t.length),t=n.digest());for(let n=0;n<O;n++){const o=n<t.length?t[n]:0;e[n]=54^o,r[n]=92^o}return n.update(e,0,O),{update(t,e,o){n.update(t,e,o)},digest(){const t=n.digest();n.update(r,0,O),n.update(t,0,V);const o=n.digest();return n.update(e,0,O),o}}}function Q(t){return j[t>>>24]<<24|j[t>>>16&255]<<16|j[t>>>8&255]<<8|j[255&t]}function X(t){return t<<24|(65280&t)<<8|t>>>8&65280|t>>>24}function Y(t){return 255&(t<<1^27*(t>>7))}const $=typeof d!=b&&typeof d.getRandomValues==k,tt="Invalid password",nt="zipjs-abort-check-password";function et(t){if($)return d.getRandomValues(t);throw new r("Crypto API not supported")}const ot={name:"PBKDF2"},rt=n.assign({hash:{name:"HMAC"}},ot),ct=n.assign({iterations:1e3,hash:{name:"SHA-1"}},ot),st=["deriveBits"],at=[8,12,16],it=[16,24,32],ft=10,ut=typeof d!=b,wt=ut&&d.subtle;let lt=ut&&typeof wt!=b&&typeof wt.importKey==k&&typeof wt.deriveBits==k,dt=G;class pt extends h{constructor({password:t,rawPassword:n,encryptionStrength:e,checkPasswordOnly:o,checkAuthenticationCode:s=!0}){const a={};super({start(){yt(a,t,n,e)},async transform(t,n){const{password:e,strength:s,l:i,ready:f}=a;if(e?(await async function(t,n,e,o){const c=await vt(t,n,e,kt(o,0,at[n])),s=kt(o,at[n]);if(c[0]!=s[0]||c[1]!=s[1])throw gt(t),new r(tt)}(a,s,e,kt(t,0,at[s]+2)),t=kt(t,at[s]+2),o?(gt(a),n.error(new r(nt))):i()):await f,a.h)return;const u=new c(t.length-ft-(t.length-ft)%16);n.enqueue(St(a,t,u,0,ft,!0))},async flush(t){const{m:n,S:e,ready:o}=a;if(n){if(await o,a.h)return;const i=kt(e,e.length-ft),f=new c(kt(e,0,e.length-ft));n.process(f,!0);const u=n.digest();let w=e.length<ft?1:0;for(let t=0;t<ft;t++)w|=u[t]^i[t];if(w&&s)return void t.error(new r("Invalid authentication code"));t.enqueue(f)}}}),mt(this,a)}}class ht extends h{constructor({password:t,rawPassword:n,encryptionStrength:e}){const o={};super({start(){yt(o,t,n,e)},async transform(t,n){const{password:e,strength:r,l:s,ready:a}=o;let i=z;if(e?(i=await async function(t,n,e){const o=et(new c(at[n]));return B(o,await vt(t,n,e,o))}(o,r,e),s()):await a,o.h)return;const f=new c(i.length+t.length-t.length%16);f.set(i,0),n.enqueue(St(o,t,f,i.length,0,!1))},async flush(t){const{m:n,S:e,ready:r}=o;if(n){if(await r,o.h)return;const s=new c(e);n.process(s,!1);const a=kt(n.digest(),0,ft);t.enqueue(B(s,a))}}}),mt(this,o)}}function yt(t,e,o,r){n.assign(t,{ready:new w(n=>t.l=n),password:bt(e,o),strength:r-1,S:z,h:!1})}function mt(t,e){const o=t.readable.getReader(),r=new y({async pull(t){try{const{value:n,done:e}=await o.read();e?t.close():t.enqueue(n)}catch(t){throw gt(e),o.cancel(t).catch(()=>{}),t}},cancel:t=>(gt(e),o.cancel(t))});n.defineProperty(t,"readable",{get:()=>r})}function St(t,n,e,o,r,s){const{m:a,S:i}=t;i.length&&(n=B(i,n));const f=n.length-r,u=f-f%16;if(e=function(t,n){if(n&&n>t.length){const e=t;(t=new c(n)).set(e,0)}return t}(e,o+u),u){const t=kt(e,o,o+u);t.set(kt(n,0,u)),a.process(t,s)}return t.S=kt(n,u),e}function gt(t){const{m:n}=t;t.h=!0,n&&n.dispose&&n.dispose()}async function vt(t,e,r,s){t.password=null;const a=it[e],i=await async function(t,e,r){if(lt)try{const o=await wt.importKey("raw",t,rt,!1,st);return new c(await wt.deriveBits(n.assign({salt:e},ct),o,8*r))}catch{lt=!1}return function(t,n,e,r){const s=J(t),a=new c(r),i=new c(n.length+4),f=new u(i.buffer);i.set(n);for(let t=1,e=0;e<r;t++,e+=V){f.setUint32(n.length,t),s.update(i,0,i.length);let c=s.digest();const u=c.slice();for(let t=1;t<1e3;t++){s.update(c,0,V),c=s.digest();for(let t=0;t<V;t++)u[t]^=c[t]}a.set(u.subarray(0,o.min(V,r-e)),e)}return a}(t,e,0,r)}(r,s,2*a+2);return t.m=dt(kt(i,0,a),kt(i,a,2*a)),t.h&&gt(t),kt(i,2*a)}function bt(t,n){return n===v?function(t){if(typeof l==b){t=unescape(encodeURIComponent(t));const n=new c(t.length);for(let e=0;e<n.length;e++)n[e]=t.charCodeAt(e);return n}return(new l).encode(t)}(t):n}function kt(t,n,e){return t.subarray(n,e)}class zt extends h{constructor({password:t,rawPassword:n,passwordVerification:e,checkPasswordOnly:o}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;if(e.password||e.rawPassword){const n=Mt(e,t.subarray(0,12));if(e.password=e.rawPassword=null,0!=(n[11]^e.passwordVerification))throw new r(tt);t=t.subarray(12)}o?n.error(new r(nt)):n.enqueue(Mt(e,t))}})}}class Ct extends h{constructor({password:t,rawPassword:n,passwordVerification:e}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;let o,r;if(e.password||e.rawPassword){e.password=e.rawPassword=null;const n=et(new c(12));n[11]=e.passwordVerification,o=new c(t.length+n.length),o.set(At(e,n),0),r=12}else o=new c(t.length),r=0;o.set(At(e,t),r),n.enqueue(o)}})}}function It(t,e,o,r){n.assign(t,{password:e,rawPassword:o,passwordVerification:r}),function(t,e,o){const r=[305419896,591751049,878082192];if(n.assign(t,{v:r,C:new F(r[0]),I:new F(r[2])}),o)for(let n=0;n<o.length;n++)Et(t,o[n]);else for(let n=0;n<e.length;n++)Et(t,e.charCodeAt(n))}(t,e,o)}function Mt(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,e[o]);return e}function At(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,n[o]);return e}function Et(t,n){let[,e]=t.v;t.C.append([n]);const r=~t.C.get();e=Pt(o.imul(Pt(e+xt(r)),134775813)+1),t.I.append([e>>>24]);const c=~t.I.get();t.v=[r,e,c]}function Rt(t){const n=2|t.v[2];return xt(o.imul(n,1^n)>>>8)}function xt(t){return 255&t}function Pt(t){return 4294967295&t}function Dt(t){return Boolean(t)&&"object"==typeof t}const Ft=new f;function Ut(t){return Ft.get(t)}const Bt="Invalid uncompressed size",Wt="Codec out of memory",Ot="Invalid CRC32",Vt="deflate-raw",Kt="gzip",Tt=[31,139,8];class _t extends h{constructor(t,{chunkSize:n,CompressionStreamFallback:e,CompressionStream:o}){super({});const{compressed:r,encrypted:c,useCompressionStream:s,zipCrypto:a,computeCrc32:i,level:f,deflate64:w,format:l,compressionMethod:d,inputSize:p}=t,h=this;let y,m,S,g=super.readable;const v=l&&Ut(l),b=qt(s,o,e),k=i&&r&&!w&&!v&&(!c||a)&&Boolean(b);if(c&&!a||!i||k||(y=new U,g=Jt(g,y)),r)if(v)g=Qt(g,Nt(v.CompressionStream,l,{level:f,chunkSize:n,compressionMethod:d,uncompressedSize:p}));else if(k)S=new jt,g=Qt(g,new b(Kt,{level:f,chunkSize:n})),g=Jt(g,S);else try{g=Gt(g,s,{level:f,chunkSize:n},o,e)}catch(t){if(!s&&e)throw nn(t);let n;try{n=new o(Kt)}catch{throw nn(t)}g=Qt(g,n),g=Jt(g,new jt)}c&&(a?g=Jt(g,new Ct(t)):(m=new ht(t),g=Jt(g,m))),Zt(h,g,()=>{c&&!a||!i||(h.crc32=k?S.crc32:new u(y.value.buffer).getUint32(0))})}}class jt extends h{constructor(){let t,n=10,e=new c(0);super({transform(t,r){if(n){const e=o.min(n,t.length);if(n-=e,!(t=t.subarray(e)).length)return}const c=e.length+t.length;if(c<=8)return void(e=B(e,t));const s=c-8,a=o.min(s,e.length);r.enqueue(B(e.subarray(0,a),t.subarray(0,s-a))),e=B(e.subarray(a),t.subarray(s-a))},flush(){const n=W(e);t.crc32=n.getUint32(0,!0),t.uncompressedSize=n.getUint32(4,!0)}}),t=this}}class Ht extends h{constructor(t,{chunkSize:n,DecompressionStreamFallback:e,DecompressionStream:o}){super({});const{zipCrypto:s,encrypted:a,checkCrc32:i,crc32:f,compressed:l,useCompressionStream:d,deflate64:p,format:h,compressionMethod:m,rawBitFlag:S,outputSize:g}=t;let b,k,z,C=super.readable;if(a&&(s?C=Jt(C,new zt(t)):(k=new pt(t),C=Jt(C,k))),l){const t=new Set,s=h&&Ut(h);let a;if(s)C=Qt(C,Nt(s.DecompressionStream,h,{chunkSize:n,compressionMethod:m,rawBitFlag:S,uncompressedSize:g}),t);else{const r=qt(d,o,e);if(i&&!p&&f!==v&&g!==v&&r)try{a=new r(Kt,{chunkSize:n})}catch{a=v}if(!a)try{C=Gt(C,d,{chunkSize:n,deflate64:p},o,e,t)}catch(t){if(p||g===v||!d&&e)throw nn(t);try{a=new o(Kt)}catch{throw nn(t)}}}a?(z=!0,C=function(t,n,e,o,s){const a=n.writable.getWriter(),i=n.readable.getReader(),f=o===v?new F:v;let u,l,d=0,p=!1,h=!1;const m=new y({start(t){l=t},pull(){b()},cancel:t=>(h=!0,b(),i.cancel(t))});return async function(){const n=t.getReader();try{const t=new c(10);for(t.set(Tt),await a.write(t);;){await g(),await a.ready;const{value:t,done:e}=await $t(n,s);if(e)break;await a.write(t)}f&&await a.write(new c(0));const r=new c(8),i=W(r);i.setUint32(0,f?f.get():o,!0),i.setUint32(4,e,!0),p=!0,await a.write(r),await a.close()}catch(t){await Xt(a,t),await Yt(n,t)}}(),async function(){try{for(;;){const{value:t,done:n}=await S();if(n)break;if(d+=t.length,d>e)throw new r(Bt);f&&f.append(t),l.enqueue(t)}h||(h=!0,l.close())}catch(t){!function(t){h||(h=!0,l.error(t),b())}(t),await Yt(i,t)}}(),m;function S(){return i.read().catch(t=>{if(p){if(!f)throw on(t,Ot);if(d!=e)throw on(t,Bt);return{done:!0}}throw tn(t,s)})}function g(){if(!h&&l.desiredSize<=0)return new w(t=>u=t)}function b(){if(u){const t=u;u=v,t()}}}(C,a,g,f,t)):C=function(t,n){const e=t.getReader();return new y({async pull(t){try{const{value:n,done:o}=await e.read();o?t.close():t.enqueue(n)}catch(t){throw await Yt(e,t),tn(t,n)}},cancel:t=>e.cancel(t)})}(C,t)}i&&!z&&(b=new U,C=Jt(C,b)),Zt(this,C,()=>{if(b){const t=new u(b.value.buffer).getUint32(0,!1);if(f!=t)throw new r(Ot)}})}}const Lt=new f;function Zt(t,e,o){e=Jt(e,new h({flush:o})),n.defineProperty(t,"readable",{get:()=>e})}function Nt(t,n,e){if(!t)throw new r("Compression method not supported");return new t(n,e)}function qt(t,n,e){return t&&n?n:e&&e.requiresModule?e:void 0}function Gt(t,n,e,o,r,c){const s=n&&o?o:r||o,a=e.deflate64?"deflate64-raw":Vt;let i;try{i=new s(a,e)}catch(t){if(!n||!r||s==r)throw t;i=new r(a,e)}return Qt(t,i,c)}function Jt(t,n){return function(t){if(t instanceof y)return t;const n=t.getReader();return new y({async pull(t){try{const{value:e,done:o}=await n.read();o?t.close():t.enqueue(e)}catch(t){throw n.cancel(t).catch(()=>{}),t}},cancel:t=>n.cancel(t)})}(t).pipeThrough(n)}function Qt(t,n,e){const o=n.writable.getWriter(),r=t.getReader();return async function(){try{for(;;){await o.ready;const t=await $t(r,e);if(t.done){await o.close();break}await o.write(t.value)}}catch(t){await Xt(o,t),await Yt(r,t)}}(),n.readable}async function Xt(t,n){try{await t.abort(n)}catch{}}async function Yt(t,n){try{await t.cancel(n)}catch{}}function $t(t,n){const e=t.read();return n?e.catch(t=>{throw n.add(t),t}):e}function tn(t,n){return n.has(t)?t:on(t,en(t)?Wt:"Invalid compressed data")}function nn(t){return en(t)?on(t,Wt):t}function en(t){return Dt(t)&&"Z_MEM_ERROR"==t.code}function on(t,n){const e=new r(n);return e.cause=t,e}const rn="data",cn="deflate";class sn extends h{constructor(t,e){super({});const o=this,{codecType:c}=t;let s;c.startsWith(cn)?s=_t:c.startsWith("inflate")&&(s=Ht),o.outputSize=0;let a=0;const i=new s(t,e),f=super.readable,u=new h({transform(t,n){t&&t.length&&(a+=t.length,n.enqueue(t))},flush(){n.assign(o,{inputSize:a})}}),w=new h({transform(n,e){if(n&&n.length&&(e.enqueue(n),o.outputSize+=n.length,t.outputSize!==v&&o.outputSize>t.outputSize))throw new r(Bt)},flush(){const{crc32:t}=i;n.assign(o,{crc32:t,inputSize:a})}});n.defineProperty(o,"readable",{get:()=>f.pipeThrough(u).pipeThrough(i).pipeThrough(w)})}}class an extends h{constructor(t){const o=[];let r=0,s=0;function a(){const n=new c(t);let e=0;for(;e<t;){const r=o[0],c=t-e;r.length<=c?(n.set(r,e),e+=r.length,o.shift()):(n.set(r.subarray(0,c),e),o[0]=r.subarray(c),e+=c)}return r-=t,n}(!e.isFinite(t)||t<1)&&(t=262144),super({transform(n,e){for(o.push(n),r+=n.length;r>t;)s+=t,e.enqueue(a())},flush(t){r&&(s+=r,t.enqueue(function(t,n){const e=new c(n);let o=0;for(const n of t)e.set(n,o),o+=n.length;return e}(o,r)))}}),n.defineProperty(this,"outputSize",{get:()=>s})}}let fn=2;try{typeof navigator!=b&&navigator.hardwareConcurrency&&(fn=navigator.hardwareConcurrency)}catch{}const un=new f,wn=new f,ln=function(){try{return structuredClone(new r)instanceof r}catch{return!1}}();let dn=0;async function pn(t){let n,c,s;try{const{options:a,config:i}=t;if(a.format)try{await async function(t,n){!Ft.has(t)&&n&&function(t,n){const{CompressionStream:e,DecompressionStream:o}=n;if(typeof e!=k&&typeof o!=k)throw new r("Invalid codec module");Ft.set(t,{CompressionStream:e,DecompressionStream:o})}(t,await(import(n)))}(a.format,a.codecURI)}catch(t){if(Dt(t))try{t.codecImportFailed=!0}catch{}throw t}if(i.CompressionStream=self.CompressionStream,i.DecompressionStream=self.DecompressionStream,a.compressed&&!a.format)if(a.useCompressionStream){if(!function(t,n){if(!t)return!1;let e=Lt.get(t);e||(e=new f,Lt.set(t,e));let o=e.get(n);if(o===v){try{new t(n),o=!0}catch{o=!1}e.set(n,o)}return o}(a.codecType.startsWith(cn)?i.CompressionStream:i.DecompressionStream,Vt))try{await self.initModule(t.config)}catch{}}else try{await self.initModule(t.config)}catch{a.useCompressionStream=!0}if(a.encrypted&&!a.zipCrypto)try{await self.initModule(t.config)}catch{}!i.CompressionStreamFallback&&i.CompressionStreamZlib&&(i.CompressionStreamFallback=i.CompressionStreamZlib),!i.DecompressionStreamFallback&&i.DecompressionStreamZlib&&(i.DecompressionStreamFallback=i.DecompressionStreamZlib);const u={highWaterMark:1},l=new y({async pull(t){const n=new w(t=>un.set(dn,t));hn({type:"pull",messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER;const{value:o,done:r}=await n;t.enqueue(o),r&&t.close()}},u);s=new m({async write(t){let n;const o=new w(t=>n=t);wn.set(dn,n),hn({type:rn,value:t,messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER,await o}},u),n=new sn(a,i),c=new an(function(t){return r="string"==typeof(n=r=t.chunkSize)&&n.trim()?e(n):n,e.isInteger(r)&&r>=1?o.max(r,64):262144;var n,r}(i)),await l.pipeThrough(n).pipeThrough(c).pipeTo(s,{preventClose:!0,preventAbort:!0}),await s.getWriter().close();const{crc32:d,inputSize:p,outputSize:h}=n;hn({type:"close",result:{crc32:d,inputSize:p,outputSize:h}})}catch(t){const n=c?c.outputSize:0;if(Dt(t))try{t.outputSize=n}catch{}if(s&&!s.locked)try{await s.getWriter().close()}catch{}yn(t,n)}}function hn(t){const{value:n}=t;if(n)if(n.length)try{t.value=(e=n,e.byteOffset||e.byteLength!=e.buffer.byteLength?new c(e):e).buffer,p(t,[t.value])}catch{p(t)}else p(t);else p(t);var e}function yn(t,n){const{message:e,stack:o,code:c,name:s,outputSize:a,cause:i,codecImportFailed:f}=function(t=new r("Unknown error")){return Dt(t)?t:new r(String(t))}(t),u={message:e,stack:o,code:c,name:s,outputSize:a===v?n:a};if(Dt(i)&&(u.cause={name:i.name,message:i.message,code:i.code}),f&&(u.codecImportFailed=!0),ln)try{return void p({error:u,errorValue:{value:t}})}catch{}p({error:u})}addEventListener("message",({data:t})=>{const{type:n,messageId:e,value:o,done:r}=t;try{if("start"==n&&pn(t),n==rn){const t=un.get(e);un.delete(e),t({value:o||new c,done:r})}if("ack"==n){const t=wn.get(e);wn.delete(e),t()}}catch(t){yn(t)}}),p({type:"ready"});const mn="deflate",Sn="deflate-raw",gn="deflate64-raw",vn="gzip",bn=[mn,Sn,vn],kn=[mn,Sn,vn,gn];let zn,Cn,In,Mn,An;function En(t,n){return-4===n&&(t.code="Z_MEM_ERROR"),t}function Rn(t,n,e={}){if(!(t?bn:kn).includes(n))throw new TypeError("Unsupported format: "+n);if(!zn){const t=new r("WASM module not loaded");throw t.cause=An,t}const s="number"==typeof e.level?e.level:-1,a="number"==typeof e.outBuffer?e.outBuffer:65536,i="number"==typeof e.inBufferSize?e.inBufferSize:65536,f={M:0,in:0,inBufferSize:0,A:0,R:!1};let u,l,d,p,h=!0,S=!1;return function(){try{let e;if(f.M=Cn(a),f.in=Cn(i),f.inBufferSize=i,!f.M||!f.in)throw En(new r("allocation failed"),-4);if(t?(f.P=zn.deflate_process,f.D=zn.deflate_last_consumed,f.F=zn.deflate_end,f.A=zn.deflate_new(),e=n===vn?zn.deflate_init_gzip(f.A,s):n===Sn?zn.deflate_init_raw(f.A,s):zn.deflate_init(f.A,s)):n===gn?(f.P=zn.inflate9_process,f.D=zn.inflate9_last_consumed,f.F=zn.inflate9_end,f.A=zn.inflate9_new(),e=zn.inflate9_init_raw(f.A)):(f.P=zn.inflate_process,f.D=zn.inflate_last_consumed,f.F=zn.inflate_end,f.A=zn.inflate_new(),e=n===Sn?zn.inflate_init_raw(f.A):n===vn?zn.inflate_init_gzip(f.A):zn.inflate_init(f.A)),0!==e)throw En(new r("init failed:"+e),e)}catch(t){throw b(f),t}}(),{readable:new y({start(t){u=t},pull(){h=!1,v()},cancel(t){S=!0,p=t,b(f),l.error(t),v()}},{highWaterMark:0}),writable:new m({start(t){l=t},async write(t){if(h&&await new w(t=>d=t),S)throw p;try{!function(t){const n=new c(Mn.buffer),e=f.P,s=f.D,i=f.M;let u=0;for(;u<t.length;){if(f.R)throw new r("trailing data after the end of the stream");const c=o.min(t.length-u,32768);if((!f.in||f.inBufferSize<c)&&(f.in&&In&&(In(f.in),f.in=0),f.in=Cn(c),f.inBufferSize=c,!f.in))throw En(new r("allocation failed"),-4);n.set(t.subarray(u,u+c),f.in);const w=e(f.A,f.in,c,i,a,0),l=w>>24&255,d=128&l?l-256:l;if(d<0)throw En(new r("process error:"+d),d);const p=16777215&w;p&&g(n.slice(i,i+p));const h=s(f.A);if(1===l)f.R=!0;else if(0===h&&0===p)break;u+=h}}(t)}catch(t){throw b(f),u.error(t),t}},close(){if(S)return;try{!function(){const t=new c(Mn.buffer),n=f.P,e=f.M;for(;;){const o=n(f.A,0,0,e,a,4),c=o>>24&255,s=128&c?c-256:c;if(s<0)throw En(new r("process error:"+s),s);const i=16777215&o;if(i&&g(t.slice(e,e+i)),1===c||0===i)break}}()}catch(t){throw b(f),u.error(t),t}const t=b(f);if(0!==t){const n=En(new r("end error:"+t),t);throw u.error(n),n}u.close()},abort(t){b(f),u.error(t)}},{highWaterMark:1})};function g(t){h=!0,u.enqueue(t)}function v(){if(d){const t=d;d=null,t()}}function b(t){let n=0;return t.A&&t.F&&(n=t.F(t.A)),t.A=0,t.in&&In&&In(t.in),t.in=0,t.M&&In&&In(t.M),t.M=0,n}}class xn{constructor(t=mn,n){return Rn(!0,t,n)}}class Pn{constructor(t=mn,n){return Rn(!1,t,n)}}xn.requiresModule=!0,Pn.requiresModule=!0,xn.supportedFormats=bn,Pn.supportedFormats=kn;const Dn=65536;let Fn,Un;function Bn(t){return new c(t.memory.buffer)}let Wn=!1;!function(t={}){const{init:n,U:e}=t,o=t.CompressionStreamFallback||t.CompressionStreamZlib,r=t.DecompressionStreamFallback||t.DecompressionStreamZlib;e&&(dt=e||G),self.initModule=async t=>{n&&await n(t),o&&(t.CompressionStreamFallback=o),r&&(t.DecompressionStreamFallback=r)}}({CompressionStreamFallback:xn,DecompressionStreamFallback:Pn,U:function(t,n){const e=Fn;let o=e?function(t,n,e){Un||(Un=t.malloc(Dn));const o=Un?t.aes_hmac_new():0;if(o){const r=Bn(t);if(r.set(n,Un),r.set(e,Un+n.length),t.aes_hmac_init(o,Un,n.length,Un+n.length,e.length))return t.aes_hmac_end(o,0),0}return o}(e,t,n):0;if(!o)return G(t,n);const r=Un;return{process(t,n){for(let c=0;c<t.length;c+=Dn){const s=t.subarray(c,c+Dn),a=Bn(e);a.set(s,r),e.aes_hmac_process(o,r,s.length,n?1:0),s.set(a.subarray(r,r+s.length))}},digest:()=>(e.aes_hmac_end(o,r),o=0,Bn(e).slice(r,r+20)),dispose(){o&&(e.aes_hmac_end(o,0),o=0)}}},init:t=>async function(t,{baseURI:n}){if(!Wn)try{await async function(t,n){let e,o;try{try{o=new URL(t,n)}catch{}const r=await fetch(o);e=await r.arrayBuffer()}catch(n){if(!t.startsWith("data:application/wasm;base64,"))throw n;e=function(t){const n=t.split(",")[1],e=atob(n),o=e.length,r=new c(o);for(let t=0;t<o;++t)r[t]=e.charCodeAt(t);return r.buffer}(t)}const s=await WebAssembly.instantiate(e);var a;(function(t){if(zn=t,({malloc:Cn,free:In,memory:Mn}=zn),"function"!=typeof Cn||"function"!=typeof In||!Mn)throw zn=Cn=In=Mn=null,new r("Invalid WASM module")})(s.instance.exports),typeof(a=s.instance.exports).aes_hmac_new==k&&(Fn=a,Un=0)}(t,n),Wn=!0}catch(t){throw function(t){An=t}(t),t}}(t.wasmURI,t)})});
`;
  if (typeof a == "string" && (a = new TextEncoder().encode(a)), e) {
    const r = new Blob([a], { type: n });
    return URL.createObjectURL(r);
  }
  return "data:" + n + ";base64," + (function(r) {
    let s = "";
    const i = r.length;
    let o = 0;
    for (; o + 2 < i; o += 3) {
      const d = r[o] << 16 | r[o + 1] << 8 | r[o + 2];
      s += G[d >> 18 & 63] + G[d >> 12 & 63] + G[d >> 6 & 63] + G[63 & d];
    }
    const c = i - o;
    if (c === 1) {
      const d = r[o] << 16;
      s += G[d >> 18 & 63] + G[d >> 12 & 63] + "==";
    } else if (c === 2) {
      const d = r[o] << 16 | r[o + 1] << 8;
      s += G[d >> 18 & 63] + G[d >> 12 & 63] + G[d >> 6 & 63] + "=";
    }
    return s;
  })(a);
} });
function rt(t, e) {
  const n = new Uint8Array(t.length + e.length);
  return n.set(t), n.set(e, t.length), n;
}
function en(t) {
  return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
function Ba(t) {
  return !!t && typeof t == "object";
}
const gt = [[], [], [], [], [], [], [], []];
for (let t = 0; t < 256; t++) {
  let e = t;
  for (let n = 0; n < 8; n++)
    e = e & 1 ? e >>> 1 ^ 3988292384 : e >>> 1;
  gt[0][t] = e;
}
for (let t = 0; t < 256; t++)
  for (let e = 1; e < 8; e++) {
    const n = gt[e - 1][t];
    gt[e][t] = n >>> 8 ^ gt[0][n & 255];
  }
const [ve, qa, Fa, Ha, Za, Wa, Ya, Xa] = gt;
class Mt {
  constructor(e) {
    this.crc = e || -1;
  }
  append(e) {
    let n = this.crc | 0;
    const a = e.length | 0;
    let r = 0;
    if (a >= 8 && e.buffer) {
      const s = new DataView(e.buffer, e.byteOffset, a), i = a - 8;
      for (; r <= i; r += 8) {
        const o = n ^ s.getInt32(r, !0), c = s.getInt32(r + 4, !0);
        n = Xa[o & 255] ^ Ya[o >>> 8 & 255] ^ Wa[o >>> 16 & 255] ^ Za[o >>> 24 & 255] ^ Ha[c & 255] ^ Fa[c >>> 8 & 255] ^ qa[c >>> 16 & 255] ^ ve[c >>> 24 & 255];
      }
    }
    for (; r < a; r++)
      n = n >>> 8 ^ ve[(n ^ e[r]) & 255];
    this.crc = n;
  }
  get() {
    return ~this.crc;
  }
}
class nn extends TransformStream {
  constructor() {
    let e;
    const n = new Mt();
    super({
      transform(a, r) {
        n.append(a), r.enqueue(a);
      },
      flush() {
        const a = new Uint8Array(4);
        new DataView(a.buffer).setUint32(0, n.get()), e.value = a;
      }
    }), e = this;
  }
}
function Va(t) {
  if (typeof TextEncoder == $) {
    t = unescape(encodeURIComponent(t));
    const e = new Uint8Array(t.length);
    for (let n = 0; n < e.length; n++)
      e[n] = t.charCodeAt(n);
    return e;
  } else
    return new TextEncoder().encode(t);
}
const Jt = 16, Ja = 60, F = 64, et = 20, Ga = 16, Ka = 56, ja = new Uint8Array([128]), Qa = new Uint8Array(1), Ie = new Int32Array([1732584193, 4023233417, 2562383102, 271733878, 3285377520]), _a = 54, $a = 92, T = new Uint8Array(256), v = new Int32Array(256), I = new Int32Array(256), S = new Int32Array(256), A = new Int32Array(256);
let Se = !1;
function le(t, e) {
  nr();
  const n = new Int32Array(Ja), a = ar(t, n), r = new Int32Array(Jt / 4), s = an(e);
  let i = 0, o = 0, c = 0, d = 0;
  return {
    process(u, f) {
      f && s.update(u, 0, u.length), h(u), f || s.update(u, 0, u.length);
    },
    digest() {
      return s.digest();
    }
  };
  function h(u) {
    const f = new DataView(u.buffer, u.byteOffset, u.byteLength), g = u.length;
    let w = 0;
    for (; w + Jt <= g; w += Jt)
      y(), f.setInt32(w, f.getInt32(w) ^ r[0]), f.setInt32(w + 4, f.getInt32(w + 4) ^ r[1]), f.setInt32(w + 8, f.getInt32(w + 8) ^ r[2]), f.setInt32(w + 12, f.getInt32(w + 12) ^ r[3]);
    if (w < g) {
      y();
      for (let m = 0; w < g; w++, m++)
        u[w] ^= r[m >> 2] >>> 24 - 8 * (m & 3);
    }
  }
  function y() {
    i = i + 1 | 0, i || (o = o + 1 | 0, o || (c = c + 1 | 0, c || (d = d + 1 | 0)));
    let u = Pt(i) ^ n[0], f = Pt(o) ^ n[1], g = Pt(c) ^ n[2], w = Pt(d) ^ n[3], m = v[u >>> 24] ^ I[f >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[w & 255] ^ n[4], l = v[f >>> 24] ^ I[g >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[u & 255] ^ n[5], p = v[g >>> 24] ^ I[w >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[f & 255] ^ n[6], b = v[w >>> 24] ^ I[u >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[g & 255] ^ n[7];
    u = v[m >>> 24] ^ I[l >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[8], f = v[l >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[m & 255] ^ n[9], g = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[l & 255] ^ n[10], w = v[b >>> 24] ^ I[m >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[p & 255] ^ n[11], m = v[u >>> 24] ^ I[f >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[w & 255] ^ n[12], l = v[f >>> 24] ^ I[g >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[u & 255] ^ n[13], p = v[g >>> 24] ^ I[w >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[f & 255] ^ n[14], b = v[w >>> 24] ^ I[u >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[g & 255] ^ n[15], u = v[m >>> 24] ^ I[l >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[16], f = v[l >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[m & 255] ^ n[17], g = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[l & 255] ^ n[18], w = v[b >>> 24] ^ I[m >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[p & 255] ^ n[19], m = v[u >>> 24] ^ I[f >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[w & 255] ^ n[20], l = v[f >>> 24] ^ I[g >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[u & 255] ^ n[21], p = v[g >>> 24] ^ I[w >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[f & 255] ^ n[22], b = v[w >>> 24] ^ I[u >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[g & 255] ^ n[23], u = v[m >>> 24] ^ I[l >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[24], f = v[l >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[m & 255] ^ n[25], g = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[l & 255] ^ n[26], w = v[b >>> 24] ^ I[m >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[p & 255] ^ n[27], m = v[u >>> 24] ^ I[f >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[w & 255] ^ n[28], l = v[f >>> 24] ^ I[g >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[u & 255] ^ n[29], p = v[g >>> 24] ^ I[w >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[f & 255] ^ n[30], b = v[w >>> 24] ^ I[u >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[g & 255] ^ n[31], u = v[m >>> 24] ^ I[l >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[32], f = v[l >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[m & 255] ^ n[33], g = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[l & 255] ^ n[34], w = v[b >>> 24] ^ I[m >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[p & 255] ^ n[35], m = v[u >>> 24] ^ I[f >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[w & 255] ^ n[36], l = v[f >>> 24] ^ I[g >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[u & 255] ^ n[37], p = v[g >>> 24] ^ I[w >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[f & 255] ^ n[38], b = v[w >>> 24] ^ I[u >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[g & 255] ^ n[39];
    let U = 40;
    a > 10 && (u = v[m >>> 24] ^ I[l >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[40], f = v[l >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[m & 255] ^ n[41], g = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[l & 255] ^ n[42], w = v[b >>> 24] ^ I[m >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[p & 255] ^ n[43], m = v[u >>> 24] ^ I[f >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[w & 255] ^ n[44], l = v[f >>> 24] ^ I[g >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[u & 255] ^ n[45], p = v[g >>> 24] ^ I[w >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[f & 255] ^ n[46], b = v[w >>> 24] ^ I[u >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[g & 255] ^ n[47], U = 48), a > 12 && (u = v[m >>> 24] ^ I[l >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[48], f = v[l >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[m & 255] ^ n[49], g = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[l & 255] ^ n[50], w = v[b >>> 24] ^ I[m >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[p & 255] ^ n[51], m = v[u >>> 24] ^ I[f >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[w & 255] ^ n[52], l = v[f >>> 24] ^ I[g >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[u & 255] ^ n[53], p = v[g >>> 24] ^ I[w >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[f & 255] ^ n[54], b = v[w >>> 24] ^ I[u >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[g & 255] ^ n[55], U = 56), r[0] = (T[m >>> 24] << 24 | T[l >>> 16 & 255] << 16 | T[p >>> 8 & 255] << 8 | T[b & 255]) ^ n[U], r[1] = (T[l >>> 24] << 24 | T[p >>> 16 & 255] << 16 | T[b >>> 8 & 255] << 8 | T[m & 255]) ^ n[U + 1], r[2] = (T[p >>> 24] << 24 | T[b >>> 16 & 255] << 16 | T[m >>> 8 & 255] << 8 | T[l & 255]) ^ n[U + 2], r[3] = (T[b >>> 24] << 24 | T[m >>> 16 & 255] << 16 | T[l >>> 8 & 255] << 8 | T[p & 255]) ^ n[U + 3];
  }
}
function tr(t, e, n, a) {
  const r = an(t), s = new Uint8Array(a), i = new Uint8Array(e.length + 4), o = new DataView(i.buffer);
  i.set(e);
  for (let c = 1, d = 0; d < a; c++, d += et) {
    o.setUint32(e.length, c), r.update(i, 0, i.length);
    let h = r.digest();
    const y = h.slice();
    for (let u = 1; u < n; u++) {
      r.update(h, 0, et), h = r.digest();
      for (let f = 0; f < et; f++)
        y[f] ^= h[f];
    }
    s.set(y.subarray(0, Math.min(et, a - d)), d);
  }
  return s;
}
function an(t) {
  const e = er(), n = new Uint8Array(F), a = new Uint8Array(F);
  t.length > F && (e.update(t, 0, t.length), t = e.digest());
  for (let r = 0; r < F; r++) {
    const s = r < t.length ? t[r] : 0;
    n[r] = s ^ _a, a[r] = s ^ $a;
  }
  return e.update(n, 0, F), {
    update(r, s, i) {
      e.update(r, s, i);
    },
    digest() {
      const r = e.digest();
      e.update(a, 0, F), e.update(r, 0, et);
      const s = e.digest();
      return e.update(n, 0, F), s;
    }
  };
}
function er() {
  const t = new Int32Array(Ie), e = new Int32Array(Ga), n = new Uint8Array(F), a = new DataView(n.buffer), r = new Uint8Array(8);
  let s = 0, i = 0;
  return {
    update: o,
    digest: c
  };
  function o(h, y, u) {
    const f = y + u;
    if (i += u, s) {
      for (; y < f && s < F; )
        n[s++] = h[y++];
      s == F && (d(a, 0), s = 0);
    }
    if (y + F <= f) {
      const g = new DataView(h.buffer, h.byteOffset, h.byteLength);
      for (; y + F <= f; y += F)
        d(g, y);
    }
    for (; y < f; )
      n[s++] = h[y++];
  }
  function c() {
    const h = i * 8, y = Math.floor(h / 4294967296), u = h >>> 0;
    for (o(ja, 0, 1); s != Ka; )
      o(Qa, 0, 1);
    r[0] = y >>> 24, r[1] = y >>> 16, r[2] = y >>> 8, r[3] = y, r[4] = u >>> 24, r[5] = u >>> 16, r[6] = u >>> 8, r[7] = u, o(r, 0, 8);
    const f = new Uint8Array(et), g = new DataView(f.buffer);
    for (let w = 0; w < t.length; w++)
      g.setInt32(4 * w, t[w]);
    return t.set(Ie), s = 0, i = 0, f;
  }
  function d(h, y) {
    for (let p = 0; p < 16; p++)
      e[p] = h.getInt32(y + 4 * p);
    let u = t[0], f = t[1], g = t[2], w = t[3], m = t[4], l;
    for (let p = 0; p < 15; p += 5)
      m = (u << 5 | u >>> 27) + ((g ^ w) & f ^ w) + m + 1518500249 + e[p] | 0, f = f << 30 | f >>> 2, w = (m << 5 | m >>> 27) + ((f ^ g) & u ^ g) + w + 1518500249 + e[p + 1] | 0, u = u << 30 | u >>> 2, g = (w << 5 | w >>> 27) + ((u ^ f) & m ^ f) + g + 1518500249 + e[p + 2] | 0, m = m << 30 | m >>> 2, f = (g << 5 | g >>> 27) + ((m ^ u) & w ^ u) + f + 1518500249 + e[p + 3] | 0, w = w << 30 | w >>> 2, u = (f << 5 | f >>> 27) + ((w ^ m) & g ^ m) + u + 1518500249 + e[p + 4] | 0, g = g << 30 | g >>> 2;
    m = (u << 5 | u >>> 27) + ((g ^ w) & f ^ w) + m + 1518500249 + e[15] | 0, f = f << 30 | f >>> 2, l = e[13] ^ e[8] ^ e[2] ^ e[0], l = l << 1 | l >>> 31, e[0] = l, w = (m << 5 | m >>> 27) + ((f ^ g) & u ^ g) + w + 1518500249 + l | 0, u = u << 30 | u >>> 2, l = e[14] ^ e[9] ^ e[3] ^ e[1], l = l << 1 | l >>> 31, e[1] = l, g = (w << 5 | w >>> 27) + ((u ^ f) & m ^ f) + g + 1518500249 + l | 0, m = m << 30 | m >>> 2, l = e[15] ^ e[10] ^ e[4] ^ e[2], l = l << 1 | l >>> 31, e[2] = l, f = (g << 5 | g >>> 27) + ((m ^ u) & w ^ u) + f + 1518500249 + l | 0, w = w << 30 | w >>> 2, l = e[0] ^ e[11] ^ e[5] ^ e[3], l = l << 1 | l >>> 31, e[3] = l, u = (f << 5 | f >>> 27) + ((w ^ m) & g ^ m) + u + 1518500249 + l | 0, g = g << 30 | g >>> 2;
    for (let p = 20; p < 40; p += 5)
      l = e[p - 3 & 15] ^ e[p - 8 & 15] ^ e[p - 14 & 15] ^ e[p & 15], l = l << 1 | l >>> 31, e[p & 15] = l, m = (u << 5 | u >>> 27) + (f ^ g ^ w) + m + 1859775393 + l | 0, f = f << 30 | f >>> 2, l = e[p - 2 & 15] ^ e[p - 7 & 15] ^ e[p - 13 & 15] ^ e[p + 1 & 15], l = l << 1 | l >>> 31, e[p + 1 & 15] = l, w = (m << 5 | m >>> 27) + (u ^ f ^ g) + w + 1859775393 + l | 0, u = u << 30 | u >>> 2, l = e[p - 1 & 15] ^ e[p - 6 & 15] ^ e[p - 12 & 15] ^ e[p + 2 & 15], l = l << 1 | l >>> 31, e[p + 2 & 15] = l, g = (w << 5 | w >>> 27) + (m ^ u ^ f) + g + 1859775393 + l | 0, m = m << 30 | m >>> 2, l = e[p & 15] ^ e[p - 5 & 15] ^ e[p - 11 & 15] ^ e[p + 3 & 15], l = l << 1 | l >>> 31, e[p + 3 & 15] = l, f = (g << 5 | g >>> 27) + (w ^ m ^ u) + f + 1859775393 + l | 0, w = w << 30 | w >>> 2, l = e[p + 1 & 15] ^ e[p - 4 & 15] ^ e[p - 10 & 15] ^ e[p + 4 & 15], l = l << 1 | l >>> 31, e[p + 4 & 15] = l, u = (f << 5 | f >>> 27) + (g ^ w ^ m) + u + 1859775393 + l | 0, g = g << 30 | g >>> 2;
    for (let p = 40; p < 60; p += 5)
      l = e[p - 3 & 15] ^ e[p - 8 & 15] ^ e[p - 14 & 15] ^ e[p & 15], l = l << 1 | l >>> 31, e[p & 15] = l, m = (u << 5 | u >>> 27) + (f & g | (f | g) & w) + m + 2400959708 + l | 0, f = f << 30 | f >>> 2, l = e[p - 2 & 15] ^ e[p - 7 & 15] ^ e[p - 13 & 15] ^ e[p + 1 & 15], l = l << 1 | l >>> 31, e[p + 1 & 15] = l, w = (m << 5 | m >>> 27) + (u & f | (u | f) & g) + w + 2400959708 + l | 0, u = u << 30 | u >>> 2, l = e[p - 1 & 15] ^ e[p - 6 & 15] ^ e[p - 12 & 15] ^ e[p + 2 & 15], l = l << 1 | l >>> 31, e[p + 2 & 15] = l, g = (w << 5 | w >>> 27) + (m & u | (m | u) & f) + g + 2400959708 + l | 0, m = m << 30 | m >>> 2, l = e[p & 15] ^ e[p - 5 & 15] ^ e[p - 11 & 15] ^ e[p + 3 & 15], l = l << 1 | l >>> 31, e[p + 3 & 15] = l, f = (g << 5 | g >>> 27) + (w & m | (w | m) & u) + f + 2400959708 + l | 0, w = w << 30 | w >>> 2, l = e[p + 1 & 15] ^ e[p - 4 & 15] ^ e[p - 10 & 15] ^ e[p + 4 & 15], l = l << 1 | l >>> 31, e[p + 4 & 15] = l, u = (f << 5 | f >>> 27) + (g & w | (g | w) & m) + u + 2400959708 + l | 0, g = g << 30 | g >>> 2;
    for (let p = 60; p < 80; p += 5)
      l = e[p - 3 & 15] ^ e[p - 8 & 15] ^ e[p - 14 & 15] ^ e[p & 15], l = l << 1 | l >>> 31, e[p & 15] = l, m = (u << 5 | u >>> 27) + (f ^ g ^ w) + m + 3395469782 + l | 0, f = f << 30 | f >>> 2, l = e[p - 2 & 15] ^ e[p - 7 & 15] ^ e[p - 13 & 15] ^ e[p + 1 & 15], l = l << 1 | l >>> 31, e[p + 1 & 15] = l, w = (m << 5 | m >>> 27) + (u ^ f ^ g) + w + 3395469782 + l | 0, u = u << 30 | u >>> 2, l = e[p - 1 & 15] ^ e[p - 6 & 15] ^ e[p - 12 & 15] ^ e[p + 2 & 15], l = l << 1 | l >>> 31, e[p + 2 & 15] = l, g = (w << 5 | w >>> 27) + (m ^ u ^ f) + g + 3395469782 + l | 0, m = m << 30 | m >>> 2, l = e[p & 15] ^ e[p - 5 & 15] ^ e[p - 11 & 15] ^ e[p + 3 & 15], l = l << 1 | l >>> 31, e[p + 3 & 15] = l, f = (g << 5 | g >>> 27) + (w ^ m ^ u) + f + 3395469782 + l | 0, w = w << 30 | w >>> 2, l = e[p + 1 & 15] ^ e[p - 4 & 15] ^ e[p - 10 & 15] ^ e[p + 4 & 15], l = l << 1 | l >>> 31, e[p + 4 & 15] = l, u = (f << 5 | f >>> 27) + (g ^ w ^ m) + u + 3395469782 + l | 0, g = g << 30 | g >>> 2;
    t[0] = t[0] + u | 0, t[1] = t[1] + f | 0, t[2] = t[2] + g | 0, t[3] = t[3] + w | 0, t[4] = t[4] + m | 0;
  }
}
function nr() {
  if (!Se) {
    let t = 1, e = 1;
    do
      t = (t ^ t << 1 ^ (t & 128 ? 27 : 0)) & 255, e = (e ^ e << 1) & 255, e = (e ^ e << 2) & 255, e = (e ^ e << 4) & 255, e & 128 && (e ^= 9), T[t] = (e ^ (e << 1 | e >> 7) ^ (e << 2 | e >> 6) ^ (e << 3 | e >> 5) ^ (e << 4 | e >> 4) ^ 99) & 255;
    while (t != 1);
    T[0] = 99;
    for (let n = 0; n < 256; n++) {
      const a = T[n], r = rn(a), s = r << 24 | a << 16 | a << 8 | r ^ a;
      v[n] = s, I[n] = s >>> 8 | s << 24, S[n] = s >>> 16 | s << 16, A[n] = s >>> 24 | s << 8;
    }
    Se = !0;
  }
}
function ar(t, e) {
  const n = t.length >> 2, a = n + 6, r = 4 * (a + 1);
  let s = 1;
  for (let i = 0; i < n; i++)
    e[i] = t[4 * i] << 24 | t[4 * i + 1] << 16 | t[4 * i + 2] << 8 | t[4 * i + 3];
  for (let i = n; i < r; i++) {
    let o = e[i - 1];
    i % n == 0 ? (o = Ae(o << 8 | o >>> 24) ^ s << 24, s = rn(s)) : n > 6 && i % n == 4 && (o = Ae(o)), e[i] = e[i - n] ^ o;
  }
  return a;
}
function Ae(t) {
  return T[t >>> 24] << 24 | T[t >>> 16 & 255] << 16 | T[t >>> 8 & 255] << 8 | T[t & 255];
}
function Pt(t) {
  return t << 24 | (t & 65280) << 8 | t >>> 8 & 65280 | t >>> 24;
}
function rn(t) {
  return (t << 1 ^ (t >> 7) * 27) & 255;
}
const rr = typeof crypto != $ && typeof crypto.getRandomValues == It, sn = "Invalid password", sr = "Invalid authentication code", on = "zipjs-abort-check-password", ir = "Crypto API not supported";
function cn(t) {
  if (rr)
    return crypto.getRandomValues(t);
  throw new Error(ir);
}
const de = 16, or = "raw", ln = { name: "PBKDF2" }, cr = { name: "HMAC" }, lr = "SHA-1", dn = 1e3, dr = Object.assign({ hash: cr }, ln), ur = Object.assign({ iterations: dn, hash: { name: lr } }, ln), fr = ["deriveBits"], St = [8, 12, 16], pr = [16, 24, 32], j = 10, ne = 2, un = typeof crypto != $, At = un && crypto.subtle, hr = un && typeof At != $;
let Ue = hr && typeof At.importKey == It && typeof At.deriveBits == It, fn = le;
class wr extends TransformStream {
  constructor({ password: e, rawPassword: n, encryptionStrength: a, checkPasswordOnly: r, checkAuthenticationCode: s = !0 }) {
    const i = {};
    super({
      start() {
        pn(i, e, n, a);
      },
      async transform(o, c) {
        const {
          password: d,
          strength: h,
          resolveReady: y,
          ready: u
        } = i;
        if (d ? (await yr(i, h, d, Z(o, 0, St[h] + ne)), o = Z(o, St[h] + ne), r ? (Ut(i), c.error(new Error(on))) : y()) : await u, i.discarded)
          return;
        const f = new Uint8Array(o.length - j - (o.length - j) % de);
        c.enqueue(wn(i, o, f, 0, j, !0));
      },
      async flush(o) {
        const {
          engine: c,
          pendingInput: d,
          ready: h
        } = i;
        if (c) {
          if (await h, i.discarded)
            return;
          const y = Z(d, d.length - j), u = new Uint8Array(Z(d, 0, d.length - j));
          c.process(u, !0);
          const f = c.digest();
          let g = d.length < j ? 1 : 0;
          for (let w = 0; w < j; w++)
            g |= f[w] ^ y[w];
          if (g && s) {
            o.error(new Error(sr));
            return;
          }
          o.enqueue(u);
        }
      }
    }), hn(this, i);
  }
}
class mr extends TransformStream {
  constructor({ password: e, rawPassword: n, encryptionStrength: a }) {
    const r = {};
    super({
      start() {
        pn(r, e, n, a);
      },
      async transform(s, i) {
        const {
          password: o,
          strength: c,
          resolveReady: d,
          ready: h
        } = r;
        let y = Je;
        if (o ? (y = await br(r, c, o), d()) : await h, r.discarded)
          return;
        const u = new Uint8Array(y.length + s.length - s.length % de);
        u.set(y, 0), i.enqueue(wn(r, s, u, y.length, 0, !1));
      },
      async flush(s) {
        const {
          engine: i,
          pendingInput: o,
          ready: c
        } = r;
        if (i) {
          if (await c, r.discarded)
            return;
          const d = new Uint8Array(o);
          i.process(d, !1);
          const h = Z(i.digest(), 0, j);
          s.enqueue(rt(d, h));
        }
      }
    }), hn(this, r);
  }
}
function gr(t) {
  fn = t || le;
}
function pn(t, e, n, a) {
  Object.assign(t, {
    ready: new Promise((r) => t.resolveReady = r),
    password: Ir(e, n),
    strength: a - 1,
    pendingInput: Je,
    discarded: !1
  });
}
function hn(t, e) {
  const n = t.readable.getReader(), a = new ReadableStream({
    async pull(r) {
      try {
        const { value: s, done: i } = await n.read();
        i ? r.close() : r.enqueue(s);
      } catch (s) {
        throw Ut(e), n.cancel(s).catch(() => {
        }), s;
      }
    },
    cancel(r) {
      return Ut(e), n.cancel(r);
    }
  });
  Object.defineProperty(t, "readable", {
    get() {
      return a;
    }
  });
}
function wn(t, e, n, a, r, s) {
  const {
    engine: i,
    pendingInput: o
  } = t;
  o.length && (e = rt(o, e));
  const c = e.length - r, d = c - c % de;
  if (n = Sr(n, a + d), d) {
    const h = Z(n, a, a + d);
    h.set(Z(e, 0, d)), i.process(h, s);
  }
  return t.pendingInput = Z(e, d), n;
}
async function yr(t, e, n, a) {
  const r = await mn(t, e, n, Z(a, 0, St[e])), s = Z(a, St[e]);
  if (r[0] != s[0] || r[1] != s[1])
    throw Ut(t), new Error(sn);
}
function Ut(t) {
  const { engine: e } = t;
  t.discarded = !0, e && e.dispose && e.dispose();
}
async function br(t, e, n) {
  const a = cn(new Uint8Array(St[e])), r = await mn(t, e, n, a);
  return rt(a, r);
}
async function mn(t, e, n, a) {
  t.password = null;
  const r = pr[e], s = await vr(n, a, r * 2 + ne);
  return t.engine = fn(Z(s, 0, r), Z(s, r, r * 2)), t.discarded && Ut(t), Z(s, r * 2);
}
async function vr(t, e, n) {
  if (Ue)
    try {
      const a = await At.importKey(or, t, dr, !1, fr);
      return new Uint8Array(await At.deriveBits(Object.assign({ salt: e }, ur), a, n * 8));
    } catch {
      Ue = !1;
    }
  return tr(t, e, dn, n);
}
function Ir(t, e) {
  return e === M ? Va(t) : e;
}
function Sr(t, e) {
  if (e && e > t.length) {
    const n = t;
    t = new Uint8Array(e), t.set(n, 0);
  }
  return t;
}
function Z(t, e, n) {
  return t.subarray(e, n);
}
const st = 12;
class Ar extends TransformStream {
  constructor({ password: e, rawPassword: n, passwordVerification: a, checkPasswordOnly: r }) {
    super({
      start() {
        gn(this, e, n, a);
      },
      transform(s, i) {
        const o = this;
        if (o.password || o.rawPassword) {
          const c = xe(o, s.subarray(0, st));
          if (o.password = o.rawPassword = null, (c[st - 1] ^ o.passwordVerification) != 0)
            throw new Error(sn);
          s = s.subarray(st);
        }
        r ? i.error(new Error(on)) : i.enqueue(xe(o, s));
      }
    });
  }
}
class Ur extends TransformStream {
  constructor({ password: e, rawPassword: n, passwordVerification: a }) {
    super({
      start() {
        gn(this, e, n, a);
      },
      transform(r, s) {
        const i = this;
        let o, c;
        if (i.password || i.rawPassword) {
          i.password = i.rawPassword = null;
          const d = cn(new Uint8Array(st));
          d[st - 1] = i.passwordVerification, o = new Uint8Array(r.length + d.length), o.set(Ee(i, d), 0), c = st;
        } else
          o = new Uint8Array(r.length), c = 0;
        o.set(Ee(i, r), c), s.enqueue(o);
      }
    });
  }
}
function gn(t, e, n, a) {
  Object.assign(t, {
    password: e,
    rawPassword: n,
    passwordVerification: a
  }), xr(t, e, n);
}
function xe(t, e) {
  const n = new Uint8Array(e.length);
  for (let a = 0; a < e.length; a++)
    n[a] = yn(t) ^ e[a], Bt(t, n[a]);
  return n;
}
function Ee(t, e) {
  const n = new Uint8Array(e.length);
  for (let a = 0; a < e.length; a++)
    n[a] = yn(t) ^ e[a], Bt(t, e[a]);
  return n;
}
function xr(t, e, n) {
  const a = [305419896, 591751049, 878082192];
  if (Object.assign(t, {
    cryptoKeys: a,
    crcKey0: new Mt(a[0]),
    crcKey2: new Mt(a[2])
  }), n)
    for (let r = 0; r < n.length; r++)
      Bt(t, n[r]);
  else
    for (let r = 0; r < e.length; r++)
      Bt(t, e.charCodeAt(r));
}
function Bt(t, e) {
  let [, n] = t.cryptoKeys;
  t.crcKey0.append([e]);
  const a = ~t.crcKey0.get();
  n = Re(Math.imul(Re(n + bn(a)), 134775813) + 1), t.crcKey2.append([n >>> 24]);
  const r = ~t.crcKey2.get();
  t.cryptoKeys = [a, n, r];
}
function yn(t) {
  const e = t.cryptoKeys[2] | 2;
  return bn(Math.imul(e, e ^ 1) >>> 8);
}
function bn(t) {
  return t & 255;
}
function Re(t) {
  return t & 4294967295;
}
function Er(t) {
  if (t instanceof ReadableStream)
    return t;
  const e = t.getReader();
  return new ReadableStream({
    async pull(n) {
      try {
        const { value: a, done: r } = await e.read();
        r ? n.close() : n.enqueue(a);
      } catch (a) {
        throw e.cancel(a).catch(() => {
        }), a;
      }
    },
    cancel(n) {
      return e.cancel(n);
    }
  });
}
const Rr = "Compression method not supported", Cr = /* @__PURE__ */ new Map();
function vn(t) {
  return Cr.get(t);
}
const ae = "Invalid uncompressed size", kr = "Invalid compressed data", In = "Codec out of memory", Sn = "Invalid CRC32", Pr = "Z_MEM_ERROR", Tr = "deflate-raw", Dr = "deflate64-raw", qt = "gzip", An = 10, re = 8, Nr = [31, 139, 8];
class Or extends TransformStream {
  constructor(e, { chunkSize: n, CompressionStreamFallback: a, CompressionStream: r }) {
    super({});
    const { compressed: s, encrypted: i, useCompressionStream: o, zipCrypto: c, computeCrc32: d, level: h, deflate64: y, format: u, compressionMethod: f, inputSize: g } = e, w = this;
    let m, l, p, b = super.readable;
    const U = u && vn(u), C = En(o, r, a), k = d && s && !y && !U && (!i || c) && !!C;
    if ((!i || c) && d && !k && (m = new nn(), b = K(b, m)), s)
      if (U)
        b = yt(b, xn(U.CompressionStream, u, { level: h, chunkSize: n, compressionMethod: f, uncompressedSize: g }));
      else if (k)
        p = new Ce(), b = yt(b, new C(qt, { level: h, chunkSize: n })), b = K(b, p);
      else
        try {
          b = Rn(b, o, { level: h, chunkSize: n }, r, a);
        } catch (P) {
          if (!o && a)
            throw Ht(P);
          let B;
          try {
            B = new r(qt);
          } catch {
            throw Ht(P);
          }
          b = yt(b, B), b = K(b, new Ce());
        }
    i && (c ? b = K(b, new Ur(e)) : (l = new mr(e), b = K(b, l))), Un(w, b, () => {
      (!i || c) && d && (w.crc32 = k ? p.crc32 : new DataView(m.value.buffer).getUint32(0));
    });
  }
}
class Ce extends TransformStream {
  constructor() {
    let e, n = An, a = new Uint8Array(0);
    super({
      transform(r, s) {
        if (n) {
          const d = Math.min(n, r.length);
          if (n -= d, r = r.subarray(d), !r.length)
            return;
        }
        const i = a.length + r.length;
        if (i <= re) {
          a = rt(a, r);
          return;
        }
        const o = i - re, c = Math.min(o, a.length);
        s.enqueue(rt(
          a.subarray(0, c),
          r.subarray(0, o - c)
        )), a = rt(
          a.subarray(c),
          r.subarray(o - c)
        );
      },
      flush() {
        const r = en(a);
        e.crc32 = r.getUint32(0, !0), e.uncompressedSize = r.getUint32(4, !0);
      }
    }), e = this;
  }
}
function Lr(t, e, n, a, r) {
  const s = e.writable.getWriter(), i = e.readable.getReader(), o = a === M ? new Mt() : M;
  let c = 0, d = !1, h = !1, y, u;
  const f = new ReadableStream({
    start(U) {
      u = U;
    },
    pull() {
      p();
    },
    cancel(U) {
      return h = !0, p(), i.cancel(U);
    }
  });
  return g(), w(), f;
  async function g() {
    const U = t.getReader();
    try {
      const C = new Uint8Array(An);
      for (C.set(Nr), await s.write(C); ; ) {
        await l(), await s.ready;
        const { value: B, done: Vt } = await kn(U, r);
        if (Vt)
          break;
        await s.write(B);
      }
      o && await s.write(new Uint8Array(0));
      const k = new Uint8Array(re), P = en(k);
      P.setUint32(0, o ? o.get() : a, !0), P.setUint32(4, n, !0), d = !0, await s.write(k), await s.close();
    } catch (C) {
      await Cn(s, C), await Ft(U, C);
    }
  }
  async function w() {
    try {
      for (; ; ) {
        const { value: U, done: C } = await m();
        if (C)
          break;
        if (c += U.length, c > n)
          throw new Error(ae);
        o && o.append(U), u.enqueue(U);
      }
      h || (h = !0, u.close());
    } catch (U) {
      b(U), await Ft(i, U);
    }
  }
  function m() {
    return i.read().catch((U) => {
      if (d) {
        if (!o)
          throw Zt(U, Sn);
        if (c != n)
          throw Zt(U, ae);
        return { done: !0 };
      }
      throw Pn(U, r);
    });
  }
  function l() {
    if (!h && u.desiredSize <= 0)
      return new Promise((U) => y = U);
  }
  function p() {
    if (y) {
      const U = y;
      y = M, U();
    }
  }
  function b(U) {
    h || (h = !0, u.error(U), p());
  }
}
class zr extends TransformStream {
  constructor(e, { chunkSize: n, DecompressionStreamFallback: a, DecompressionStream: r }) {
    super({});
    const { zipCrypto: s, encrypted: i, checkCrc32: o, crc32: c, compressed: d, useCompressionStream: h, deflate64: y, format: u, compressionMethod: f, rawBitFlag: g, outputSize: w } = e;
    let m, l, p, b = super.readable;
    if (i && (s ? b = K(b, new Ar(e)) : (l = new wr(e), b = K(b, l))), d) {
      const U = /* @__PURE__ */ new Set(), C = u && vn(u);
      let k;
      if (C)
        b = yt(b, xn(C.DecompressionStream, u, { chunkSize: n, compressionMethod: f, rawBitFlag: g, uncompressedSize: w }), U);
      else {
        const P = En(h, r, a);
        if (o && !y && c !== M && w !== M && P)
          try {
            k = new P(qt, { chunkSize: n });
          } catch {
            k = M;
          }
        if (!k)
          try {
            b = Rn(b, h, { chunkSize: n, deflate64: y }, r, a, U);
          } catch (B) {
            if (y || w === M || !h && a)
              throw Ht(B);
            try {
              k = new r(qt);
            } catch {
              throw Ht(B);
            }
          }
      }
      k ? (p = !0, b = Lr(b, k, w, c, U)) : b = Mr(b, U);
    }
    o && !p && (m = new nn(), b = K(b, m)), Un(this, b, () => {
      if (m) {
        const U = new DataView(m.value.buffer).getUint32(0, !1);
        if (c != U)
          throw new Error(Sn);
      }
    });
  }
}
function Un(t, e, n) {
  e = K(e, new TransformStream({ flush: n })), Object.defineProperty(t, "readable", {
    get() {
      return e;
    }
  });
}
function xn(t, e, n) {
  if (!t)
    throw new Error(Rr);
  return new t(e, n);
}
function En(t, e, n) {
  if (t && e)
    return e;
  if (n && n.requiresModule)
    return n;
}
function Rn(t, e, n, a, r, s) {
  const i = e && a ? a : r || a, o = n.deflate64 ? Dr : Tr;
  let c;
  try {
    c = new i(o, n);
  } catch (d) {
    if (e && r && i != r)
      c = new r(o, n);
    else
      throw d;
  }
  return yt(t, c, s);
}
function K(t, e) {
  return Er(t).pipeThrough(e);
}
function yt(t, e, n) {
  const a = e.writable.getWriter(), r = t.getReader();
  return s(), e.readable;
  async function s() {
    try {
      for (; ; ) {
        await a.ready;
        const i = await kn(r, n);
        if (i.done) {
          await a.close();
          break;
        }
        await a.write(i.value);
      }
    } catch (i) {
      await Cn(a, i), await Ft(r, i);
    }
  }
}
async function Cn(t, e) {
  try {
    await t.abort(e);
  } catch {
  }
}
async function Ft(t, e) {
  try {
    await t.cancel(e);
  } catch {
  }
}
function kn(t, e) {
  const n = t.read();
  return e ? n.catch((a) => {
    throw e.add(a), a;
  }) : n;
}
function Pn(t, e) {
  return e.has(t) ? t : Zt(t, Tn(t) ? In : kr);
}
function Ht(t) {
  return Tn(t) ? Zt(t, In) : t;
}
function Tn(t) {
  return Ba(t) && t.code == Pr;
}
function Zt(t, e) {
  const n = new Error(e);
  return n.cause = t, n;
}
function Mr(t, e) {
  const n = t.getReader();
  return new ReadableStream({
    async pull(a) {
      try {
        const { value: r, done: s } = await n.read();
        s ? a.close() : a.enqueue(r);
      } catch (r) {
        throw await Ft(n, r), Pn(r, e);
      }
    },
    cancel(a) {
      return n.cancel(a);
    }
  });
}
const Br = 256 * 1024, qr = "deflate", Fr = "inflate";
class bs extends TransformStream {
  constructor(e, n) {
    super({});
    const a = this, { codecType: r } = e;
    let s;
    r.startsWith(qr) ? s = Or : r.startsWith(Fr) && (s = zr), a.outputSize = 0;
    let i = 0;
    const o = new s(e, n), c = super.readable, d = new TransformStream({
      transform(y, u) {
        y && y.length && (i += y.length, u.enqueue(y));
      },
      flush() {
        Object.assign(a, {
          inputSize: i
        });
      }
    }), h = new TransformStream({
      transform(y, u) {
        if (y && y.length && (u.enqueue(y), a.outputSize += y.length, e.outputSize !== M && a.outputSize > e.outputSize))
          throw new Error(ae);
      },
      flush() {
        const { crc32: y } = o;
        Object.assign(a, {
          crc32: y,
          inputSize: i
        });
      }
    });
    Object.defineProperty(a, "readable", {
      get() {
        return c.pipeThrough(d).pipeThrough(o).pipeThrough(h);
      }
    });
  }
}
class vs extends TransformStream {
  constructor(e) {
    const n = [];
    let a = 0, r = 0;
    (!Number.isFinite(e) || e < 1) && (e = Br), super({
      transform(o, c) {
        for (n.push(o), a += o.length; a > e; )
          r += e, c.enqueue(s());
      },
      flush(o) {
        a && (r += a, o.enqueue(i(n, a)));
      }
    }), Object.defineProperty(this, "outputSize", {
      get: () => r
    });
    function s() {
      const o = new Uint8Array(e);
      let c = 0;
      for (; c < e; ) {
        const d = n[0], h = e - c;
        d.length <= h ? (o.set(d, c), c += d.length, n.shift()) : (o.set(d.subarray(0, h), c), n[0] = d.subarray(h), c += h);
      }
      return a -= e, o;
    }
    function i(o, c) {
      const d = new Uint8Array(c);
      let h = 0;
      for (const y of o)
        d.set(y, h), h += y.length;
      return d;
    }
  }
}
class Is extends TransformStream {
  constructor({ onstart: e, onprogress: n, size: a, onend: r }) {
    let s = 0;
    super({
      async start() {
        e && await Gt(e, a);
      },
      async transform(i, o) {
        s += i.length, n && await Gt(n, s, a), o.enqueue(i);
      },
      async flush() {
        r && await Gt(r, s);
      }
    });
  }
}
async function Gt(t, ...e) {
  try {
    await t(...e);
  } catch {
  }
}
BigInt(Number.MAX_SAFE_INTEGER);
BigInt(0);
BigInt("0x7fffffffffffffff");
try {
  Yt({ baseURI: import.meta.url });
} catch {
}
const Hr = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258], Zr = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], Wr = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577], Yr = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], Xr = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], wt = new Uint8Array(288);
wt.fill(8, 0, 144), wt.fill(9, 144, 256), wt.fill(7, 256, 280), wt.fill(8, 280, 288);
const Vr = new Uint8Array(30).fill(5);
function pt(t) {
  const e = new Uint16Array(16);
  for (const r of t) e[r]++;
  e[0] = 0;
  const n = new Uint16Array(17);
  for (let r = 1; r <= 15; r++) n[r + 1] = n[r] + e[r];
  const a = new Uint16Array(t.length);
  for (let r = 0; r < t.length; r++) t[r] && (a[n[t[r]]++] = r);
  return { lengthCounts: e, symbols: a };
}
const q = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function Jr(t) {
  let e;
  t({ wasmURI: () => (e || (e = "data:application/wasm;base64," + (function(n) {
    let a = "";
    const r = n.length;
    let s = 0;
    for (; s + 2 < r; s += 3) {
      const o = n[s] << 16 | n[s + 1] << 8 | n[s + 2];
      a += q[o >> 18 & 63] + q[o >> 12 & 63] + q[o >> 6 & 63] + q[63 & o];
    }
    const i = r - s;
    if (i === 1) {
      const o = n[s] << 16;
      a += q[o >> 18 & 63] + q[o >> 12 & 63] + "==";
    } else if (i === 2) {
      const o = n[s] << 16 | n[s + 1] << 8;
      a += q[o >> 18 & 63] + q[o >> 12 & 63] + q[o >> 6 & 63] + "=";
    }
    return a;
  })((function(n) {
    let a = 0, r = 0, s = 0, i = new Uint8Array(1024), o = 0, c = 0;
    for (; !c; ) {
      c = h(1);
      const m = h(2);
      if (m == 0) y();
      else if (m == 1) u(pt(wt), pt(Vr));
      else {
        if (m != 2) throw new Error("invalid deflate block type");
        u(...f());
      }
    }
    return i.subarray(0, o);
    function d() {
      if (a >= n.length) throw new Error("unexpected end of deflate data");
      return n[a++];
    }
    function h(m) {
      for (; s < m; ) r |= d() << s, s += 8;
      const l = r & (1 << m) - 1;
      return r >>>= m, s -= m, l;
    }
    function y() {
      r = 0, s = 0;
      const m = d() | d() << 8;
      a += 2, w(o + m);
      for (let l = 0; l < m; l++) i[o++] = d();
    }
    function u(m, l) {
      let p = g(m);
      for (; p != 256; ) {
        if (p < 256) w(o + 1), i[o++] = p;
        else {
          const b = p - 257, U = Hr[b] + h(Zr[b]), C = g(l), k = Wr[C] + h(Yr[C]);
          w(o + U);
          const P = o - k;
          for (let B = 0; B < U; B++) i[o++] = i[P + B];
        }
        p = g(m);
      }
    }
    function f() {
      const m = h(5) + 257, l = h(5) + 1, p = h(4) + 4, b = new Uint8Array(19);
      for (let P = 0; P < p; P++) b[Xr[P]] = h(3);
      const U = pt(b), C = new Uint8Array(m + l);
      let k = 0;
      for (; k < C.length; ) {
        const P = g(U);
        if (P < 16) C[k++] = P;
        else if (P == 16) {
          const B = C[k - 1];
          let Vt = h(2) + 3;
          for (; Vt--; ) C[k++] = B;
        } else k += P == 17 ? h(3) + 3 : h(7) + 11;
      }
      return [pt(C.subarray(0, m)), pt(C.subarray(m))];
    }
    function g(m) {
      const { lengthCounts: l, symbols: p } = m;
      let b = 0, U = 0, C = 0;
      for (let k = 1; k <= 15; k++) {
        b |= h(1);
        const P = l[k];
        if (b - U < P) return p[C + (b - U)];
        C += P, U = U + P << 1, b <<= 1;
      }
      throw new Error("invalid huffman code");
    }
    function w(m) {
      if (i.length < m) {
        let l = 2 * i.length;
        for (; l < m; ) l *= 2;
        const p = new Uint8Array(l);
        p.set(i.subarray(0, o)), i = p;
      }
    }
  })((function(n) {
    const a = (n = String(n).replace(/[^A-Za-z0-9+/=]/g, "")).length, r = [];
    for (let s = 0; s < a; s += 4) {
      const i = q.indexOf(n[s]) << 18 | q.indexOf(n[s + 1]) << 12 | (63 & q.indexOf(n[s + 2])) << 6 | 63 & q.indexOf(n[s + 3]);
      r.push(i >> 16 & 255), n[s + 2] !== "=" && r.push(i >> 8 & 255), n[s + 3] !== "=" && r.push(255 & i);
    }
    return new Uint8Array(r);
  })("zb19kF3HdSfW3bfvx3v3vXl3gAEwwIDAuRcQNZQ4AClRA4qkpWmIg+EQhKh19Ier4ioSAkcS7gMBvvdGIOWlOUPxw5BNaRGHUdEOa43YSqRykRUmy93IDncFr+m1dq3d0BttLROpUqpYZWsTpYrKslysFEOGv3P6vo/5AEAStsMp8N17++v06dOnT58+57Q63rtfK6X0fzp2r1lZUffqFb2CJ71yb7DCP3pF8aO6V+mVe+2KPKp7oxX+T6/cG6/0H63/1Y/olXtD/zX49LFEW6W1jSJtdM3UNf4zxtSM1irQQVAP0yAIlDKN0NjY2liFYRhqYwNjjTEqaupQaaViZZPAhvoBXa+HkdZfMV8xUaJXtHvhO2Ea/5ml6P6l+890v2xU4+Tpz586vrz08XtOLz2okvH+68nTJ5fv6R5/UNWaI99UmvXfH+ieObHU66nGoJal0/ep1vb+66njveV7Tpw53fvS/Uv3qSz1CdJYVUrqHc+GX7npLeMjn77wKycfUFtb1bd+6/1aufFt1dvatu9bGm67euO2J7LhV2572/jIJ257e6v6VrW9o18r2t5pP99dWlJmW/VxDQjR/cdPnTpzQunG8aXePV+8//gJBmau2X9laFzWf6/auWNQAg0tppzz5PFTJ39lSamd99xz8vR9J7tLJ5bv+fyXTp9YPnnm9D3Lxz93akmrnfcs3d870T35wPLS6Xt6y8dPtO/pLvWWz3SXVLR7XdIXlpbvOfGlbnfp9LKKi3vuOfHQ8XtOnj7RXbp/6fTyPUsPnVh6gCvvLn3+xJkvnV5Wd9ZaWjmd1tTU7ubk0UO3fKL+0rPBMaPS735Qpyv7lMvaRX2/MnPr/0i51/UxO+ce3zZtVBG4jJRLS/dG0MHD4lQRueBsoc4W2gUdixLarfSc7pAqC+OC5UK757aVhSI9bV7cVuhpkxThEa6RAvcImQc7s0Y1dEohqVnTIEXhrElS0i4pc0WauBbjgu6ssXgtC43KrNP40khTitxTDF5yrKlJAwpnSKGQItPukia13PkiQFwuFINjSDE4ai04+sFOEfQBMgDIeIAURR4IRVFZWOL6NEXtIhRYSJEukVtRYucocQ910Fqu3TOALzdmhQKnKXHB2eUi7sz7dinuooxGo0BQmgfo6KxJKKhg0PITCCiMG/fMNrKzRrmntnGjjTR15xgR6XxTU/pFZ5anzYs7CgNsPdShqJ1bMrkOeJymTVaoectPE4Wab+oUWPE5C03Atl0s9FSOnhnSU7khlQPMlMy0mcxrZPDQKNSCncNTUuhqFPWsSRp1zjhRaLtCxk2UIV6zQs83AzIuK9M8DOYozGPShXITZR4ChIlCNxUpl/n3DO8pxU6hl7XUreQRKffdlaOcLS0L7R7q5JHvfTzfVG5vnjglPVbu9bffjo/ZOYrctaCrs18oVPssE6nTy233iTJPUk/wSYU0jdFROSgBPxS5nZQ4fbbtFCVu78LUcm4qRFY4C8je3VSk85CCwjaVU7klnatGAPJhPAfEY+uuOetsp+S+HZkiRcFUrsg4vZwbQm9RIOwKDKEzlIB0Fal2l+IORisgVQ1wrlLi8QvmhkfQkF3MNRkMpIxhiIcKpXaFtKA7LRS3GM43FVmZTBS10ZUQw5xQiAc/zOH6YU5SfJVhDnmYw/4whzzMJpgjA7KWYTZrhtkMDXMgwxwP5nUIDiRTSJk5Cpk8XXa3nZOpaEj3J2BYAiQ1mK2YVIrC/tQNR/mHU7lxKtcpZhFKYlYZroEnWaMGOM4zHGbRzrnz28gwAMj77Db3LCcJHCg2DEyfYVRVeUo6WBbWrLgfTU4bZefcT/ALOvvp5OGVQ0a5H08eXr2wurq6avH2o0mqu0bpHui4V3//3/1+2EPLr00ymtxF/7tKaaHLInCKdLuIO2BMx5qJe2mSMWjn3Iv8lJAuixolxyik2mK3WUvNnLs4OaOUs2BIFef3/ULBlydzJZSF4hgMCilhSisXmwFzjURIyKksLIxbOdIMSOeB+zG3qZxuFyGZDpgNmTZYasnE3CnzIKUAoAYeVNUHNaSgLGIKj5GieLHbtCkFWVgoMgtN3QhRzrQxG/CVKUgJUEeamgxPCkCiKXI3lBQAbpWbhk0F4ZgfFLRLXiQ6hclCyW0oKPOAswYpGbey0DQp8HwRpZwFr05J+45yj9FOFzzyWLcZ4hesIHLT5bFmmLoXJ6VD6A6P1Xf4TYGavjOJiaTSPsLtAOHSJUy1aWOLsDzSNANUoxtPC+kBk2SOTYFZPC3Ey4TmvjeJ9UK5lyf5o/vmNreC329vE9LD8ytCPxhfWc5kvQ5nzYvbSGNd+c42sMmyUI4WmirFBAjcdLtQ7iEybQdSayM/ZoNfn3k1o8GqaEo3jbl2YZv7mW+4YVNwpmNYY452pWcNl3TwRAGFJfI/u42se4gst6KkYnd+m0xHoNOQajNOscb75gzZDZoLGCWNSH4q5JE5OoQ0GfqQ8W/msDD5EQDb85jXDQPePKMA7HwzSP1omblqtCwIDWsn02IRLvqFNeG1ZBP8xRvgL74U/shS6D5IISoo3cF2ASKwLisXpwrtplhWct+fvM6oQyYj7V6Wx8R9f5JFK7S3lj48LZB2k6VMeRdX7IuUs5DHwkXwaE32CBY6YaSPdJCLxYV2YTzULMAog3X/bYiQZCpxSJkVL09qx+Ld2eXCVMKQJsPCEEtgioUhjZ5BGNL4abhGblwCdrmXl8y3/eJu3LVkNlzcVUoW02w32cOMDuXMsntxR5lrZnUiNoQOcmIRMCTnIJaFIpaxkAVwjNuJSlkEUCIC8KquRIopKknA8Ex115zFWoslXWaD7ZRFgGUu5GUO1WaATM+aSZfkhmyhc+UalRhYcLcbAkAiXUh4Yk/mxjVSsn6tA8ULG/ELlQJDxUzBGvSeliqbutVt7gYUVJX8IqsikzUFJU+1ioTLIunXoN1DpOVjQBElZWHbeVwxOAogbT/rJdf+XI6FNaKTXq7XqSz5UmAg6nrxZF0BEIlgAfgLwDKVCzpOH8HkhXxYw9dGbnhbIzQZiCxjZAcgVOkeASs8K/sSkwohexE88XVP5pEBgw4WqkpUlUtJLsPfJwplIfNDJApE4G5qClgk0sEcS4qqgGScaxGJVFOxZAzBjQuAVkLn+wVpJaVovqmk/t0FSBmE9+IORhRp0LUMlWlqd26bUDc6VfUIRSmaNhnyR8iboVv8NJGS4Z2AoWjWTHqg7Zx0LBMqmEx93yAvcsJEPyGmWpnHFFCNid3mTOqqzyMqpmYpLglcj2I/FvHG/CF+t/xBJkpDJpbnEwateD4Ru2sp3pBPGMxGM8QnTMUn1BCfYKa1XIQVn9CeT6g+n4jdTojyzCeM3yrw6iBjXlQyegw+ga0ABltEfzBf8ImwLw6HfT6hMCC26qP11KiEhK2I48IpnM86hIeUEpnZPP6JUFAICtKgIMMUhJ0wGaYgnlyKKYhivzGO+/QTUuLpJ2G6ACD8NOF3IqQoAQzSDxbUNeiH9w2T1XYB9MMJE1WCmSPrWiJiWjAqNSy4C/PpMwjsBHxyiLwB+TQw15KHg6ynLrsxddkroq5AqCsAOgPBajBEXdyKpy7rriW72SoUyCoUbLQKYWaw0qKiK1OpBXiRlgYnAZfddBkS8qq2+7a/DOlqGTKevOLBphq1Z6JnwLyuOhl48jLC3IKB+kE2aJOVaoL7hA2gkBdzvpqQl+mTV8jkBTZL4TrySoW8+sRlqOaJq9Ynrtoa4qoBArMJcZnLEpdZS1xmPXGZPnEZ5A37xGWxybTrtDzKb1G1WRnoeChYq+UZIq3A759lbBvkN9VatDxY80Kv3rEinjKKU6q7rNyvSKX/W6qTFSxn3FeXYNuhnG0LdT8EmTkPWSenOxDXnOnw+gP2rSB2BiIGLzY1665yrwSsVl6/ujWgk6ikOFnu7ELTDK+Yur9ihtUCObI8ji6i1i8genRxZH2BLI42mCPLaiFeHK0f02pxtH7sh9RCATMVy4pIFyw0A+CNySwk7ZefoC8ssLJRtTzDB2DMT80GKywTsB2ssHbTFVa/5xVWM2Y9EQ+tsFpWWE/E1RQNvWYGndUdBtVrr3iEbSVqhV7UCkZELeUlpwEyAhnvhSYULqJOeEZ+W14Iw77fi2HBiBi2vjLsyyrkggZJ8bZhlIpYh2TXyV0jVDQ6MjYVXRTIKhxSQw2TVbCpGsp4NdS7JyuTbkg//V7KxnJAMuEakgmvnGTCKyWZcBOSCTcnmXVwU0DJQlNVk6SV9mVi1Vdb91dKi6WJGZqq2Jkiu1Zp7ZeqhFS1iOjBAtESMUz1F0rlrgXLOvuFQstCqYfEsEDEsGCNGGbNipkzK6OCWDwQxITDWqHRSb9NJLWROGbBqpkc+ts21RfHbF8TS3awXtrBeonKSefWcbeDoo+FwkrfBRNuMlfY2TmV5jFrF2Td8JjhwYi9ZuabTBEaeoEVUlNg+OlTqY5XhDOHxqsYLHbYHaZY4eZKdFnayxHIBQWUX4686qKRB/2NeCAy41oWboYnn5K55tcAzm+qUTV+PvJ+xdoVUjzXWINrWTE9pPKNyRaBqHyZo9mmYhYv7xVSR1m4GWbhWli48VNQ9fesIScxC/eADVh40J+PCvPRDOajGsxHEatG56MZmo9qaD4G/fkY8HwMeD4GMh+554Yxi3krctKkR5DBfOSEiSqhz659bzfi2WqEZ2uvFBr0Xr0bnq1GePYGleHcymMTahomJuHZA7LxPDtYw7PNKM8eHooBzw6GePYoHVU8247ybDvg2e+ejphnryeYfi+FZwejPNtsyLMvRyPhldJIuAmNhJvQyEZwY1PlebauFlgZG13xbNPn2Tho1Myz9WB3EzCDNJVgn/LxkJLdjT/QMYNzHebZARrxPFv3z8+M8GxT8WxWEAXg2Up4dlDxbDO0dcY6EgxxbOs5tvH7AV6umJW6nTgpZZYdCMsOALESasA4McvWYNkBWDZ+NHKBd/dZthGW7VUX1iPW91SWJawE/fMs0bGRkh2OqnbVvIFOb9Cahe1CZ7rwIrdt4+QkgBBGvBPB+cubKZ/fpYtYQX824ZX4Li4hkhuWssmw1l6z1p7UJ5XLlo819UDrttJK3c8mBC86jRSp/Sq1ap9Kc61X3Msqs6xbUs7Mmv1YnWcNkQqdStNxRTjYdY/wqv5AVk//y0BHK+5XsIq4byQA+UYQ0iNQP0lHlGdkVAT8Ydrs97/TTrsfHaJgPFCFQbUPt7w2cDd6MWtursbPOC0fX3xLzRoLXGXXiHRK2qk7RGJxDxwpolnz6iE5qtIucy2Kpo7msehYFdKwTz3rwjLHAR1IsNWBZMOkkWC7ovOAYpGJglkzLWJiQxqUSm4iA1K8fvgbSU8TodIJsrx5tE53Zs0NqRS4TbLuf+cNR3APsARy+MW31CFsBQ8/Kt++fwhn3+7FOgvAD7xTZnXVutVVQ9EU702Bks/Kz2ccy1fTDCYwO648ynenFPLgZrV0CxME+sO6fZuNpX9wh8lXzCP7lKN2MbYfAzZZYZVX9aLmB0kV0bws1NYfN+xmPUARuO++pUStc5FHBT+YrtqF7XwvGfcjVeZExr0elvk2Mu5VVeZTZNxrqsx3SRfz7UhXZT6OSTgHWWba3CYnybbYnSeyBDbzLcPGIzgUcb+a240MS/4m/igA4bXH9oZRnNQOHLzhxnraaI61svHATGzThdo/tct+/JZbb2Pmd1eeNor+0xQ/ncobjUyeihZ+7uXz+tbiVJ42xjihkdvGjDwVwfwQXhsHcPwei34hmW9+BNYC7TyhaEYpipcphDVD5HSZR9A/lkzvOO42nXkK3e98wyx058WMYloqbs2aaaxUWMwU/rI9BfPYMeS+VWNDMuZs6Uy2hxfqf8yQyJTY7VQeNw4wqPtxrEgWp383sKZm2a2+FXTwdLZ0ex+YB/PsdJiC3O/VmX7dn1fdotC1Oi5hQdD9PF2fas8WASZoHb2yVHfxMe5FkdoVSkOZm9NkU7J3d5pbKXY4EYAIM1IZBXnYmBnF4o1XiEU20pmg0L2tNwN1BqCuXoSZEin3vyZrExlPAa/QwAvzBMVrvFu1zOANTv3kccwltyhLY5z1FhWKIczu/nDw1Dbun8iUgwmHymPp2l7ftRuutGtDcM0ayxqyGbWNpf9RmDh9BBLbh+R/2ACSCskH3wMkLjkrUhyjHOvjpeACrW6Moe+MwiUb8sCtJhimkHdoFaCsbBuB04LcRuE0qCchm4eNG3kZZuK7XWCv2zmq431CplUgI7tvAO0+GiO7MbSNfRUGkI2VoFlj3+iYzlw5ubrJZVDWW0HHJctdITk/KSfPdrsy0VmmuoGM+2fr0ZTxdKWmyDY1kVQSf5onUlU8y+rUcNbc5kw+2bgx7XOSvWsa+C43kNJeZxabHxLxsJkA5m5epygPKPGDYVjNPd+EIlrDvioY7muAvgZUH+ook4f7o7dUngwx69Dps3w+1x4LlDZBKgrjVw8VdUjikXttoizSacMmapF7c7KE+IdjxtflMZLzsCiYc+c1J5zng/px4Hu5dMmtWnnUA5Rgzq2aPKLErRrJlnC2GrIlyJb4bM8Yru0ZM1xbvLY2StyFkYqS0YpojOpudfyUO7+zhLyzm9AvAC+jM+ZqQIumcXfB0JjbXYKplLSN6hntAhFzGzTcRLimCa7xzcmSxrDeJ1ItrBWdeadaWlcrpbxB8oqkz5A5/NXV1dVX1CHzS2RAO58l4/5UmLF20UIzwPEbeHXoApxmB3lENk8aM6l7GeMp6pXnwGjBSfMklXpsuknBD6R8zpdj+x67uHOWj86tn0BrZrgdnT+Wl5fBDI8bH+YZHrq33w46BVjRSs9lZ4X7/2ltZG1B9g+A/P/50Bp5ezWhpLeqMY0cf+yngpk2t3t2BxV9sjhVBNSkgJp4mm9+kGrY62W5MIvbKWiD0+DoM68hYztH7giwJ3hLmIX4qdYohHU0Peu49l2wjr2dd7Z3j5py1tzH7+FZfLJOl7Pmi/ylfhZrti2LdNbcS7Ebk7EYO8vnAYG75pj1042s27PYZaHR/d4Izlg8cn9ScZ6WyMWnUjZ2SakFRcBWSil1W49NiS6NUtahUQqDoWDWnKJxPC8f1OcbTMEKFBzkaUOlvF/flLskV8ZdWmgokoZaQw1R6OIO2holwyhv9UlRKtguUvp2keHjWZ4J21lmzxtO0bjbSrtoirYJtjIqdjB5/dGo/JADVf/Ckxajyal8B9PQfUWGny+WeSuYowa1YPe1gk+/tOxWevlWPH4mn6Aor1OCbQ2jYoJC2tpxZrksds4oXaRkj4IWgZoAqAmoPjxJ6kBNvZokOgU/3XlQmyKpjrwaQ7gSJDHLspQyhigVDMH+xKywplUMYrP2mFHaYKBNCX6Lw7NFgYWuDJaRRiw1RNL86ugUrUNR5NfuD4I4DIpYZwCXZZ1gmScMOo2XzrQPatYZpvg+CtbedwGWJxBKz7IxO0+6GG2BuaUuXlv3nndTdzxUdyx1v606Li1T2CeneUQtSqhRLl4CISJkJLwOyLhFGDcMZ97wXMNTcwPzs1+Ovx3Ur1tB91ujs5tAsrUBwftZgBWJsg1p/r9O1lcQzZpfFv73wKz5LNYdpnkGE1RPu4jWVfQfN6joTys+s8MzYxhPN65F0vcGDPnVQ8VWSlxrsUtN97hZ7DajK5eBqEbNssjcY6ad78QLbWmXec5GSuCQ10DzjpW0MZibjWlzE28CG9Pm+mIPfm4oCtqzOAWTbf78y3kLP5/N6/j5TN7EzxzI/GPmtnwf3m7m1dy6m7sgAbY6aJs5alJ0HWjo+Sdp3+PFvm9VEz6eUUrEXzn7jmeUuUVBDR6DFbBVe5P2UfT8ufWlaqCL2nBBTTXM3Br0bZuXz2Mhdp71DbNCyqww4XOZEGX2Ufj8uXwfvqginOcT+go23yx0vi6D8B4f1CaXzWMRs0lkzHV8y61QDOx2KC3zlN6pDpWm1Mpjqos8QOFwPu5dCCikBilAIaCIuTGzgl1Cp5jw1pd5TJGYStzcxfMAy/m+Cv8uLjH/xig8qI00N8HNsfXrboppQlqb4NZqlLdhjbzIXi4hxXgrjjUVxvf7h+Bz8Jf1RiRnv/HdbBoTUNwu81CsY/bg7Khd8BeKKb2bt0YpKkqhkqqhUsqyAoZqeUxJHkJ3mS4ymn2aL4H8feEu25fXIAEmecyCYB5SRrW2O3gXvAcobDNO4/lmneuplTNKDUYMdiftPJYFmdvJ9uc1mPTjJRWAYI3Pr5wWpe6H4M8XVacZ7KI6Y5BJKJRqQiSBPJpMBUgSBIf98ZQVHLIQhY46Tb3LfTet5MjUm2BEdA2wVKOdMKJNB1PcD2ERidp4J7r7mCkLzwiuoajtxsqCOUGDLIxsA/CBhoARMBjgCKPqLLac+e5baqF5DQy/Z80rhxrXgAP9G2HIfZlVhNi4sTtl5pFHjT3VE8Ww/eAOXpOybMnywAQ0hIbqy8L5Nt6E/dO3lMfI6kXVmfI7vsZOvzdqFFYcQoCckX3nnisUHhVtoSZbiUybiVKOG8y0IbbnJD7sLOrzYIxHujK9g3bOjHd33hIgJuwctQim+HtEJ98oUCyvY8AkYS/0i4aG+oYO1FktgE11eNndLzc0dYQ1038+oo+iZr6lsSvtC+7NfAsG6H+SlWRHSs35Zo1qLJCDyKvVg5pAULNiUzu8pvmVQ8OiWCaiWGuNKNaikDLhQo1RUcxeoSzQAC/MQIDgWQ2n26yoGkM1ad5yKk8FfRnPjQm3Qik1SgaqwQwR4mCjQ+lZBiMDGC1Ky8V3BweLYbaS9bIZpfIGZQwcRixjTQlk+xKoIUstkV9ayN4AzKJnNu5fC8LH4B1DHf703Ur8lYnDSReVqNu+O6qLgy7V/csq/17Xoq1TFHXACO+qxJeUUhwCDg0F2+Rb4YjBPJ/8XEmnmcRfOUSpdMpv1kLg2PP7Fvo9KgdXMpTdYF5PbvBtxwbftsseMudT1X9V7Ttbs+YHh1Ihu1+WEcbjZzcku0ZnMN7vegcgI9swczzSRSYuU4wMOWxpUYPpbSvTWyb0ljGStzLNV/TWWENvyXuit2oY8pjnQZ7JvGhQK+dhiqshGh2KrE9FP0w3lI/Hgd8/q/CbQRBgQmJ5+I4BPQ2hl1I7SkzR+yCmO4aJCS2Owo89TT2PAOT3vSTbbLLuqtkY96z9jsJ61nyU5Qt4JhVsjnTDMWGbLGIQhIyRmdRKDVMShFS7KMN7M/53va+jXfrT3ptxsNQuUzkjhW6jTpbqi1MFhEELrUZep6Zr3QUtqWMFbI2C65Q6xMJCAmEhwE8AzZP16dNKzXK6lXTr041PP6jUrZxuJN34dBiuGWQYkUZwdl+jgOrZB0SGFSVMpXZhAL1cY3m0RO/gq1on24gOQYQS61pH0eG7eWWrgwe3OqxPGNJKosBYorQ11trAApia0+0blTr86FceP3f+wsVV/Uix75CCvLYPiKljibRe6yOwRJLWz2Jdhiw1mCvUBBjIbQU+mfZBpbJraey6IGEpc+y6IBsq67VJAdWPNGF6OijhG0b+fJ+U3x/MDZreL8OWCR6yNptIgJ/127btaaWyD15R2wENl3hvbQeCzqR9nVIjOBxuyFSV+4z5vuGK921YMRONhaRSz4MAArg9xuPNQ51yLVTDQzLSKpOQlcYtzAdkjte4NgoqGvTvTJOeA4Am66zua1Jd9Hz1hWajL240GhusB2MbfGtu8K0x2MInKSs766yziuHhLep/9weDPfFEUffnJQyYJfgKsbaSWQmfWaRgHikOaRv+aRL8fBpn4O3CgsdYapQEfQS6Lhb0raNT0G5Om4m8ziLcBidh/qAEilB/plMpQws+eBHNp9eDpmSbQKH7wyFV2e39oyN0gn2mk/lmIkoXTGjMUH+Agxbr2KK3vDR5e5HiA93NoKSsAr2dJRgKblHiToyxBcUni1NNtfk5Vb8n1amZrXS3lnsw39TwBq7OgJScAfEp1v+4YXeyoe7El+rO/rXdmf5b6k6yrjv70Z2XhonLYtB5tRycGMZXtt8Q2CqAQiijdotQ//ioPBikI0db/pQR5iQ3gBJdTY5jr0/XnoSvOb/iPf98k0WNiflmOLJJCq9wk2QZXk1cC8ElWLk/HFl1GUibB7yF9YCL4WGS0g6cUQDQVySv0zmMJa9USeUXIqzgTcU7sSa7gtkiQo1HYfvi7EITp1H/mt+9uUcwbW4W6TzwZjuwjJtedlnp2EqUYMETwV4nmm8atjC/vki4AOxebuDYFFwEG+frMXosktQpuZsN3GqUtCnJcqGUm8SP4PpZc4O3eoMUEpdUo3qbEug1IqpTRPXFIpkqoixnHSbARBY4JkZtwmc2kVtTHb/cBMcLxHFIBNj6whRnhA4uofrdbDUH9sl2DbBByZtsk5JzvA6YrdJuStqlWCVzb6J1e9+I974VoQ42vzCwQQSJQPa/dTIiak3wKXJAUbYHkMrj3lQO+XhIb2ADqWl41sMgDGepU6Vb1fIMx0QY5eATlALsxvPP8QHHVpwwC/HN/X2yU+LXy0BNga3T7iNTIIAjU/mkkNm/9WT2cD6JtZ3gGjKZ/nZNN1bEDAwGS2J/dHM+hp/bCJEMzAqN8V4u02J4NXc3Mlden3wK4GB8nZbs1IpwLzlLD+2ihl60oANpmjlqOfZyodStGthmpc6WxOdaNezQoQdnj3unl4/Bl17Jgt0seW+SSlZkKxKXoYIaOJ7Tna4zbAFZoxSRABLvj9OAyq3yxokpyTARvf1s4wjHaMBjsyyalB5j0XCD+hJp0jskwlm2csJOvLPlM4Man6pqTChdbMKFNJHCvKXasP5m39cxgTNkIt6OCTznvMu0yBYoSElVlPPGFA8HqIixVWB/oKb3B4q9pyHwUCTOdJqaHZEA4TgghBI/bedbkKOR1/kcR0xFGzB3jKm+xow3GXZ5jakOLlVHO4lvZ5L1F3VqLAxVMpLL8PeJIrYr1GBT3gYEjhi8tMGmvM1gjpp5QnFRhylvE92cKGIsghDpmlj6MrzDW3Hg8lpPKRNL3Qafc8M+IGZLXYwNxWypWwd266OWusmQpW6DMm+pmyEvW+ry00QK1RRP5AxMXoDmOR6DZXM3J1PfN16xkTDRT9giy6IfyfEBEYyPjqQM94aUuMVT9roylNCWDHIzVsY4ZbiwVDFiMHXZAnCXe9g9BFsV9vyKXdCZYg0l6sJxbHx0ikvWaIziN+uQI8YyQ7W0GPMM4t7KpvM2UjQ2a25OCcbKYzBIlAJsDJtVvh2c1wqPvVmUsCFF43B/41hBYMLtWd7Igi232YQYPh6Ty930Po3TBbviHkHu7BrPbHfDE+NmNpJeaysJ/qu9CaVeY0LJ0VsYjsyQygzp0D2Sppk3gvWml3NrrGJbWX3Nl866L3uzeloXO/lWdlf12Bk87s3uWmu2GWZj6X/4gG6Ko8ojpLJZmFoe7TbVrsqFo+GNNneLW7BFlBU24vQGrvaILBPW/Xa44I/mf47DO4ELpj8iE0xjbYJ18nR/A+vXJ5XdzBllU2ArkWRl1kxXLk32SJd9btyDjr2Oj06VbEPN74Gzd06Vd3abMOu/hMmldR9aYNPC3w4XxBcFlkGNLRIgSlSFP2fJTEJBrWrXWHarr+k2S03WG/1op+8UAfgHugicuaOp3EVIzoGLFpsKS+dF+M1HR6ZyCRxCYbcIHHWJV+eX9FQRuL0PUNB1e3vZJ+WbuK0f1B/BBzzckH0SuPTKdxEcGTrGF1DnZS00Yt3HwSO9uOntz724WZmpaZYjOCkp3V5WOG+c9hv6EonJLarvLytGpRvnU5eo428qzRlxi+OBqS28s2pYZ0WQ4WGbgk7nDj8sG9VC9hItBKKjHx0Epm6h1RaLqftz9hDdnbOQCbU/xMGcpcKM5wBXXpPKGeKabzx2asFBxEqmugx3MNV1HBpsqusyHI9NdRmGabObZfqqstBDGvqKgivLxeagkvGgjq6guhkVXz7X+0U+g924Amg4QAm8crHnvxJcTFwZLkIK0mlzPVssqmlMIcjmKIbN6Q1saDTYQhNHXpJ5yEzmT1R7LDS1Wi1gRd4PFSuk3F+phSar6IVamNcPejFHwUE9wTJ+G36jAFbOEMR6mzfEd8uMT6DukB7xIRCVrB4q+tZdjYINjCXL9fNgQKJIHO6PLRG2oF11afhorU/b4irUziN/jtdny410E0CiCoYJDnIwAgY0XRuBEQyBwRjlA5f+3nX3tNktS8NEHgtCdnsUidaZBavI9zRe30Rc8nm+b6LPPUNfkxdacXgCHYRgwhMIUShaELBxTzJ9sEEvgddq+D7KuoDIefGxploLRTCAYtDRH6rKUJrr2F/V8Tff1/3voa/vpad/NTyU18tQNip9jRFzogpQK9Chss0B6adecipXa2cFxlq+HVTEHPfJOuo/hf0ngYY9Vcy0eRn+1+ykzefvvx0eaepK5lipuJ+sijo71KjSPBM0lXWacT+Bn2zQT+R6TXbrcBuRUMnjB0SJoqXDz4G9qk9bbu2cpqCEH5UIERS0nc78mv+SnjXPMcNQ2c0ucPwRctaU9E7Nmhe0r4Sz90ffTJvXZryJ5mszcgLz05nh5fc9JMvQhexsh/AnwUFEei1hHWak1063Z83LuoKeFYez6BXXiP+/PnM5NOAcyakNUVB1n+PxpVIpq9+uBKuXrnK+GQhOX90KMzcZXbY9FdNE6V8RuccMn2oOcP+SFrspDL2eH8q32GnGFK3PTJEzR5t+3FiTN0wlRyp57GpQSdxHUu3qICn2KmkATkPmIRxgqcApF45+Ez7WhNKQn3T/ySzw5vsrpsybzgwfhYkHF841xPaKEgn3E3IhI09w0pYnu9C08hQuQNOKp2ihGclTvACVMVRlOHsKy6LG4OAY+f/RixTmASujYTnEp4ARnnBgCBIIYd/pLctwyMg+w/AN5NPC0EXe3C2E+Rof0NSo2UafOABZQBHOQqoBf20GgSVdsNjUu8Q9QeYUzyjEpdTDU66fHG44I9clo+Z2Iawd5hIz6sJ5RIOgtHSPJ2vmaMNd+E0NZ8z1s3favKDZpcsTqlAxW5i/LJtNYS8ym5liAZAc7sbMdTALg9HeBWvA7ycHG/ZuXTKFSOaxeZf8Jh1lOOp9Mxw59UOEhsA1Trk3tsInZNyotAjcIx1nxOXxt9ljigL3qx0+cec9cTPaNSwwBk4v9Bcc7IjbY6FCWHfN1rPnDsj8fepAESx3Oe5b4MY+zUwhulWfO7CZ5B1tvu2BsvmrB7xsjIpds51bZ1xGQfsse5iAkEq/1501Tx1wv/uUPqhlLYncBX5BTKLlbuGhYG1t0CZ7x2ADWS31dgOY1qYNYIIFp4csbJ/l2hGR02Vt0czbMgVIZLKD3mWXhYIZ+JsviBDzLGsWOA7qO409rYuwsv3nEFCKAjhJC30/e2CwWnu2y78YdPyCeip9BudhGUI0JbATZtqYBCXdBXNElmRAFqa/sK0fAN2XeTbPUsk8B/VH8stUNKM+ml+2reT9ZRmAU788OOmls/BhVYvnj8vOjqpHZJJNIq7sndY7qrf7cbXmU1aN/YTVUX8/3a31ypDKLNs1pIhL/5nWwQo0YFD1hX0VH7bPHCvlEpo+zURz6QznL5fhnH73ysRfZeXXz9WRqRSO2TozaY31e6cync5zbC/EWfFu89OG1njL75ZgDqwrUn4yWPeDt1Tb3bvIcKXP1ky8Ej9C2qsnzZx7+jHEb0PIzsd4QTj/mOZ1yGkcIUuqBBmdB+eD9ScfLIdwlYQXGluXs98rwiYUNXfhyf/9/3qkB6MYpzswVMd09xtOsG8oss7fKuttyOeYHG86D9yFx7Q846xBi32NoyPcRno4+UU7d/hVQ+nh4Mlfzeuc86E8cBJMp/4Ztq05rB/jB+v2djhG+YXHNAXZNCx/BA7kOcc2oyml33L15YJjXJ7/1Du85/wfI2xZv2lx14MHCMyILSxHg2xaYvv1u5Qe1g+zDWUKbOHgWEkJHCRm01j+AcOgBAeH7slRvDu42OSAy/OkXdyZFzdsnBUbwnBQ0GNzTfTk/K28GepxUAKESRk6AwZvmj5d1AC4tyVix2t9XUAUPf9E0fzWoJ5P5RESJkk9/0QxNpKgkJBR/PwTRWskIUbCOwLV808U2UhCiARFwfNPFOlIQnBY53UMzOHk78G0BqhmBPPxV/1w8GTROFeVKDnue49tBMZozXfVyyEzttZ+j3uwVads7fewl0MMTNd+D4C6OoarLqZQDDn6lY9xv/MW4yXPGG852Pw0wtHU3C+dIsMBX55/IrvueVjuP/8EP7WAK37KgE5+SoHxJ7Lr8oCDuHId3GCAkMTJooVzA9jDZUfYk4L31l/phZsWKRDQCqma1HDqIMFslhBslmA3Swg3S4g2S4jXJHAPE+lh4nuY/tOQmTb7VOYcy8nHwzrClgXoOgIn/vztoA0NhXvt7eAoTqktbmHIcOnG6uptJa8snESqi0A1fAEEzsk81v30qioMxJd7MKXIookHXLYMdozGEBqQa+y2wP5+aDguwgsfxu5Pc7jqACufr0xe4IXoH83gMRg82sFjOHiMBo/x4DEZPNYGj/XBYzp4bAwem4PHscFjC498OUXG8fE4RH5TVf3mow9+wBi98GEZpBc+XNGhsStMx9mAjq8Qo/2aw8FocuRkptuyUP7RDB6DwaMdPIaDx2jwGA8ek8FjbfBYHzymg8fG4LE5eBwbPFb40j42MkwqGRXQLMMUcLkbOp2m/7Kmt+NOmzk2LvCb2Njh4FdUv8SrZMNRSVrcqnkTs8znroP9zJCXNYeKi10Lx+hgpVXxui8Mvgrcy2oWwZRYAmwiZLrcJHHRzEL23fCz0/kYNrcxzpVhj5vHTrMpaY1P6akuG11us1a1qSuDWbC0UBLjgYttjEQxZ4rhpEW1o1P5mNNct3iWZwvibr2cp763XAFJS2gE9g3q003dsKgGXquI2jGP3i50m2LvRA00aFCzWIitQfQAx3wC3RAgPa5hfMHYDuUzO6SmQ7h3E/k4hcXWfKIKbTdmjEKYpJZbbVI0lU+4i2PuYgOPW92jJh/Hyfhq5lbHfGrLXWxKqsrHYYyFwCP6iPufI/eDiKKpYtJpGlsuWoudJqajOeL+3LpXLJJ2knxtYXh3ydnTFhpjna9xK1BHOU3Rcr49wGmvonEKaVvV36bT5dGm2kVNGl9kxUzT/ZjNNrbiU9vp5SJCzrxJEU1g057msVuhGmXtYsdyPkVbYM/OJvj5btrOA7ebEpoq2QiiLCJq3qoNRbQDXn4RxRD/E9zSwPTRXpZRKSKnz3IEwqgDHjMgpT7Rt4sqwkGbTIeiko/IcoPuIC5QzAuC+ASxObAe6qr/EeXLrg6MZI7A2OBYt8lOZXA8qx+doozGKJsqMhzHbKHt3K8tABUdjpdhH8I2JjFlZZEeZasghjX1LbSL1Kk7m5riPBoaS4wBtcqiRZNHOzyG1KKdRzvdZixTLiXBV0xjQFQsG+GYtsA2yZwFDpOcNQpoKW9W8weTC9MrlmnC1FsWQquDecK+Oge1Ail77gzTOfZ7wzYK1SsZIhxrix0nA0Yt5OGQDBZmF0pMIONW6lbSDytUFMwJA1Sif9d8KdZALuEQZ2n6n2tctRCQaov9vhH7fQhWYr/vF3rlQwgbsd9H3Gix39dQrWl/y0PKwSUl3dvva6jjkG44nYN9wUpy1xro2I5Ek8k+kKb3m2BFPyI3H6kCRt2BhGlqHZV4d9NGwYbPwkAbfrzWG2grig5VigpfOmxLLGwtdmR8SRcHBZdbNUil37Em6AfLCnCfGew2jgIYOanjqJu7fahrRp53ABiKUCX6n2EHAO7WWgeAaARK2+bI7UAg7yKaEWniLNpn4dXKr10i9YoiFPj05vwBJGCOuOmN8H31Ui9agQMADDeqEr5h5MfBOMpjtvebjmXc++slkwrHXq7arsz5r6TtQIxGfIn31nYg6BQHgGiThkxVufYOANFwxdGGFRsOPwiH2MBNltk+tpqExUCbg1FnH2ARiNhUpw3izFnDxraSOv2ywTWPPFUkJnefDAMZPezjnD3rA8Iy0RQyXQC3qjYSm5T30HpJb2gzodJCaxbfIMdx3NaS9K3cJDY6LI9vlGWWs9gqy906WPEbcbmSTFV3LfFmCy2S6njjIn22sJV2gMXDzpSwkrPVFie9UZrUPpBWtX37GPY56nBy7ok+C5JufCt9Tmu7IjPP7mfw27yDNwL5EY54oTkI4BRrHJyP5ChxQZXnlRHiVWi5PodXJ1ExswqLVyfM4ezDLCQY1GO8YIuBDEnC9hYRRGxcCACWzLyCFdT9/OlNOliR+5VgiVcEPtav00c5rr70rp3728jeZtO19Pc1W63xMZRh7PxDI1eL4ICK7xDjr3vk4/e3DX/cuuBjH5pKQBvGn9O36p/URAO1ekBiE74xI++vzYSbFdw0If1vDcMKnR7rbhXrcqErDlmbi7XCihJb+TC+fWWwYiUhK/o3SVOVopgjsPrKg0pR7Jpt8bwPvJZYZQeqmgaqSKnJDLWyLq3Sd26W/PbbQU9OWjaBs29/4iMYi+E3L065Nw+fIATRmUi/pX1sT+6LdrUh1GhfrR50/9yBoWY3SGf0iIZa3dVUl6uJbdJkYNA+8woluGNKRDgSlDx/IP1vKkDNSh9YNmp9n8BWEDgPdnIHXwlw2TpRfAC5S9o85mn6Vl3HUJXGg5tEcY4vKmWOV1mfNtdDRR/4OVVzb6++/TsrrPSLJOyVZfUnoiyByrHrYbM8fbYf9Y33CBpL10F9zjRZi/2U/33GNI2jvhIRCwsrBL0CsoYK56tzJA41Km4oESyBI3Y2AVp+ur3MbuSn1/tPP9ElOvGz7dlH+P3Vrfz+RvW+uoNzun+zDaxuC1Ywg14F2AYYOd8J4YbyytaqZyJ6S48E8W/MoMSpsgjdeDnLDGHavDnj6iWuXIWt6RQ/hcdE8/wqzqo5bEqMyCEwf8HpN2zx7VFv1MJHh9kMr4XgDXLr0FMHcov9HWcInOn6gyWzCbNYSxDmigiMT5U8zXpmodczC3fhce0ufE1nH2VChCGqB4cvbuoD4mF7PwD56dNkD2WXkW7LEsjgiM+OFaAw1EUNAQr8jaRvbMfWgxHT8PDQCM7eB1wSzmwYV7w4pW25lMTjgqwLyxSBvJ+SIdIDSGLSVwWS+NKQcDP8ZQBJ5P7ftwVJDFJzgJyrA9JG6CkST0yNtgh5VXPVd1umhfXgsT93NTNFtoyoLkJIsmZS4obIfjWXnwbJlXXAbAj70EQYhrXPD8BzCkO17KaK4xSaYn6DWdRHcfh2PZ+uquxAmv6rmh5fkUuBEn/YxjETJYRt8I6MAXnxlT9Vh8yF69ipMHDqTr4l1n37Oh5A99wOcOWVvN4X1qycAqlpc+E6XENwl5fdNF8od+E6WN3yKU2dJWQH0xJzRxFPyX1zCacWjRICj/K3gPaR9sYMGw+8AfOmOsXw9Y7mq1XozRmKeJNt2rPmzRkWf9gJRwRH6DCqgblwHRqve3jqDI+/7q5qz0i0kpi35iOipIZPh/XiMAuv6i7re8wfRIDnytW0eWEHb5t8t/lmxhd2EGsPs48JON+8jrcPs+abVQnYp8hhVtS/UW84V5XqccbGXf2eWugbElkRudssGON4nkVeGPvwFSn8hK1UtAiJG722FEATEcsPm7IPAetD6/XH9s6mSodhMx42GWDuiSgxn9oB/0k+120IxcV9isvkGrsk9+a8mQRxbyKoNxT2ooTk2Av94IAMhz9Vs6y9FBgEwZW8a9xLVhLQS/eSvWsqH+dl1khHDI3D1TTmI1ApW+Dgs9hSFnBriWnMhybCpgOFsDreVZipogX8GNGfBzm4SQM6p4gjDI7avXB08pDST7NfUcjqJG5LIuLLMj4mthoBtcpTspI3hwkb0Q22AIqSQqQLeRsOJYA9D2+FoGsk2VBFZAo+LzAMThO1j0GSoSaNOd2WnVLIiQYmLFDa3MpqqlR0fRz2z5k78b92Dhd6VD7PfdSVMs/Itpb10IiNUQzQCHxwYH0xBEL4J9yHvlBNwTdmEBKKr85s+x6HpKu5Vm1/ZZMl6hDYhkXZh0Lmwib72FC+9J8YXVshjVAhfK0ok8Dbbwe36shZF5CFxjx2v67xlPi9lzCuFQ7S7jedqedjlo+rQ7nhlS8USo/wrVjas7KKKOwRLAn4FB6F3tSsQFEt8bgCr3+N0M9QJiFbx7CiiReUKlPIyBB6SWVX9tR2fn1qOxdi2bB2TLB3UJ+XxPPbvcrioH5avjy9PUXMwLqLHG5YtEeKYKrqtgucpWDKo4Px9oNE1/ym5rUZlv9Y5Au9yBc0qgvDfzoDLzQ7owxHB+WV7qDyIeV1Ze0l+O9vKkF1UbX5q3aWLuPoAXcMFsm1+7bwEnu6oUUyGt5Y+l0rTrRgg2TEBknkw5At7IoaZnbCUD6ZjIL5eFLUfV3xchfKAFnNBdZ4CNbYwxNXG8grg7XehzVun/X1wwjP20vhsVrTa25325262/obFC98HX5QHphk2qyOF4k34GKezuKHHRaa1oJhr2SfvkZksu2zbCaYDCy6RKiUjxWsirgrchGebhcJJS4+61ZN+c77o2ZxakZd+E2P+ViYgOgQmdwRXGZY3+Ayivpdez8qh/pwP3z9cOToYzsqU2iHGdsWnrAJ/Ckv/ANEgnEZnle3wPPcUynURsGALqT9gf37u6IEuw7R6wEctFhRdR9gCWVapDJjcdFyCrb3lYTVyyGeV3FVSTCgCnHRvvSUs1eGWN2HW/ntGV88nXlp3+/Q0n+U6vqKsFuw5CKeyi2z4XiKzQU88x1lvCscplthC8e3+YRUF6arRVSsVyw3ofiI6PHKwgjT5TsHhenGfGIUeEZmPSODXVRQUZ8VztSgcA2SojaFQ0haO8LDSFqbNoSkRh9JYfusrz8cDG7IgxmKdWR1OoPDqsGOO6h23IhZyQFaIorZWlUCRfpesi40l8vQI+G1tqJSMyeDfqnZdEUUayoeW0qEosgboAYy5HZ4F8y3yGHlEkhgOQVcHNRf314MYBmZRVcBJrMBTMa7Kj91gMJqu2lc69N9rmnWbjUj31i0wVbTVN4wl91qGj8tDGLFGor9qYM06FPYPinm2AkUypoeyJq+Fm2/+XeKtrcqtI39LaKt2d4IZRJoORA5Zy2WvvF3iqW/rrBU/1vEUs0vE6NYQrBaIxGjPXwpi4ExJUcKw2JgAk4MMdBADEymOKq6iIJva52uyNYeQhu29kXY37QWNShFOErwsvexkZOUajto75TrUMl+usl32WND0C1sVT6uFCaJT/TfG9X3psTDbS7wFoP9E3g/P6MkgI3Fdilli5DRGmy/5kXezLETioTok90uLs0i3xV/uaLfXlQfazhef0yL6a65pOku352pK9NdKFAlWssPFe6p2n7MwdhcL7tHL6yazpTcLyi+qdoYw9K9+9ARUvBh63Kco48vNKtb2036Zo1HYdo0XNgumCYehoE8BYtTOW9zOXYNn7MuiLWRKLf5+JzvM/N69g+x5jfmWCmgI3x+SYvk8JwuGpDWcPs6wkQZROLh/SyiQIhS7+6pwhyFerhO8XwHaQvdbocjHSmJBnCE1T2dIspmhg5PnG17+h58CtqDs5rBV4OvK9UBzeC7bg+cCcWjI5WQItL7Bn7PaekHaz1gSHR0ih1xGQ8W9lgN9qrla9DhJwu3mExeJjhlQibgc5rfnmO1d5sHoTp+YPuLBpns47tGP5T+/mv2v23L3djB4KSI7wxM5Tb3gE8L5J5gWxi5N5BHgkmQw0QbhHHkgWY3Nb6ubfWA7yWbgABT6JzPxf4PPMVf0lIJhlz7EYZ/x1E+UQpQdcC+fFwZ5jO0QB5RqwfAfI71FXRoNa0qwe/jB+6WetBgWgFU+nFAeEWyFVgvaZh3GmlMOO7DUkcRtKGdpxDx0EtfFYB/jhnqO2P+9IGjAsSsefoAb3Wt+O/psVArpbTHJvxBYQsXSLHncLXfoPfGBy1GtrubfnCLUHBm7+CewGygDyT8sHnkK+Twrd3mMsh5mAKvBHtJy2Sr0GSkb4EnQo7aARYtYfYEJ3D6xACApDzaggHagmG02XZVnKxH2wbYqlBRRO0irOZ5Y5gHAC2Bn9G2YigBprpYnAWY5H46Rwvd+W7T9LEtN6UKqOc0Rey8DjwdnSoMm7OJg80u8ZuSEdrFnu9pocEX/BwzZYVpzGfokZwJXcAXnLuEzy0pSH9DvEHYRSI76EOVFFqujoPyJVic8re2e1/mjHRFgQ3Spdz0LN9LiUXDR7h6MOFxiCO3a3Llil+Rpvs+Z+/Ak6Xp1zQ7rvANecxjYMRs/CKPac/I3I2wR4Eo8eFKnLP1kjkycBDHYfIeH7LMF3Dc1lD6Xh8QTCop+zrfhF8Qgi/9rYQv+mVTgtgfiEZyg151ePqydk/w5SgKbq3ypTDuSTFuEm8eccCGa6NXHL2ks9vEIQWk4Z40bU+Xpr0oQJLJfgEk+oL2XXhB5yYVB1sX3F31dNQbUIk3oFSlps1F3R46iR/1VFaVX+TQcf6GOQw8J43EAxn2nIzEc9JrMsUQJGaNpNz7g42m10sgmtriFLwqy8qtcqSYErRJNwvTxk5NXl+fkWn/2gwfBgaLMvVe0dXJqWj9X9DBXDW3/akHz222Ruhkt/mJ/4L2GnO4bvb16MNFArILzZANoryLZ8UxTL/WafPMgUpNzKyl4BsPklnzjP/6TdZ/QcOhps239TJi2j/jK+eIP/3F1Huim81Hc+gk5j0ki1QQ+UOKjZBeeYauxx47hipxDA28h+HCCHd6TuMwCX6i0iHrnaTJip+or3OYC6m+Y7phExvTZ+rGmbunhp27qyb0cBO6akKLY/f6Jtix2zcz1fJKG890L1vlpaGGqRaWQrDNP450fUU4e4wJLILiy3IU4BdH3zdbQpvI6Q+XchOGrH4cA6yEvr5dMdSLmq+RuDggvLjtQwNUbD2WBdTKkiXWZ7YvLTzNQD+r5RRCZs/DbO4UiN+n1xBDcwhbYkrunvJ2WF4touDC5083An+2ccVl4eL1LHQvcZmHXk5QfOXpvBcG+lOdCaakMPu4fGPCkyQIMPAp0lLBMwf4kmPWGvr1uy1dQnQKxTchD03zxw/wsYinJTbJ9WwZntaQU1KxpgkWqxXhnBdauOpCs9adg3IOpnSRkJ1ha26e1EW03OtgZJ7R4hMfCjyarTX4nA97oeUeJVU2QSwA1KQ7bKwsA2b5TKh+UPNJW520zM9gXTe4A+YoayCNe8IcbQ5EADmbYsoTmezpA4VhGxSxSXq5YjiFJnPUzrmvsFMK70HcVwy2HvNY7ftBNnlqIKgRuwSD0QnW4MCvyRxjNaFpQ/EpcqAXFeyKXLnsuWN187KAFBK8vqCzfPpAmt7Dq71nmVWT7I017RHG3BOEcSn8yYGbYtMAQZ0cZKc/NKa1Yh5Btu97HnMWL9/zKPqRhluHn6Yitbbdk2D1js+lj/n934+91ImAFXJ2m9c92aQU8tGUBMPQ7aJJQXlQKbl893EtoT3Pa9zThs+ZD4SCLXlaCklqWA6zJHRQKcr4iUmKj1oDf99Po4R57jhLzHja8ot89dSWJ37lWy44i0MYU2Jxse4Nvehj48Pl4CsmLcynmdI1cxZDrDcx4oJnqOnhNTlHAm+RprFO5S2hIWfH7IjAd730Qzek/64+EI6SgXDkxaOV9cLR/JB0tNhBOJL5JiNaoj4MyUZpbqsVG2P/PV0xx1nzokY8DNmwvaBxUzRrolkouHu9QGX7ApXNfsFHmwhceLRvm6XFOTdYaGoXVHsMLzy5Rwky23CDqZAP71lFHAkWB5GJhpdgmXKjQlnBtPaidiu9clQyG4pYsYlktj7Hu5HMkvchmX2PY/+1h0fiZYmsUjLDjqFsELX/6zMynV6bGRXIgv5myx7DwiubI2HZaABswctm36tkMz/CLIh9Z0RAkfUwXgD1VLLTIGaF2jBmxSVkEcPy3rT5zoBtCaeUKC1/N9LZQPoaloXMcBeNdLHaOWzSzWEpdyBHDAl+fSzYUNbvEWRvUKRh+H7P/79hTOhkWKjEHvxdCJXBexEqzeWrvCKhEgylBTuCT/bXxPV6aj1qfL0uGUbLsXLfDjKb/vtIx7D9/7FqF/X9Ck6ClZKVHTRClx1lzU7kNC4Ae/QrHA6ew6Zd+AZ8h7B/rbwSJ5fd3i+5qQ7HK+6AGS33KOwV8lrj23gp6rEpD76HzvpfKVnryI3URdgrOG/o4rNdtpdCqKCz3R6sapf50lR+RnFn+bnn/kL1blEvfIOd5xawpqk8ci98Q7u/ALmwZbKEI0B9RUrR9chd8ME4w6yXe0UNIQoq8DO53Wq5i8jO7H3dxa7zhWc0x9GZfHDWvHBBnjM8f1ueEzy/oIfNnC98Q2JCiPOVvb9A5KNZ85rmeCohm+8lwYooyVf4ki2z7HZDhtIU3jGVY/Q1heISSOkChxI2y4RgABI6mKPbxBSeKWpy63LyYHaYg/YiKIC+6LsJkb0nHjU1ZxfIuN13QN0dZYdhPQ3HF2w1BhEFoPIY8kiFg0PwhpbfVZiy/pES5ehrf/xn//DhWfOMIXX4rT/4P//kP3z9v/it7FBwHu+P/oun//AbP/8//vLMoeCckbIX5HzUZp+CYUB2u5tAZAk2vXI/hVgPImO31ItqgWdRBHMMvkXJR0mCtTf7zsKqYbYHotfy8iPVEyPYAdzvCT5U7y6q7FMOLvuM8qIGY7Namc2PYga+f3X3YwW3pDj9JHgNr7egSDji99/gFq/c5Fl5mVzuQtE2lJwsd7vp7+jK/05dF1wwkCifPxw8+TDDFUGWc5/s8P7HXfT4/zYLgxcV394hF70DUutDQLtzHFMrzI7A+Zys+2R5zK6gXxDKbZkdIevm2hJhQy6Bg0pW1GolaudsPqR0+m915bGXsceewMk2ueHh5O9B4nKrycDsMvuU++kEGCGyHX4jeOzwxeAXRb0ClzaXgA4AY24rk1U3IVYGpmSrgoc7TJE4mXDBsniHiPGn+HmG3+KaSooO30whQpycuw0GNAhXEXpfo4lsQTCFQV3oD3TgsnK/SqfBMhWcvCcxRP0b7lT/hjvFN9yl/0uuP70iDpg3FQFHNRnkDvq5A38bPPJRYZDPDPKZfj4j+WrIl1w+31Z2/Lx8voler+f0g4VB/usLjr5iB/ltP7+V/C3km7h8vjryNS6fr+Hbt8h/c3G5ewOLEPn2FxHyRYN8UT9fJPmaBFtVZS+fc9JDECGYjp5Wk0WMIvGgSNwvEkuRbVixyHIx3H/QwtrCb2M9VDFdJLJE9KtI+lUkUkVKtR4Zzn3b5XPDxFtlRYZ82SBf1s+XSb7ttLVHqYCSoczuYhxlxgdlxvtlxqXMEar3KJAy4/z/nbBkRf/4jYPo9SiWtyn+/27UfUMBzkR6ULfu162lbkfbaHuPV179YKGpSUd6lEhN10Dt0+tRSK5Hukdj/HUP/39vD0y6R3t6tJs/EI3RNT3aK0XzHqUolfXoGv5Q4Pr2Ho1L8j441fdop7ztJ0vjPdolbx+gmHb2aErerqUx2oU2+O2DNIUWSd6m+f/XkUZdBdrG+4doHIDskzwfpr14pD3I8KEe5fz1ev7/TI8I367v0XX84QDl9OEezUjRgz3aiVL7e/Rh/nAD7aJ9PfqAJN9IU0i6Vt4+QrvpAz36oLx9lIiu7dG0vN1EOX0QbfDbx2gaLR6Qt1n+/yHaD0BuQNt4v5k+AEBulDwfpxk80vXIcHOPDvLXW/j/t/boAL7d0qND/OEwHaSP9+hWKbrQo2tR6iM9+jh/uI0+SDf26KOS/As0jaSb5O0TdB19tEcfk7dP0gG6qUez8nYHHaSPoQ1+W6RZtHhY3o7x/z9NHwEgt6FtvM/RLXRbr0cL/HYnfRRg/UKP5vj9U/QJ+hgdoBm6gT5AU3zNAUIV1eUw6m6aEHXi7S58sCzlmOgoH0MVrFtIioleh+Z7pfut//jVH4RlscPtebDYUlKDjuKpXtIkzZdUp4ke3d6hiV5JO1BXlX+SttDtyNnodajRK2krTZS0A9dr9DpU75U0OZx9pOxdxK3VaRI/W3sd2tpDy9tRwRbChy29ku4aLtMYftnuga3RXXhK0fo21FCn1Le+fTj/VtpCDeSs9TpU66FbR0rajrsrcIczoN+0rW1SMqWtDLOvHne/cHtbPLDbhss0h1+2cMPw6N2GpwStt0pqYrx861uG87dQOXIGvQ4FPYRpcCVtYQbQoaRXUmvTtlIpmVALP61eh1q9UmSgJvRVvvvpcJnaaG1ouOQriVAEr7gOZ8+DRdjrUNhDXKRWyVcpV+CMQGCGXyIBxgjqcR9nKQEvex3SPYiowyV7XraC1qzm+z5SneaX/+rf/9VfI7wRKrU4EuDdHgCUhkyPS+IiElhe9LilYLjo+noiqSHukaFrIGiFGxXr4Xx5J8fSljbWVDT0Yjx0Ee1CLQwdN6GxKALqAr2NekO93LSeSGqIsWbs8dCtKybQ7fPQmSuEbv8m0O19b9DtvjR0H3pX0F3rYQI8tBk8bIos7YOg6MOlLKxoIhytdRgcIZUA8teeB4uxDoiy00VLOWAc2wBGqeCbT/5nv4ZzJkZaSTf2YfS4GKMPshtOlyAkkEGldrikobALe6UQKQFdj+aiLukOfvFtpB09/BJIY7brCb2DnSOKRDTtGw37jQabVsNdjkq6WRAX+OmD4DofQTVBl2wfIeFINRR1kcJwWroOYxpzT0OK8W0U3NFuBx52QRibbAnGP+objfqNmk2rqWA/6FHgyRc2dx/HdBfYzeVhv8nDbt4f7Le9B9gt/YInF8OGgoC/OwCDbrlMR0YbGExeC+41yxOlS3G/r6OEwLP7Vr5egaH2FLRB53//zdefg9bcQx3S3ADZQ7zC0iE0OTLpfdH19fi5Cu5KnwTdxhsUExgPszvg8DzctFbG6cKG0IV0B68q7xq6myCJfaJHn5Jdz6VhXXyXsB7bBNaPQcD7ZLVTSN4L5Leiik/16M5qi3RpyGfRxzuwZeHd0bvoB93tLZjmKaRP0Bygpkx2jJ6jbAy9cNxS7uCaoEPo8CK2Nk4/yGEPmSmRHubhQy37mxCP0hwdRjfp01xQg6SjnkgoI/0s5Zqv2+mTwEuCjZ7TD5bEUs7Y+s7C2JYj4rDG3q2JWtX2AUp+N9dbV0Tvk3KkJlYXB1WMguxTUDb9WJd5hohZuszHERlAl/kW3B1qynwrdCumzCdIuTc5QJlyb+gy304mH2NfZb5UMJBje9QYih7sDX1YP8zax+3ZPG3L5vOYJrJ58YpTvcK6sbPuzbgzzWpZtjzbms1Dl7y9+v6M7omLmO0VsYuqz9/WPe8xAm10FWbzhRd0jy3DoBdeU/UkjHEH+cgOV0bRSPZwpP1eDxrxEYjY+i0aqS8cqS8eqc+uq68+2hU2rbMj9UUj9YUj9cXr6rPrcDANNK7BwX6qj7RRG2kjuQzM8TocXC+a901wWh+pr7auvnAdDggG1kP1JSP1jVJL/QpwcNMGdHADhZfA8+XGbT0d3HxJuhodt+gK6OC2NXQVXwIH4RXgYG4DOrjrKtPB7VeZDu64ynTwyxvQwS9dZTr4zFWmg89eZTr44gZ0cN9VpoNTV5kO7r3KdLC8AR08cJXp4KGrTAcPX2U6WNXA9BokPKXfFyU01mHhcf2+SKG1Dg3n9Puihdo6PDyre2Ld8oym1iVW8salQRWPoaf1GipqjNQxSnStdXXE3gqucYkxaF16pPOQ4Aa5hY0YdNFw6R3wH+gbPjEtb95Lexm6HMW9t4a+Ynkq3mDeDOeG45u+pPwTX4bO62sp+jl9yXkTXoai1+PXimnMGrKuX6LWTWjlxbVzLbwErSQb08oLa7F/qfla34BWxqnhmoueQn6kxV7r6lLIy1eZQi5eZQr5/t8Ihbx6FSjkB1eBQl55vxSSpbh4XvVxPqNknKTcjPrvX2DDiAoNM+offVuMI6phmVH/3TNiHNG77KEqLDNSwkX3failvWhte/G69ux7as9Ke0mf5qU9u7a9aF174XtqL5H2Gn2ak/bCte3Zde3FG7R3uaN8aCw0NUu5+JRtaZttl8HuJIXpkcWPzWP8JHlIER4aFE2rRm9WNRDRCC9Jb1YlUMrgxfZmlSXY9ETTSvVmOegm2zCPwewDLsLweBUT+RT2PmzS42+B4cBDY3AEH6Mm3z8vF8OkYsnxiNY+pK2BaYr1Kg0y2e3v0RKIjZLYFIjtWSb4V2e3Q9nx7QC2JBmb+yKabZpwmypNA6XSp5o6HNyzNIilmwcCYbRfuUcYq8q70MFIcZI3sIXyXs3wc3Z8OYFbOTKVB7hc06k7YMBDph36EMNOwxwcF0TJBRtZG47nfM1XcqSIO3x5CgWudrTbbSr3MGIyTZtpp92FA6TGAyXtIdC4U+6ZA2+mUMDgbiVSDpceSjS4VXbSZBjdh0THpCWemCazjBwPkzr89tuPrr6iDrHV/uHV1a+svqYPmWd13x/rcS3RxacBVdfBSsXQeKBm2VJUUthQeyjlvO5/f1YPEmBXBKQ97b1v4d/iVlf1rPnZjK8Kr85WBQBjIhaSP5txZnnWNCpfPXh5eKe785VH49P8YOQ2d76XDi4OCTCgs127+q6+D8Px3risZAMs669Ls5VngyRzLGfTb6LvPME9eFWLW+8PONz7LWp/BWTh7TdnEfGJzeFPOWjsXp8B8ZDOZpsc6H3WXA/yQvc0YhFPoMu7YfYsQRUC8aLk0NoFk9AchxAU0+1JBE3+uPsQbGePFGqKewoz/cFl6rijwV/CnuI+9cA9wrfx5cY98/XKIlT50K27JRSsWS54XC58XTteLFfHlxFcH32+cwpOPErsxDjUsrtwXleXXw8HiubQr0pe3e/8pna7/RXn/gonE8y5jO9jQVRdvghnzxExcYPVOg7MXLw8i3BCDK6mEPGEXNzmG6y8GWY4CG1t3YWnES12AMnwtVWiGWVrOR8qW+LhmUE8vAH4bAQcHdSZRBx353Eljzuv5esWRhfs7Pk6Y7LuNcQG3OJWjWQY8xme6WeYLG/VY+4Z49u+4FFnll1yq/7dx/Uw6hA14hkYQGccofV3DMK19a3s9lQlC+XCW/Xvfk2maIhY3Re+NlwRBpjNWCU8g4vXtuS/1zb5nqz/Hg5o4x9UtLHlkrTxm9qHmxrqoNyEVtFGSgEo/6kD4hnjwzMH7qfZrDm3gwL3g2zWvLmdAncxmzWvbWeu+v1t8CTfwc+vbi1nzevy/SfQov90OwXZ9TKTVDWTZ71nf/+6RC2sojBVUG9/A58eTO9nD8gvwgRwFE86xOb1gPc7evDtOe/SUHmW/UC7xqlCu9e3wt9m1vyYOaR7zb/+SF7/b//6irz+tX/9vk4RlRmGqTZN/xLG36tJ+o/tqjp5uvelz3/+5ImTS6eX6f6l+890v6xuPPDRAzceuHHm/jPLp5a+rE6ePnv81Mn76NTJ5aXu8VMHTy2d/sLyF3vUW1rup504c98SDSd86XT79JkHT9MXl47ft9Slz586/oXREved7C0fP31iafTr504u+2qou/TA0vFltXzmDN1//PSXq89nuv2i1Pvy/Z87c6rXL91bPtNduo8+d+rMiXYFjfrclz7/+aUuLXW7Z7qqt9xdOn6/fxkBfmaG7j/Z6508/QVaOn3fzJnPz3A16uTpE2e63aUTy1VXTnxxaeSzh2vt5/uOLx/vfxztMqFPnz/epc8dP9FWVbXdEwDg/uPLJ77YL/HgydP3nXmQeid/ZWmAIu7d8pcfWNpkZLg/6xvlr9WwnDhz/wPdpV7v5JnTdP/S8hfP3KfwX6bG1RalVKJiVVORqqtQpcqqhgpUUxk1prRqKXexkf6BDZRVoYpUrBJVU3WVqqZqqXG1Ve1QU2qv2qc+rD6qblWfUv+JOqF66jH1e+qP1V8oo5Vva/Rv3P9t8X9b/d+E/9vm/zK1qL7HkSeMEhgAa1ONq50qVzcqp46rR9UfKa0fxS2wgbY60olu6ExPatI36Dl973D7VZtVW2hju9qudqgdalJNqp1qp9qldqkpNaV2q93qGnWNmlNz6r32P5Duq9U1f4/6v6/4v8f83+P+7wn/d/4q9F+v6ovD7VbtVe08qZ5Uv6Z+TZ1T59RX1VfVr6tfV7+hfkM9pZ5SX1NfU19XX1d0WKnVRCmtldqjlWoppS4cUUrVpH97lHzjvvpvW5VSsXIXxtNjEjxk8M+s+Res+WfX/AtH/rnzW9KltVWtLVplj/y/2P9L/L+a/1f3/1L/r+H/Nfmfu7g13VdVH/sOZuNbVBLXonqY2kbQNGO6pdwbW9P7Y27bqoT/KR6vTCX+OWIfncTnATXWGJaMv1fPGCV5pneelcYznoxWVp6NNlplNeV+NpHWbvhlLVj9/wA=")))), e) });
}
const Xt = "deflate", Dn = "deflate-raw", Gr = "deflate64-raw", Nn = "gzip", On = [Xt, Dn, Nn], Ln = [Xt, Dn, Nn, Gr];
let Kr;
function zn(t, e, n = {}) {
  if (!(t ? On : Ln).includes(e))
    throw new TypeError("Unsupported format: " + e);
  {
    const a = new Error("WASM module not loaded");
    throw a.cause = Kr, a;
  }
}
class ue {
  constructor(e = Xt, n) {
    return zn(!0, e, n);
  }
}
class fe {
  constructor(e = Xt, n) {
    return zn(!1, e, n);
  }
}
ue.requiresModule = !0;
fe.requiresModule = !0;
ue.supportedFormats = On;
fe.supportedFormats = Ln;
function jr(t, e) {
  return le(t, e);
}
gr(jr);
Yt({
  CompressionStreamFallback: ue,
  DecompressionStreamFallback: fe
});
Jr(Yt);
Ma(Yt);
class xt extends Error {
  constructor() {
    super("ZIP cache could not be written. Free some disk space, then Resume.");
  }
}
let Kt;
async function x(t, e = {}) {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length || (Kt ||= chrome.offscreen.createDocument({ url: "offscreen/index.html", reasons: [chrome.offscreen.Reason.BLOBS], justification: "Validate archived image bytes, decode dimensions, and create local blob URLs for browser downloads and exports." }).finally(() => {
    Kt = void 0;
  }), await Kt);
  const n = await chrome.runtime.sendMessage({ target: "offscreen", action: t, ...e });
  if (!n?.ok)
    throw n?.error === new J().message ? new J() : n?.error === new xt().message ? new xt() : new Error(n?.error || "Image validator did not respond");
  return n.data;
}
async function E(t) {
  t && await x("release", { url: t }).catch(() => {
  });
}
async function se(t, e, n = "application/json", a = !1) {
  const { blobUrl: r } = await x("export", { text: t, mime: n });
  try {
    return { id: await chrome.downloads.download({ url: r, filename: e, conflictAction: a ? "overwrite" : "uniquify", saveAs: !1 }), blobUrl: r };
  } catch (s) {
    throw await E(r), s;
  }
}
const bt = 3;
function ct(t, e = 0) {
  return Math.max(2e3 * 2 ** Math.max(0, t - 1), e);
}
async function Qr(t, e) {
  const n = ya(t, e);
  if (!n.length)
    return t.status = "skipped", t.errorMessage = e.mode === "original" ? "No original URL was exposed by the archive. No URL was invented." : "No observed or supported thumbnail URL is available.", await z(t), 0;
  t.status = "transferring", t.attempts++, await z(t);
  let a = 0, r = !1;
  for (const s of n)
    if (!t.candidateFailures.some((i) => i.url === s.url && /Image HTTP (400|401|403|404|410|422)\b/.test(i.reason)))
      try {
        const i = new URL(s.url).hostname;
        if (!H.includes(new URL(s.url).origin) && !sa.includes(i) && !await chrome.permissions.contains({ origins: [`https://${i}/*`] })) {
          t.candidateFailures.push({ url: s.url, reason: "Optional permission for this original host was not granted" });
          continue;
        }
        const o = await x("image", { url: s.url });
        if (o.failure) {
          if (t.candidateFailures.push({ url: s.url, reason: o.failure }), o.status === 429) {
            a = ct(t.attempts, o.retryAfterMs), r = !0;
            break;
          }
          (!o.status || o.status >= 500) && (r = !0);
          continue;
        }
        if (t.resolvedUrl = s.url, t.quality = s.quality, t.bytes = o.bytes, t.sha256 = o.sha256, t.mime = o.mime, t.width = o.width, t.height = o.height, t.blobUrl = o.blobUrl, t.savedPath = pa(t, o.ext), await z(t), e.destination?.kind === "zip")
          return await x("stage-image", { jobId: e.id, recordId: t.id, url: o.blobUrl }), t.status = "staged", t.downloadId = null, await E(t.blobUrl), t.blobUrl = null, t.errorMessage = null, await z(t), 0;
        if (e.destination?.kind === "folder") {
          const c = await x("save-image", { jobId: V(e), path: t.savedPath, url: o.blobUrl });
          return t.savedPath = c.path, t.status = "downloaded", t.downloadId = null, await E(t.blobUrl), t.blobUrl = null, t.errorMessage = null, await z(t), 0;
        }
        return t.downloadId = await chrome.downloads.download({ url: o.blobUrl, filename: t.savedPath, conflictAction: "uniquify", saveAs: !1 }), t.errorMessage = null, await z(t), 0;
      } catch (i) {
        if (i instanceof J || i instanceof xt)
          throw t.status = "queued", t.attempts--, t.errorMessage = i.message, await E(t.blobUrl), t.blobUrl = null, await z(t), i;
        r = !0, t.candidateFailures.push({ url: s.url, reason: "Image fetch, decoding, or browser download failed" }), await E(t.blobUrl), t.blobUrl = null, t.downloadId = null;
      }
  return t.errorMessage = t.candidateFailures.at(-1)?.reason || "All allowed image candidates failed", r && t.attempts < bt ? (t.status = "queued", t.nextAttemptAt = Date.now() + (a || ct(t.attempts))) : t.status = "failed", await z(t), a;
}
async function pe(t, e = !1, n) {
  if (n?.destination?.kind === "zip") {
    const { ids: r } = await x("zip-matches", { jobId: n.id, records: [t] });
    t.status = r.includes(t.id) ? "staged" : t.attempts < bt ? "queued" : "failed", t.errorMessage = t.status === "staged" ? null : "ZIP image collection was interrupted", await E(t.blobUrl), t.blobUrl = null, t.downloadId = null, await z(t);
    return;
  }
  if (n?.destination?.kind === "folder") {
    t.savedPath && t.sha256 && t.bytes !== null && await Ve(V(n), t.savedPath, t.sha256, t.bytes) ? (t.status = "downloaded", t.errorMessage = null) : (t.status = t.attempts < bt ? "queued" : "failed", t.errorMessage = "Folder write was interrupted before completion", t.nextAttemptAt = Date.now() + ct(t.attempts)), await E(t.blobUrl), t.blobUrl = null, t.downloadId = null, await z(t);
    return;
  }
  let a;
  if (t.downloadId !== null ? [a] = await chrome.downloads.search({ id: t.downloadId }) : t.savedPath && t.blobUrl && (a = (await chrome.downloads.search({ query: [t.savedPath.split("/").at(-1)], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === t.blobUrl), a && (t.downloadId = a.id)), a?.state === "complete") {
    if (a.exists === !1 ? (t.status = "failed", t.errorMessage = "The completed file was removed outside the extension") : (t.status = "downloaded", t.errorMessage = null), a.filename) {
      const r = a.filename.replaceAll("\\", "/"), s = r.lastIndexOf("/ArchiveRoot/");
      s >= 0 && (t.savedPath = r.slice(s + 1));
    }
    await E(t.blobUrl), t.blobUrl = null;
  } else (a?.state === "interrupted" || !a && e) && (t.errorMessage = a?.error || "Worker/browser interrupted an uncommitted transfer", t.status = t.attempts < bt ? "queued" : "failed", t.nextAttemptAt = Date.now() + ct(t.attempts), await E(t.blobUrl), t.blobUrl = null, t.downloadId = null);
  await z(t);
}
function Tt(t) {
  return { state: "pending", filename: `kemono-discord_${t.serverId}_${tt(t.serverName, "server")}_${t.id.slice(0, 8)}.zip`, blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null };
}
async function Mn(t) {
  const e = t.archive;
  if (!e || !["ready", "saved", "saving"].includes(e.state)) throw new Error("The ZIP is still being prepared");
  if (e.state === "saving") return;
  await E(e.blobUrl);
  const n = await x("zip-open", { jobId: t.id });
  e.blobUrl = n.blobUrl, e.bytes = n.bytes, e.downloadId = null, e.state = "saving", e.error = null, t.manifestState = "saving", await R(t);
  try {
    e.downloadId = await chrome.downloads.download({ url: n.blobUrl, filename: e.filename, conflictAction: "uniquify", saveAs: !0 });
  } catch {
    e.state = "ready", e.error = "ZIP saving was cancelled or blocked. Click Save ZIP to try again; images remain cached.", t.manifestState = "pending", await E(e.blobUrl), e.blobUrl = null;
  }
  await R(t);
}
async function _r(t, e) {
  t.archive ||= Tt(t);
  const n = t.archive;
  if (n.state === "pending") {
    n.state = "building", n.error = null, t.manifestState = "pending", await R(t), await x("zip-build-start", { job: t, records: e });
    return;
  }
  if (n.state !== "building") return;
  const a = await x("zip-build-status", { jobId: t.id });
  if (!a) {
    n.state = "pending", await R(t);
    return;
  }
  Object.assign(n, a), a.state === "ready" ? (t.status = "finished", await R(t), await Mn(t)) : a.state === "failed" ? (t.status = "finished", t.manifestState = "failed", await R(t)) : await R(t);
}
async function Bn(t, e = !1) {
  const n = t.archive;
  if (!n || n.state !== "saving") return;
  let a;
  if (n.downloadId !== null ? [a] = await chrome.downloads.search({ id: n.downloadId }) : n.blobUrl && (a = (await chrome.downloads.search({ query: [n.filename], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === n.blobUrl), a && (n.downloadId = a.id)), a?.state === "complete" && a.exists !== !1) {
    n.state = "saved", n.error = null, t.manifestState = "saved", await E(n.blobUrl), n.blobUrl = null;
    const r = await N(t.id);
    for (const s of r) s.status === "staged" && (s.status = "downloaded");
    await at(t, r);
  } else (a?.state === "interrupted" || a?.exists === !1 || !a && e) && (n.state = "ready", n.error = "ZIP download was interrupted. Click Save ZIP to retry without fetching images again.", t.manifestState = "pending", await E(n.blobUrl), n.blobUrl = null, n.downloadId = null, await R(t));
}
const qn = new qe();
function L(t) {
  return t.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), t;
}
async function ke(t) {
  const e = await Ze(t);
  if (!e) throw new Error("Archive job was not found");
  return e;
}
async function Pe(t) {
  const e = Ot(t);
  if (!e) throw new Error("Open or paste a Kemono or Pawchive Discord server or channel URL");
  const n = new URL(t).origin, r = (await chrome.tabs.query({ url: `${n}/discord/server/*` })).filter((y) => y.id !== void 0 && Ot(y.url || "")?.serverId === e.serverId && new URL(y.url).origin === n).map(async (y) => {
    try {
      const u = await chrome.tabs.sendMessage(y.id, { type: "DISCOVER_CHANNELS" });
      return u?.serverId === e.serverId && Array.isArray(u.channels) ? u : null;
    } catch {
      return null;
    }
  }), [s, ...i] = await Promise.allSettled([qn.server(e.serverId, n), ...r]), o = s.status === "fulfilled" ? s.value : null, c = i.flatMap((y) => y.status === "fulfilled" && y.value ? [y.value] : []), d = la(e.serverId, o, c);
  e.serverName = d?.name || null, e.channelName = d?.channels.find((y) => y.id === e.channelId)?.name || null;
  let h = null;
  return o || (h = `${s.status === "rejected" && s.reason instanceof Error ? s.reason.message : "Server metadata is unavailable."} ${d?.channels.length ? "Using channel links from the open page; hidden or unloaded channels may be missing." : e.channelId ? "Current-channel scanning is still available." : "Open the server page, reload it, and discover its channel links again."}`), { scope: e, server: d, warning: h, apiChannelCount: o?.channels.length || 0, domChannelCount: d?.channels.filter((y) => y.sources?.includes("dom")).length || 0 };
}
async function Te(t, e) {
  if (t.type === "DISCOVER") return Pe(t.url);
  if (t.type === "LIST") {
    const a = (await W()).sort((r, s) => s.createdAt.localeCompare(r.createdAt));
    return Promise.all(a.map(async (r) => ({ job: r, totals: te(r, await N(r.id)) })));
  }
  if (t.type === "DETAIL") {
    const a = await ke(t.jobId), r = await N(a.id);
    return { job: a, media: r, totals: te(a, r) };
  }
  if (t.type === "DASHBOARD")
    return await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") }), null;
  if (t.type === "START") {
    if (!["thumbnail", "best", "original"].includes(t.mode)) throw new Error("Invalid quality mode");
    const { scope: a, server: r, warning: s, apiChannelCount: i, domChannelCount: o } = await Pe(t.url), c = new URL(t.url).origin, d = !!t.allChannels || !a.channelId && !t.channelIds.length, h = [...new Set(d ? r?.channels.map((f) => f.id) || [] : t.channelIds.length ? t.channelIds.map(X) : a.channelId ? [a.channelId] : [])];
    if (!h.length) throw new Error(s || "No channels were discovered in this server. Open the server page and try Discover channels again.");
    if (h.some((f) => f !== a.channelId && !r?.channels.some((g) => g.id === f))) throw new Error("Selected channel was not discovered in this server");
    for (const f of await W()) ["scanning", "downloading"].includes(f.status) && (f.resumeStatus = f.status, f.status = "paused", await R(L(f)));
    const y = {
      service: "discord",
      id: crypto.randomUUID(),
      serverId: a.serverId,
      serverName: a.serverName,
      mode: t.mode,
      tryOriginal: !!t.tryOriginal,
      channels: h.map((f) => {
        const g = r?.channels.find((w) => w.id === f);
        return { channelId: f, channelName: g?.name || null, postCount: g?.postCount ?? null, offset: 0, pages: 0, messageIds: [], pageFingerprints: [], coverage: "pending", terminal: null, failures: [], attempts: 0, nextAttemptAt: 0, error: null, domMessages: 0 };
      }),
      status: "scanning",
      resumeStatus: "scanning",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      warnings: s ? [s] : [],
      autoManifest: !1,
      manifestState: "pending",
      manifestDownloads: [],
      apiNextAt: 0,
      mediaNextAt: 0,
      scope: d ? "server" : h.length === 1 ? "channel" : "selected",
      sourceUrl: `${c}/discord/server/${a.serverId}${a.channelId ? "/" + a.channelId : ""}`,
      discoveredChannelCount: r?.channels.length || h.length,
      channelDiscovery: i ? o ? "api+dom" : "api" : o ? "dom" : "current-channel",
      destination: { kind: "zip" }
    };
    await R(y);
    const u = await chrome.tabs.query({ url: `${c}/discord/server/*` });
    for (const f of u) f.id && Ot(f.url || "")?.serverId === y.serverId && new URL(f.url).origin === c && chrome.tabs.sendMessage(f.id, { type: "SCAN_DOM" }).catch(() => {
    });
    return { jobId: y.id };
  }
  if (t.type === "DOM") {
    const a = we(t.url), r = we(e.tab?.url || "");
    if (!a || !r || r.channelId !== a.channelId || r.serverId !== a.serverId || new URL(t.url).origin !== new URL(e.tab.url).origin) return null;
    const s = new URL(t.url).origin;
    for (const i of await W()) {
      if (i.serverId !== a.serverId || new URL(i.sourceUrl || H[0]).origin !== s || !["scanning", "indexed", "paused"].includes(i.status)) continue;
      const o = i.channels.find((d) => d.channelId === a.channelId);
      if (!o) continue;
      const c = t.records.slice(0, 1e4).filter((d) => d.serverId === a.serverId && d.channelId === a.channelId).map((d) => ({
        ...d,
        jobId: i.id,
        service: i.service,
        serverName: i.serverName,
        channelName: o.channelName,
        originalUrl: Q(d.originalUrl),
        discordCdnUrl: Q(d.discordCdnUrl),
        thumbnailUrl: Q(d.thumbnailUrl)
      }));
      o.domMessages = Math.max(o.domMessages, t.messageCount), await at(L(i), He(await N(i.id), c));
    }
    return null;
  }
  const n = await ke(t.jobId);
  if (n.archive?.state === "saving" && (t.type === "DESTINATION" || t.type === "ACTION" && ["download", "retry"].includes(t.action))) throw new Error("Finish or cancel the current ZIP save before starting another");
  if (t.type === "DESTINATION") {
    if (n.status === "downloading") throw new Error("Pause the job before choosing its save destination");
    const a = await N(n.id);
    if (t.kind === "folder") {
      const r = t.directoryId || n.id, s = await mt(r);
      for (const i of a)
        ["downloaded", "staged"].includes(i.status) && (!i.savedPath || !i.sha256 || i.bytes === null || !await Ve(r, i.savedPath, i.sha256, i.bytes)) || i.status === "transferring" ? (i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await E(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = n.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null) : i.status === "staged" && (i.status = "downloaded");
      for (const i of n.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await E(i.blobUrl);
      n.destination = { kind: "folder", name: s.name, ...t.directoryId ? { directoryId: r } : {} }, n.manifestState = "pending", n.manifestPaths = [], n.manifestDownloads = [], n.archive = void 0;
    } else if (t.kind === "zip") {
      const r = a.filter((i) => ["downloaded", "staged", "transferring"].includes(i.status)), s = new Set((await x("zip-matches", { jobId: n.id, records: r })).ids);
      for (const i of r)
        i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await E(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = s.has(i.id) ? "staged" : n.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null;
      for (const i of n.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await E(i.blobUrl);
      n.destination = { kind: "zip" }, n.archive = Tt(n), n.manifestState = "pending", n.manifestDownloads = [], n.manifestPaths = [];
    } else if (t.kind === "browser") {
      if (a.some((r) => ["downloaded", "staged"].includes(r.status)) && n.destination?.kind !== "browser" && n.destination) throw new Error("Create a new job to switch collected files to individual Browser downloads.");
      n.destination = { kind: "browser" }, n.archive = void 0;
    } else throw new Error("Unsupported save destination");
    return n.destinationError = null, await at(L(n), a), null;
  }
  if (t.type === "EXPORT") {
    const a = await N(n.id), r = zt(n), s = n.id.slice(0, 8), i = `${r}/${t.format === "csv" ? "links" : t.format === "failures" ? "failures" : "manifest"}-${s}.${t.format === "csv" ? "csv" : "json"}`, o = t.format === "csv" ? ga(a) : ht(n, t.format === "failures" ? a.filter((d) => d.status === "failed" || d.status === "skipped") : a), c = t.format === "csv" ? "text/csv;charset=utf-8" : "application/json";
    return n.destination?.kind === "folder" ? await x("save-text", { jobId: V(n), path: i, text: o, mime: c }) : await se(o, i, c), null;
  }
  if (t.action === "pause") {
    ["scanning", "downloading"].includes(n.status) && (n.resumeStatus = n.status, n.status = "paused");
    for (const a of await N(n.id)) a.status === "transferring" && a.downloadId !== null && await chrome.downloads.pause(a.downloadId).catch(() => {
    });
    n.destination?.kind === "zip" && n.archive?.state === "building" && (await x("zip-stop", { jobId: n.id }), n.archive.state = "pending");
  } else if (t.action === "cancel") {
    n.status = "cancelled", n.destination?.kind === "zip" && (await x("zip-stop", { jobId: n.id }), n.archive?.state === "saving" && n.archive.downloadId !== null && await chrome.downloads.cancel(n.archive.downloadId).catch(() => {
    }), n.archive?.state === "building" && (n.archive.state = "pending"));
    for (const a of await N(n.id))
      a.status === "transferring" && a.downloadId !== null && await chrome.downloads.cancel(a.downloadId).catch(() => {
      }), ["queued", "transferring"].includes(a.status) && (a.status = "skipped", a.errorMessage = "Cancelled by user", await E(a.blobUrl), a.blobUrl = null, await z(a));
  } else if (t.action === "resume") {
    if (n.status !== "paused") throw new Error("Only paused jobs can be resumed");
    n.destination?.kind === "folder" && n.resumeStatus === "downloading" && await mt(V(n)), n.destinationError = null, n.status = n.resumeStatus;
    for (const a of await N(n.id)) a.status === "transferring" && a.downloadId !== null && await chrome.downloads.resume(a.downloadId).catch(() => {
    });
  } else if (t.action === "retry") {
    for (const a of n.channels) a.coverage === "incomplete" && (a.coverage = "pending", a.attempts = 0, a.error = null, a.nextAttemptAt = 0);
    for (const a of await N(n.id)) (a.status === "failed" || a.status === "skipped") && (a.status = n.autoManifest ? "queued" : "discovered", a.attempts = 0, a.nextAttemptAt = 0, a.errorMessage = null, a.candidateFailures = [], await z(a));
    n.status = n.channels.some((a) => a.coverage !== "complete") ? "scanning" : n.autoManifest ? "downloading" : "indexed", n.manifestState = "pending", n.destination?.kind === "zip" && (n.archive = Tt(n));
  } else if (t.action === "save-zip") {
    if (n.destination?.kind !== "zip") throw new Error("Select ZIP output first");
    return await Mn(n), null;
  } else if (t.action === "clear-cache") {
    if (n.destination?.kind !== "zip" || ["scanning", "downloading"].includes(n.status) || n.archive?.state === "saving") throw new Error("Finish or cancel ZIP saving before clearing its cache");
    await E(n.archive?.blobUrl || null), await x("zip-clear", { jobId: n.id });
    const a = await N(n.id);
    for (const r of a) ["downloaded", "staged"].includes(r.status) && (r.status = "discovered", r.attempts = 0, r.nextAttemptAt = 0);
    return n.archive = void 0, n.status = "indexed", n.autoManifest = !1, n.manifestState = "pending", await at(L(n), a), null;
  } else if (t.action === "download") {
    if (n.status === "scanning" || n.channels.some((s) => ["pending", "scanning"].includes(s.coverage))) throw new Error("Pause or finish the scan before downloading the indexed results");
    if (!n.destination) throw new Error("Choose a save folder or explicitly select Browser downloads before starting the batch");
    n.destination.kind === "folder" && await mt(V(n));
    const a = await N(n.id);
    let r;
    n.destination.kind === "zip" && (r = new Set((await x("zip-matches", { jobId: n.id, records: a.filter((s) => ["downloaded", "staged"].includes(s.status)) })).ids), n.archive = Tt(n));
    for (const s of a) (s.status === "discovered" || r && ["staged", "downloaded"].includes(s.status) && !r.has(s.id)) && (s.status = "queued", s.attempts = 0, s.nextAttemptAt = 0, await z(s));
    n.status = "downloading", n.autoManifest = !0, n.manifestState = "pending", n.destinationError = null;
  }
  return await R(L(n)), null;
}
async function $r(t) {
  if (!t.channels.some((n) => ["pending", "scanning"].includes(n.coverage))) {
    t.status = t.autoManifest ? "downloading" : "indexed", await R(L(t));
    return;
  }
  if (Date.now() < t.apiNextAt) return;
  const e = t.channels.find((n) => ["pending", "scanning"].includes(n.coverage) && n.nextAttemptAt <= Date.now());
  if (!e) {
    t.channels.some((n) => ["pending", "scanning"].includes(n.coverage)) || (t.status = t.autoManifest ? "downloading" : "indexed", await R(L(t)));
    return;
  }
  try {
    const n = new URL(t.sourceUrl || H[0]).origin, a = await qn.channel(e.channelId, e.offset, n), r = fa(e, a), s = da(a, { serverId: t.serverId, serverName: t.serverName, channelId: e.channelId, channelName: e.channelName, service: t.service }, t.id, n);
    if (t.autoManifest) for (const i of s) i.status = "queued";
    t.channels[t.channels.indexOf(e)] = r, r.coverage === "complete" && r.postCount !== null && r.postCount !== r.messageIds.length && t.warnings.push(`Channel ${r.channelId}: metadata post_count=${r.postCount}; API unique messages=${r.messageIds.length}.`), t.apiNextAt = Date.now() + 1100, await at(L(t), He(await N(t.id), s));
  } catch (n) {
    e.attempts++, e.error = n instanceof Error ? n.message : "Page scan failed", e.failures.push({ offset: e.offset, reason: e.error, at: (/* @__PURE__ */ new Date()).toISOString() });
    const a = n instanceof O && n.retryable;
    if (n instanceof O && n.status === 429 && (t.apiNextAt = Date.now() + ct(e.attempts, n.retryAfterMs)), a && e.attempts < bt) {
      const r = ct(e.attempts, n.retryAfterMs);
      e.nextAttemptAt = Date.now() + r, t.apiNextAt = e.nextAttemptAt;
    } else e.coverage = "incomplete";
    await R(L(t));
  }
}
async function ts(t, e) {
  t.manifestState = "saving", t.manifestDownloads = [], await R(L(t));
  try {
    if (t.destination?.kind === "folder") {
      t.manifestPaths = [];
      for (const s of t.channels) {
        const i = `${$t({ ...t, channelId: s.channelId, channelName: s.channelName })}/channel-manifest.json`;
        await x("save-text", { jobId: V(t), path: i, text: ht(t, e, s.channelId), overwrite: !0 }), t.manifestPaths.push(i), await R(t);
      }
      const r = `${zt(t)}/manifest.json`;
      await x("save-text", { jobId: V(t), path: r, text: ht(t, e), overwrite: !0 }), t.manifestPaths.push(r), t.manifestState = "saved", await R(L(t));
      return;
    }
    for (const r of t.channels) {
      const s = `${$t({ ...t, channelId: r.channelId, channelName: r.channelName })}/channel-manifest.json`, i = await se(ht(t, e, r.channelId), s, "application/json", !0);
      t.manifestDownloads.push({ ...i, path: s, state: "in_progress" }), await R(t);
    }
    const n = `${zt(t)}/manifest.json`, a = await se(ht(t, e), n, "application/json", !0);
    t.manifestDownloads.push({ ...a, path: n, state: "in_progress" }), await R(t);
  } catch (n) {
    n instanceof J ? (t.manifestState = "pending", await Wt(t, n)) : (t.manifestState = "failed", t.warnings.push("One or more manifest saves failed. Use Export JSON to save the current state."), await R(L(t)));
  }
}
async function Wt(t, e) {
  t.resumeStatus = "downloading", t.status = "paused", t.destinationError = e.message, await R(L(t));
}
async function es() {
  const t = await W(["scanning", "downloading"]), e = Math.max(0, ...t.map((a) => a.apiNextAt)), n = Math.max(0, ...t.map((a) => a.mediaNextAt));
  for (const a of t) {
    if (a.status === "scanning") {
      (Date.now() >= e || a.channels.every((o) => !["pending", "scanning"].includes(o.coverage))) && await $r(a);
      return;
    }
    if (a.status !== "downloading") continue;
    if (a.destination?.kind === "folder")
      try {
        await mt(V(a));
      } catch (o) {
        await Wt(a, o instanceof Error ? o : new J());
        return;
      }
    let r = await N(a.id);
    for (const o of r) o.status === "transferring" && (o.downloadId !== null || ["folder", "zip"].includes(a.destination?.kind || "")) && await pe(o, !0, a);
    r = await N(a.id);
    const s = r.filter((o) => o.status === "transferring").length, i = r.filter((o) => o.status === "queued" && o.nextAttemptAt <= Date.now()).slice(0, Math.max(0, 2 - s));
    if (i.length && Date.now() >= n) {
      const o = await Promise.allSettled(i.map((h) => Qr(h, a))), c = o.find((h) => h.status === "rejected");
      if (c?.status === "rejected") {
        if (c.reason instanceof J || c.reason instanceof xt) {
          await Wt(a, c.reason);
          return;
        }
        throw c.reason;
      }
      const d = o.flatMap((h) => h.status === "fulfilled" ? [h.value] : []);
      a.mediaNextAt = Date.now() + Math.max(a.destination?.kind === "zip" ? 250 : 1100, ...d), await R(a);
    }
    if (r = await N(a.id), !r.some((o) => o.status === "queued" || o.status === "transferring")) {
      if (a.destination?.kind === "zip") {
        await _r(a, r);
        return;
      }
      a.status = "finished", await R(L(a)), a.autoManifest && a.manifestState === "pending" && await ts(a, r);
    }
    if (a.destination?.kind === "zip") {
      const o = r.filter((c) => c.status === "queued");
      if (o.length) {
        const c = Math.max(n, a.mediaNextAt, Math.min(...o.map((d) => d.nextAttemptAt)));
        return Math.max(100, Math.min(1200, c - Date.now()));
      }
    }
    return;
  }
}
async function ns() {
  for (const t of await W()) {
    t.destination?.kind === "zip" && await Bn(t, !0);
    try {
      for (const e of await N(t.id)) e.status === "transferring" && await pe(e, !0, t);
    } catch (e) {
      if (!(e instanceof J || e instanceof xt)) throw e;
      t.status === "downloading" && await Wt(t, e);
    }
    if (t.manifestState === "saving") {
      if (t.destination?.kind === "zip") continue;
      if (t.destination?.kind === "folder") {
        t.manifestState = "pending", t.status === "finished" && (t.status = "downloading"), await R(t);
        continue;
      }
      for (const e of t.manifestDownloads) {
        const [n] = await chrome.downloads.search({ id: e.id });
        e.state = n?.state === "complete" ? "complete" : n?.state === "in_progress" ? "in_progress" : "interrupted";
      }
      t.manifestDownloads.length !== t.channels.length + 1 ? (t.manifestState = "pending", t.status === "finished" && (t.status = "downloading")) : t.manifestDownloads.every((e) => e.state === "complete") ? t.manifestState = "saved" : t.manifestDownloads.some((e) => e.state === "interrupted") && (t.manifestState = "failed"), await R(t);
    }
  }
}
async function as(t) {
  if (!t.state || !["complete", "interrupted"].includes(t.state.current || "")) return;
  for (const n of await W()) {
    n.destination?.kind === "zip" && n.archive?.downloadId === t.id && await Bn(n);
    for (const r of await N(n.id)) r.downloadId === t.id && r.status === "transferring" && await pe(r);
    const a = n.manifestDownloads.find((r) => r.id === t.id);
    a && (a.state = t.state.current === "complete" ? "complete" : "interrupted", await E(a.blobUrl), n.manifestDownloads.length === n.channels.length + 1 && n.manifestDownloads.every((r) => r.state === "complete") && (n.manifestState = "saved"), a.state === "interrupted" && (n.manifestState = "failed"), await R(L(n)));
  }
  const [e] = await chrome.downloads.search({ id: t.id });
  e?.url.startsWith(`blob:chrome-extension://${chrome.runtime.id}/`) && await E(e.url);
}
function Et(t) {
  try {
    const e = new URL(t);
    return H.includes(e.origin) && !e.username && !e.password;
  } catch {
    return !1;
  }
}
function ie(t) {
  if (!Et(t)) return null;
  const e = new URL(t), n = /^\/(fanbox|patreon)\/user\/(\d+)(?:\/post\/(\d+))?\/?$/.exec(e.pathname);
  return n ? { origin: e.origin, platform: n[1], creatorId: n[2], postId: n[3] || null } : null;
}
function De(t) {
  return `${t.origin}/${t.platform}/user/${t.creatorId}${t.postId ? `/post/${t.postId}` : ""}`;
}
class rs extends qe {
  validate(e, n) {
    const a = e;
    if (!a || typeof a != "object" || typeof a.id != "string" || !/^\d+$/.test(a.id) || a.user !== n.creatorId || a.service !== n.platform) throw new O("Post response belongs to a different creator or service.", 422);
    if (a.attachments != null && (!Array.isArray(a.attachments) || a.attachments.some((r) => !r || typeof r != "object"))) throw new O("Invalid post attachment list.", 422);
    if (a.content != null && typeof a.content != "string") throw new O("Invalid post text.", 422);
    return a;
  }
  async profile(e) {
    const n = await this.json(`/${e.platform}/user/${e.creatorId}/profile`, e.origin);
    return n && n.id === e.creatorId && typeof n.name == "string" ? n.name : e.creatorId;
  }
  async total(e) {
    const n = await fetch(`${e.origin}/${e.platform}/user/${e.creatorId}`, { headers: { Accept: "text/html" }, credentials: "omit", redirect: "error", signal: AbortSignal.timeout(1e4) });
    if (!n.ok) return null;
    const a = /Showing\s+[\d,]+\s*[-–]\s*[\d,]+\s+of\s+([\d,]+)/i.exec(await n.text()), r = a ? Number(a[1].replaceAll(",", "")) : NaN;
    return Number.isSafeInteger(r) && r >= 0 ? r : null;
  }
  async posts(e, n) {
    const a = `/${e.platform}/user/${e.creatorId}`;
    let r;
    try {
      r = await this.json(`${a}${e.origin === "https://kemono.cr" ? "/posts" : ""}?o=${n}`, e.origin);
    } catch (i) {
      if (!(i instanceof O) || i.status !== 404) throw i;
      r = await this.json(`${a}${e.origin === "https://kemono.cr" ? "" : "/posts"}?o=${n}`, e.origin);
    }
    const s = Array.isArray(r) ? r : r?.posts;
    if (!Array.isArray(s)) throw new O("Post list is not an array.", 422);
    return s.map((i) => this.validate(i, e));
  }
  async post(e) {
    const n = await this.json(`/${e.platform}/user/${e.creatorId}/post/${e.postId}`, e.origin), a = this.validate(n?.post || n, e);
    if (a.id !== e.postId) throw new O("The API returned a different post.", 422);
    return a;
  }
}
const Fn = /^\/[0-9a-f]{2}\/[0-9a-f]{2}\/[0-9a-f]{64}(?:\.[a-z0-9_-]{1,16})?$/i, Ne = /\.(png|jpe?g|webp|gif|avif|bmp|tiff?|svg|heic|heif|jxl)$/i;
function Rt(t) {
  if (typeof t != "string") return null;
  try {
    const e = new URL(t);
    if (e.protocol !== "https:" || e.port || e.username || e.password) return null;
    const n = Nt(e.href) ? "/thumbnail/data" : "/data";
    return !_t(e.hostname) || !e.pathname.startsWith(n + "/") || !Fn.test(e.pathname.slice(n.length)) ? null : (e.hash = "", e.href);
  } catch {
    return null;
  }
}
function ss(t, e, n) {
  if (typeof t != "string" || !t) return null;
  try {
    const a = new URL(t.includes("://") ? t : `https://${t}`);
    a.pathname === "/" && !a.search && !a.hash && (a.pathname = `/data${e}`, a.search = `?f=${encodeURIComponent(n)}`);
    const r = Rt(a.href);
    return r && new URL(r).pathname === `/data${e}` ? r : null;
  } catch {
    return null;
  }
}
function Oe(t, e, n, a) {
  const r = t.path;
  if (typeof r != "string" || !Fn.test(r)) return null;
  const s = typeof t.name == "string" && t.name ? t.name : r.split("/").at(-1), i = Ne.test(r) || Ne.test(s) ? "image" : "file", o = new URL(e.origin).hostname, c = Number.isSafeInteger(t.node) && t.node >= 1 ? t.node : null, d = c ? `n${c}.${o}` : o === "pawchive.pw" ? "file.pawchive.pw" : o, h = n === !1 ? null : ss(t.server, r, s) || Rt(`https://${d}/data${r}?f=${encodeURIComponent(s)}`);
  return { id: `${a}:${r}`, name: s, path: r, kind: i, thumbnailUrl: i === "image" ? Rt(`https://img.${o}/thumbnail/data${r}`) : null, originalUrl: h };
}
function Le(t, e) {
  const n = typeof t.has_full == "boolean" ? t.has_full : null, a = [];
  for (const r of [t.file, ...t.attachments || []]) {
    if (!r) continue;
    const s = Oe(r, e, n, a.length + 1);
    s && !a.some((i) => i.path === s.path) && a.push(s);
  }
  for (const r of (t.content || "").matchAll(/(?:src|href)=["']([^"']+)["']/gi)) {
    let s = null;
    try {
      s = Rt(new URL(r[1].replaceAll("&amp;", "&"), e.origin).href);
    } catch {
    }
    if (!s) continue;
    const i = new URL(s).pathname.replace(/^\/(?:thumbnail\/)?data/, ""), o = a.find((d) => d.path === i);
    if (o) {
      Nt(s) ? o.thumbnailUrl = s : n !== !1 && (o.originalUrl = s);
      continue;
    }
    const c = Oe({ path: i }, e, n, a.length + 1);
    c && (Nt(s) ? c.thumbnailUrl = s : c.originalUrl = n === !1 ? null : s, a.push(c));
  }
  return { id: t.id, title: t.title || `Post ${t.id}`, content: t.content || "", published: t.published || null, hasFull: n, media: a, embed: t.embed || null };
}
function Hn(t) {
  return `${t.source.platform}_${t.source.creatorId}_${tt(t.creatorName, "creator")}`;
}
function Zn(t) {
  const e = ot(t.path), n = e.indexOf(t.quality);
  if (n < 0 || e.length !== n + 3 || !Wn(e[n + 1], t.postId)) throw new Error("Unsafe post archive path");
  return e.slice(n).join("/");
}
function Wn(t, e) {
  return t.startsWith(e + "_") || /^(?:\d{4}-\d{2}-\d{2}|unknown-date)_/.test(t) && t.slice(t.indexOf("_") + 1).startsWith(e + "_");
}
function is(t) {
  return `${Fe(t.published)?.slice(0, 10) || "unknown-date"}_${t.id}_${tt(t.title, "post")}`;
}
function Yn(t, e) {
  if (t.kind !== "image" || t.quality !== "full res" || !t.fallbackUrl || !Rt(t.fallbackUrl) || !Nt(t.fallbackUrl)) return null;
  const n = ot(t.path), a = n.indexOf("full res");
  return Zn(t), n[a] = "thumbnail", { ...t, id: t.id.replace(":full res:", ":thumbnail:"), quality: "thumbnail", url: t.fallbackUrl, path: n.join("/"), status: "queued", bytes: null, attempts: 0, nextAt: 0, error: null, synced: !1, fallback: !0, fallbackReason: e, fallbackChecked: !1 };
}
function Xn(t) {
  const e = Hn(t);
  return { ...t, tasks: t.tasks.map((n) => ({ ...n, path: `${e}/${Zn(n)}` })) };
}
function os(t) {
  const e = t.lastIndexOf("."), n = e >= 0 && /^[a-z0-9_-]{1,16}$/i.test(t.slice(e + 1)) ? t.slice(e) : "";
  return tt(n ? t.slice(0, e) : t, "attachment") + n;
}
function cs(t, e) {
  const n = [], a = e.quality === "both" ? ["thumbnail", "full res"] : [e.quality];
  for (const r of t.posts) for (const s of a) {
    const i = `${t.destination?.kind === "folder" ? "" : Hn(t) + "/"}${s}/${is(r)}`;
    for (const [o, c] of r.media.entries()) {
      if (c.kind === "image" ? !e.images : !e.files || s === "thumbnail") continue;
      const d = s === "thumbnail" ? c.thumbnailUrl : c.originalUrl, h = { id: `${r.id}:${s}:${c.id}`, postId: r.id, quality: s, kind: c.kind, url: d, path: `${i}/${String(o + 1).padStart(3, "0")}_${os(c.name)}`, status: d ? "queued" : "unavailable", bytes: null, attempts: 0, nextAt: 0, error: d ? null : "Full-resolution file was not archived." };
      e.quality === "full res" && e.fallbackToThumbnail && c.kind === "image" && c.thumbnailUrl && (h.fallbackUrl = c.thumbnailUrl), n.push(d ? h : Yn(h, h.error) || h);
    }
    e.text && n.push({ id: `${r.id}:${s}:text`, postId: r.id, quality: s, kind: "text", url: null, path: `${i}/post.txt`, status: "queued", bytes: null, attempts: 0, nextAt: 0, error: null });
  }
  return n;
}
const nt = (t) => {
  if (!t || typeof t != "object" || Array.isArray(t)) throw new Error("Invalid post sync JSON.");
  return t;
};
function Vn(t) {
  return t.replace(/^(\d+:(?:thumbnail|full res):)\d+:(\/)/, "$1$2");
}
function Jn(t) {
  const e = nt(t);
  if (!["thumbnail", "full res", "both"].includes(String(e.quality)) || ["images", "files", "text"].some((n) => typeof e[n] != "boolean")) throw new Error("Invalid content selection.");
  if (e.fallbackToThumbnail !== void 0 && typeof e.fallbackToThumbnail != "boolean") throw new Error("Invalid thumbnail fallback selection.");
  return { quality: e.quality, images: e.images, files: e.files, text: e.text, ...e.fallbackToThumbnail !== void 0 ? { fallbackToThumbnail: e.fallbackToThumbnail } : {} };
}
function he(t, e) {
  if (t.source.origin !== e.origin || t.source.platform !== e.platform || t.source.creatorId !== e.creatorId) throw new Error("This JSON belongs to a different website, service, or creator. Open that creator’s profile to sync it.");
}
function ls(t, e, n = !1) {
  const a = nt(t);
  if (typeof a.id != "string" || a.id.length > 500 || !["thumbnail", "full res"].includes(String(a.quality)) || !["image", "file", "text"].includes(String(a.kind)) || typeof a.path != "string" || a.path.length > 2e3 || !Number.isSafeInteger(a.bytes) || a.bytes <= 0) throw new Error("Invalid downloaded file in sync JSON.");
  const r = Vn(a.id);
  if (!r.startsWith(`${e}:${a.quality}:`) || (a.kind === "text" ? r !== `${e}:${a.quality}:text` : !/^\/[a-f0-9]{2}\/[a-f0-9]{2}\/[a-f0-9]{64}(?:\.[a-z0-9_-]{1,16})?$/i.test(r.slice(`${e}:${a.quality}:`.length)))) throw new Error("Invalid downloaded file ID in sync JSON.");
  let s = a.path;
  if (n) {
    const o = ot(s), c = o.findIndex((d) => d === a.quality);
    if (c < 0) throw new Error("Invalid legacy archive path.");
    s = o.slice(c).join("/");
  }
  const i = ot(s);
  if (i.length !== 3 || i[0] !== a.quality || !Wn(i[1], e)) throw new Error("Downloaded paths must stay inside this post’s quality folder.");
  return { id: r, quality: a.quality, kind: a.kind, path: s, bytes: a.bytes };
}
function ds(t, e) {
  const n = nt(t), a = n.schemaVersion === 1 && typeof n.sourceUrl == "string" && Array.isArray(n.files) && Array.isArray(n.posts);
  let r;
  if (a) r = ie(n.sourceUrl);
  else {
    if (n.format !== "archive-ripper-post-sync" || n.version !== 1) throw new Error("Choose sync.json or a post archive manifest.json. A failures.json is not a download history.");
    const d = nt(n.source);
    if (r = ie(`${d.origin}/${d.platform}/user/${d.creatorId}`), !r || d.origin !== r.origin || d.platform !== r.platform || d.creatorId !== r.creatorId) throw new Error("Invalid creator in sync JSON.");
  }
  if (!r) throw new Error("Invalid creator in sync JSON.");
  const s = { format: "archive-ripper-post-sync", version: 1, source: { origin: r.origin, platform: r.platform, creatorId: r.creatorId }, creatorName: String(a ? n.creator || r.creatorId : n.creatorName || r.creatorId).slice(0, 300), updatedAt: (/* @__PURE__ */ new Date()).toISOString(), selection: Jn(n.selection), posts: [] };
  if (he(s, e), !Array.isArray(n.posts) || n.posts.length > 1e5) throw new Error("Invalid post list in sync JSON.");
  let i = 0;
  const o = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Map();
  if (a) for (const d of n.files) {
    const h = nt(d);
    if (!["staged", "downloaded"].includes(String(h.status))) continue;
    const y = String(h.postId), u = c.get(y) || [];
    u.push(h), c.set(y, u);
  }
  for (const d of n.posts) {
    const h = nt(d);
    if (typeof h.id != "string" || !/^\d{1,40}$/.test(h.id) || o.has(h.id)) throw new Error("Invalid or duplicate post ID in sync JSON.");
    o.add(h.id);
    const y = a ? c.get(h.id) || [] : h.files;
    if (!Array.isArray(y) || (i += y.length) > 2e5) throw new Error("Invalid file list in sync JSON.");
    const u = y.map((f) => ls(f, h.id, a));
    if (new Set(u.map((f) => f.id)).size !== u.length) throw new Error("Duplicate file ID in sync JSON.");
    u.length && s.posts.push({ id: h.id, title: String(h.title || `Post ${h.id}`).slice(0, 500), files: u });
  }
  return s;
}
function Gn(t) {
  const { origin: e, platform: n, creatorId: a } = t.source;
  return { format: "archive-ripper-post-sync", version: 1, source: { origin: e, platform: n, creatorId: a }, creatorName: t.creatorName, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), selection: t.selection, posts: [] };
}
function ze(t, e) {
  if (!t) return structuredClone(e);
  he(e, { ...t.source });
  const n = structuredClone(t), a = new Map(n.posts.map((r) => [r.id, r]));
  for (const r of e.posts) {
    const s = a.get(r.id);
    if (s) {
      const i = new Map(s.files.map((o) => [o.id, o]));
      for (const o of r.files) i.set(o.id, { ...o });
      s.files = [...i.values()];
    } else {
      const i = structuredClone(r);
      n.posts.push(i), a.set(i.id, i);
    }
  }
  return n.selection = e.selection, n.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), n;
}
function us(t, e, n) {
  if (!["downloaded", "staged"].includes(e.status) || !e.bytes) return;
  let a = t.posts.find((i) => i.id === e.postId);
  a || (a = { id: e.postId, title: n, files: [] }, t.posts.push(a));
  const r = { id: Vn(e.id), quality: e.quality, kind: e.kind, path: e.path, bytes: e.bytes }, s = a.files.findIndex((i) => i.id === r.id);
  s < 0 ? a.files.push(r) : a.files[s] = r, t.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
}
const vt = new rs(), Kn = (t, e = 0) => Math.max(e, 2e3 * 2 ** Math.max(0, t - 1));
async function fs(t) {
  const e = await wa(t);
  if (!e) throw new Error("Post archive was not found.");
  return e;
}
function jt(t) {
  t.posts = [], t.detailQueue = [], t.tasks = [], t.status = "scanning", t.resumeStatus = "scanning", t.scan = { offset: 0, pages: 0, total: t.source.postId ? 1 : null, complete: !1, error: null, attempts: 0, nextAt: 0, fingerprints: [] }, t.nextAt = 0, t.error = null, t.archive = void 0, t.autoDownload = void 0;
}
async function jn(t) {
  const e = t.autoDownload;
  if (!(!e || !t.scan.complete)) {
    t.autoDownload = void 0, t.status = "ready", await D(t);
    try {
      await _n({ type: "POST_DOWNLOAD", jobId: t.id, selection: e, destination: "folder" });
    } catch (n) {
      t.autoDownload = e, t.status = "paused", t.resumeStatus = "downloading", t.error = n instanceof Error ? n.message : "Could not start sync.", await D(t);
    }
  }
}
async function _() {
  for (const t of await dt(["scanning", "downloading"])) {
    t.resumeStatus = t.status, t.status = "paused", await x("post-transfer-stop", { jobId: t.id });
    for (const e of t.tasks) e.status === "transferring" && (e.status = "queued", e.attempts = Math.max(0, e.attempts - 1));
    t.archive?.state === "building" && (await x("zip-stop", { jobId: t.id }), t.archive.state = "pending"), await D(t);
  }
}
function ps(t, e = 100) {
  const { posts: n, tasks: a, sync: r, ...s } = t, i = new Set(r?.posts.map((c) => c.id)), o = [...new Set(n.flatMap((c) => c.media.flatMap((d) => {
    if (!d.originalUrl) return [];
    const h = new URL(d.originalUrl);
    return h.hostname.endsWith(".kemono.cr") ? [`${h.origin}/*`] : [];
  })))];
  return { job: s, originalOrigins: o, totals: {
    synced: a.filter((c) => c.synced).length,
    thumbnails: a.filter((c) => c.fallback && ["staged", "downloaded"].includes(c.status)).length,
    syncPosts: r?.posts.length || 0,
    newPosts: n.filter((c) => !i.has(c.id)).length,
    posts: n.length,
    discovered: n.length - t.detailQueue.length,
    total: t.scan.total,
    images: n.reduce((c, d) => c + d.media.filter((h) => h.kind === "image").length, 0),
    files: n.reduce((c, d) => c + d.media.filter((h) => h.kind === "file").length, 0),
    fullPosts: n.filter((c) => c.hasFull !== !1).length,
    selected: a.length,
    saved: a.filter((c) => c.status === "downloaded" || t.destination?.kind !== "folder" && c.status === "staged").length,
    failed: a.filter((c) => ["failed", "unavailable"].includes(c.status)).length,
    retryable: a.filter((c) => c.status === "failed").length,
    processed: a.filter((c) => ["downloaded", "failed", "unavailable"].includes(c.status) || t.destination?.kind !== "folder" && c.status === "staged").length
  }, posts: n.slice(0, Math.min(1e3, Math.max(1, e))).map((c) => ({ id: c.id, title: c.title, files: c.media.length, hasFull: c.hasFull })) };
}
async function Qn(t) {
  const e = t.archive;
  if (!e || !["ready", "saved"].includes(e.state)) throw new Error("The ZIP is still being prepared.");
  const n = Xn(t);
  if (n.tasks.some((r, s) => r.path !== t.tasks[s].path)) {
    await _();
    for (const r of await W()) ["scanning", "downloading"].includes(r.status) && (r.resumeStatus = r.status, r.status = "paused", await R(r));
    await E(e.blobUrl), t.tasks = n.tasks, t.status = "downloading", t.resumeStatus = "downloading", t.error = null, Object.assign(e, { state: "pending", blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null }), await D(t);
    return;
  }
  await E(e.blobUrl);
  const a = await x("zip-open", { jobId: t.id });
  Object.assign(e, a, { state: "saving", downloadId: null, error: null }), await D(t);
  try {
    e.downloadId = await chrome.downloads.download({ url: a.blobUrl, filename: e.filename, conflictAction: "uniquify", saveAs: !0 });
  } catch {
    e.state = "ready", e.error = "Save was cancelled. Choose Save ZIP to try again.", await E(e.blobUrl), e.blobUrl = null;
  }
  await D(t);
}
async function _n(t) {
  if (t.type === "POST_START") {
    const n = ie(t.url);
    if (!n) throw new Error("Open a Patreon or Fanbox profile or post on Kemono or Pawchive.");
    await _();
    for (const s of await W()) ["scanning", "downloading"].includes(s.status) && (s.resumeStatus = s.status, s.status = "paused", await R(s));
    const a = {
      id: crypto.randomUUID(),
      service: "posts",
      source: n,
      sourceUrl: De(n),
      creatorName: n.creatorId,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      status: "scanning",
      resumeStatus: "scanning",
      selection: { quality: "full res", images: !0, files: !0, text: !0, fallbackToThumbnail: !0 },
      scan: { offset: 0, pages: 0, total: n.postId ? 1 : Number.isSafeInteger(t.expectedPosts) && t.expectedPosts > 0 ? t.expectedPosts : null, complete: !1, error: null, attempts: 0, nextAt: 0, fingerprints: [] },
      posts: [],
      detailQueue: [],
      tasks: [],
      archive: void 0,
      destination: { kind: "folder", directoryId: "", name: "" },
      nextAt: 0,
      error: null
    }, r = await Promise.allSettled([vt.profile(n), a.scan.total === null ? vt.total(n) : Promise.resolve(a.scan.total)]);
    return r[0].status === "fulfilled" && (a.creatorName = r[0].value), r[1].status === "fulfilled" && (a.scan.total = r[1].value), await D(a), { jobId: a.id };
  }
  const e = await fs(t.jobId);
  if (t.type === "POST_DETAIL") return ps(e, t.limit);
  if (e.archive?.state === "saving" && !(t.type === "POST_ACTION" && t.action === "cancel")) throw new Error("Finish or cancel the current ZIP save first.");
  if (t.type === "POST_FOLDER") {
    if (e.status === "downloading") throw new Error("Pause this download before changing its folder.");
    if (typeof t.directoryId != "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(t.directoryId)) throw new Error("Invalid folder selection.");
    const n = await x("post-folder-read", { directoryId: t.directoryId, postJob: e });
    e.destination = { kind: "folder", directoryId: t.directoryId, name: String(t.name).slice(0, 300) }, await E(e.archive?.blobUrl || null), e.archive = void 0, e.tasks = [], e.autoDownload = void 0, e.scan.complete && (e.status = "ready"), n && (e.sync = ze(e.sync, n), e.tasks.length || (e.selection = n.selection));
  } else if (t.type === "POST_SYNC_IMPORT") {
    if (e.status === "downloading") throw new Error("Pause this download before importing a sync JSON.");
    const n = ds(t.json, e.source);
    await _(), e.sync = ze(e.sync, n), e.selection = n.selection, e.source.postId = null, e.sourceUrl = De(e.source), await E(e.archive?.blobUrl || null), jt(e), e.destination?.kind !== "folder" && (e.destination = { kind: "folder", directoryId: "", name: "" });
  } else if (t.type === "POST_DOWNLOAD") {
    if (!e.scan.complete || ["scanning", "downloading"].includes(e.status)) throw new Error("Finish scanning before starting another download.");
    const n = Jn(t.selection), a = t.destination || e.destination?.kind || "zip";
    if (!["folder", "zip"].includes(a)) throw new Error("Invalid download destination.");
    if (a === "zip" && e.sync) throw new Error("Sync extends an existing folder. Choose Save to folder.");
    if (a === "folder" && (e.destination?.kind !== "folder" || !e.destination.directoryId)) throw new Error("Choose the creator folder before saving. For an older ZIP, choose its extracted creator folder containing thumbnail or full res.");
    if (a === "folder" && e.status === "finished" && !e.source.postId)
      return jt(e), e.autoDownload = n, await D(e), null;
    a === "zip" && (e.destination = { kind: "zip" }), e.autoDownload = void 0;
    const r = new Map(e.tasks.map((s) => [s.id, s]));
    if (e.tasks = cs(e, n), !e.tasks.length) throw new Error("Choose at least one available content type.");
    for (const s of e.tasks) {
      const i = r.get(s.id);
      i && ["staged", "downloaded"].includes(i.status) && await x("post-cached", { jobId: e.id, task: i }) && (Object.assign(s, { status: "staged", bytes: i.bytes }), s.kind === "image" && (s.path = s.path.replace(/\.[^/.]+$/, i.path.slice(i.path.lastIndexOf(".")))));
    }
    if (a === "folder") {
      const s = await x("post-folder-check", { postJob: e });
      e.sync = s.sync || Gn(e);
      const i = new Map(s.files.map((o) => [o.id, o]));
      for (const o of e.tasks) {
        const c = i.get(o.id);
        c && Object.assign(o, c, { status: "downloaded", synced: !0, error: null }), o.fallback && (o.fallbackChecked = !0);
      }
      e.sync.selection = n;
    }
    e.selection = n, e.status = "downloading", e.resumeStatus = "downloading", e.error = null, e.archive && await E(e.archive.blobUrl), e.archive = a === "zip" ? { state: "pending", filename: `${e.source.platform}_${e.source.creatorId}_${tt(e.creatorName)}${e.source.postId ? "_post-" + e.source.postId : ""}_${e.id.slice(0, 8)}.zip`, blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null } : void 0;
  } else {
    if (t.action === "pause")
      return await _(), null;
    if (t.action === "rescan") {
      if (["scanning", "downloading"].includes(e.status)) throw new Error("Pause or finish this job before scanning again.");
      await E(e.archive?.blobUrl || null), jt(e);
    } else if (t.action === "resume" || t.action === "retry") {
      if (t.action === "resume" && e.status !== "paused") throw new Error("Only paused jobs can be resumed.");
      if (e.error = null, e.scan.error = null, e.scan.attempts = 0, e.scan.nextAt = 0, e.scan.complete && e.autoDownload)
        return await jn(e), null;
      for (const n of e.tasks) n.status === "failed" && (n.status = "queued", n.attempts = 0, n.nextAt = 0, n.error = null);
      e.status = e.scan.complete ? e.tasks.length ? "downloading" : "ready" : "scanning", e.archive && e.archive.state !== "pending" && (await E(e.archive.blobUrl), e.archive.blobUrl = null, e.archive.downloadId = null, e.archive.error = null, await x("zip-stop", { jobId: e.id }), e.archive.state = "pending");
    } else if (t.action === "cancel") {
      await x("post-transfer-stop", { jobId: e.id }), await x("zip-stop", { jobId: e.id });
      for (const n of e.tasks) n.status === "transferring" && (n.status = "queued");
      e.archive?.state === "saving" && e.archive.downloadId !== null && await chrome.downloads.cancel(e.archive.downloadId).catch(() => {
      }), e.archive?.state === "building" && (e.archive.state = "pending"), e.status = "cancelled";
    } else {
      if (t.action === "save-zip")
        return await Qn(e), null;
      if (t.action === "clear-cache") {
        if (["scanning", "downloading"].includes(e.status)) throw new Error("Pause or finish this job before clearing its cache.");
        await E(e.archive?.blobUrl || null), await x("zip-clear", { jobId: e.id }), e.archive = void 0, e.tasks = [], e.status = e.scan.complete ? "ready" : "paused";
      }
    }
  }
  return await D(e), null;
}
async function hs(t) {
  try {
    if (t.detailQueue.length) {
      const e = await vt.post({ ...t.source, postId: t.detailQueue[0] }), n = t.posts.findIndex((a) => a.id === e.id);
      t.posts[n] = Le(e, t.source), t.detailQueue.shift();
    } else {
      const e = t.source.postId ? [await vt.post(t.source)] : await vt.posts(t.source, t.scan.offset), n = e.map((r) => r.id).join(",");
      if (e.length && t.scan.fingerprints.includes(n)) throw new Error("The API repeated a page. Retry to finish this scan.");
      if (t.scan.pages >= 1e4) throw new Error("The profile exceeded the scan page limit.");
      e.length && t.scan.fingerprints.push(n);
      const a = new Set(t.posts.map((r) => r.id));
      for (const r of e) a.has(r.id) || (t.posts.push(Le(r, t.source)), a.add(r.id), !t.source.postId && (r.detail_fetched === !1 || r.content === void 0 || r.attachments === void 0) && t.detailQueue.push(r.id));
      t.scan.offset += 50, t.scan.pages++, (!e.length || t.source.postId) && (t.scan.complete = !0, t.scan.total = t.posts.length, t.status = "ready");
    }
    t.scan.attempts = 0, t.scan.error = null, t.scan.nextAt = Date.now() + 1e3;
  } catch (e) {
    t.scan.attempts++, t.scan.error = e instanceof Error ? e.message : "Post discovery failed.", e instanceof O && e.retryable && t.scan.attempts < 3 ? t.scan.nextAt = Date.now() + Kn(t.scan.attempts, e.retryAfterMs) : (t.status = "paused", t.resumeStatus = "scanning", t.error = t.scan.error);
  }
  await D(t), t.scan.complete && t.autoDownload && await jn(t);
}
async function $n(t) {
  for (const e of t.tasks) if (e.status === "transferring") {
    const n = e.id, a = await x("post-transfer-status", { jobId: t.id, recordId: n });
    if (a?.state === "transferring") continue;
    if (a?.bytes !== void 0)
      e.bytes = a.bytes, e.status = "staged", e.error = null, e.kind === "image" && a.ext && (e.path = e.path.replace(/\.[^/.]+$/, "." + a.ext));
    else {
      e.error = a?.failure || "Transfer interrupted; retrying.";
      const r = !a?.status || a.status === 429 || a.status >= 500;
      if (e.status = r && e.attempts < 3 ? "queued" : "failed", e.nextAt = Date.now() + Kn(e.attempts, a?.retryAfterMs), a?.status === 429 && (t.nextAt = Math.max(t.nextAt, e.nextAt)), a?.status === 404 || a?.status === 410) {
        const s = Yn(e, e.error);
        s && Object.assign(e, s);
      }
    }
    await D(t), await x("post-transfer-forget", { jobId: t.id, recordId: n });
  }
}
async function ws() {
  const t = await dt(["scanning", "downloading"]), e = Math.max(0, ...t.map((n) => Math.max(n.nextAt, n.scan.nextAt)));
  for (const n of t) {
    if (n.status === "scanning")
      return Date.now() >= e && await hs(n), !0;
    if (n.status !== "downloading") continue;
    if (await $n(n), n.destination?.kind === "folder")
      try {
        const i = n.tasks.filter((o) => o.fallback && !o.fallbackChecked && o.status === "queued");
        if (i.length) {
          const o = await x("post-folder-check", { postJob: n });
          n.sync = o.sync || n.sync, n.sync && (n.sync.selection = n.selection);
          const c = new Map(o.files.map((d) => [d.id, d]));
          for (const d of i) {
            const h = c.get(d.id);
            h && Object.assign(d, h, { status: "downloaded", synced: !0, error: null }), d.fallbackChecked = !0;
          }
          await D(n);
        }
        for (const o of n.tasks) if (o.status === "staged") {
          const c = await x("post-folder-write", { postJob: n, recordId: o.id });
          Object.assign(o, c, { status: "downloaded" }), n.sync ||= Gn(n), he(n.sync, n.source), us(n.sync, o, n.posts.find((d) => d.id === o.postId)?.title || o.postId), await D(n), await x("post-folder-index", { postJob: n }), await x("post-cache-remove", { jobId: n.id, recordId: o.id }).catch(() => {
          });
        }
      } catch (i) {
        await x("post-transfer-stop", { jobId: n.id });
        for (const o of n.tasks) o.status === "transferring" && (o.status = "queued", o.attempts = Math.max(0, o.attempts - 1));
        return n.status = "paused", n.resumeStatus = "downloading", n.error = i instanceof Error ? i.message : "Could not write to the creator folder. Check folder access and free disk space, then Resume.", await D(n), !0;
      }
    const a = n.tasks.filter((i) => i.status === "transferring").length, r = Date.now() >= e ? n.tasks.filter((i) => i.status === "queued" && i.nextAt <= Date.now()).slice(0, Math.max(0, 2 - a)) : [];
    for (const i of r)
      i.status = "transferring", i.attempts++, await D(n), await x("post-transfer-start", { jobId: n.id, task: i, post: n.posts.find((o) => o.id === i.postId), source: n.source });
    if (r.length && (n.nextAt = Date.now() + 400, await D(n)), n.tasks.some((i) => ["queued", "transferring"].includes(i.status))) return !0;
    if (n.destination?.kind === "folder") {
      try {
        await x("post-folder-index", { postJob: n }), n.status = "finished", await x("zip-clear", { jobId: n.id }).catch(() => {
        });
      } catch (i) {
        n.status = "paused", n.error = i instanceof Error ? i.message : "Could not update sync.json. Check folder access, then Resume.";
      }
      return await D(n), !0;
    }
    const s = n.archive;
    if (s.state === "pending")
      n.tasks = Xn(n).tasks, await x("post-zip-build-start", { postJob: n }), s.state = "building";
    else if (s.state === "building") {
      const i = await x("zip-build-status", { jobId: n.id });
      if (!i) s.state = "pending";
      else {
        if (Object.assign(s, i), i.state === "ready")
          return n.status = "finished", await D(n), await Qn(n), !0;
        i.state === "failed" && (n.status = "finished", n.error = i.error);
      }
    }
    return await D(n), !0;
  }
  return !1;
}
async function ta(t = !1) {
  const e = await ha(), n = new Map(e.map((a) => [a.id, a]));
  if (t) for (const a of await dt(["downloading"])) n.set(a.id, a);
  for (const a of n.values()) {
    const r = a.archive;
    if (r?.state === "saving") {
      let s;
      if (r.downloadId !== null ? [s] = await chrome.downloads.search({ id: r.downloadId }) : r.blobUrl && (s = (await chrome.downloads.search({ query: [r.filename], limit: 20 })).find((i) => i.url === r.blobUrl)), s?.state === "complete" && s.exists !== !1) {
        r.state = "saved", r.error = null;
        for (const i of a.tasks) i.status === "staged" && (i.status = "downloaded");
      } else if (s?.state === "interrupted" || s?.exists === !1 || !s && t)
        r.state = "ready", r.error = "ZIP saving was interrupted. Choose Save ZIP to retry.";
      else continue;
      await E(r.blobUrl), r.blobUrl = null, await D(a);
    }
    t && a.status === "downloading" && await $n(a);
  }
}
async function ms(t) {
  if (t.scope !== "all" && t.scope !== "job") throw new Error("Choose which local data to clear.");
  const e = t.scope === "job" ? t.jobId : void 0;
  if (t.scope === "job" && (typeof e != "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(e))) throw new Error("Invalid job to remove.");
  const [n, a] = await Promise.all([W(), dt()]), r = n.filter((c) => e === void 0 || c.id === e), s = a.filter((c) => e === void 0 || c.id === e);
  if (e !== void 0 && !r.length && !s.length) throw new Error("This job was already removed.");
  const i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  for (const c of [...r, ...s])
    c.archive?.blobUrl && i.add(c.archive.blobUrl), c.archive?.state === "saving" && c.archive.downloadId !== null && o.add(c.archive.downloadId);
  for (const c of r) {
    c.status = "cancelled", await R(c);
    for (const d of await N(c.id))
      d.blobUrl && i.add(d.blobUrl), d.status === "transferring" && d.downloadId !== null && o.add(d.downloadId);
    for (const d of c.manifestDownloads)
      i.add(d.blobUrl), d.state === "in_progress" && o.add(d.id);
  }
  for (const c of s)
    c.status = "cancelled", c.autoDownload = void 0, await D(c);
  for (const c of o) await chrome.downloads.cancel(c).catch(() => {
  });
  if (await x("local-purge", { ...e !== void 0 ? { jobId: e } : {}, blobUrls: [...i] }), e === void 0) await be();
  else {
    const c = /* @__PURE__ */ new Set([
      e,
      ...r.filter((d) => d.destination?.kind === "folder").map(V),
      ...s.flatMap((d) => d.destination?.kind === "folder" && d.destination.directoryId ? [d.destination.directoryId] : [])
    ]);
    for (const d of n) d.id !== e && d.destination?.kind === "folder" && c.delete(V(d));
    for (const d of a) d.id !== e && d.destination?.kind === "folder" && c.delete(d.destination.directoryId);
    await be([...c]);
  }
  await ma(e);
}
const Me = 60 * 1e3;
async function gs(t) {
  const e = await We();
  if (t.type === "LOCAL_SETTINGS") {
    if (!Number.isInteger(t.retentionMinutes) || t.retentionMinutes < 0 || t.retentionMinutes > 10) throw new Error("Choose 1–10 minutes, or turn automatic cleanup off.");
    e.retentionMinutes = t.retentionMinutes, await Ye(e);
  }
  return e;
}
async function ea(t = Date.now()) {
  const e = await We();
  if (!e.retentionMinutes || t - e.lastCheckAt < Me) return;
  const [n, a] = await Promise.all([W(), dt()]), r = [...n, ...a], { removed: s } = await x("zip-prune", { cleanup: {
    before: t - e.retentionMinutes * Me,
    protectedJobIds: r.filter((c) => ["scanning", "downloading", "paused"].includes(c.status) || ["building", "saving"].includes(c.archive?.state || "")).map((c) => c.id),
    jobUpdatedAt: Object.fromEntries(r.map((c) => [c.id, Date.parse(c.updatedAt) || Date.parse(c.createdAt) || t]))
  } }), i = new Set(s), o = `Temporary ZIP data expired after ${e.retentionMinutes} minutes without use. Download again to prepare a new ZIP.`;
  for (const c of n) if (i.has(c.id) && c.destination?.kind === "zip") {
    await E(c.archive?.blobUrl || null);
    const d = await N(c.id);
    for (const h of d) ["downloaded", "staged"].includes(h.status) && (h.status = "discovered", h.attempts = 0, h.nextAttemptAt = 0);
    c.archive = void 0, c.status = "indexed", c.autoManifest = !1, c.manifestState = "pending", c.destinationError = o, await at(c, d);
  }
  for (const c of a) i.has(c.id) && c.destination?.kind !== "folder" && (await E(c.archive?.blobUrl || null), c.archive = void 0, c.tasks = [], c.status = c.scan.complete ? "ready" : "cancelled", c.error = o, await D(c));
  e.lastCheckAt = t, e.removedCaches = s.length, await Ye(e);
}
async function ys(t, e) {
  const n = e.id === chrome.runtime.id && e.tab?.url?.split("#")[0] === chrome.runtime.getURL("folder/index.html");
  if (e.tab?.url && !Et(e.tab.url) && !n) throw new Error("Archive Ripper works only on Kemono and Pawchive.");
  if (t.type === "LOCAL_CLEAR")
    return await ms(t), null;
  if (t.type === "LOCAL_STATUS" || t.type === "LOCAL_SETTINGS") return gs(t);
  if (t.type === "PAGE_CONTEXT") {
    const a = e.tab?.id !== void 0 ? await chrome.tabs.get(e.tab.id) : (await chrome.tabs.query({ active: !0, lastFocusedWindow: !0 }))[0];
    if (!a?.id || !Et(a.url || "")) return null;
    try {
      const r = await chrome.tabs.sendMessage(a.id, { type: "PAGE_CONTEXT" });
      if (r?.url === a.url) return r;
    } catch {
    }
    return { url: a.url, expectedPosts: null };
  }
  if (t.type === "SERVICE_JOBS") {
    const a = (await W()).map((s) => ({ id: s.id, service: "discord", sourceUrl: s.sourceUrl || `https://kemono.cr/discord/server/${s.serverId}${s.channels.length === 1 ? "/" + s.channels[0].channelId : ""}`, title: s.serverName || s.serverId, status: s.status, createdAt: s.createdAt })), r = (await dt()).map((s) => ({ id: s.id, service: "posts", sourceUrl: s.sourceUrl, title: s.source.postId && s.posts[0]?.title || s.creatorName, status: s.status, createdAt: s.createdAt }));
    return [...a, ...r].sort((s, i) => i.createdAt.localeCompare(s.createdAt));
  }
  if (t.type.startsWith("POST_")) {
    if (t.type === "POST_DOWNLOAD" || t.type === "POST_SYNC_IMPORT" || t.type === "POST_ACTION" && ["resume", "retry", "rescan"].includes(t.action)) {
      await _();
      for (const a of await W()) ["scanning", "downloading"].includes(a.status) && (a.resumeStatus = a.status, a.status = "paused", await R(a));
    }
    return _n(t);
  }
  if (t.type === "DISCORD_DOWNLOAD") {
    const a = await Ze(t.jobId);
    if (!a || !["thumbnail", "full res", "best"].includes(t.quality)) throw new Error("Invalid Discord download.");
    if (!["indexed", "finished"].includes(a.status)) throw new Error("Finish scanning before downloading.");
    return a.mode = t.quality === "full res" ? "original" : t.quality, a.tryOriginal = t.quality === "best", await R(a), await _(), Te({ type: "ACTION", jobId: a.id, action: "download" }, e);
  }
  return (t.type === "START" || t.type === "ACTION" && ["download", "resume", "retry"].includes(t.action)) && await _(), Te(t, e);
}
let Be = Promise.resolve(), Qt, Dt = !1;
function ut(t) {
  const e = Be.then(t);
  return Be = e.catch(() => {
  }), e;
}
function na() {
  Dt || (Dt = !0, ut(async () => await ws() ? 750 : es()).then((t) => t || 1200, () => 1200).then((t) => {
    Dt = !1, ft(t);
  }));
}
function ft(t = 1200) {
  Qt || Dt || (Qt = setTimeout(() => {
    Qt = void 0, na();
  }, t));
}
chrome.runtime.onMessage.addListener((t, e, n) => {
  if (!(e.id !== chrome.runtime.id || t.target === "offscreen"))
    return ut(() => ys(t, e)).then((a) => n({ ok: !0, data: a }), (a) => n({ ok: !1, error: a instanceof Error ? a.message : "Archive operation failed" })).finally(ft), !0;
});
chrome.downloads.onChanged.addListener((t) => {
  ut(async () => {
    await as(t), await ta();
  }).catch(() => {
  }).finally(ft);
});
chrome.alarms.onAlarm.addListener((t) => {
  t.name === "archive-tick" && na(), t.name === "archive-maintenance" && ut(() => ea()).catch(() => {
  }).finally(ft);
});
async function aa() {
  await ns(), await ta(!0), await ea();
}
chrome.runtime.onStartup.addListener(() => {
  ut(aa).catch(() => {
  }).finally(ft);
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
});
chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
chrome.alarms.create("archive-maintenance", { periodInMinutes: 1 });
ut(aa).catch(() => {
}).finally(ft);
chrome.action.onClicked.addListener((t) => {
  !t.id || !Et(t.url || "") || (async () => {
    try {
      await chrome.tabs.sendMessage(t.id, { type: "TOGGLE_OVERLAY" });
    } catch {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["content.js"] }), await chrome.tabs.sendMessage(t.id, { type: "TOGGLE_OVERLAY" });
    }
  })().catch(() => {
    chrome.action.setTitle({ tabId: t.id, title: "Refresh this page, then open Archive Ripper." });
  });
});
async function ra(t) {
  t.id !== void 0 && await (Et(t.url || "") ? chrome.action.enable(t.id) : chrome.action.disable(t.id));
}
chrome.tabs.onUpdated.addListener((t, e, n) => {
  ra(n);
});
chrome.action.disable().then(async () => {
  for (const t of await chrome.tabs.query({ url: ["https://kemono.cr/*", "https://pawchive.pw/*"] })) await ra(t);
});
