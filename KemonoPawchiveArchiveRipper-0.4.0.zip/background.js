const Z = ["https://kemono.cr", "https://pawchive.pw"], ua = Z.map((t) => `img.${new URL(t).hostname}`);
function ee(t) {
  return /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)*(?:kemono\.cr|pawchive\.pw)$/.test(t);
}
function Nt(t) {
  return new URL(t).pathname.startsWith("/thumbnail/data/");
}
function Ot(t) {
  try {
    const e = new URL(t), n = /^\/discord\/server\/(\d+)(?:\/(\d+))?\/?$/.exec(e.pathname);
    return !Z.includes(e.origin) || e.username || e.password || !n ? null : { serverId: n[1], channelId: n[2] || null, serverName: null, channelName: null };
  } catch {
    return null;
  }
}
function Se(t) {
  const e = Ot(t);
  return e?.channelId ? { ...e, channelId: e.channelId } : null;
}
function X(t) {
  if (typeof t != "string" || !/^\d+$/.test(t)) throw new Error("Expected a Discord ID encoded as a string");
  return t;
}
const fa = /^\/([0-9a-f]{2})\/([0-9a-f]{2})\/([0-9a-f]{64})\.(png|jpe?g|webp|gif|avif)$/i;
function Lt(t) {
  if (typeof t != "string") return null;
  const e = fa.exec(t);
  return e ? { path: t, hash: e[3].toLowerCase() } : null;
}
function pa(t, e = Z[0]) {
  const n = Lt(t);
  return n && Z.includes(e) ? `https://img.${new URL(e).hostname}/thumbnail/data${n.path}` : null;
}
function $(t) {
  if (typeof t != "string") return null;
  try {
    const e = new URL(t);
    if (e.protocol !== "https:" || e.username || e.password || e.port) return null;
    const n = e.hostname;
    return ee(n) && e.pathname.startsWith("/thumbnail/data/") && Lt(e.pathname.slice(15)) || ee(n) && e.pathname.startsWith("/data/") && Lt(e.pathname.slice(5)) || (n === "cdn.discordapp.com" || n === "media.discordapp.net") && /^\/attachments\/\d+\/\d+\/[^/]+\.(png|jpe?g|webp|gif|avif)$/i.test(e.pathname) ? (e.hash = "", e.href) : null;
  } catch {
    return null;
  }
}
class O extends Error {
  constructor(e, n, a = 0) {
    super(e), this.status = n, this.retryAfterMs = a, this.name = "RequestError";
  }
  status;
  retryAfterMs;
  get retryable() {
    return this.status === 0 || this.status === 429 || this.status >= 500;
  }
}
function ha(t, e = Date.now()) {
  if (!t) return 0;
  const n = Number(t);
  return Math.max(0, Number.isFinite(n) ? n * 1e3 : Date.parse(t) - e || 0);
}
class Je {
  constructor(e = (n, a) => fetch(n, a)) {
    this.transport = e;
  }
  transport;
  async json(e, n = Z[0]) {
    if (!Z.includes(n)) throw new Error("Unsupported archive origin");
    let a;
    try {
      a = await this.transport(`${n}/api/v1${e}`, {
        headers: { Accept: "text/css" },
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(2e4)
      });
    } catch {
      throw new O("API network request failed or timed out. Open the channel to check site access.", 0);
    }
    if (!a.ok) {
      const r = a.status === 403 ? " Access denied; the required Accept: text/css header was sent. Check access in the site tab." : "";
      throw new O(`API HTTP ${a.status}.${r}`, a.status, ha(a.headers.get("retry-after")));
    }
    try {
      return JSON.parse(await a.text());
    } catch {
      throw new O("API returned invalid JSON; this page is incomplete.", 422);
    }
  }
  async channel(e, n, a = Z[0]) {
    if (X(e), !Number.isSafeInteger(n) || n < 0) throw new Error("Invalid page offset");
    const r = await this.json(`/discord/channel/${e}?o=${n}`, a);
    if (!Array.isArray(r)) throw new O("Channel response is not an array", 422);
    for (const s of r) {
      if (!s || typeof s != "object") throw new O("Invalid message object", 422);
      if (X(s.id), s.channel !== void 0 && X(s.channel) !== e) throw new O("Channel response contains a different channel", 422);
      if (s.server !== void 0 && X(s.server), s.attachments != null && (!Array.isArray(s.attachments) || s.attachments.some((i) => !i || typeof i != "object" || Array.isArray(i)))) throw new O("Invalid attachment list", 422);
    }
    return r;
  }
  async server(e, n = Z[0]) {
    X(e);
    const a = await this.json(`/discord/server/${e}`, n);
    if (!a || X(a.id) !== e || !Array.isArray(a.channels)) throw new O("Invalid server metadata", 422);
    return {
      id: e,
      name: typeof a.name == "string" ? a.name : e,
      channels: a.channels.map((r) => ({
        id: X(r.id),
        name: typeof r.name == "string" ? r.name : r.id,
        parentId: typeof r.parent_channel_id == "string" ? X(r.parent_channel_id) : null,
        type: typeof r.type == "number" ? r.type : null,
        postCount: Number.isSafeInteger(r.post_count) && r.post_count >= 0 ? r.post_count : null
      }))
    };
  }
}
function wa(t, e, n) {
  const a = /* @__PURE__ */ new Map();
  for (const s of e?.channels || []) a.set(s.id, { ...s, sources: ["api"] });
  let r = e?.name || null;
  for (const s of n)
    if (s.serverId === t) {
      r ||= typeof s.serverName == "string" ? s.serverName : null;
      for (const i of s.channels) {
        try {
          X(i.id);
        } catch {
          continue;
        }
        const o = a.get(i.id);
        o ? o.sources = [.../* @__PURE__ */ new Set([...o.sources || [], "dom"])] : a.set(i.id, { id: i.id, name: typeof i.name == "string" ? i.name : i.id, parentId: null, type: null, postCount: null, sources: ["dom"] });
      }
    }
  return e || a.size ? { id: t, name: r || t, channels: [...a.values()] } : null;
}
function de(t) {
  let e = 0xcbf29ce484222325n;
  for (const n of t) e = BigInt.asUintN(64, (e ^ BigInt(n.codePointAt(0))) * 0x100000001b3n);
  return e.toString(16).padStart(16, "0");
}
function Ge(t) {
  if (typeof t != "string") return null;
  const e = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$/.exec(t);
  if (!e) return null;
  const [, n, a, r, s, i, o, l, f] = e, h = Number(n), y = Number(a), c = Number(r);
  if (y < 1 || y > 12 || c < 1 || c > new Date(Date.UTC(h, y, 0)).getUTCDate() || Number(s) > 23 || Number(i) > 59 || Number(o) > 59) return null;
  const u = `${n}-${a}-${r}T${s}:${i}:${o}.${(l || "").padEnd(3, "0").slice(0, 3)}${f || "Z"}`, w = Date.parse(u);
  return Number.isFinite(w) ? new Date(w).toISOString() : null;
}
function Ae(t, e, n, a, r) {
  return {
    ...t,
    jobId: e,
    id: `${t.serverId}:${t.channelId}:${n || "dom"}:${a}:${de(r)}`,
    messageId: n,
    attachmentIndex: a,
    attachmentId: null,
    publishedRaw: null,
    publishedAtUtc: null,
    originalFilename: null,
    kemonoPath: null,
    kemonoFileHash: null,
    originalUrl: null,
    discordCdnUrl: null,
    thumbnailUrl: null,
    resolvedUrl: null,
    mediaType: "unknown",
    sourceType: "api",
    provenance: [],
    warnings: [],
    status: "discovered",
    savedPath: null,
    errorMessage: null,
    attempts: 0,
    nextAttemptAt: 0,
    downloadId: null,
    blobUrl: null,
    quality: null,
    bytes: null,
    sha256: null,
    mime: null,
    width: null,
    height: null,
    candidateFailures: []
  };
}
function ma(t, e, n, a = Z[0]) {
  const r = [];
  for (const s of t) {
    if (s.server && s.server !== e.serverId) throw new Error("Message belongs to a different server");
    const i = (h) => (h.publishedRaw = typeof s.published == "string" ? s.published : null, h.publishedAtUtc = Ge(h.publishedRaw), h.provenance = ["api"], h.publishedAtUtc ? /(Z|[+-]\d\d:\d\d)$/.test(h.publishedRaw) || h.warnings.push("Archive timestamp has no timezone; interpreted as UTC") : h.warnings.push("Missing or invalid publication timestamp"), h), o = s.attachments || [];
    o.forEach((h, y) => {
      const c = typeof h.path == "string" ? h.path : null, u = i(Ae(e, n, s.id, y + 1, c || h.name || `attachment-${y}`));
      u.originalFilename = typeof h.name == "string" ? h.name : null;
      const w = Lt(c);
      w ? (u.kemonoPath = w.path, u.kemonoFileHash = w.hash, u.thumbnailUrl = pa(w.path, a), u.mediaType = "image") : (u.discordCdnUrl = $(c), u.discordCdnUrl?.includes("discordapp.") ? u.mediaType = "image" : (u.discordCdnUrl = null, u.warnings.push("Unsupported attachment path; needs an observed image URL"))), r.push(u);
    });
    const l = typeof s.content == "string" ? s.content.match(/https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\/[^\s<>"')]+/g) || [] : [];
    [...new Set(l.map($).filter((h) => !!h))].forEach((h, y) => {
      const c = i(Ae(e, n, s.id, o.length + y + 1, h));
      c.discordCdnUrl = h, c.mediaType = "image", c.originalFilename = new URL(h).pathname.split("/").at(-1);
      try {
        c.originalFilename = decodeURIComponent(c.originalFilename);
      } catch {
      }
      c.provenance.push("inline-content"), r.push(c);
    });
  }
  return r;
}
function Ke(t, e) {
  const n = new Map(t.map((a) => [a.id, a]));
  for (const a of e) {
    let r = n.get(a.id);
    if (!r && a.messageId) {
      const o = [...n.values()].filter((l) => (l.sourceType === "dom" || a.sourceType === "dom") && l.sourceType !== a.sourceType && l.serverId === a.serverId && l.channelId === a.channelId && l.messageId === a.messageId && (l.kemonoPath && l.kemonoPath === a.kemonoPath || l.discordCdnUrl && l.discordCdnUrl === a.discordCdnUrl));
      r = o.find((l) => l.attachmentIndex === a.attachmentIndex) || (o.length === 1 ? o[0] : void 0);
    }
    if (!r) {
      n.set(a.id, a);
      continue;
    }
    const s = a.sourceType === "api" && r.sourceType === "dom" ? a : r, i = {
      ...r,
      id: s.id,
      attachmentIndex: s.attachmentIndex,
      publishedRaw: s.publishedRaw || r.publishedRaw || a.publishedRaw,
      publishedAtUtc: s.publishedAtUtc || r.publishedAtUtc || a.publishedAtUtc,
      originalFilename: s.originalFilename || r.originalFilename || a.originalFilename,
      kemonoPath: r.kemonoPath || a.kemonoPath,
      kemonoFileHash: r.kemonoFileHash || a.kemonoFileHash,
      thumbnailUrl: r.thumbnailUrl || a.thumbnailUrl,
      originalUrl: r.originalUrl || a.originalUrl,
      discordCdnUrl: r.discordCdnUrl || a.discordCdnUrl,
      mediaType: r.mediaType === "unknown" ? a.mediaType : r.mediaType,
      sourceType: r.sourceType === a.sourceType ? r.sourceType : "merged",
      provenance: [.../* @__PURE__ */ new Set([...r.provenance, ...a.provenance])],
      warnings: [.../* @__PURE__ */ new Set([...r.warnings, ...a.warnings])]
    };
    n.delete(r.id), n.set(i.id, i);
  }
  return [...n.values()];
}
const ga = 150;
function ya(t, e) {
  const n = structuredClone(t);
  if (n.attempts = 0, n.nextAttemptAt = 0, n.error = null, !e.length)
    return n.pages++, n.coverage = "complete", n.terminal = "empty-page", n;
  const a = de(e.map((r) => r.id).join(","));
  if (n.pageFingerprints.includes(a)) throw new Error("API repeated an earlier page; pagination stopped with incomplete coverage");
  if (n.pages >= 1e4) throw new Error("Safety page limit reached; coverage is incomplete");
  return n.pageFingerprints.push(a), n.pages++, n.messageIds = [.../* @__PURE__ */ new Set([...n.messageIds, ...e.map((r) => r.id)])], n.offset += ga, n.coverage = "scanning", n;
}
function nt(t, e = "unnamed") {
  let n = (t || e).normalize("NFKC").replace(/[<>:"/\\|?*\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "_").replace(/^[. ]+|[. ]+$/g, "").slice(0, 40).trim().replace(/[. ]+$/g, "");
  return (!n || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(n)) && (n = "_" + (n || e)), n;
}
function Mt(t) {
  return `ArchiveRoot/${t.service === "discord" ? "discord/" : ""}${t.serverId}_${nt(t.serverName, "server")}`;
}
function ne(t) {
  return `${Mt(t)}/${t.channelId}_${nt(t.channelName, "channel")}`;
}
function ba(t, e) {
  if (!/^(png|jpg|webp|gif|avif)$/.test(e)) throw new Error("Unvalidated image format");
  const n = t.publishedAtUtc ? t.publishedAtUtc.slice(0, 19).replace("T", "_").replace(/:(\d{2})/g, "$1") + "Z" : "unknown-date";
  return `${ne(t)}/${n}_${t.messageId || "unknown-message"}_${String(t.attachmentIndex).padStart(3, "0")}_${de(t.id).slice(0, 8)}.${e}`;
}
function kt(t) {
  const e = {
    id: t.id,
    status: t.status,
    createdAt: t.createdAt,
    updatedAt: t.updatedAt,
    archiveState: t.archive?.state,
    cacheCleared: !!t.archive?.cacheCleared,
    destinationKind: t.destination?.kind
  };
  return t.service === "posts" ? { ...e, service: "posts", sourceUrl: t.sourceUrl, title: t.source.postId && t.posts[0]?.title || t.creatorName } : { ...e, service: "discord", sourceUrl: t.sourceUrl || `https://kemono.cr/discord/server/${t.serverId}${t.channels.length === 1 ? "/" + t.channels[0].channelId : ""}`, title: t.serverName || t.serverId };
}
let ut;
function L() {
  return ut || (ut = new Promise((t, e) => {
    const n = indexedDB.open("kemono-archive", 4);
    n.onupgradeneeded = () => {
      n.result.objectStoreNames.contains("jobs") || (n.result.createObjectStore("jobs", { keyPath: "id" }), n.result.createObjectStore("media", { keyPath: ["jobId", "id"] }).createIndex("jobId", "jobId")), n.result.objectStoreNames.contains("postJobs") || n.result.createObjectStore("postJobs", { keyPath: "id" });
      for (const s of ["jobs", "postJobs"]) {
        const i = n.transaction.objectStore(s);
        i.indexNames.contains("status") || i.createIndex("status", "status"), i.indexNames.contains("archiveState") || i.createIndex("archiveState", "archive.state"), i.indexNames.contains("archiveDownloadId") || i.createIndex("archiveDownloadId", "archive.downloadId");
      }
      const a = n.transaction.objectStore("jobs");
      a.indexNames.contains("manifestState") || a.createIndex("manifestState", "manifestState");
      const r = n.transaction.objectStore("media");
      if (r.indexNames.contains("downloadId") || r.createIndex("downloadId", "downloadId"), r.indexNames.contains("jobStatus") || r.createIndex("jobStatus", ["jobId", "status"]), !n.result.objectStoreNames.contains("jobSummaries")) {
        const s = n.result.createObjectStore("jobSummaries", { keyPath: "id" });
        s.createIndex("status", "status");
        for (const i of ["jobs", "postJobs"]) {
          const o = n.transaction.objectStore(i).openCursor();
          o.onsuccess = () => {
            const l = o.result;
            l && (s.put(kt(l.value)), l.continue());
          };
        }
      }
      n.result.objectStoreNames.contains("settings") || n.result.createObjectStore("settings");
    }, n.onsuccess = () => {
      n.result.onversionchange = () => {
        n.result.close(), ut = void 0;
      }, t(n.result);
    }, n.onerror = () => {
      ut = void 0, e(n.error);
    };
  })), ut;
}
function Y(t) {
  return new Promise((e, n) => {
    t.onsuccess = () => e(t.result), t.onerror = () => n(t.error);
  });
}
function _(t) {
  return new Promise((e, n) => {
    t.oncomplete = () => e(), t.onerror = t.onabort = () => n(t.error || new Error("Database transaction aborted"));
  });
}
async function lt(t, e, n = []) {
  const a = (await L()).transaction(t).objectStore(t);
  return e ? (await Promise.all(n.map((r) => Y(a.index(e).getAll(r))))).flat() : Y(a.getAll());
}
async function j(t) {
  return lt("jobs", t ? "status" : void 0, t);
}
async function ue() {
  return lt("jobSummaries");
}
async function va() {
  const t = (await L()).transaction("jobSummaries").objectStore("jobSummaries").index("status");
  return (await Promise.all(["scanning", "downloading"].map((n) => Y(t.count(n))))).some((n) => n > 0);
}
async function Ia() {
  return lt("jobs", "archiveState", ["saving"]);
}
async function je() {
  return lt("jobs", "manifestState", ["saving"]);
}
async function Sa(t) {
  return Y((await L()).transaction("jobs").objectStore("jobs").index("archiveDownloadId").getAll(t));
}
async function Aa(t) {
  return Y((await L()).transaction("postJobs").objectStore("postJobs").index("archiveDownloadId").getAll(t));
}
async function xa(t) {
  return Y((await L()).transaction("media").objectStore("media").index("downloadId").getAll(t));
}
async function vt(t) {
  return Y((await L()).transaction("jobs").objectStore("jobs").get(t));
}
async function N(t, e) {
  const n = (await L()).transaction("media").objectStore("media");
  return e ? (await Promise.all(e.map((a) => Y(n.index("jobStatus").getAll([t, a]))))).flat() : Y(n.index("jobId").getAll(t));
}
async function E(t) {
  const e = (await L()).transaction(["jobs", "jobSummaries"], "readwrite"), n = _(e);
  e.objectStore("jobs").put(t), e.objectStore("jobSummaries").put(kt(t)), await n;
}
async function Ua(t, e) {
  const n = (await L()).transaction(["jobs", "jobSummaries", "media"], "readwrite"), a = _(n);
  n.objectStore("jobs").put(t), n.objectStore("jobSummaries").put(kt(t));
  for (const r of e) n.objectStore("media").put(r);
  await a;
}
async function F(t) {
  const e = (await L()).transaction("media", "readwrite"), n = _(e);
  e.objectStore("media").put(t), await n;
}
async function xe(t) {
  if (!t.length) return;
  const e = (await L()).transaction("media", "readwrite"), n = _(e);
  for (const a of t) e.objectStore("media").put(a);
  await n;
}
async function Jt(t) {
  return lt("postJobs", t ? "status" : void 0, t);
}
async function Ea() {
  return lt("postJobs", "archiveState", ["saving"]);
}
async function fe() {
  return { retentionMinutes: 5, lastCheckAt: 0, removedCaches: 0, clearAfterDownload: !1, ...await Y((await L()).transaction("settings").objectStore("settings").get("cache-maintenance")) };
}
async function Qe(t) {
  const e = (await L()).transaction("settings", "readwrite"), n = _(e);
  e.objectStore("settings").put(t, "cache-maintenance"), await n;
}
async function zt(t) {
  return Y((await L()).transaction("postJobs").objectStore("postJobs").get(t));
}
async function P(t) {
  t.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const e = (await L()).transaction(["postJobs", "jobSummaries"], "readwrite"), n = _(e);
  e.objectStore("postJobs").put(t), e.objectStore("jobSummaries").put(kt(t)), await n;
}
async function Ca(t) {
  const e = t === void 0 ? ["jobs", "media", "postJobs", "jobSummaries", "settings"] : ["jobs", "media", "postJobs", "jobSummaries"], n = (await L()).transaction(e, "readwrite"), a = _(n);
  if (t === void 0)
    for (const r of e) n.objectStore(r).clear();
  else {
    n.objectStore("jobs").delete(t), n.objectStore("postJobs").delete(t), n.objectStore("jobSummaries").delete(t);
    const r = n.objectStore("media"), s = r.index("jobId").openKeyCursor(IDBKeyRange.only(t));
    s.onsuccess = () => {
      const i = s.result;
      i && (r.delete(i.primaryKey), i.continue());
    };
  }
  await a;
}
async function Bt(t, e) {
  const n = (await L()).transaction(["jobs", "media", "jobSummaries"], "readwrite"), a = _(n);
  n.objectStore("jobs").put(t), n.objectStore("jobSummaries").put(kt(t));
  const r = n.objectStore("media"), s = r.index("jobId").openKeyCursor(IDBKeyRange.only(t.id));
  s.onsuccess = () => {
    const i = s.result;
    if (i)
      r.delete(i.primaryKey), i.continue();
    else for (const o of e) r.put(o);
  }, await a;
}
function ae(t, e) {
  const n = {
    discovered: e.length,
    downloaded: 0,
    staged: 0,
    failed: 0,
    skipped: 0,
    queued: 0,
    pages: 0,
    messages: 0,
    incomplete: t.scope === "server" && t.channelDiscovery === "dom" || t.status === "cancelled"
  };
  for (const a of t.channels)
    n.pages += a.pages, n.messages += a.messageIds.length, a.coverage !== "complete" && (n.incomplete = !0);
  for (const a of e) {
    switch (a.status) {
      case "downloaded":
        n.downloaded++;
        break;
      case "staged":
        n.staged++;
        break;
      case "failed":
        n.failed++;
        break;
      case "skipped":
        n.skipped++;
        break;
      case "queued":
      case "transferring":
        n.queued++;
        break;
    }
    (["failed", "skipped", "queued", "transferring", "staged"].includes(a.status) || a.mediaType === "unknown" || !a.messageId || !(a.thumbnailUrl || a.originalUrl || a.discordCdnUrl)) && (n.incomplete = !0);
  }
  return n;
}
function pt(t, e, n) {
  const a = n ? e.filter((s) => s.channelId === n) : e, r = n ? { ...t, channels: t.channels.filter((s) => s.channelId === n) } : t;
  return JSON.stringify({
    schemaVersion: 1,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    job: { ...r, archive: r.archive ? { ...r.archive, blobUrl: void 0 } : void 0, manifestDownloads: r.manifestDownloads.map(({ blobUrl: s, ...i }) => i) },
    totals: ae(r, a),
    coverageNote: "Complete means every requested API page reached a validated empty array. DOM coverage is limited to observed messages. Indexed links are not a claim that every image is available.",
    timestampPolicy: "Timezone-less archive publication times are interpreted as UTC; raw values are retained.",
    media: a.map(({ blobUrl: s, ...i }) => i)
  }, null, 2);
}
const Ue = ["serverId", "serverName", "channelId", "channelName", "messageId", "publishedRaw", "publishedAtUtc", "attachmentIndex", "originalFilename", "kemonoPath", "kemonoFileHash", "originalUrl", "discordCdnUrl", "thumbnailUrl", "resolvedUrl", "quality", "sourceType", "status", "savedPath", "sha256", "errorMessage"];
function ka(t) {
  const e = (n) => {
    let a = n == null ? "" : String(n);
    return /^[\s]*[=+\-@\t\r]/.test(a) && (a = "'" + a), '"' + a.replaceAll('"', '""') + '"';
  };
  return "\uFEFF" + [Ue.join(","), ...t.map((n) => Ue.map((a) => e(n[a])).join(","))].join(`\r
`);
}
function Ra(t, e) {
  const n = [t.originalUrl, t.discordCdnUrl].map($).filter((i) => !!i).map((i) => ({ url: i, quality: "original" })), a = $(t.thumbnailUrl), r = a ? [{ url: a, quality: "thumbnail" }] : [], s = e.mode === "original" ? n : e.mode === "best" && e.tryOriginal ? [...n, ...r] : r;
  return s.filter((i, o) => s.findIndex((l) => l.url === i.url) === o);
}
function V(t) {
  return t.destination?.kind === "folder" && t.destination.directoryId || t.id;
}
let Ee;
async function _e() {
  return Ee ||= new Promise((t, e) => {
    const n = indexedDB.open("kemono-archive-destinations", 1);
    n.onupgradeneeded = () => n.result.createObjectStore("folders"), n.onsuccess = () => t(n.result), n.onerror = () => {
      Ee = void 0, e(n.error);
    };
  });
}
async function Pa(t) {
  const e = await _e();
  return new Promise((n, a) => {
    const r = e.transaction("folders").objectStore("folders").get(t);
    r.onsuccess = () => n(r.result), r.onerror = () => a(r.error);
  });
}
async function Ce(t) {
  const e = (await _e()).transaction("folders", "readwrite"), n = new Promise((r, s) => {
    e.oncomplete = () => r(), e.onerror = e.onabort = () => s(e.error);
  }), a = e.objectStore("folders");
  if (t === void 0) a.clear();
  else for (const r of t) a.delete(r);
  await n;
}
class J extends Error {
  constructor() {
    super("Folder access is required. Choose folder, click Allow folder access, then Resume.");
  }
}
async function wt(t) {
  const e = await Pa(t);
  try {
    if (!e || await e.queryPermission({ mode: "readwrite" }) !== "granted") throw new J();
  } catch {
    throw new J();
  }
  return e;
}
function ot(t) {
  const e = t.split("/");
  if (!t || e.some((n) => !n || n === "." || n === ".." || /[\\:\x00-\x1f<>"|?*]/.test(n))) throw new Error("Unsafe archive path");
  return e;
}
function Da(t) {
  const e = ot(t);
  if (e[0] !== "ArchiveRoot" || e.length < 2) throw new Error("Unsafe archive path");
  return e;
}
async function Ta(t, e, n, a = !1) {
  const r = a ? ot(e) : Da(e);
  let s = await wt(t);
  for (const i of r.slice(0, -1)) s = await s.getDirectoryHandle(i, { create: n });
  return { directory: s, name: r.at(-1) };
}
async function Na(t) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", await t.arrayBuffer()))].map((e) => e.toString(16).padStart(2, "0")).join("");
}
async function $e(t, e, n, a) {
  try {
    const { directory: r, name: s } = await Ta(t, e, !1), i = await (await r.getFileHandle(s)).getFile();
    return i.size === a && await Na(i) === n;
  } catch (r) {
    if (r instanceof DOMException && r.name === "NotFoundError") return !1;
    throw r instanceof DOMException && ["NotAllowedError", "SecurityError"].includes(r.name) ? new J() : r;
  }
}
Promise.resolve();
const M = void 0, et = "undefined", It = "function", re = "string", tn = new Uint8Array(), Oa = "Invalid option (must be a function)";
function La(t) {
  if (t && typeof t != It)
    throw new Error(Oa);
  return t;
}
function Ma(t) {
  return typeof t == re && t.trim() ? Number(t) : t;
}
const za = 256 * 1024, Ba = 1, qa = "Invalid maxWorkers (must be an integer greater than 0)", Fa = "Invalid baseURI (must be a string)", Ha = "Invalid URI (must be a string or a function returning a string)";
let en = 2;
try {
  typeof navigator != et && navigator.hardwareConcurrency && (en = navigator.hardwareConcurrency);
} catch {
}
const nn = {
  workerURI: "./core/web-worker-wasm.js",
  wasmURI: "./core/streams/zlib-wasm/zlib-streams.wasm",
  chunkSize: za,
  maxWorkers: en,
  terminateWorkerTimeout: 5e3,
  workerStarvationTimeout: 5e3,
  workerStartupTimeout: 5e3,
  useWebWorkers: !0,
  useCompressionStream: !0,
  CompressionStream: typeof CompressionStream != et && CompressionStream,
  DecompressionStream: typeof DecompressionStream != et && DecompressionStream
}, an = "maxWorkers", rn = "baseURI", sn = [
  "wasmURI",
  "workerURI"
], Za = [
  "useCompressionStream",
  "useWebWorkers"
], on = [
  "chunkSize",
  an,
  "terminateWorkerTimeout",
  "workerStarvationTimeout",
  "workerStartupTimeout"
], cn = [
  "createWorker",
  "CompressionStream",
  "DecompressionStream",
  "CompressionStreamFallback",
  "DecompressionStreamFallback"
], Wa = [
  rn,
  ...sn,
  ...Za,
  ...on,
  ...cn
], Ya = { ...nn };
function Xa(t) {
  const e = {};
  for (const n of Wa) {
    const a = t[n];
    a !== M && (e[n] = Va(n, a));
  }
  return e;
}
function Va(t, e) {
  if (on.includes(t)) {
    if (e = Ma(e), t == an && (!Number.isInteger(e) || e < Ba))
      throw new Error(qa);
  } else if (cn.includes(t))
    La(e);
  else if (t == rn) {
    if (e && typeof e != re)
      throw new Error(Fa);
  } else if (sn.includes(t) && e && typeof e != re && typeof e != It)
    throw new Error(Ha);
  return e;
}
function Ja(t) {
  t = t || {};
  const { CompressionStreamZlib: e, DecompressionStreamZlib: n } = t;
  if (e === M && n === M)
    return t;
  const a = Object.assign({}, t);
  return a.CompressionStreamFallback === M && (a.CompressionStreamFallback = e), a.DecompressionStreamFallback === M && (a.DecompressionStreamFallback = n), a;
}
function Gt(t) {
  const e = Xa(Ja(t));
  Object.assign(nn, e), Object.assign(Ya, e);
}
const Pt = new Uint8Array(288);
Pt.fill(8, 0, 144), Pt.fill(9, 144, 256), Pt.fill(7, 256, 280), Pt.fill(8, 280, 288), new Uint8Array(30).fill(5);
const G = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Ga = (t) => t({ workerURI: (e) => {
  const n = "text/javascript";
  let a = `!function(t){"function"==typeof define&&define.amd?define(t):t()}(function(){"use strict";const{Array:t,Object:n,Number:e,Math:o,Error:r,Uint8Array:c,Uint16Array:s,Uint32Array:a,Int32Array:i,Map:f,DataView:u,Promise:w,TextEncoder:l,crypto:d,postMessage:p,TransformStream:h,ReadableStream:y,WritableStream:m,CompressionStream:S,DecompressionStream:g}=self,v=void 0,b="undefined",k="function",z=new c,C=[[],[],[],[],[],[],[],[]];for(let t=0;t<256;t++){let n=t;for(let t=0;t<8;t++)n=1&n?n>>>1^3988292384:n>>>1;C[0][t]=n}for(let t=0;t<256;t++)for(let n=1;n<8;n++){const e=C[n-1][t];C[n][t]=e>>>8^C[0][255&e]}const[I,M,A,E,R,x,P,D]=C;class F{constructor(t){this.o=t||-1}append(t){let n=0|this.o;const e=0|t.length;let o=0;if(e>=8&&t.buffer){const r=new u(t.buffer,t.byteOffset,e),c=e-8;for(;o<=c;o+=8){const t=n^r.getInt32(o,!0),e=r.getInt32(o+4,!0);n=D[255&t]^P[t>>>8&255]^x[t>>>16&255]^R[t>>>24&255]^E[255&e]^A[e>>>8&255]^M[e>>>16&255]^I[e>>>24&255]}}for(;o<e;o++)n=n>>>8^I[255&(n^t[o])];this.o=n}get(){return~this.o}}class U extends h{constructor(){let t;const n=new F;super({transform(t,e){n.append(t),e.enqueue(t)},flush(){const e=new c(4);new u(e.buffer).setUint32(0,n.get()),t.value=e}}),t=this}}function B(t,n){const e=new c(t.length+n.length);return e.set(t),e.set(n,t.length),e}function W(t){return new u(t.buffer,t.byteOffset,t.byteLength)}const O=64,V=20,K=new c([128]),T=new c(1),_=new i([1732584193,4023233417,2562383102,271733878,3285377520]),j=new c(256),H=new i(256),L=new i(256),Z=new i(256),N=new i(256);let q=!1;function G(t,n){!function(){if(!q){let t=1,n=1;do{t=255&(t^t<<1^(128&t?27:0)),n=255&(n^n<<1),n=255&(n^n<<2),n=255&(n^n<<4),128&n&&(n^=9),j[t]=255&(n^(n<<1|n>>7)^(n<<2|n>>6)^(n<<3|n>>5)^(n<<4|n>>4)^99)}while(1!=t);j[0]=99;for(let t=0;t<256;t++){const n=j[t],e=Y(n),o=e<<24|n<<16|n<<8|e^n;H[t]=o,L[t]=o>>>8|o<<24,Z[t]=o>>>16|o<<16,N[t]=o>>>24|o<<8}q=!0}}();const e=new i(60),o=function(t,n){const e=t.length>>2,o=e+6,r=4*(o+1);let c=1;for(let o=0;o<e;o++)n[o]=t[4*o]<<24|t[4*o+1]<<16|t[4*o+2]<<8|t[4*o+3];for(let t=e;t<r;t++){let o=n[t-1];t%e==0?(o=Q(o<<8|o>>>24)^c<<24,c=Y(c)):e>6&&t%e==4&&(o=Q(o)),n[t]=n[t-e]^o}return o}(t,e),r=new i(4),c=J(n);let s=0,a=0,f=0,w=0;return{process(t,n){n&&c.update(t,0,t.length),function(t){const n=new u(t.buffer,t.byteOffset,t.byteLength),e=t.length;let o=0;for(;o+16<=e;o+=16)l(),n.setInt32(o,n.getInt32(o)^r[0]),n.setInt32(o+4,n.getInt32(o+4)^r[1]),n.setInt32(o+8,n.getInt32(o+8)^r[2]),n.setInt32(o+12,n.getInt32(o+12)^r[3]);if(o<e){l();for(let n=0;o<e;o++,n++)t[o]^=r[n>>2]>>>24-8*(3&n)}}(t),n||c.update(t,0,t.length)},digest:()=>c.digest()};function l(){s=s+1|0,s||(a=a+1|0,a||(f=f+1|0,f||(w=w+1|0)));let t=X(s)^e[0],n=X(a)^e[1],c=X(f)^e[2],i=X(w)^e[3],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[4],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[5],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[6],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[7];t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[8],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[9],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[10],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[11],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[12],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[13],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[14],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[15],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[16],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[17],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[18],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[19],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[20],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[21],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[22],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[23],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[24],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[25],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[26],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[27],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[28],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[29],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[30],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[31],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[32],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[33],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[34],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[35],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[36],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[37],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[38],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[39];let h=40;o>10&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[40],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[41],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[42],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[43],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[44],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[45],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[46],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[47],h=48),o>12&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[48],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[49],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[50],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[51],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[52],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[53],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[54],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[55],h=56),r[0]=(j[u>>>24]<<24|j[l>>>16&255]<<16|j[d>>>8&255]<<8|j[255&p])^e[h],r[1]=(j[l>>>24]<<24|j[d>>>16&255]<<16|j[p>>>8&255]<<8|j[255&u])^e[h+1],r[2]=(j[d>>>24]<<24|j[p>>>16&255]<<16|j[u>>>8&255]<<8|j[255&l])^e[h+2],r[3]=(j[p>>>24]<<24|j[u>>>16&255]<<16|j[l>>>8&255]<<8|j[255&d])^e[h+3]}}function J(t){const n=function(){const t=new i(_),n=new i(16),e=new c(O),r=new u(e.buffer),s=new c(8);let a=0,f=0;return{update:w,digest:function(){const n=8*f,e=o.floor(n/4294967296),r=n>>>0;for(w(K,0,1);56!=a;)w(T,0,1);s[0]=e>>>24,s[1]=e>>>16,s[2]=e>>>8,s[3]=e,s[4]=r>>>24,s[5]=r>>>16,s[6]=r>>>8,s[7]=r,w(s,0,8);const i=new c(V),l=new u(i.buffer);for(let n=0;n<t.length;n++)l.setInt32(4*n,t[n]);return t.set(_),a=0,f=0,i}};function w(t,n,o){const c=n+o;if(f+=o,a){for(;n<c&&a<O;)e[a++]=t[n++];a==O&&(l(r,0),a=0)}if(n+O<=c){const e=new u(t.buffer,t.byteOffset,t.byteLength);for(;n+O<=c;n+=O)l(e,n)}for(;n<c;)e[a++]=t[n++]}function l(e,o){for(let t=0;t<16;t++)n[t]=e.getInt32(o+4*t);let r,c=t[0],s=t[1],a=t[2],i=t[3],f=t[4];for(let t=0;t<15;t+=5)f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[t]|0,s=s<<30|s>>>2,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+n[t+1]|0,c=c<<30|c>>>2,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+n[t+2]|0,f=f<<30|f>>>2,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+n[t+3]|0,i=i<<30|i>>>2,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+n[t+4]|0,a=a<<30|a>>>2;f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[15]|0,s=s<<30|s>>>2,r=n[13]^n[8]^n[2]^n[0],r=r<<1|r>>>31,n[0]=r,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+r|0,c=c<<30|c>>>2,r=n[14]^n[9]^n[3]^n[1],r=r<<1|r>>>31,n[1]=r,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+r|0,f=f<<30|f>>>2,r=n[15]^n[10]^n[4]^n[2],r=r<<1|r>>>31,n[2]=r,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+r|0,i=i<<30|i>>>2,r=n[0]^n[11]^n[5]^n[3],r=r<<1|r>>>31,n[3]=r,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+r|0,a=a<<30|a>>>2;for(let t=20;t<40;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+1859775393+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+1859775393+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+1859775393+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+1859775393+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+1859775393+r|0,a=a<<30|a>>>2;for(let t=40;t<60;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s&a|(s|a)&i)+f+2400959708+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c&s|(c|s)&a)+i+2400959708+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f&c|(f|c)&s)+a+2400959708+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i&f|(i|f)&c)+s+2400959708+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a&i|(a|i)&f)+c+2400959708+r|0,a=a<<30|a>>>2;for(let t=60;t<80;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+3395469782+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+3395469782+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+3395469782+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+3395469782+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+3395469782+r|0,a=a<<30|a>>>2;t[0]=t[0]+c|0,t[1]=t[1]+s|0,t[2]=t[2]+a|0,t[3]=t[3]+i|0,t[4]=t[4]+f|0}}(),e=new c(O),r=new c(O);t.length>O&&(n.update(t,0,t.length),t=n.digest());for(let n=0;n<O;n++){const o=n<t.length?t[n]:0;e[n]=54^o,r[n]=92^o}return n.update(e,0,O),{update(t,e,o){n.update(t,e,o)},digest(){const t=n.digest();n.update(r,0,O),n.update(t,0,V);const o=n.digest();return n.update(e,0,O),o}}}function Q(t){return j[t>>>24]<<24|j[t>>>16&255]<<16|j[t>>>8&255]<<8|j[255&t]}function X(t){return t<<24|(65280&t)<<8|t>>>8&65280|t>>>24}function Y(t){return 255&(t<<1^27*(t>>7))}const $=typeof d!=b&&typeof d.getRandomValues==k,tt="Invalid password",nt="zipjs-abort-check-password";function et(t){if($)return d.getRandomValues(t);throw new r("Crypto API not supported")}const ot={name:"PBKDF2"},rt=n.assign({hash:{name:"HMAC"}},ot),ct=n.assign({iterations:1e3,hash:{name:"SHA-1"}},ot),st=["deriveBits"],at=[8,12,16],it=[16,24,32],ft=10,ut=typeof d!=b,wt=ut&&d.subtle;let lt=ut&&typeof wt!=b&&typeof wt.importKey==k&&typeof wt.deriveBits==k,dt=G;class pt extends h{constructor({password:t,rawPassword:n,encryptionStrength:e,checkPasswordOnly:o,checkAuthenticationCode:s=!0}){const a={};super({start(){yt(a,t,n,e)},async transform(t,n){const{password:e,strength:s,l:i,ready:f}=a;if(e?(await async function(t,n,e,o){const c=await vt(t,n,e,kt(o,0,at[n])),s=kt(o,at[n]);if(c[0]!=s[0]||c[1]!=s[1])throw gt(t),new r(tt)}(a,s,e,kt(t,0,at[s]+2)),t=kt(t,at[s]+2),o?(gt(a),n.error(new r(nt))):i()):await f,a.h)return;const u=new c(t.length-ft-(t.length-ft)%16);n.enqueue(St(a,t,u,0,ft,!0))},async flush(t){const{m:n,S:e,ready:o}=a;if(n){if(await o,a.h)return;const i=kt(e,e.length-ft),f=new c(kt(e,0,e.length-ft));n.process(f,!0);const u=n.digest();let w=e.length<ft?1:0;for(let t=0;t<ft;t++)w|=u[t]^i[t];if(w&&s)return void t.error(new r("Invalid authentication code"));t.enqueue(f)}}}),mt(this,a)}}class ht extends h{constructor({password:t,rawPassword:n,encryptionStrength:e}){const o={};super({start(){yt(o,t,n,e)},async transform(t,n){const{password:e,strength:r,l:s,ready:a}=o;let i=z;if(e?(i=await async function(t,n,e){const o=et(new c(at[n]));return B(o,await vt(t,n,e,o))}(o,r,e),s()):await a,o.h)return;const f=new c(i.length+t.length-t.length%16);f.set(i,0),n.enqueue(St(o,t,f,i.length,0,!1))},async flush(t){const{m:n,S:e,ready:r}=o;if(n){if(await r,o.h)return;const s=new c(e);n.process(s,!1);const a=kt(n.digest(),0,ft);t.enqueue(B(s,a))}}}),mt(this,o)}}function yt(t,e,o,r){n.assign(t,{ready:new w(n=>t.l=n),password:bt(e,o),strength:r-1,S:z,h:!1})}function mt(t,e){const o=t.readable.getReader(),r=new y({async pull(t){try{const{value:n,done:e}=await o.read();e?t.close():t.enqueue(n)}catch(t){throw gt(e),o.cancel(t).catch(()=>{}),t}},cancel:t=>(gt(e),o.cancel(t))});n.defineProperty(t,"readable",{get:()=>r})}function St(t,n,e,o,r,s){const{m:a,S:i}=t;i.length&&(n=B(i,n));const f=n.length-r,u=f-f%16;if(e=function(t,n){if(n&&n>t.length){const e=t;(t=new c(n)).set(e,0)}return t}(e,o+u),u){const t=kt(e,o,o+u);t.set(kt(n,0,u)),a.process(t,s)}return t.S=kt(n,u),e}function gt(t){const{m:n}=t;t.h=!0,n&&n.dispose&&n.dispose()}async function vt(t,e,r,s){t.password=null;const a=it[e],i=await async function(t,e,r){if(lt)try{const o=await wt.importKey("raw",t,rt,!1,st);return new c(await wt.deriveBits(n.assign({salt:e},ct),o,8*r))}catch{lt=!1}return function(t,n,e,r){const s=J(t),a=new c(r),i=new c(n.length+4),f=new u(i.buffer);i.set(n);for(let t=1,e=0;e<r;t++,e+=V){f.setUint32(n.length,t),s.update(i,0,i.length);let c=s.digest();const u=c.slice();for(let t=1;t<1e3;t++){s.update(c,0,V),c=s.digest();for(let t=0;t<V;t++)u[t]^=c[t]}a.set(u.subarray(0,o.min(V,r-e)),e)}return a}(t,e,0,r)}(r,s,2*a+2);return t.m=dt(kt(i,0,a),kt(i,a,2*a)),t.h&&gt(t),kt(i,2*a)}function bt(t,n){return n===v?function(t){if(typeof l==b){t=unescape(encodeURIComponent(t));const n=new c(t.length);for(let e=0;e<n.length;e++)n[e]=t.charCodeAt(e);return n}return(new l).encode(t)}(t):n}function kt(t,n,e){return t.subarray(n,e)}class zt extends h{constructor({password:t,rawPassword:n,passwordVerification:e,checkPasswordOnly:o}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;if(e.password||e.rawPassword){const n=Mt(e,t.subarray(0,12));if(e.password=e.rawPassword=null,0!=(n[11]^e.passwordVerification))throw new r(tt);t=t.subarray(12)}o?n.error(new r(nt)):n.enqueue(Mt(e,t))}})}}class Ct extends h{constructor({password:t,rawPassword:n,passwordVerification:e}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;let o,r;if(e.password||e.rawPassword){e.password=e.rawPassword=null;const n=et(new c(12));n[11]=e.passwordVerification,o=new c(t.length+n.length),o.set(At(e,n),0),r=12}else o=new c(t.length),r=0;o.set(At(e,t),r),n.enqueue(o)}})}}function It(t,e,o,r){n.assign(t,{password:e,rawPassword:o,passwordVerification:r}),function(t,e,o){const r=[305419896,591751049,878082192];if(n.assign(t,{v:r,C:new F(r[0]),I:new F(r[2])}),o)for(let n=0;n<o.length;n++)Et(t,o[n]);else for(let n=0;n<e.length;n++)Et(t,e.charCodeAt(n))}(t,e,o)}function Mt(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,e[o]);return e}function At(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,n[o]);return e}function Et(t,n){let[,e]=t.v;t.C.append([n]);const r=~t.C.get();e=Pt(o.imul(Pt(e+xt(r)),134775813)+1),t.I.append([e>>>24]);const c=~t.I.get();t.v=[r,e,c]}function Rt(t){const n=2|t.v[2];return xt(o.imul(n,1^n)>>>8)}function xt(t){return 255&t}function Pt(t){return 4294967295&t}function Dt(t){return Boolean(t)&&"object"==typeof t}const Ft=new f;function Ut(t){return Ft.get(t)}const Bt="Invalid uncompressed size",Wt="Codec out of memory",Ot="Invalid CRC32",Vt="deflate-raw",Kt="gzip",Tt=[31,139,8];class _t extends h{constructor(t,{chunkSize:n,CompressionStreamFallback:e,CompressionStream:o}){super({});const{compressed:r,encrypted:c,useCompressionStream:s,zipCrypto:a,computeCrc32:i,level:f,deflate64:w,format:l,compressionMethod:d,inputSize:p}=t,h=this;let y,m,S,g=super.readable;const v=l&&Ut(l),b=qt(s,o,e),k=i&&r&&!w&&!v&&(!c||a)&&Boolean(b);if(c&&!a||!i||k||(y=new U,g=Jt(g,y)),r)if(v)g=Qt(g,Nt(v.CompressionStream,l,{level:f,chunkSize:n,compressionMethod:d,uncompressedSize:p}));else if(k)S=new jt,g=Qt(g,new b(Kt,{level:f,chunkSize:n})),g=Jt(g,S);else try{g=Gt(g,s,{level:f,chunkSize:n},o,e)}catch(t){if(!s&&e)throw nn(t);let n;try{n=new o(Kt)}catch{throw nn(t)}g=Qt(g,n),g=Jt(g,new jt)}c&&(a?g=Jt(g,new Ct(t)):(m=new ht(t),g=Jt(g,m))),Zt(h,g,()=>{c&&!a||!i||(h.crc32=k?S.crc32:new u(y.value.buffer).getUint32(0))})}}class jt extends h{constructor(){let t,n=10,e=new c(0);super({transform(t,r){if(n){const e=o.min(n,t.length);if(n-=e,!(t=t.subarray(e)).length)return}const c=e.length+t.length;if(c<=8)return void(e=B(e,t));const s=c-8,a=o.min(s,e.length);r.enqueue(B(e.subarray(0,a),t.subarray(0,s-a))),e=B(e.subarray(a),t.subarray(s-a))},flush(){const n=W(e);t.crc32=n.getUint32(0,!0),t.uncompressedSize=n.getUint32(4,!0)}}),t=this}}class Ht extends h{constructor(t,{chunkSize:n,DecompressionStreamFallback:e,DecompressionStream:o}){super({});const{zipCrypto:s,encrypted:a,checkCrc32:i,crc32:f,compressed:l,useCompressionStream:d,deflate64:p,format:h,compressionMethod:m,rawBitFlag:S,outputSize:g}=t;let b,k,z,C=super.readable;if(a&&(s?C=Jt(C,new zt(t)):(k=new pt(t),C=Jt(C,k))),l){const t=new Set,s=h&&Ut(h);let a;if(s)C=Qt(C,Nt(s.DecompressionStream,h,{chunkSize:n,compressionMethod:m,rawBitFlag:S,uncompressedSize:g}),t);else{const r=qt(d,o,e);if(i&&!p&&f!==v&&g!==v&&r)try{a=new r(Kt,{chunkSize:n})}catch{a=v}if(!a)try{C=Gt(C,d,{chunkSize:n,deflate64:p},o,e,t)}catch(t){if(p||g===v||!d&&e)throw nn(t);try{a=new o(Kt)}catch{throw nn(t)}}}a?(z=!0,C=function(t,n,e,o,s){const a=n.writable.getWriter(),i=n.readable.getReader(),f=o===v?new F:v;let u,l,d=0,p=!1,h=!1;const m=new y({start(t){l=t},pull(){b()},cancel:t=>(h=!0,b(),i.cancel(t))});return async function(){const n=t.getReader();try{const t=new c(10);for(t.set(Tt),await a.write(t);;){await g(),await a.ready;const{value:t,done:e}=await $t(n,s);if(e)break;await a.write(t)}f&&await a.write(new c(0));const r=new c(8),i=W(r);i.setUint32(0,f?f.get():o,!0),i.setUint32(4,e,!0),p=!0,await a.write(r),await a.close()}catch(t){await Xt(a,t),await Yt(n,t)}}(),async function(){try{for(;;){const{value:t,done:n}=await S();if(n)break;if(d+=t.length,d>e)throw new r(Bt);f&&f.append(t),l.enqueue(t)}h||(h=!0,l.close())}catch(t){!function(t){h||(h=!0,l.error(t),b())}(t),await Yt(i,t)}}(),m;function S(){return i.read().catch(t=>{if(p){if(!f)throw on(t,Ot);if(d!=e)throw on(t,Bt);return{done:!0}}throw tn(t,s)})}function g(){if(!h&&l.desiredSize<=0)return new w(t=>u=t)}function b(){if(u){const t=u;u=v,t()}}}(C,a,g,f,t)):C=function(t,n){const e=t.getReader();return new y({async pull(t){try{const{value:n,done:o}=await e.read();o?t.close():t.enqueue(n)}catch(t){throw await Yt(e,t),tn(t,n)}},cancel:t=>e.cancel(t)})}(C,t)}i&&!z&&(b=new U,C=Jt(C,b)),Zt(this,C,()=>{if(b){const t=new u(b.value.buffer).getUint32(0,!1);if(f!=t)throw new r(Ot)}})}}const Lt=new f;function Zt(t,e,o){e=Jt(e,new h({flush:o})),n.defineProperty(t,"readable",{get:()=>e})}function Nt(t,n,e){if(!t)throw new r("Compression method not supported");return new t(n,e)}function qt(t,n,e){return t&&n?n:e&&e.requiresModule?e:void 0}function Gt(t,n,e,o,r,c){const s=n&&o?o:r||o,a=e.deflate64?"deflate64-raw":Vt;let i;try{i=new s(a,e)}catch(t){if(!n||!r||s==r)throw t;i=new r(a,e)}return Qt(t,i,c)}function Jt(t,n){return function(t){if(t instanceof y)return t;const n=t.getReader();return new y({async pull(t){try{const{value:e,done:o}=await n.read();o?t.close():t.enqueue(e)}catch(t){throw n.cancel(t).catch(()=>{}),t}},cancel:t=>n.cancel(t)})}(t).pipeThrough(n)}function Qt(t,n,e){const o=n.writable.getWriter(),r=t.getReader();return async function(){try{for(;;){await o.ready;const t=await $t(r,e);if(t.done){await o.close();break}await o.write(t.value)}}catch(t){await Xt(o,t),await Yt(r,t)}}(),n.readable}async function Xt(t,n){try{await t.abort(n)}catch{}}async function Yt(t,n){try{await t.cancel(n)}catch{}}function $t(t,n){const e=t.read();return n?e.catch(t=>{throw n.add(t),t}):e}function tn(t,n){return n.has(t)?t:on(t,en(t)?Wt:"Invalid compressed data")}function nn(t){return en(t)?on(t,Wt):t}function en(t){return Dt(t)&&"Z_MEM_ERROR"==t.code}function on(t,n){const e=new r(n);return e.cause=t,e}const rn="data",cn="deflate";class sn extends h{constructor(t,e){super({});const o=this,{codecType:c}=t;let s;c.startsWith(cn)?s=_t:c.startsWith("inflate")&&(s=Ht),o.outputSize=0;let a=0;const i=new s(t,e),f=super.readable,u=new h({transform(t,n){t&&t.length&&(a+=t.length,n.enqueue(t))},flush(){n.assign(o,{inputSize:a})}}),w=new h({transform(n,e){if(n&&n.length&&(e.enqueue(n),o.outputSize+=n.length,t.outputSize!==v&&o.outputSize>t.outputSize))throw new r(Bt)},flush(){const{crc32:t}=i;n.assign(o,{crc32:t,inputSize:a})}});n.defineProperty(o,"readable",{get:()=>f.pipeThrough(u).pipeThrough(i).pipeThrough(w)})}}class an extends h{constructor(t){const o=[];let r=0,s=0;function a(){const n=new c(t);let e=0;for(;e<t;){const r=o[0],c=t-e;r.length<=c?(n.set(r,e),e+=r.length,o.shift()):(n.set(r.subarray(0,c),e),o[0]=r.subarray(c),e+=c)}return r-=t,n}(!e.isFinite(t)||t<1)&&(t=262144),super({transform(n,e){for(o.push(n),r+=n.length;r>t;)s+=t,e.enqueue(a())},flush(t){r&&(s+=r,t.enqueue(function(t,n){const e=new c(n);let o=0;for(const n of t)e.set(n,o),o+=n.length;return e}(o,r)))}}),n.defineProperty(this,"outputSize",{get:()=>s})}}let fn=2;try{typeof navigator!=b&&navigator.hardwareConcurrency&&(fn=navigator.hardwareConcurrency)}catch{}const un=new f,wn=new f,ln=function(){try{return structuredClone(new r)instanceof r}catch{return!1}}();let dn=0;async function pn(t){let n,c,s;try{const{options:a,config:i}=t;if(a.format)try{await async function(t,n){!Ft.has(t)&&n&&function(t,n){const{CompressionStream:e,DecompressionStream:o}=n;if(typeof e!=k&&typeof o!=k)throw new r("Invalid codec module");Ft.set(t,{CompressionStream:e,DecompressionStream:o})}(t,await(import(n)))}(a.format,a.codecURI)}catch(t){if(Dt(t))try{t.codecImportFailed=!0}catch{}throw t}if(i.CompressionStream=self.CompressionStream,i.DecompressionStream=self.DecompressionStream,a.compressed&&!a.format)if(a.useCompressionStream){if(!function(t,n){if(!t)return!1;let e=Lt.get(t);e||(e=new f,Lt.set(t,e));let o=e.get(n);if(o===v){try{new t(n),o=!0}catch{o=!1}e.set(n,o)}return o}(a.codecType.startsWith(cn)?i.CompressionStream:i.DecompressionStream,Vt))try{await self.initModule(t.config)}catch{}}else try{await self.initModule(t.config)}catch{a.useCompressionStream=!0}if(a.encrypted&&!a.zipCrypto)try{await self.initModule(t.config)}catch{}!i.CompressionStreamFallback&&i.CompressionStreamZlib&&(i.CompressionStreamFallback=i.CompressionStreamZlib),!i.DecompressionStreamFallback&&i.DecompressionStreamZlib&&(i.DecompressionStreamFallback=i.DecompressionStreamZlib);const u={highWaterMark:1},l=new y({async pull(t){const n=new w(t=>un.set(dn,t));hn({type:"pull",messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER;const{value:o,done:r}=await n;t.enqueue(o),r&&t.close()}},u);s=new m({async write(t){let n;const o=new w(t=>n=t);wn.set(dn,n),hn({type:rn,value:t,messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER,await o}},u),n=new sn(a,i),c=new an(function(t){return r="string"==typeof(n=r=t.chunkSize)&&n.trim()?e(n):n,e.isInteger(r)&&r>=1?o.max(r,64):262144;var n,r}(i)),await l.pipeThrough(n).pipeThrough(c).pipeTo(s,{preventClose:!0,preventAbort:!0}),await s.getWriter().close();const{crc32:d,inputSize:p,outputSize:h}=n;hn({type:"close",result:{crc32:d,inputSize:p,outputSize:h}})}catch(t){const n=c?c.outputSize:0;if(Dt(t))try{t.outputSize=n}catch{}if(s&&!s.locked)try{await s.getWriter().close()}catch{}yn(t,n)}}function hn(t){const{value:n}=t;if(n)if(n.length)try{t.value=(e=n,e.byteOffset||e.byteLength!=e.buffer.byteLength?new c(e):e).buffer,p(t,[t.value])}catch{p(t)}else p(t);else p(t);var e}function yn(t,n){const{message:e,stack:o,code:c,name:s,outputSize:a,cause:i,codecImportFailed:f}=function(t=new r("Unknown error")){return Dt(t)?t:new r(String(t))}(t),u={message:e,stack:o,code:c,name:s,outputSize:a===v?n:a};if(Dt(i)&&(u.cause={name:i.name,message:i.message,code:i.code}),f&&(u.codecImportFailed=!0),ln)try{return void p({error:u,errorValue:{value:t}})}catch{}p({error:u})}addEventListener("message",({data:t})=>{const{type:n,messageId:e,value:o,done:r}=t;try{if("start"==n&&pn(t),n==rn){const t=un.get(e);un.delete(e),t({value:o||new c,done:r})}if("ack"==n){const t=wn.get(e);wn.delete(e),t()}}catch(t){yn(t)}}),p({type:"ready"});const mn="deflate",Sn="deflate-raw",gn="deflate64-raw",vn="gzip",bn=[mn,Sn,vn],kn=[mn,Sn,vn,gn];let zn,Cn,In,Mn,An;function En(t,n){return-4===n&&(t.code="Z_MEM_ERROR"),t}function Rn(t,n,e={}){if(!(t?bn:kn).includes(n))throw new TypeError("Unsupported format: "+n);if(!zn){const t=new r("WASM module not loaded");throw t.cause=An,t}const s="number"==typeof e.level?e.level:-1,a="number"==typeof e.outBuffer?e.outBuffer:65536,i="number"==typeof e.inBufferSize?e.inBufferSize:65536,f={M:0,in:0,inBufferSize:0,A:0,R:!1};let u,l,d,p,h=!0,S=!1;return function(){try{let e;if(f.M=Cn(a),f.in=Cn(i),f.inBufferSize=i,!f.M||!f.in)throw En(new r("allocation failed"),-4);if(t?(f.P=zn.deflate_process,f.D=zn.deflate_last_consumed,f.F=zn.deflate_end,f.A=zn.deflate_new(),e=n===vn?zn.deflate_init_gzip(f.A,s):n===Sn?zn.deflate_init_raw(f.A,s):zn.deflate_init(f.A,s)):n===gn?(f.P=zn.inflate9_process,f.D=zn.inflate9_last_consumed,f.F=zn.inflate9_end,f.A=zn.inflate9_new(),e=zn.inflate9_init_raw(f.A)):(f.P=zn.inflate_process,f.D=zn.inflate_last_consumed,f.F=zn.inflate_end,f.A=zn.inflate_new(),e=n===Sn?zn.inflate_init_raw(f.A):n===vn?zn.inflate_init_gzip(f.A):zn.inflate_init(f.A)),0!==e)throw En(new r("init failed:"+e),e)}catch(t){throw b(f),t}}(),{readable:new y({start(t){u=t},pull(){h=!1,v()},cancel(t){S=!0,p=t,b(f),l.error(t),v()}},{highWaterMark:0}),writable:new m({start(t){l=t},async write(t){if(h&&await new w(t=>d=t),S)throw p;try{!function(t){const n=new c(Mn.buffer),e=f.P,s=f.D,i=f.M;let u=0;for(;u<t.length;){if(f.R)throw new r("trailing data after the end of the stream");const c=o.min(t.length-u,32768);if((!f.in||f.inBufferSize<c)&&(f.in&&In&&(In(f.in),f.in=0),f.in=Cn(c),f.inBufferSize=c,!f.in))throw En(new r("allocation failed"),-4);n.set(t.subarray(u,u+c),f.in);const w=e(f.A,f.in,c,i,a,0),l=w>>24&255,d=128&l?l-256:l;if(d<0)throw En(new r("process error:"+d),d);const p=16777215&w;p&&g(n.slice(i,i+p));const h=s(f.A);if(1===l)f.R=!0;else if(0===h&&0===p)break;u+=h}}(t)}catch(t){throw b(f),u.error(t),t}},close(){if(S)return;try{!function(){const t=new c(Mn.buffer),n=f.P,e=f.M;for(;;){const o=n(f.A,0,0,e,a,4),c=o>>24&255,s=128&c?c-256:c;if(s<0)throw En(new r("process error:"+s),s);const i=16777215&o;if(i&&g(t.slice(e,e+i)),1===c||0===i)break}}()}catch(t){throw b(f),u.error(t),t}const t=b(f);if(0!==t){const n=En(new r("end error:"+t),t);throw u.error(n),n}u.close()},abort(t){b(f),u.error(t)}},{highWaterMark:1})};function g(t){h=!0,u.enqueue(t)}function v(){if(d){const t=d;d=null,t()}}function b(t){let n=0;return t.A&&t.F&&(n=t.F(t.A)),t.A=0,t.in&&In&&In(t.in),t.in=0,t.M&&In&&In(t.M),t.M=0,n}}class xn{constructor(t=mn,n){return Rn(!0,t,n)}}class Pn{constructor(t=mn,n){return Rn(!1,t,n)}}xn.requiresModule=!0,Pn.requiresModule=!0,xn.supportedFormats=bn,Pn.supportedFormats=kn;const Dn=65536;let Fn,Un;function Bn(t){return new c(t.memory.buffer)}let Wn=!1;!function(t={}){const{init:n,U:e}=t,o=t.CompressionStreamFallback||t.CompressionStreamZlib,r=t.DecompressionStreamFallback||t.DecompressionStreamZlib;e&&(dt=e||G),self.initModule=async t=>{n&&await n(t),o&&(t.CompressionStreamFallback=o),r&&(t.DecompressionStreamFallback=r)}}({CompressionStreamFallback:xn,DecompressionStreamFallback:Pn,U:function(t,n){const e=Fn;let o=e?function(t,n,e){Un||(Un=t.malloc(Dn));const o=Un?t.aes_hmac_new():0;if(o){const r=Bn(t);if(r.set(n,Un),r.set(e,Un+n.length),t.aes_hmac_init(o,Un,n.length,Un+n.length,e.length))return t.aes_hmac_end(o,0),0}return o}(e,t,n):0;if(!o)return G(t,n);const r=Un;return{process(t,n){for(let c=0;c<t.length;c+=Dn){const s=t.subarray(c,c+Dn),a=Bn(e);a.set(s,r),e.aes_hmac_process(o,r,s.length,n?1:0),s.set(a.subarray(r,r+s.length))}},digest:()=>(e.aes_hmac_end(o,r),o=0,Bn(e).slice(r,r+20)),dispose(){o&&(e.aes_hmac_end(o,0),o=0)}}},init:t=>async function(t,{baseURI:n}){if(!Wn)try{await async function(t,n){let e,o;try{try{o=new URL(t,n)}catch{}const r=await fetch(o);e=await r.arrayBuffer()}catch(n){if(!t.startsWith("data:application/wasm;base64,"))throw n;e=function(t){const n=t.split(",")[1],e=atob(n),o=e.length,r=new c(o);for(let t=0;t<o;++t)r[t]=e.charCodeAt(t);return r.buffer}(t)}const s=await WebAssembly.instantiate(e);var a;(function(t){if(zn=t,({malloc:Cn,free:In,memory:Mn}=zn),"function"!=typeof Cn||"function"!=typeof In||!Mn)throw zn=Cn=In=Mn=null,new r("Invalid WASM module")})(s.instance.exports),typeof(a=s.instance.exports).aes_hmac_new==k&&(Fn=a,Un=0)}(t,n),Wn=!0}catch(t){throw function(t){An=t}(t),t}}(t.wasmURI,t)})});
`;
  if (typeof a == "string" && (a = new TextEncoder().encode(a)), e) {
    const r = new Blob([a], { type: n });
    return URL.createObjectURL(r);
  }
  return "data:" + n + ";base64," + (function(r) {
    let s = "";
    const i = r.length;
    let o = 0;
    for (; o + 2 < i; o += 3) {
      const f = r[o] << 16 | r[o + 1] << 8 | r[o + 2];
      s += G[f >> 18 & 63] + G[f >> 12 & 63] + G[f >> 6 & 63] + G[63 & f];
    }
    const l = i - o;
    if (l === 1) {
      const f = r[o] << 16;
      s += G[f >> 18 & 63] + G[f >> 12 & 63] + "==";
    } else if (l === 2) {
      const f = r[o] << 16 | r[o + 1] << 8;
      s += G[f >> 18 & 63] + G[f >> 12 & 63] + G[f >> 6 & 63] + "=";
    }
    return s;
  })(a);
} });
function st(t, e) {
  const n = new Uint8Array(t.length + e.length);
  return n.set(t), n.set(e, t.length), n;
}
function ln(t) {
  return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
function Ka(t) {
  return !!t && typeof t == "object";
}
const mt = [[], [], [], [], [], [], [], []];
for (let t = 0; t < 256; t++) {
  let e = t;
  for (let n = 0; n < 8; n++)
    e = e & 1 ? e >>> 1 ^ 3988292384 : e >>> 1;
  mt[0][t] = e;
}
for (let t = 0; t < 256; t++)
  for (let e = 1; e < 8; e++) {
    const n = mt[e - 1][t];
    mt[e][t] = n >>> 8 ^ mt[0][n & 255];
  }
const [ke, ja, Qa, _a, $a, tr, er, nr] = mt;
class qt {
  constructor(e) {
    this.crc = e || -1;
  }
  append(e) {
    let n = this.crc | 0;
    const a = e.length | 0;
    let r = 0;
    if (a >= 8 && e.buffer) {
      const s = new DataView(e.buffer, e.byteOffset, a), i = a - 8;
      for (; r <= i; r += 8) {
        const o = n ^ s.getInt32(r, !0), l = s.getInt32(r + 4, !0);
        n = nr[o & 255] ^ er[o >>> 8 & 255] ^ tr[o >>> 16 & 255] ^ $a[o >>> 24 & 255] ^ _a[l & 255] ^ Qa[l >>> 8 & 255] ^ ja[l >>> 16 & 255] ^ ke[l >>> 24 & 255];
      }
    }
    for (; r < a; r++)
      n = n >>> 8 ^ ke[(n ^ e[r]) & 255];
    this.crc = n;
  }
  get() {
    return ~this.crc;
  }
}
class dn extends TransformStream {
  constructor() {
    let e;
    const n = new qt();
    super({
      transform(a, r) {
        n.append(a), r.enqueue(a);
      },
      flush() {
        const a = new Uint8Array(4);
        new DataView(a.buffer).setUint32(0, n.get()), e.value = a;
      }
    }), e = this;
  }
}
function ar(t) {
  if (typeof TextEncoder == et) {
    t = unescape(encodeURIComponent(t));
    const e = new Uint8Array(t.length);
    for (let n = 0; n < e.length; n++)
      e[n] = t.charCodeAt(n);
    return e;
  } else
    return new TextEncoder().encode(t);
}
const Qt = 16, rr = 60, H = 64, at = 20, sr = 16, ir = 56, or = new Uint8Array([128]), cr = new Uint8Array(1), Re = new Int32Array([1732584193, 4023233417, 2562383102, 271733878, 3285377520]), lr = 54, dr = 92, T = new Uint8Array(256), v = new Int32Array(256), I = new Int32Array(256), S = new Int32Array(256), A = new Int32Array(256);
let Pe = !1;
function pe(t, e) {
  pr();
  const n = new Int32Array(rr), a = hr(t, n), r = new Int32Array(Qt / 4), s = un(e);
  let i = 0, o = 0, l = 0, f = 0;
  return {
    process(c, u) {
      u && s.update(c, 0, c.length), h(c), u || s.update(c, 0, c.length);
    },
    digest() {
      return s.digest();
    }
  };
  function h(c) {
    const u = new DataView(c.buffer, c.byteOffset, c.byteLength), w = c.length;
    let m = 0;
    for (; m + Qt <= w; m += Qt)
      y(), u.setInt32(m, u.getInt32(m) ^ r[0]), u.setInt32(m + 4, u.getInt32(m + 4) ^ r[1]), u.setInt32(m + 8, u.getInt32(m + 8) ^ r[2]), u.setInt32(m + 12, u.getInt32(m + 12) ^ r[3]);
    if (m < w) {
      y();
      for (let g = 0; m < w; m++, g++)
        c[m] ^= r[g >> 2] >>> 24 - 8 * (g & 3);
    }
  }
  function y() {
    i = i + 1 | 0, i || (o = o + 1 | 0, o || (l = l + 1 | 0, l || (f = f + 1 | 0)));
    let c = Dt(i) ^ n[0], u = Dt(o) ^ n[1], w = Dt(l) ^ n[2], m = Dt(f) ^ n[3], g = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[m & 255] ^ n[4], d = v[u >>> 24] ^ I[w >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[c & 255] ^ n[5], p = v[w >>> 24] ^ I[m >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[6], b = v[m >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[w & 255] ^ n[7];
    c = v[g >>> 24] ^ I[d >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[8], u = v[d >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[g & 255] ^ n[9], w = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[d & 255] ^ n[10], m = v[b >>> 24] ^ I[g >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[p & 255] ^ n[11], g = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[m & 255] ^ n[12], d = v[u >>> 24] ^ I[w >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[c & 255] ^ n[13], p = v[w >>> 24] ^ I[m >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[14], b = v[m >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[w & 255] ^ n[15], c = v[g >>> 24] ^ I[d >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[16], u = v[d >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[g & 255] ^ n[17], w = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[d & 255] ^ n[18], m = v[b >>> 24] ^ I[g >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[p & 255] ^ n[19], g = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[m & 255] ^ n[20], d = v[u >>> 24] ^ I[w >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[c & 255] ^ n[21], p = v[w >>> 24] ^ I[m >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[22], b = v[m >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[w & 255] ^ n[23], c = v[g >>> 24] ^ I[d >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[24], u = v[d >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[g & 255] ^ n[25], w = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[d & 255] ^ n[26], m = v[b >>> 24] ^ I[g >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[p & 255] ^ n[27], g = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[m & 255] ^ n[28], d = v[u >>> 24] ^ I[w >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[c & 255] ^ n[29], p = v[w >>> 24] ^ I[m >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[30], b = v[m >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[w & 255] ^ n[31], c = v[g >>> 24] ^ I[d >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[32], u = v[d >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[g & 255] ^ n[33], w = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[d & 255] ^ n[34], m = v[b >>> 24] ^ I[g >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[p & 255] ^ n[35], g = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[m & 255] ^ n[36], d = v[u >>> 24] ^ I[w >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[c & 255] ^ n[37], p = v[w >>> 24] ^ I[m >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[38], b = v[m >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[w & 255] ^ n[39];
    let x = 40;
    a > 10 && (c = v[g >>> 24] ^ I[d >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[40], u = v[d >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[g & 255] ^ n[41], w = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[d & 255] ^ n[42], m = v[b >>> 24] ^ I[g >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[p & 255] ^ n[43], g = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[m & 255] ^ n[44], d = v[u >>> 24] ^ I[w >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[c & 255] ^ n[45], p = v[w >>> 24] ^ I[m >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[46], b = v[m >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[w & 255] ^ n[47], x = 48), a > 12 && (c = v[g >>> 24] ^ I[d >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[b & 255] ^ n[48], u = v[d >>> 24] ^ I[p >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[g & 255] ^ n[49], w = v[p >>> 24] ^ I[b >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[d & 255] ^ n[50], m = v[b >>> 24] ^ I[g >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[p & 255] ^ n[51], g = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[m & 255] ^ n[52], d = v[u >>> 24] ^ I[w >>> 16 & 255] ^ S[m >>> 8 & 255] ^ A[c & 255] ^ n[53], p = v[w >>> 24] ^ I[m >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[54], b = v[m >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[w & 255] ^ n[55], x = 56), r[0] = (T[g >>> 24] << 24 | T[d >>> 16 & 255] << 16 | T[p >>> 8 & 255] << 8 | T[b & 255]) ^ n[x], r[1] = (T[d >>> 24] << 24 | T[p >>> 16 & 255] << 16 | T[b >>> 8 & 255] << 8 | T[g & 255]) ^ n[x + 1], r[2] = (T[p >>> 24] << 24 | T[b >>> 16 & 255] << 16 | T[g >>> 8 & 255] << 8 | T[d & 255]) ^ n[x + 2], r[3] = (T[b >>> 24] << 24 | T[g >>> 16 & 255] << 16 | T[d >>> 8 & 255] << 8 | T[p & 255]) ^ n[x + 3];
  }
}
function ur(t, e, n, a) {
  const r = un(t), s = new Uint8Array(a), i = new Uint8Array(e.length + 4), o = new DataView(i.buffer);
  i.set(e);
  for (let l = 1, f = 0; f < a; l++, f += at) {
    o.setUint32(e.length, l), r.update(i, 0, i.length);
    let h = r.digest();
    const y = h.slice();
    for (let c = 1; c < n; c++) {
      r.update(h, 0, at), h = r.digest();
      for (let u = 0; u < at; u++)
        y[u] ^= h[u];
    }
    s.set(y.subarray(0, Math.min(at, a - f)), f);
  }
  return s;
}
function un(t) {
  const e = fr(), n = new Uint8Array(H), a = new Uint8Array(H);
  t.length > H && (e.update(t, 0, t.length), t = e.digest());
  for (let r = 0; r < H; r++) {
    const s = r < t.length ? t[r] : 0;
    n[r] = s ^ lr, a[r] = s ^ dr;
  }
  return e.update(n, 0, H), {
    update(r, s, i) {
      e.update(r, s, i);
    },
    digest() {
      const r = e.digest();
      e.update(a, 0, H), e.update(r, 0, at);
      const s = e.digest();
      return e.update(n, 0, H), s;
    }
  };
}
function fr() {
  const t = new Int32Array(Re), e = new Int32Array(sr), n = new Uint8Array(H), a = new DataView(n.buffer), r = new Uint8Array(8);
  let s = 0, i = 0;
  return {
    update: o,
    digest: l
  };
  function o(h, y, c) {
    const u = y + c;
    if (i += c, s) {
      for (; y < u && s < H; )
        n[s++] = h[y++];
      s == H && (f(a, 0), s = 0);
    }
    if (y + H <= u) {
      const w = new DataView(h.buffer, h.byteOffset, h.byteLength);
      for (; y + H <= u; y += H)
        f(w, y);
    }
    for (; y < u; )
      n[s++] = h[y++];
  }
  function l() {
    const h = i * 8, y = Math.floor(h / 4294967296), c = h >>> 0;
    for (o(or, 0, 1); s != ir; )
      o(cr, 0, 1);
    r[0] = y >>> 24, r[1] = y >>> 16, r[2] = y >>> 8, r[3] = y, r[4] = c >>> 24, r[5] = c >>> 16, r[6] = c >>> 8, r[7] = c, o(r, 0, 8);
    const u = new Uint8Array(at), w = new DataView(u.buffer);
    for (let m = 0; m < t.length; m++)
      w.setInt32(4 * m, t[m]);
    return t.set(Re), s = 0, i = 0, u;
  }
  function f(h, y) {
    for (let p = 0; p < 16; p++)
      e[p] = h.getInt32(y + 4 * p);
    let c = t[0], u = t[1], w = t[2], m = t[3], g = t[4], d;
    for (let p = 0; p < 15; p += 5)
      g = (c << 5 | c >>> 27) + ((w ^ m) & u ^ m) + g + 1518500249 + e[p] | 0, u = u << 30 | u >>> 2, m = (g << 5 | g >>> 27) + ((u ^ w) & c ^ w) + m + 1518500249 + e[p + 1] | 0, c = c << 30 | c >>> 2, w = (m << 5 | m >>> 27) + ((c ^ u) & g ^ u) + w + 1518500249 + e[p + 2] | 0, g = g << 30 | g >>> 2, u = (w << 5 | w >>> 27) + ((g ^ c) & m ^ c) + u + 1518500249 + e[p + 3] | 0, m = m << 30 | m >>> 2, c = (u << 5 | u >>> 27) + ((m ^ g) & w ^ g) + c + 1518500249 + e[p + 4] | 0, w = w << 30 | w >>> 2;
    g = (c << 5 | c >>> 27) + ((w ^ m) & u ^ m) + g + 1518500249 + e[15] | 0, u = u << 30 | u >>> 2, d = e[13] ^ e[8] ^ e[2] ^ e[0], d = d << 1 | d >>> 31, e[0] = d, m = (g << 5 | g >>> 27) + ((u ^ w) & c ^ w) + m + 1518500249 + d | 0, c = c << 30 | c >>> 2, d = e[14] ^ e[9] ^ e[3] ^ e[1], d = d << 1 | d >>> 31, e[1] = d, w = (m << 5 | m >>> 27) + ((c ^ u) & g ^ u) + w + 1518500249 + d | 0, g = g << 30 | g >>> 2, d = e[15] ^ e[10] ^ e[4] ^ e[2], d = d << 1 | d >>> 31, e[2] = d, u = (w << 5 | w >>> 27) + ((g ^ c) & m ^ c) + u + 1518500249 + d | 0, m = m << 30 | m >>> 2, d = e[0] ^ e[11] ^ e[5] ^ e[3], d = d << 1 | d >>> 31, e[3] = d, c = (u << 5 | u >>> 27) + ((m ^ g) & w ^ g) + c + 1518500249 + d | 0, w = w << 30 | w >>> 2;
    for (let p = 20; p < 40; p += 5)
      d = e[p - 3 & 15] ^ e[p - 8 & 15] ^ e[p - 14 & 15] ^ e[p & 15], d = d << 1 | d >>> 31, e[p & 15] = d, g = (c << 5 | c >>> 27) + (u ^ w ^ m) + g + 1859775393 + d | 0, u = u << 30 | u >>> 2, d = e[p - 2 & 15] ^ e[p - 7 & 15] ^ e[p - 13 & 15] ^ e[p + 1 & 15], d = d << 1 | d >>> 31, e[p + 1 & 15] = d, m = (g << 5 | g >>> 27) + (c ^ u ^ w) + m + 1859775393 + d | 0, c = c << 30 | c >>> 2, d = e[p - 1 & 15] ^ e[p - 6 & 15] ^ e[p - 12 & 15] ^ e[p + 2 & 15], d = d << 1 | d >>> 31, e[p + 2 & 15] = d, w = (m << 5 | m >>> 27) + (g ^ c ^ u) + w + 1859775393 + d | 0, g = g << 30 | g >>> 2, d = e[p & 15] ^ e[p - 5 & 15] ^ e[p - 11 & 15] ^ e[p + 3 & 15], d = d << 1 | d >>> 31, e[p + 3 & 15] = d, u = (w << 5 | w >>> 27) + (m ^ g ^ c) + u + 1859775393 + d | 0, m = m << 30 | m >>> 2, d = e[p + 1 & 15] ^ e[p - 4 & 15] ^ e[p - 10 & 15] ^ e[p + 4 & 15], d = d << 1 | d >>> 31, e[p + 4 & 15] = d, c = (u << 5 | u >>> 27) + (w ^ m ^ g) + c + 1859775393 + d | 0, w = w << 30 | w >>> 2;
    for (let p = 40; p < 60; p += 5)
      d = e[p - 3 & 15] ^ e[p - 8 & 15] ^ e[p - 14 & 15] ^ e[p & 15], d = d << 1 | d >>> 31, e[p & 15] = d, g = (c << 5 | c >>> 27) + (u & w | (u | w) & m) + g + 2400959708 + d | 0, u = u << 30 | u >>> 2, d = e[p - 2 & 15] ^ e[p - 7 & 15] ^ e[p - 13 & 15] ^ e[p + 1 & 15], d = d << 1 | d >>> 31, e[p + 1 & 15] = d, m = (g << 5 | g >>> 27) + (c & u | (c | u) & w) + m + 2400959708 + d | 0, c = c << 30 | c >>> 2, d = e[p - 1 & 15] ^ e[p - 6 & 15] ^ e[p - 12 & 15] ^ e[p + 2 & 15], d = d << 1 | d >>> 31, e[p + 2 & 15] = d, w = (m << 5 | m >>> 27) + (g & c | (g | c) & u) + w + 2400959708 + d | 0, g = g << 30 | g >>> 2, d = e[p & 15] ^ e[p - 5 & 15] ^ e[p - 11 & 15] ^ e[p + 3 & 15], d = d << 1 | d >>> 31, e[p + 3 & 15] = d, u = (w << 5 | w >>> 27) + (m & g | (m | g) & c) + u + 2400959708 + d | 0, m = m << 30 | m >>> 2, d = e[p + 1 & 15] ^ e[p - 4 & 15] ^ e[p - 10 & 15] ^ e[p + 4 & 15], d = d << 1 | d >>> 31, e[p + 4 & 15] = d, c = (u << 5 | u >>> 27) + (w & m | (w | m) & g) + c + 2400959708 + d | 0, w = w << 30 | w >>> 2;
    for (let p = 60; p < 80; p += 5)
      d = e[p - 3 & 15] ^ e[p - 8 & 15] ^ e[p - 14 & 15] ^ e[p & 15], d = d << 1 | d >>> 31, e[p & 15] = d, g = (c << 5 | c >>> 27) + (u ^ w ^ m) + g + 3395469782 + d | 0, u = u << 30 | u >>> 2, d = e[p - 2 & 15] ^ e[p - 7 & 15] ^ e[p - 13 & 15] ^ e[p + 1 & 15], d = d << 1 | d >>> 31, e[p + 1 & 15] = d, m = (g << 5 | g >>> 27) + (c ^ u ^ w) + m + 3395469782 + d | 0, c = c << 30 | c >>> 2, d = e[p - 1 & 15] ^ e[p - 6 & 15] ^ e[p - 12 & 15] ^ e[p + 2 & 15], d = d << 1 | d >>> 31, e[p + 2 & 15] = d, w = (m << 5 | m >>> 27) + (g ^ c ^ u) + w + 3395469782 + d | 0, g = g << 30 | g >>> 2, d = e[p & 15] ^ e[p - 5 & 15] ^ e[p - 11 & 15] ^ e[p + 3 & 15], d = d << 1 | d >>> 31, e[p + 3 & 15] = d, u = (w << 5 | w >>> 27) + (m ^ g ^ c) + u + 3395469782 + d | 0, m = m << 30 | m >>> 2, d = e[p + 1 & 15] ^ e[p - 4 & 15] ^ e[p - 10 & 15] ^ e[p + 4 & 15], d = d << 1 | d >>> 31, e[p + 4 & 15] = d, c = (u << 5 | u >>> 27) + (w ^ m ^ g) + c + 3395469782 + d | 0, w = w << 30 | w >>> 2;
    t[0] = t[0] + c | 0, t[1] = t[1] + u | 0, t[2] = t[2] + w | 0, t[3] = t[3] + m | 0, t[4] = t[4] + g | 0;
  }
}
function pr() {
  if (!Pe) {
    let t = 1, e = 1;
    do
      t = (t ^ t << 1 ^ (t & 128 ? 27 : 0)) & 255, e = (e ^ e << 1) & 255, e = (e ^ e << 2) & 255, e = (e ^ e << 4) & 255, e & 128 && (e ^= 9), T[t] = (e ^ (e << 1 | e >> 7) ^ (e << 2 | e >> 6) ^ (e << 3 | e >> 5) ^ (e << 4 | e >> 4) ^ 99) & 255;
    while (t != 1);
    T[0] = 99;
    for (let n = 0; n < 256; n++) {
      const a = T[n], r = fn(a), s = r << 24 | a << 16 | a << 8 | r ^ a;
      v[n] = s, I[n] = s >>> 8 | s << 24, S[n] = s >>> 16 | s << 16, A[n] = s >>> 24 | s << 8;
    }
    Pe = !0;
  }
}
function hr(t, e) {
  const n = t.length >> 2, a = n + 6, r = 4 * (a + 1);
  let s = 1;
  for (let i = 0; i < n; i++)
    e[i] = t[4 * i] << 24 | t[4 * i + 1] << 16 | t[4 * i + 2] << 8 | t[4 * i + 3];
  for (let i = n; i < r; i++) {
    let o = e[i - 1];
    i % n == 0 ? (o = De(o << 8 | o >>> 24) ^ s << 24, s = fn(s)) : n > 6 && i % n == 4 && (o = De(o)), e[i] = e[i - n] ^ o;
  }
  return a;
}
function De(t) {
  return T[t >>> 24] << 24 | T[t >>> 16 & 255] << 16 | T[t >>> 8 & 255] << 8 | T[t & 255];
}
function Dt(t) {
  return t << 24 | (t & 65280) << 8 | t >>> 8 & 65280 | t >>> 24;
}
function fn(t) {
  return (t << 1 ^ (t >> 7) * 27) & 255;
}
const wr = typeof crypto != et && typeof crypto.getRandomValues == It, pn = "Invalid password", mr = "Invalid authentication code", hn = "zipjs-abort-check-password", gr = "Crypto API not supported";
function wn(t) {
  if (wr)
    return crypto.getRandomValues(t);
  throw new Error(gr);
}
const he = 16, yr = "raw", mn = { name: "PBKDF2" }, br = { name: "HMAC" }, vr = "SHA-1", gn = 1e3, Ir = Object.assign({ hash: br }, mn), Sr = Object.assign({ iterations: gn, hash: { name: vr } }, mn), Ar = ["deriveBits"], St = [8, 12, 16], xr = [16, 24, 32], Q = 10, se = 2, yn = typeof crypto != et, At = yn && crypto.subtle, Ur = yn && typeof At != et;
let Te = Ur && typeof At.importKey == It && typeof At.deriveBits == It, bn = pe;
class Er extends TransformStream {
  constructor({ password: e, rawPassword: n, encryptionStrength: a, checkPasswordOnly: r, checkAuthenticationCode: s = !0 }) {
    const i = {};
    super({
      start() {
        vn(i, e, n, a);
      },
      async transform(o, l) {
        const {
          password: f,
          strength: h,
          resolveReady: y,
          ready: c
        } = i;
        if (f ? (await Rr(i, h, f, W(o, 0, St[h] + se)), o = W(o, St[h] + se), r ? (xt(i), l.error(new Error(hn))) : y()) : await c, i.discarded)
          return;
        const u = new Uint8Array(o.length - Q - (o.length - Q) % he);
        l.enqueue(Sn(i, o, u, 0, Q, !0));
      },
      async flush(o) {
        const {
          engine: l,
          pendingInput: f,
          ready: h
        } = i;
        if (l) {
          if (await h, i.discarded)
            return;
          const y = W(f, f.length - Q), c = new Uint8Array(W(f, 0, f.length - Q));
          l.process(c, !0);
          const u = l.digest();
          let w = f.length < Q ? 1 : 0;
          for (let m = 0; m < Q; m++)
            w |= u[m] ^ y[m];
          if (w && s) {
            o.error(new Error(mr));
            return;
          }
          o.enqueue(c);
        }
      }
    }), In(this, i);
  }
}
class Cr extends TransformStream {
  constructor({ password: e, rawPassword: n, encryptionStrength: a }) {
    const r = {};
    super({
      start() {
        vn(r, e, n, a);
      },
      async transform(s, i) {
        const {
          password: o,
          strength: l,
          resolveReady: f,
          ready: h
        } = r;
        let y = tn;
        if (o ? (y = await Pr(r, l, o), f()) : await h, r.discarded)
          return;
        const c = new Uint8Array(y.length + s.length - s.length % he);
        c.set(y, 0), i.enqueue(Sn(r, s, c, y.length, 0, !1));
      },
      async flush(s) {
        const {
          engine: i,
          pendingInput: o,
          ready: l
        } = r;
        if (i) {
          if (await l, r.discarded)
            return;
          const f = new Uint8Array(o);
          i.process(f, !1);
          const h = W(i.digest(), 0, Q);
          s.enqueue(st(f, h));
        }
      }
    }), In(this, r);
  }
}
function kr(t) {
  bn = t || pe;
}
function vn(t, e, n, a) {
  Object.assign(t, {
    ready: new Promise((r) => t.resolveReady = r),
    password: Tr(e, n),
    strength: a - 1,
    pendingInput: tn,
    discarded: !1
  });
}
function In(t, e) {
  const n = t.readable.getReader(), a = new ReadableStream({
    async pull(r) {
      try {
        const { value: s, done: i } = await n.read();
        i ? r.close() : r.enqueue(s);
      } catch (s) {
        throw xt(e), n.cancel(s).catch(() => {
        }), s;
      }
    },
    cancel(r) {
      return xt(e), n.cancel(r);
    }
  });
  Object.defineProperty(t, "readable", {
    get() {
      return a;
    }
  });
}
function Sn(t, e, n, a, r, s) {
  const {
    engine: i,
    pendingInput: o
  } = t;
  o.length && (e = st(o, e));
  const l = e.length - r, f = l - l % he;
  if (n = Nr(n, a + f), f) {
    const h = W(n, a, a + f);
    h.set(W(e, 0, f)), i.process(h, s);
  }
  return t.pendingInput = W(e, f), n;
}
async function Rr(t, e, n, a) {
  const r = await An(t, e, n, W(a, 0, St[e])), s = W(a, St[e]);
  if (r[0] != s[0] || r[1] != s[1])
    throw xt(t), new Error(pn);
}
function xt(t) {
  const { engine: e } = t;
  t.discarded = !0, e && e.dispose && e.dispose();
}
async function Pr(t, e, n) {
  const a = wn(new Uint8Array(St[e])), r = await An(t, e, n, a);
  return st(a, r);
}
async function An(t, e, n, a) {
  t.password = null;
  const r = xr[e], s = await Dr(n, a, r * 2 + se);
  return t.engine = bn(W(s, 0, r), W(s, r, r * 2)), t.discarded && xt(t), W(s, r * 2);
}
async function Dr(t, e, n) {
  if (Te)
    try {
      const a = await At.importKey(yr, t, Ir, !1, Ar);
      return new Uint8Array(await At.deriveBits(Object.assign({ salt: e }, Sr), a, n * 8));
    } catch {
      Te = !1;
    }
  return ur(t, e, gn, n);
}
function Tr(t, e) {
  return e === M ? ar(t) : e;
}
function Nr(t, e) {
  if (e && e > t.length) {
    const n = t;
    t = new Uint8Array(e), t.set(n, 0);
  }
  return t;
}
function W(t, e, n) {
  return t.subarray(e, n);
}
const it = 12;
class Or extends TransformStream {
  constructor({ password: e, rawPassword: n, passwordVerification: a, checkPasswordOnly: r }) {
    super({
      start() {
        xn(this, e, n, a);
      },
      transform(s, i) {
        const o = this;
        if (o.password || o.rawPassword) {
          const l = Ne(o, s.subarray(0, it));
          if (o.password = o.rawPassword = null, (l[it - 1] ^ o.passwordVerification) != 0)
            throw new Error(pn);
          s = s.subarray(it);
        }
        r ? i.error(new Error(hn)) : i.enqueue(Ne(o, s));
      }
    });
  }
}
class Lr extends TransformStream {
  constructor({ password: e, rawPassword: n, passwordVerification: a }) {
    super({
      start() {
        xn(this, e, n, a);
      },
      transform(r, s) {
        const i = this;
        let o, l;
        if (i.password || i.rawPassword) {
          i.password = i.rawPassword = null;
          const f = wn(new Uint8Array(it));
          f[it - 1] = i.passwordVerification, o = new Uint8Array(r.length + f.length), o.set(Oe(i, f), 0), l = it;
        } else
          o = new Uint8Array(r.length), l = 0;
        o.set(Oe(i, r), l), s.enqueue(o);
      }
    });
  }
}
function xn(t, e, n, a) {
  Object.assign(t, {
    password: e,
    rawPassword: n,
    passwordVerification: a
  }), Mr(t, e, n);
}
function Ne(t, e) {
  const n = new Uint8Array(e.length);
  for (let a = 0; a < e.length; a++)
    n[a] = Un(t) ^ e[a], Ft(t, n[a]);
  return n;
}
function Oe(t, e) {
  const n = new Uint8Array(e.length);
  for (let a = 0; a < e.length; a++)
    n[a] = Un(t) ^ e[a], Ft(t, e[a]);
  return n;
}
function Mr(t, e, n) {
  const a = [305419896, 591751049, 878082192];
  if (Object.assign(t, {
    cryptoKeys: a,
    crcKey0: new qt(a[0]),
    crcKey2: new qt(a[2])
  }), n)
    for (let r = 0; r < n.length; r++)
      Ft(t, n[r]);
  else
    for (let r = 0; r < e.length; r++)
      Ft(t, e.charCodeAt(r));
}
function Ft(t, e) {
  let [, n] = t.cryptoKeys;
  t.crcKey0.append([e]);
  const a = ~t.crcKey0.get();
  n = Le(Math.imul(Le(n + En(a)), 134775813) + 1), t.crcKey2.append([n >>> 24]);
  const r = ~t.crcKey2.get();
  t.cryptoKeys = [a, n, r];
}
function Un(t) {
  const e = t.cryptoKeys[2] | 2;
  return En(Math.imul(e, e ^ 1) >>> 8);
}
function En(t) {
  return t & 255;
}
function Le(t) {
  return t & 4294967295;
}
function zr(t) {
  if (t instanceof ReadableStream)
    return t;
  const e = t.getReader();
  return new ReadableStream({
    async pull(n) {
      try {
        const { value: a, done: r } = await e.read();
        r ? n.close() : n.enqueue(a);
      } catch (a) {
        throw e.cancel(a).catch(() => {
        }), a;
      }
    },
    cancel(n) {
      return e.cancel(n);
    }
  });
}
const Br = "Compression method not supported", qr = /* @__PURE__ */ new Map();
function Cn(t) {
  return qr.get(t);
}
const ie = "Invalid uncompressed size", Fr = "Invalid compressed data", kn = "Codec out of memory", Rn = "Invalid CRC32", Hr = "Z_MEM_ERROR", Zr = "deflate-raw", Wr = "deflate64-raw", Ht = "gzip", Pn = 10, oe = 8, Yr = [31, 139, 8];
class Xr extends TransformStream {
  constructor(e, { chunkSize: n, CompressionStreamFallback: a, CompressionStream: r }) {
    super({});
    const { compressed: s, encrypted: i, useCompressionStream: o, zipCrypto: l, computeCrc32: f, level: h, deflate64: y, format: c, compressionMethod: u, inputSize: w } = e, m = this;
    let g, d, p, b = super.readable;
    const x = c && Cn(c), k = Nn(o, r, a), R = f && s && !y && !x && (!i || l) && !!k;
    if ((!i || l) && f && !R && (g = new dn(), b = K(b, g)), s)
      if (x)
        b = gt(b, Tn(x.CompressionStream, c, { level: h, chunkSize: n, compressionMethod: u, uncompressedSize: w }));
      else if (R)
        p = new Me(), b = gt(b, new k(Ht, { level: h, chunkSize: n })), b = K(b, p);
      else
        try {
          b = On(b, o, { level: h, chunkSize: n }, r, a);
        } catch (D) {
          if (!o && a)
            throw Wt(D);
          let B;
          try {
            B = new r(Ht);
          } catch {
            throw Wt(D);
          }
          b = gt(b, B), b = K(b, new Me());
        }
    i && (l ? b = K(b, new Lr(e)) : (d = new Cr(e), b = K(b, d))), Dn(m, b, () => {
      (!i || l) && f && (m.crc32 = R ? p.crc32 : new DataView(g.value.buffer).getUint32(0));
    });
  }
}
class Me extends TransformStream {
  constructor() {
    let e, n = Pn, a = new Uint8Array(0);
    super({
      transform(r, s) {
        if (n) {
          const f = Math.min(n, r.length);
          if (n -= f, r = r.subarray(f), !r.length)
            return;
        }
        const i = a.length + r.length;
        if (i <= oe) {
          a = st(a, r);
          return;
        }
        const o = i - oe, l = Math.min(o, a.length);
        s.enqueue(st(
          a.subarray(0, l),
          r.subarray(0, o - l)
        )), a = st(
          a.subarray(l),
          r.subarray(o - l)
        );
      },
      flush() {
        const r = ln(a);
        e.crc32 = r.getUint32(0, !0), e.uncompressedSize = r.getUint32(4, !0);
      }
    }), e = this;
  }
}
function Vr(t, e, n, a, r) {
  const s = e.writable.getWriter(), i = e.readable.getReader(), o = a === M ? new qt() : M;
  let l = 0, f = !1, h = !1, y, c;
  const u = new ReadableStream({
    start(x) {
      c = x;
    },
    pull() {
      p();
    },
    cancel(x) {
      return h = !0, p(), i.cancel(x);
    }
  });
  return w(), m(), u;
  async function w() {
    const x = t.getReader();
    try {
      const k = new Uint8Array(Pn);
      for (k.set(Yr), await s.write(k); ; ) {
        await d(), await s.ready;
        const { value: B, done: jt } = await Mn(x, r);
        if (jt)
          break;
        await s.write(B);
      }
      o && await s.write(new Uint8Array(0));
      const R = new Uint8Array(oe), D = ln(R);
      D.setUint32(0, o ? o.get() : a, !0), D.setUint32(4, n, !0), f = !0, await s.write(R), await s.close();
    } catch (k) {
      await Ln(s, k), await Zt(x, k);
    }
  }
  async function m() {
    try {
      for (; ; ) {
        const { value: x, done: k } = await g();
        if (k)
          break;
        if (l += x.length, l > n)
          throw new Error(ie);
        o && o.append(x), c.enqueue(x);
      }
      h || (h = !0, c.close());
    } catch (x) {
      b(x), await Zt(i, x);
    }
  }
  function g() {
    return i.read().catch((x) => {
      if (f) {
        if (!o)
          throw Yt(x, Rn);
        if (l != n)
          throw Yt(x, ie);
        return { done: !0 };
      }
      throw zn(x, r);
    });
  }
  function d() {
    if (!h && c.desiredSize <= 0)
      return new Promise((x) => y = x);
  }
  function p() {
    if (y) {
      const x = y;
      y = M, x();
    }
  }
  function b(x) {
    h || (h = !0, c.error(x), p());
  }
}
class Jr extends TransformStream {
  constructor(e, { chunkSize: n, DecompressionStreamFallback: a, DecompressionStream: r }) {
    super({});
    const { zipCrypto: s, encrypted: i, checkCrc32: o, crc32: l, compressed: f, useCompressionStream: h, deflate64: y, format: c, compressionMethod: u, rawBitFlag: w, outputSize: m } = e;
    let g, d, p, b = super.readable;
    if (i && (s ? b = K(b, new Or(e)) : (d = new Er(e), b = K(b, d))), f) {
      const x = /* @__PURE__ */ new Set(), k = c && Cn(c);
      let R;
      if (k)
        b = gt(b, Tn(k.DecompressionStream, c, { chunkSize: n, compressionMethod: u, rawBitFlag: w, uncompressedSize: m }), x);
      else {
        const D = Nn(h, r, a);
        if (o && !y && l !== M && m !== M && D)
          try {
            R = new D(Ht, { chunkSize: n });
          } catch {
            R = M;
          }
        if (!R)
          try {
            b = On(b, h, { chunkSize: n, deflate64: y }, r, a, x);
          } catch (B) {
            if (y || m === M || !h && a)
              throw Wt(B);
            try {
              R = new r(Ht);
            } catch {
              throw Wt(B);
            }
          }
      }
      R ? (p = !0, b = Vr(b, R, m, l, x)) : b = Gr(b, x);
    }
    o && !p && (g = new dn(), b = K(b, g)), Dn(this, b, () => {
      if (g) {
        const x = new DataView(g.value.buffer).getUint32(0, !1);
        if (l != x)
          throw new Error(Rn);
      }
    });
  }
}
function Dn(t, e, n) {
  e = K(e, new TransformStream({ flush: n })), Object.defineProperty(t, "readable", {
    get() {
      return e;
    }
  });
}
function Tn(t, e, n) {
  if (!t)
    throw new Error(Br);
  return new t(e, n);
}
function Nn(t, e, n) {
  if (t && e)
    return e;
  if (n && n.requiresModule)
    return n;
}
function On(t, e, n, a, r, s) {
  const i = e && a ? a : r || a, o = n.deflate64 ? Wr : Zr;
  let l;
  try {
    l = new i(o, n);
  } catch (f) {
    if (e && r && i != r)
      l = new r(o, n);
    else
      throw f;
  }
  return gt(t, l, s);
}
function K(t, e) {
  return zr(t).pipeThrough(e);
}
function gt(t, e, n) {
  const a = e.writable.getWriter(), r = t.getReader();
  return s(), e.readable;
  async function s() {
    try {
      for (; ; ) {
        await a.ready;
        const i = await Mn(r, n);
        if (i.done) {
          await a.close();
          break;
        }
        await a.write(i.value);
      }
    } catch (i) {
      await Ln(a, i), await Zt(r, i);
    }
  }
}
async function Ln(t, e) {
  try {
    await t.abort(e);
  } catch {
  }
}
async function Zt(t, e) {
  try {
    await t.cancel(e);
  } catch {
  }
}
function Mn(t, e) {
  const n = t.read();
  return e ? n.catch((a) => {
    throw e.add(a), a;
  }) : n;
}
function zn(t, e) {
  return e.has(t) ? t : Yt(t, Bn(t) ? kn : Fr);
}
function Wt(t) {
  return Bn(t) ? Yt(t, kn) : t;
}
function Bn(t) {
  return Ka(t) && t.code == Hr;
}
function Yt(t, e) {
  const n = new Error(e);
  return n.cause = t, n;
}
function Gr(t, e) {
  const n = t.getReader();
  return new ReadableStream({
    async pull(a) {
      try {
        const { value: r, done: s } = await n.read();
        s ? a.close() : a.enqueue(r);
      } catch (r) {
        throw await Zt(n, r), zn(r, e);
      }
    },
    cancel(a) {
      return n.cancel(a);
    }
  });
}
const Kr = 256 * 1024, jr = "deflate", Qr = "inflate";
class Ns extends TransformStream {
  constructor(e, n) {
    super({});
    const a = this, { codecType: r } = e;
    let s;
    r.startsWith(jr) ? s = Xr : r.startsWith(Qr) && (s = Jr), a.outputSize = 0;
    let i = 0;
    const o = new s(e, n), l = super.readable, f = new TransformStream({
      transform(y, c) {
        y && y.length && (i += y.length, c.enqueue(y));
      },
      flush() {
        Object.assign(a, {
          inputSize: i
        });
      }
    }), h = new TransformStream({
      transform(y, c) {
        if (y && y.length && (c.enqueue(y), a.outputSize += y.length, e.outputSize !== M && a.outputSize > e.outputSize))
          throw new Error(ie);
      },
      flush() {
        const { crc32: y } = o;
        Object.assign(a, {
          crc32: y,
          inputSize: i
        });
      }
    });
    Object.defineProperty(a, "readable", {
      get() {
        return l.pipeThrough(f).pipeThrough(o).pipeThrough(h);
      }
    });
  }
}
class Os extends TransformStream {
  constructor(e) {
    const n = [];
    let a = 0, r = 0;
    (!Number.isFinite(e) || e < 1) && (e = Kr), super({
      transform(o, l) {
        for (n.push(o), a += o.length; a > e; )
          r += e, l.enqueue(s());
      },
      flush(o) {
        a && (r += a, o.enqueue(i(n, a)));
      }
    }), Object.defineProperty(this, "outputSize", {
      get: () => r
    });
    function s() {
      const o = new Uint8Array(e);
      let l = 0;
      for (; l < e; ) {
        const f = n[0], h = e - l;
        f.length <= h ? (o.set(f, l), l += f.length, n.shift()) : (o.set(f.subarray(0, h), l), n[0] = f.subarray(h), l += h);
      }
      return a -= e, o;
    }
    function i(o, l) {
      const f = new Uint8Array(l);
      let h = 0;
      for (const y of o)
        f.set(y, h), h += y.length;
      return f;
    }
  }
}
class Ls extends TransformStream {
  constructor({ onstart: e, onprogress: n, size: a, onend: r }) {
    let s = 0;
    super({
      async start() {
        e && await _t(e, a);
      },
      async transform(i, o) {
        s += i.length, n && await _t(n, s, a), o.enqueue(i);
      },
      async flush() {
        r && await _t(r, s);
      }
    });
  }
}
async function _t(t, ...e) {
  try {
    await t(...e);
  } catch {
  }
}
BigInt(Number.MAX_SAFE_INTEGER);
BigInt(0);
BigInt("0x7fffffffffffffff");
try {
  Gt({ baseURI: import.meta.url });
} catch {
}
const _r = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258], $r = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], ts = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577], es = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], ns = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], ht = new Uint8Array(288);
ht.fill(8, 0, 144), ht.fill(9, 144, 256), ht.fill(7, 256, 280), ht.fill(8, 280, 288);
const as = new Uint8Array(30).fill(5);
function ft(t) {
  const e = new Uint16Array(16);
  for (const r of t) e[r]++;
  e[0] = 0;
  const n = new Uint16Array(17);
  for (let r = 1; r <= 15; r++) n[r + 1] = n[r] + e[r];
  const a = new Uint16Array(t.length);
  for (let r = 0; r < t.length; r++) t[r] && (a[n[t[r]]++] = r);
  return { lengthCounts: e, symbols: a };
}
const q = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function rs(t) {
  let e;
  t({ wasmURI: () => (e || (e = "data:application/wasm;base64," + (function(n) {
    let a = "";
    const r = n.length;
    let s = 0;
    for (; s + 2 < r; s += 3) {
      const o = n[s] << 16 | n[s + 1] << 8 | n[s + 2];
      a += q[o >> 18 & 63] + q[o >> 12 & 63] + q[o >> 6 & 63] + q[63 & o];
    }
    const i = r - s;
    if (i === 1) {
      const o = n[s] << 16;
      a += q[o >> 18 & 63] + q[o >> 12 & 63] + "==";
    } else if (i === 2) {
      const o = n[s] << 16 | n[s + 1] << 8;
      a += q[o >> 18 & 63] + q[o >> 12 & 63] + q[o >> 6 & 63] + "=";
    }
    return a;
  })((function(n) {
    let a = 0, r = 0, s = 0, i = new Uint8Array(1024), o = 0, l = 0;
    for (; !l; ) {
      l = h(1);
      const g = h(2);
      if (g == 0) y();
      else if (g == 1) c(ft(ht), ft(as));
      else {
        if (g != 2) throw new Error("invalid deflate block type");
        c(...u());
      }
    }
    return i.subarray(0, o);
    function f() {
      if (a >= n.length) throw new Error("unexpected end of deflate data");
      return n[a++];
    }
    function h(g) {
      for (; s < g; ) r |= f() << s, s += 8;
      const d = r & (1 << g) - 1;
      return r >>>= g, s -= g, d;
    }
    function y() {
      r = 0, s = 0;
      const g = f() | f() << 8;
      a += 2, m(o + g);
      for (let d = 0; d < g; d++) i[o++] = f();
    }
    function c(g, d) {
      let p = w(g);
      for (; p != 256; ) {
        if (p < 256) m(o + 1), i[o++] = p;
        else {
          const b = p - 257, x = _r[b] + h($r[b]), k = w(d), R = ts[k] + h(es[k]);
          m(o + x);
          const D = o - R;
          for (let B = 0; B < x; B++) i[o++] = i[D + B];
        }
        p = w(g);
      }
    }
    function u() {
      const g = h(5) + 257, d = h(5) + 1, p = h(4) + 4, b = new Uint8Array(19);
      for (let D = 0; D < p; D++) b[ns[D]] = h(3);
      const x = ft(b), k = new Uint8Array(g + d);
      let R = 0;
      for (; R < k.length; ) {
        const D = w(x);
        if (D < 16) k[R++] = D;
        else if (D == 16) {
          const B = k[R - 1];
          let jt = h(2) + 3;
          for (; jt--; ) k[R++] = B;
        } else R += D == 17 ? h(3) + 3 : h(7) + 11;
      }
      return [ft(k.subarray(0, g)), ft(k.subarray(g))];
    }
    function w(g) {
      const { lengthCounts: d, symbols: p } = g;
      let b = 0, x = 0, k = 0;
      for (let R = 1; R <= 15; R++) {
        b |= h(1);
        const D = d[R];
        if (b - x < D) return p[k + (b - x)];
        k += D, x = x + D << 1, b <<= 1;
      }
      throw new Error("invalid huffman code");
    }
    function m(g) {
      if (i.length < g) {
        let d = 2 * i.length;
        for (; d < g; ) d *= 2;
        const p = new Uint8Array(d);
        p.set(i.subarray(0, o)), i = p;
      }
    }
  })((function(n) {
    const a = (n = String(n).replace(/[^A-Za-z0-9+/=]/g, "")).length, r = [];
    for (let s = 0; s < a; s += 4) {
      const i = q.indexOf(n[s]) << 18 | q.indexOf(n[s + 1]) << 12 | (63 & q.indexOf(n[s + 2])) << 6 | 63 & q.indexOf(n[s + 3]);
      r.push(i >> 16 & 255), n[s + 2] !== "=" && r.push(i >> 8 & 255), n[s + 3] !== "=" && r.push(255 & i);
    }
    return new Uint8Array(r);
  })("zb19kF3HdSfW3bfvx3v3vXl3gAEwwIDAuRcQNZQ4AClRA4qkpWmIg+EQhKh19Ier4ioSAkcS7gMBvvdGIOWlOUPxw5BNaRGHUdEOa43YSqRykRUmy93IDncFr+m1dq3d0BttLROpUqpYZWsTpYrKslysFEOGv3P6vo/5AEAStsMp8N17++v06dOnT58+57Q63rtfK6X0fzp2r1lZUffqFb2CJ71yb7DCP3pF8aO6V+mVe+2KPKp7oxX+T6/cG6/0H63/1Y/olXtD/zX49LFEW6W1jSJtdM3UNf4zxtSM1irQQVAP0yAIlDKN0NjY2liFYRhqYwNjjTEqaupQaaViZZPAhvoBXa+HkdZfMV8xUaJXtHvhO2Ea/5ml6P6l+890v2xU4+Tpz586vrz08XtOLz2okvH+68nTJ5fv6R5/UNWaI99UmvXfH+ieObHU66nGoJal0/ep1vb+66njveV7Tpw53fvS/Uv3qSz1CdJYVUrqHc+GX7npLeMjn77wKycfUFtb1bd+6/1aufFt1dvatu9bGm67euO2J7LhV2572/jIJ257e6v6VrW9o18r2t5pP99dWlJmW/VxDQjR/cdPnTpzQunG8aXePV+8//gJBmau2X9laFzWf6/auWNQAg0tppzz5PFTJ39lSamd99xz8vR9J7tLJ5bv+fyXTp9YPnnm9D3Lxz93akmrnfcs3d870T35wPLS6Xt6y8dPtO/pLvWWz3SXVLR7XdIXlpbvOfGlbnfp9LKKi3vuOfHQ8XtOnj7RXbp/6fTyPUsPnVh6gCvvLn3+xJkvnV5Wd9ZaWjmd1tTU7ubk0UO3fKL+0rPBMaPS735Qpyv7lMvaRX2/MnPr/0i51/UxO+ce3zZtVBG4jJRLS/dG0MHD4lQRueBsoc4W2gUdixLarfSc7pAqC+OC5UK757aVhSI9bV7cVuhpkxThEa6RAvcImQc7s0Y1dEohqVnTIEXhrElS0i4pc0WauBbjgu6ssXgtC43KrNP40khTitxTDF5yrKlJAwpnSKGQItPukia13PkiQFwuFINjSDE4ai04+sFOEfQBMgDIeIAURR4IRVFZWOL6NEXtIhRYSJEukVtRYucocQ910Fqu3TOALzdmhQKnKXHB2eUi7sz7dinuooxGo0BQmgfo6KxJKKhg0PITCCiMG/fMNrKzRrmntnGjjTR15xgR6XxTU/pFZ5anzYs7CgNsPdShqJ1bMrkOeJymTVaoectPE4Wab+oUWPE5C03Atl0s9FSOnhnSU7khlQPMlMy0mcxrZPDQKNSCncNTUuhqFPWsSRp1zjhRaLtCxk2UIV6zQs83AzIuK9M8DOYozGPShXITZR4ChIlCNxUpl/n3DO8pxU6hl7XUreQRKffdlaOcLS0L7R7q5JHvfTzfVG5vnjglPVbu9bffjo/ZOYrctaCrs18oVPssE6nTy233iTJPUk/wSYU0jdFROSgBPxS5nZQ4fbbtFCVu78LUcm4qRFY4C8je3VSk85CCwjaVU7klnatGAPJhPAfEY+uuOetsp+S+HZkiRcFUrsg4vZwbQm9RIOwKDKEzlIB0Fal2l+IORisgVQ1wrlLi8QvmhkfQkF3MNRkMpIxhiIcKpXaFtKA7LRS3GM43FVmZTBS10ZUQw5xQiAc/zOH6YU5SfJVhDnmYw/4whzzMJpgjA7KWYTZrhtkMDXMgwxwP5nUIDiRTSJk5Cpk8XXa3nZOpaEj3J2BYAiQ1mK2YVIrC/tQNR/mHU7lxKtcpZhFKYlYZroEnWaMGOM4zHGbRzrnz28gwAMj77Db3LCcJHCg2DEyfYVRVeUo6WBbWrLgfTU4bZefcT/ALOvvp5OGVQ0a5H08eXr2wurq6avH2o0mqu0bpHui4V3//3/1+2EPLr00ymtxF/7tKaaHLInCKdLuIO2BMx5qJe2mSMWjn3Iv8lJAuixolxyik2mK3WUvNnLs4OaOUs2BIFef3/ULBlydzJZSF4hgMCilhSisXmwFzjURIyKksLIxbOdIMSOeB+zG3qZxuFyGZDpgNmTZYasnE3CnzIKUAoAYeVNUHNaSgLGIKj5GieLHbtCkFWVgoMgtN3QhRzrQxG/CVKUgJUEeamgxPCkCiKXI3lBQAbpWbhk0F4ZgfFLRLXiQ6hclCyW0oKPOAswYpGbey0DQp8HwRpZwFr05J+45yj9FOFzzyWLcZ4hesIHLT5bFmmLoXJ6VD6A6P1Xf4TYGavjOJiaTSPsLtAOHSJUy1aWOLsDzSNANUoxtPC+kBk2SOTYFZPC3Ey4TmvjeJ9UK5lyf5o/vmNreC329vE9LD8ytCPxhfWc5kvQ5nzYvbSGNd+c42sMmyUI4WmirFBAjcdLtQ7iEybQdSayM/ZoNfn3k1o8GqaEo3jbl2YZv7mW+4YVNwpmNYY452pWcNl3TwRAGFJfI/u42se4gst6KkYnd+m0xHoNOQajNOscb75gzZDZoLGCWNSH4q5JE5OoQ0GfqQ8W/msDD5EQDb85jXDQPePKMA7HwzSP1omblqtCwIDWsn02IRLvqFNeG1ZBP8xRvgL74U/shS6D5IISoo3cF2ASKwLisXpwrtplhWct+fvM6oQyYj7V6Wx8R9f5JFK7S3lj48LZB2k6VMeRdX7IuUs5DHwkXwaE32CBY6YaSPdJCLxYV2YTzULMAog3X/bYiQZCpxSJkVL09qx+Ld2eXCVMKQJsPCEEtgioUhjZ5BGNL4abhGblwCdrmXl8y3/eJu3LVkNlzcVUoW02w32cOMDuXMsntxR5lrZnUiNoQOcmIRMCTnIJaFIpaxkAVwjNuJSlkEUCIC8KquRIopKknA8Ex115zFWoslXWaD7ZRFgGUu5GUO1WaATM+aSZfkhmyhc+UalRhYcLcbAkAiXUh4Yk/mxjVSsn6tA8ULG/ELlQJDxUzBGvSeliqbutVt7gYUVJX8IqsikzUFJU+1ioTLIunXoN1DpOVjQBElZWHbeVwxOAogbT/rJdf+XI6FNaKTXq7XqSz5UmAg6nrxZF0BEIlgAfgLwDKVCzpOH8HkhXxYw9dGbnhbIzQZiCxjZAcgVOkeASs8K/sSkwohexE88XVP5pEBgw4WqkpUlUtJLsPfJwplIfNDJApE4G5qClgk0sEcS4qqgGScaxGJVFOxZAzBjQuAVkLn+wVpJaVovqmk/t0FSBmE9+IORhRp0LUMlWlqd26bUDc6VfUIRSmaNhnyR8iboVv8NJGS4Z2AoWjWTHqg7Zx0LBMqmEx93yAvcsJEPyGmWpnHFFCNid3mTOqqzyMqpmYpLglcj2I/FvHG/CF+t/xBJkpDJpbnEwateD4Ru2sp3pBPGMxGM8QnTMUn1BCfYKa1XIQVn9CeT6g+n4jdTojyzCeM3yrw6iBjXlQyegw+ga0ABltEfzBf8ImwLw6HfT6hMCC26qP11KiEhK2I48IpnM86hIeUEpnZPP6JUFAICtKgIMMUhJ0wGaYgnlyKKYhivzGO+/QTUuLpJ2G6ACD8NOF3IqQoAQzSDxbUNeiH9w2T1XYB9MMJE1WCmSPrWiJiWjAqNSy4C/PpMwjsBHxyiLwB+TQw15KHg6ynLrsxddkroq5AqCsAOgPBajBEXdyKpy7rriW72SoUyCoUbLQKYWaw0qKiK1OpBXiRlgYnAZfddBkS8qq2+7a/DOlqGTKevOLBphq1Z6JnwLyuOhl48jLC3IKB+kE2aJOVaoL7hA2gkBdzvpqQl+mTV8jkBTZL4TrySoW8+sRlqOaJq9Ynrtoa4qoBArMJcZnLEpdZS1xmPXGZPnEZ5A37xGWxybTrtDzKb1G1WRnoeChYq+UZIq3A759lbBvkN9VatDxY80Kv3rEinjKKU6q7rNyvSKX/W6qTFSxn3FeXYNuhnG0LdT8EmTkPWSenOxDXnOnw+gP2rSB2BiIGLzY1665yrwSsVl6/ujWgk6ikOFnu7ELTDK+Yur9ihtUCObI8ji6i1i8genRxZH2BLI42mCPLaiFeHK0f02pxtH7sh9RCATMVy4pIFyw0A+CNySwk7ZefoC8ssLJRtTzDB2DMT80GKywTsB2ssHbTFVa/5xVWM2Y9EQ+tsFpWWE/E1RQNvWYGndUdBtVrr3iEbSVqhV7UCkZELeUlpwEyAhnvhSYULqJOeEZ+W14Iw77fi2HBiBi2vjLsyyrkggZJ8bZhlIpYh2TXyV0jVDQ6MjYVXRTIKhxSQw2TVbCpGsp4NdS7JyuTbkg//V7KxnJAMuEakgmvnGTCKyWZcBOSCTcnmXVwU0DJQlNVk6SV9mVi1Vdb91dKi6WJGZqq2Jkiu1Zp7ZeqhFS1iOjBAtESMUz1F0rlrgXLOvuFQstCqYfEsEDEsGCNGGbNipkzK6OCWDwQxITDWqHRSb9NJLWROGbBqpkc+ts21RfHbF8TS3awXtrBeonKSefWcbeDoo+FwkrfBRNuMlfY2TmV5jFrF2Td8JjhwYi9ZuabTBEaeoEVUlNg+OlTqY5XhDOHxqsYLHbYHaZY4eZKdFnayxHIBQWUX4686qKRB/2NeCAy41oWboYnn5K55tcAzm+qUTV+PvJ+xdoVUjzXWINrWTE9pPKNyRaBqHyZo9mmYhYv7xVSR1m4GWbhWli48VNQ9fesIScxC/eADVh40J+PCvPRDOajGsxHEatG56MZmo9qaD4G/fkY8HwMeD4GMh+554Yxi3krctKkR5DBfOSEiSqhz659bzfi2WqEZ2uvFBr0Xr0bnq1GePYGleHcymMTahomJuHZA7LxPDtYw7PNKM8eHooBzw6GePYoHVU8247ybDvg2e+ejphnryeYfi+FZwejPNtsyLMvRyPhldJIuAmNhJvQyEZwY1PlebauFlgZG13xbNPn2Tho1Myz9WB3EzCDNJVgn/LxkJLdjT/QMYNzHebZARrxPFv3z8+M8GxT8WxWEAXg2Up4dlDxbDO0dcY6EgxxbOs5tvH7AV6umJW6nTgpZZYdCMsOALESasA4McvWYNkBWDZ+NHKBd/dZthGW7VUX1iPW91SWJawE/fMs0bGRkh2OqnbVvIFOb9Cahe1CZ7rwIrdt4+QkgBBGvBPB+cubKZ/fpYtYQX824ZX4Li4hkhuWssmw1l6z1p7UJ5XLlo819UDrttJK3c8mBC86jRSp/Sq1ap9Kc61X3Msqs6xbUs7Mmv1YnWcNkQqdStNxRTjYdY/wqv5AVk//y0BHK+5XsIq4byQA+UYQ0iNQP0lHlGdkVAT8Ydrs97/TTrsfHaJgPFCFQbUPt7w2cDd6MWtursbPOC0fX3xLzRoLXGXXiHRK2qk7RGJxDxwpolnz6iE5qtIucy2Kpo7msehYFdKwTz3rwjLHAR1IsNWBZMOkkWC7ovOAYpGJglkzLWJiQxqUSm4iA1K8fvgbSU8TodIJsrx5tE53Zs0NqRS4TbLuf+cNR3APsARy+MW31CFsBQ8/Kt++fwhn3+7FOgvAD7xTZnXVutVVQ9EU702Bks/Kz2ccy1fTDCYwO648ynenFPLgZrV0CxME+sO6fZuNpX9wh8lXzCP7lKN2MbYfAzZZYZVX9aLmB0kV0bws1NYfN+xmPUARuO++pUStc5FHBT+YrtqF7XwvGfcjVeZExr0elvk2Mu5VVeZTZNxrqsx3SRfz7UhXZT6OSTgHWWba3CYnybbYnSeyBDbzLcPGIzgUcb+a240MS/4m/igA4bXH9oZRnNQOHLzhxnraaI61svHATGzThdo/tct+/JZbb2Pmd1eeNor+0xQ/ncobjUyeihZ+7uXz+tbiVJ42xjihkdvGjDwVwfwQXhsHcPwei34hmW9+BNYC7TyhaEYpipcphDVD5HSZR9A/lkzvOO42nXkK3e98wyx058WMYloqbs2aaaxUWMwU/rI9BfPYMeS+VWNDMuZs6Uy2hxfqf8yQyJTY7VQeNw4wqPtxrEgWp383sKZm2a2+FXTwdLZ0ex+YB/PsdJiC3O/VmX7dn1fdotC1Oi5hQdD9PF2fas8WASZoHb2yVHfxMe5FkdoVSkOZm9NkU7J3d5pbKXY4EYAIM1IZBXnYmBnF4o1XiEU20pmg0L2tNwN1BqCuXoSZEin3vyZrExlPAa/QwAvzBMVrvFu1zOANTv3kccwltyhLY5z1FhWKIczu/nDw1Dbun8iUgwmHymPp2l7ftRuutGtDcM0ayxqyGbWNpf9RmDh9BBLbh+R/2ACSCskH3wMkLjkrUhyjHOvjpeACrW6Moe+MwiUb8sCtJhimkHdoFaCsbBuB04LcRuE0qCchm4eNG3kZZuK7XWCv2zmq431CplUgI7tvAO0+GiO7MbSNfRUGkI2VoFlj3+iYzlw5ubrJZVDWW0HHJctdITk/KSfPdrsy0VmmuoGM+2fr0ZTxdKWmyDY1kVQSf5onUlU8y+rUcNbc5kw+2bgx7XOSvWsa+C43kNJeZxabHxLxsJkA5m5epygPKPGDYVjNPd+EIlrDvioY7muAvgZUH+ook4f7o7dUngwx69Dps3w+1x4LlDZBKgrjVw8VdUjikXttoizSacMmapF7c7KE+IdjxtflMZLzsCiYc+c1J5zng/px4Hu5dMmtWnnUA5Rgzq2aPKLErRrJlnC2GrIlyJb4bM8Yru0ZM1xbvLY2StyFkYqS0YpojOpudfyUO7+zhLyzm9AvAC+jM+ZqQIumcXfB0JjbXYKplLSN6hntAhFzGzTcRLimCa7xzcmSxrDeJ1ItrBWdeadaWlcrpbxB8oqkz5A5/NXV1dVX1CHzS2RAO58l4/5UmLF20UIzwPEbeHXoApxmB3lENk8aM6l7GeMp6pXnwGjBSfMklXpsuknBD6R8zpdj+x67uHOWj86tn0BrZrgdnT+Wl5fBDI8bH+YZHrq33w46BVjRSs9lZ4X7/2ltZG1B9g+A/P/50Bp5ezWhpLeqMY0cf+yngpk2t3t2BxV9sjhVBNSkgJp4mm9+kGrY62W5MIvbKWiD0+DoM68hYztH7giwJ3hLmIX4qdYohHU0Peu49l2wjr2dd7Z3j5py1tzH7+FZfLJOl7Pmi/ylfhZrti2LdNbcS7Ebk7EYO8vnAYG75pj1042s27PYZaHR/d4Izlg8cn9ScZ6WyMWnUjZ2SakFRcBWSil1W49NiS6NUtahUQqDoWDWnKJxPC8f1OcbTMEKFBzkaUOlvF/flLskV8ZdWmgokoZaQw1R6OIO2holwyhv9UlRKtguUvp2keHjWZ4J21lmzxtO0bjbSrtoirYJtjIqdjB5/dGo/JADVf/Ckxajyal8B9PQfUWGny+WeSuYowa1YPe1gk+/tOxWevlWPH4mn6Aor1OCbQ2jYoJC2tpxZrksds4oXaRkj4IWgZoAqAmoPjxJ6kBNvZokOgU/3XlQmyKpjrwaQ7gSJDHLspQyhigVDMH+xKywplUMYrP2mFHaYKBNCX6Lw7NFgYWuDJaRRiw1RNL86ugUrUNR5NfuD4I4DIpYZwCXZZ1gmScMOo2XzrQPatYZpvg+CtbedwGWJxBKz7IxO0+6GG2BuaUuXlv3nndTdzxUdyx1v606Li1T2CeneUQtSqhRLl4CISJkJLwOyLhFGDcMZ97wXMNTcwPzs1+Ovx3Ur1tB91ujs5tAsrUBwftZgBWJsg1p/r9O1lcQzZpfFv73wKz5LNYdpnkGE1RPu4jWVfQfN6joTys+s8MzYxhPN65F0vcGDPnVQ8VWSlxrsUtN97hZ7DajK5eBqEbNssjcY6ad78QLbWmXec5GSuCQ10DzjpW0MZibjWlzE28CG9Pm+mIPfm4oCtqzOAWTbf78y3kLP5/N6/j5TN7EzxzI/GPmtnwf3m7m1dy6m7sgAbY6aJs5alJ0HWjo+Sdp3+PFvm9VEz6eUUrEXzn7jmeUuUVBDR6DFbBVe5P2UfT8ufWlaqCL2nBBTTXM3Br0bZuXz2Mhdp71DbNCyqww4XOZEGX2Ufj8uXwfvqginOcT+go23yx0vi6D8B4f1CaXzWMRs0lkzHV8y61QDOx2KC3zlN6pDpWm1Mpjqos8QOFwPu5dCCikBilAIaCIuTGzgl1Cp5jw1pd5TJGYStzcxfMAy/m+Cv8uLjH/xig8qI00N8HNsfXrboppQlqb4NZqlLdhjbzIXi4hxXgrjjUVxvf7h+Bz8Jf1RiRnv/HdbBoTUNwu81CsY/bg7Khd8BeKKb2bt0YpKkqhkqqhUsqyAoZqeUxJHkJ3mS4ymn2aL4H8feEu25fXIAEmecyCYB5SRrW2O3gXvAcobDNO4/lmneuplTNKDUYMdiftPJYFmdvJ9uc1mPTjJRWAYI3Pr5wWpe6H4M8XVacZ7KI6Y5BJKJRqQiSBPJpMBUgSBIf98ZQVHLIQhY46Tb3LfTet5MjUm2BEdA2wVKOdMKJNB1PcD2ERidp4J7r7mCkLzwiuoajtxsqCOUGDLIxsA/CBhoARMBjgCKPqLLac+e5baqF5DQy/Z80rhxrXgAP9G2HIfZlVhNi4sTtl5pFHjT3VE8Ww/eAOXpOybMnywAQ0hIbqy8L5Nt6E/dO3lMfI6kXVmfI7vsZOvzdqFFYcQoCckX3nnisUHhVtoSZbiUybiVKOG8y0IbbnJD7sLOrzYIxHujK9g3bOjHd33hIgJuwctQim+HtEJ98oUCyvY8AkYS/0i4aG+oYO1FktgE11eNndLzc0dYQ1038+oo+iZr6lsSvtC+7NfAsG6H+SlWRHSs35Zo1qLJCDyKvVg5pAULNiUzu8pvmVQ8OiWCaiWGuNKNaikDLhQo1RUcxeoSzQAC/MQIDgWQ2n26yoGkM1ad5yKk8FfRnPjQm3Qik1SgaqwQwR4mCjQ+lZBiMDGC1Ky8V3BweLYbaS9bIZpfIGZQwcRixjTQlk+xKoIUstkV9ayN4AzKJnNu5fC8LH4B1DHf703Ur8lYnDSReVqNu+O6qLgy7V/csq/17Xoq1TFHXACO+qxJeUUhwCDg0F2+Rb4YjBPJ/8XEmnmcRfOUSpdMpv1kLg2PP7Fvo9KgdXMpTdYF5PbvBtxwbftsseMudT1X9V7Ttbs+YHh1Ihu1+WEcbjZzcku0ZnMN7vegcgI9swczzSRSYuU4wMOWxpUYPpbSvTWyb0ljGStzLNV/TWWENvyXuit2oY8pjnQZ7JvGhQK+dhiqshGh2KrE9FP0w3lI/Hgd8/q/CbQRBgQmJ5+I4BPQ2hl1I7SkzR+yCmO4aJCS2Owo89TT2PAOT3vSTbbLLuqtkY96z9jsJ61nyU5Qt4JhVsjnTDMWGbLGIQhIyRmdRKDVMShFS7KMN7M/53va+jXfrT3ptxsNQuUzkjhW6jTpbqi1MFhEELrUZep6Zr3QUtqWMFbI2C65Q6xMJCAmEhwE8AzZP16dNKzXK6lXTr041PP6jUrZxuJN34dBiuGWQYkUZwdl+jgOrZB0SGFSVMpXZhAL1cY3m0RO/gq1on24gOQYQS61pH0eG7eWWrgwe3OqxPGNJKosBYorQ11trAApia0+0blTr86FceP3f+wsVV/Uix75CCvLYPiKljibRe6yOwRJLWz2Jdhiw1mCvUBBjIbQU+mfZBpbJraey6IGEpc+y6IBsq67VJAdWPNGF6OijhG0b+fJ+U3x/MDZreL8OWCR6yNptIgJ/127btaaWyD15R2wENl3hvbQeCzqR9nVIjOBxuyFSV+4z5vuGK921YMRONhaRSz4MAArg9xuPNQ51yLVTDQzLSKpOQlcYtzAdkjte4NgoqGvTvTJOeA4Am66zua1Jd9Hz1hWajL240GhusB2MbfGtu8K0x2MInKSs766yziuHhLep/9weDPfFEUffnJQyYJfgKsbaSWQmfWaRgHikOaRv+aRL8fBpn4O3CgsdYapQEfQS6Lhb0raNT0G5Om4m8ziLcBidh/qAEilB/plMpQws+eBHNp9eDpmSbQKH7wyFV2e39oyN0gn2mk/lmIkoXTGjMUH+Agxbr2KK3vDR5e5HiA93NoKSsAr2dJRgKblHiToyxBcUni1NNtfk5Vb8n1amZrXS3lnsw39TwBq7OgJScAfEp1v+4YXeyoe7El+rO/rXdmf5b6k6yrjv70Z2XhonLYtB5tRycGMZXtt8Q2CqAQiijdotQ//ioPBikI0db/pQR5iQ3gBJdTY5jr0/XnoSvOb/iPf98k0WNiflmOLJJCq9wk2QZXk1cC8ElWLk/HFl1GUibB7yF9YCL4WGS0g6cUQDQVySv0zmMJa9USeUXIqzgTcU7sSa7gtkiQo1HYfvi7EITp1H/mt+9uUcwbW4W6TzwZjuwjJtedlnp2EqUYMETwV4nmm8atjC/vki4AOxebuDYFFwEG+frMXosktQpuZsN3GqUtCnJcqGUm8SP4PpZc4O3eoMUEpdUo3qbEug1IqpTRPXFIpkqoixnHSbARBY4JkZtwmc2kVtTHb/cBMcLxHFIBNj6whRnhA4uofrdbDUH9sl2DbBByZtsk5JzvA6YrdJuStqlWCVzb6J1e9+I974VoQ42vzCwQQSJQPa/dTIiak3wKXJAUbYHkMrj3lQO+XhIb2ADqWl41sMgDGepU6Vb1fIMx0QY5eATlALsxvPP8QHHVpwwC/HN/X2yU+LXy0BNga3T7iNTIIAjU/mkkNm/9WT2cD6JtZ3gGjKZ/nZNN1bEDAwGS2J/dHM+hp/bCJEMzAqN8V4u02J4NXc3Mlden3wK4GB8nZbs1IpwLzlLD+2ihl60oANpmjlqOfZyodStGthmpc6WxOdaNezQoQdnj3unl4/Bl17Jgt0seW+SSlZkKxKXoYIaOJ7Tna4zbAFZoxSRABLvj9OAyq3yxokpyTARvf1s4wjHaMBjsyyalB5j0XCD+hJp0jskwlm2csJOvLPlM4Man6pqTChdbMKFNJHCvKXasP5m39cxgTNkIt6OCTznvMu0yBYoSElVlPPGFA8HqIixVWB/oKb3B4q9pyHwUCTOdJqaHZEA4TgghBI/bedbkKOR1/kcR0xFGzB3jKm+xow3GXZ5jakOLlVHO4lvZ5L1F3VqLAxVMpLL8PeJIrYr1GBT3gYEjhi8tMGmvM1gjpp5QnFRhylvE92cKGIsghDpmlj6MrzDW3Hg8lpPKRNL3Qafc8M+IGZLXYwNxWypWwd266OWusmQpW6DMm+pmyEvW+ry00QK1RRP5AxMXoDmOR6DZXM3J1PfN16xkTDRT9giy6IfyfEBEYyPjqQM94aUuMVT9roylNCWDHIzVsY4ZbiwVDFiMHXZAnCXe9g9BFsV9vyKXdCZYg0l6sJxbHx0ikvWaIziN+uQI8YyQ7W0GPMM4t7KpvM2UjQ2a25OCcbKYzBIlAJsDJtVvh2c1wqPvVmUsCFF43B/41hBYMLtWd7Igi232YQYPh6Ty930Po3TBbviHkHu7BrPbHfDE+NmNpJeaysJ/qu9CaVeY0LJ0VsYjsyQygzp0D2Sppk3gvWml3NrrGJbWX3Nl866L3uzeloXO/lWdlf12Bk87s3uWmu2GWZj6X/4gG6Ko8ojpLJZmFoe7TbVrsqFo+GNNneLW7BFlBU24vQGrvaILBPW/Xa44I/mf47DO4ELpj8iE0xjbYJ18nR/A+vXJ5XdzBllU2ArkWRl1kxXLk32SJd9btyDjr2Oj06VbEPN74Gzd06Vd3abMOu/hMmldR9aYNPC3w4XxBcFlkGNLRIgSlSFP2fJTEJBrWrXWHarr+k2S03WG/1op+8UAfgHugicuaOp3EVIzoGLFpsKS+dF+M1HR6ZyCRxCYbcIHHWJV+eX9FQRuL0PUNB1e3vZJ+WbuK0f1B/BBzzckH0SuPTKdxEcGTrGF1DnZS00Yt3HwSO9uOntz724WZmpaZYjOCkp3V5WOG+c9hv6EonJLarvLytGpRvnU5eo428qzRlxi+OBqS28s2pYZ0WQ4WGbgk7nDj8sG9VC9hItBKKjHx0Epm6h1RaLqftz9hDdnbOQCbU/xMGcpcKM5wBXXpPKGeKabzx2asFBxEqmugx3MNV1HBpsqusyHI9NdRmGabObZfqqstBDGvqKgivLxeagkvGgjq6guhkVXz7X+0U+g924Amg4QAm8crHnvxJcTFwZLkIK0mlzPVssqmlMIcjmKIbN6Q1saDTYQhNHXpJ5yEzmT1R7LDS1Wi1gRd4PFSuk3F+phSar6IVamNcPejFHwUE9wTJ+G36jAFbOEMR6mzfEd8uMT6DukB7xIRCVrB4q+tZdjYINjCXL9fNgQKJIHO6PLRG2oF11afhorU/b4irUziN/jtdny410E0CiCoYJDnIwAgY0XRuBEQyBwRjlA5f+3nX3tNktS8NEHgtCdnsUidaZBavI9zRe30Rc8nm+b6LPPUNfkxdacXgCHYRgwhMIUShaELBxTzJ9sEEvgddq+D7KuoDIefGxploLRTCAYtDRH6rKUJrr2F/V8Tff1/3voa/vpad/NTyU18tQNip9jRFzogpQK9Chss0B6adecipXa2cFxlq+HVTEHPfJOuo/hf0ngYY9Vcy0eRn+1+ykzefvvx0eaepK5lipuJ+sijo71KjSPBM0lXWacT+Bn2zQT+R6TXbrcBuRUMnjB0SJoqXDz4G9qk9bbu2cpqCEH5UIERS0nc78mv+SnjXPMcNQ2c0ucPwRctaU9E7Nmhe0r4Sz90ffTJvXZryJ5mszcgLz05nh5fc9JMvQhexsh/AnwUFEei1hHWak1063Z83LuoKeFYez6BXXiP+/PnM5NOAcyakNUVB1n+PxpVIpq9+uBKuXrnK+GQhOX90KMzcZXbY9FdNE6V8RuccMn2oOcP+SFrspDL2eH8q32GnGFK3PTJEzR5t+3FiTN0wlRyp57GpQSdxHUu3qICn2KmkATkPmIRxgqcApF45+Ez7WhNKQn3T/ySzw5vsrpsybzgwfhYkHF841xPaKEgn3E3IhI09w0pYnu9C08hQuQNOKp2ihGclTvACVMVRlOHsKy6LG4OAY+f/RixTmASujYTnEp4ARnnBgCBIIYd/pLctwyMg+w/AN5NPC0EXe3C2E+Rof0NSo2UafOABZQBHOQqoBf20GgSVdsNjUu8Q9QeYUzyjEpdTDU66fHG44I9clo+Z2Iawd5hIz6sJ5RIOgtHSPJ2vmaMNd+E0NZ8z1s3favKDZpcsTqlAxW5i/LJtNYS8ym5liAZAc7sbMdTALg9HeBWvA7ycHG/ZuXTKFSOaxeZf8Jh1lOOp9Mxw59UOEhsA1Trk3tsInZNyotAjcIx1nxOXxt9ljigL3qx0+cec9cTPaNSwwBk4v9Bcc7IjbY6FCWHfN1rPnDsj8fepAESx3Oe5b4MY+zUwhulWfO7CZ5B1tvu2BsvmrB7xsjIpds51bZ1xGQfsse5iAkEq/1501Tx1wv/uUPqhlLYncBX5BTKLlbuGhYG1t0CZ7x2ADWS31dgOY1qYNYIIFp4csbJ/l2hGR02Vt0czbMgVIZLKD3mWXhYIZ+JsviBDzLGsWOA7qO409rYuwsv3nEFCKAjhJC30/e2CwWnu2y78YdPyCeip9BudhGUI0JbATZtqYBCXdBXNElmRAFqa/sK0fAN2XeTbPUsk8B/VH8stUNKM+ml+2reT9ZRmAU788OOmls/BhVYvnj8vOjqpHZJJNIq7sndY7qrf7cbXmU1aN/YTVUX8/3a31ypDKLNs1pIhL/5nWwQo0YFD1hX0VH7bPHCvlEpo+zURz6QznL5fhnH73ysRfZeXXz9WRqRSO2TozaY31e6cync5zbC/EWfFu89OG1njL75ZgDqwrUn4yWPeDt1Tb3bvIcKXP1ky8Ej9C2qsnzZx7+jHEb0PIzsd4QTj/mOZ1yGkcIUuqBBmdB+eD9ScfLIdwlYQXGluXs98rwiYUNXfhyf/9/3qkB6MYpzswVMd09xtOsG8oss7fKuttyOeYHG86D9yFx7Q846xBi32NoyPcRno4+UU7d/hVQ+nh4Mlfzeuc86E8cBJMp/4Ztq05rB/jB+v2djhG+YXHNAXZNCx/BA7kOcc2oyml33L15YJjXJ7/1Du85/wfI2xZv2lx14MHCMyILSxHg2xaYvv1u5Qe1g+zDWUKbOHgWEkJHCRm01j+AcOgBAeH7slRvDu42OSAy/OkXdyZFzdsnBUbwnBQ0GNzTfTk/K28GepxUAKESRk6AwZvmj5d1AC4tyVix2t9XUAUPf9E0fzWoJ5P5RESJkk9/0QxNpKgkJBR/PwTRWskIUbCOwLV808U2UhCiARFwfNPFOlIQnBY53UMzOHk78G0BqhmBPPxV/1w8GTROFeVKDnue49tBMZozXfVyyEzttZ+j3uwVads7fewl0MMTNd+D4C6OoarLqZQDDn6lY9xv/MW4yXPGG852Pw0wtHU3C+dIsMBX55/IrvueVjuP/8EP7WAK37KgE5+SoHxJ7Lr8oCDuHId3GCAkMTJooVzA9jDZUfYk4L31l/phZsWKRDQCqma1HDqIMFslhBslmA3Swg3S4g2S4jXJHAPE+lh4nuY/tOQmTb7VOYcy8nHwzrClgXoOgIn/vztoA0NhXvt7eAoTqktbmHIcOnG6uptJa8snESqi0A1fAEEzsk81v30qioMxJd7MKXIookHXLYMdozGEBqQa+y2wP5+aDguwgsfxu5Pc7jqACufr0xe4IXoH83gMRg82sFjOHiMBo/x4DEZPNYGj/XBYzp4bAwem4PHscFjC498OUXG8fE4RH5TVf3mow9+wBi98GEZpBc+XNGhsStMx9mAjq8Qo/2aw8FocuRkptuyUP7RDB6DwaMdPIaDx2jwGA8ek8FjbfBYHzymg8fG4LE5eBwbPFb40j42MkwqGRXQLMMUcLkbOp2m/7Kmt+NOmzk2LvCb2Njh4FdUv8SrZMNRSVrcqnkTs8znroP9zJCXNYeKi10Lx+hgpVXxui8Mvgrcy2oWwZRYAmwiZLrcJHHRzEL23fCz0/kYNrcxzpVhj5vHTrMpaY1P6akuG11us1a1qSuDWbC0UBLjgYttjEQxZ4rhpEW1o1P5mNNct3iWZwvibr2cp763XAFJS2gE9g3q003dsKgGXquI2jGP3i50m2LvRA00aFCzWIitQfQAx3wC3RAgPa5hfMHYDuUzO6SmQ7h3E/k4hcXWfKIKbTdmjEKYpJZbbVI0lU+4i2PuYgOPW92jJh/Hyfhq5lbHfGrLXWxKqsrHYYyFwCP6iPufI/eDiKKpYtJpGlsuWoudJqajOeL+3LpXLJJ2knxtYXh3ydnTFhpjna9xK1BHOU3Rcr49wGmvonEKaVvV36bT5dGm2kVNGl9kxUzT/ZjNNrbiU9vp5SJCzrxJEU1g057msVuhGmXtYsdyPkVbYM/OJvj5btrOA7ebEpoq2QiiLCJq3qoNRbQDXn4RxRD/E9zSwPTRXpZRKSKnz3IEwqgDHjMgpT7Rt4sqwkGbTIeiko/IcoPuIC5QzAuC+ASxObAe6qr/EeXLrg6MZI7A2OBYt8lOZXA8qx+doozGKJsqMhzHbKHt3K8tABUdjpdhH8I2JjFlZZEeZasghjX1LbSL1Kk7m5riPBoaS4wBtcqiRZNHOzyG1KKdRzvdZixTLiXBV0xjQFQsG+GYtsA2yZwFDpOcNQpoKW9W8weTC9MrlmnC1FsWQquDecK+Oge1Ail77gzTOfZ7wzYK1SsZIhxrix0nA0Yt5OGQDBZmF0pMIONW6lbSDytUFMwJA1Sif9d8KdZALuEQZ2n6n2tctRCQaov9vhH7fQhWYr/vF3rlQwgbsd9H3Gix39dQrWl/y0PKwSUl3dvva6jjkG44nYN9wUpy1xro2I5Ek8k+kKb3m2BFPyI3H6kCRt2BhGlqHZV4d9NGwYbPwkAbfrzWG2grig5VigpfOmxLLGwtdmR8SRcHBZdbNUil37Em6AfLCnCfGew2jgIYOanjqJu7fahrRp53ABiKUCX6n2EHAO7WWgeAaARK2+bI7UAg7yKaEWniLNpn4dXKr10i9YoiFPj05vwBJGCOuOmN8H31Ui9agQMADDeqEr5h5MfBOMpjtvebjmXc++slkwrHXq7arsz5r6TtQIxGfIn31nYg6BQHgGiThkxVufYOANFwxdGGFRsOPwiH2MBNltk+tpqExUCbg1FnH2ARiNhUpw3izFnDxraSOv2ywTWPPFUkJnefDAMZPezjnD3rA8Iy0RQyXQC3qjYSm5T30HpJb2gzodJCaxbfIMdx3NaS9K3cJDY6LI9vlGWWs9gqy906WPEbcbmSTFV3LfFmCy2S6njjIn22sJV2gMXDzpSwkrPVFie9UZrUPpBWtX37GPY56nBy7ok+C5JufCt9Tmu7IjPP7mfw27yDNwL5EY54oTkI4BRrHJyP5ChxQZXnlRHiVWi5PodXJ1ExswqLVyfM4ezDLCQY1GO8YIuBDEnC9hYRRGxcCACWzLyCFdT9/OlNOliR+5VgiVcEPtav00c5rr70rp3728jeZtO19Pc1W63xMZRh7PxDI1eL4ICK7xDjr3vk4/e3DX/cuuBjH5pKQBvGn9O36p/URAO1ekBiE74xI++vzYSbFdw0If1vDcMKnR7rbhXrcqErDlmbi7XCihJb+TC+fWWwYiUhK/o3SVOVopgjsPrKg0pR7Jpt8bwPvJZYZQeqmgaqSKnJDLWyLq3Sd26W/PbbQU9OWjaBs29/4iMYi+E3L065Nw+fIATRmUi/pX1sT+6LdrUh1GhfrR50/9yBoWY3SGf0iIZa3dVUl6uJbdJkYNA+8woluGNKRDgSlDx/IP1vKkDNSh9YNmp9n8BWEDgPdnIHXwlw2TpRfAC5S9o85mn6Vl3HUJXGg5tEcY4vKmWOV1mfNtdDRR/4OVVzb6++/TsrrPSLJOyVZfUnoiyByrHrYbM8fbYf9Y33CBpL10F9zjRZi/2U/33GNI2jvhIRCwsrBL0CsoYK56tzJA41Km4oESyBI3Y2AVp+ur3MbuSn1/tPP9ElOvGz7dlH+P3Vrfz+RvW+uoNzun+zDaxuC1Ywg14F2AYYOd8J4YbyytaqZyJ6S48E8W/MoMSpsgjdeDnLDGHavDnj6iWuXIWt6RQ/hcdE8/wqzqo5bEqMyCEwf8HpN2zx7VFv1MJHh9kMr4XgDXLr0FMHcov9HWcInOn6gyWzCbNYSxDmigiMT5U8zXpmodczC3fhce0ufE1nH2VChCGqB4cvbuoD4mF7PwD56dNkD2WXkW7LEsjgiM+OFaAw1EUNAQr8jaRvbMfWgxHT8PDQCM7eB1wSzmwYV7w4pW25lMTjgqwLyxSBvJ+SIdIDSGLSVwWS+NKQcDP8ZQBJ5P7ftwVJDFJzgJyrA9JG6CkST0yNtgh5VXPVd1umhfXgsT93NTNFtoyoLkJIsmZS4obIfjWXnwbJlXXAbAj70EQYhrXPD8BzCkO17KaK4xSaYn6DWdRHcfh2PZ+uquxAmv6rmh5fkUuBEn/YxjETJYRt8I6MAXnxlT9Vh8yF69ipMHDqTr4l1n37Oh5A99wOcOWVvN4X1qycAqlpc+E6XENwl5fdNF8od+E6WN3yKU2dJWQH0xJzRxFPyX1zCacWjRICj/K3gPaR9sYMGw+8AfOmOsXw9Y7mq1XozRmKeJNt2rPmzRkWf9gJRwRH6DCqgblwHRqve3jqDI+/7q5qz0i0kpi35iOipIZPh/XiMAuv6i7re8wfRIDnytW0eWEHb5t8t/lmxhd2EGsPs48JON+8jrcPs+abVQnYp8hhVtS/UW84V5XqccbGXf2eWugbElkRudssGON4nkVeGPvwFSn8hK1UtAiJG722FEATEcsPm7IPAetD6/XH9s6mSodhMx42GWDuiSgxn9oB/0k+120IxcV9isvkGrsk9+a8mQRxbyKoNxT2ooTk2Av94IAMhz9Vs6y9FBgEwZW8a9xLVhLQS/eSvWsqH+dl1khHDI3D1TTmI1ApW+Dgs9hSFnBriWnMhybCpgOFsDreVZipogX8GNGfBzm4SQM6p4gjDI7avXB08pDST7NfUcjqJG5LIuLLMj4mthoBtcpTspI3hwkb0Q22AIqSQqQLeRsOJYA9D2+FoGsk2VBFZAo+LzAMThO1j0GSoSaNOd2WnVLIiQYmLFDa3MpqqlR0fRz2z5k78b92Dhd6VD7PfdSVMs/Itpb10IiNUQzQCHxwYH0xBEL4J9yHvlBNwTdmEBKKr85s+x6HpKu5Vm1/ZZMl6hDYhkXZh0Lmwib72FC+9J8YXVshjVAhfK0ok8Dbbwe36shZF5CFxjx2v67xlPi9lzCuFQ7S7jedqedjlo+rQ7nhlS8USo/wrVjas7KKKOwRLAn4FB6F3tSsQFEt8bgCr3+N0M9QJiFbx7CiiReUKlPIyBB6SWVX9tR2fn1qOxdi2bB2TLB3UJ+XxPPbvcrioH5avjy9PUXMwLqLHG5YtEeKYKrqtgucpWDKo4Px9oNE1/ym5rUZlv9Y5Au9yBc0qgvDfzoDLzQ7owxHB+WV7qDyIeV1Ze0l+O9vKkF1UbX5q3aWLuPoAXcMFsm1+7bwEnu6oUUyGt5Y+l0rTrRgg2TEBknkw5At7IoaZnbCUD6ZjIL5eFLUfV3xchfKAFnNBdZ4CNbYwxNXG8grg7XehzVun/X1wwjP20vhsVrTa25325262/obFC98HX5QHphk2qyOF4k34GKezuKHHRaa1oJhr2SfvkZksu2zbCaYDCy6RKiUjxWsirgrchGebhcJJS4+61ZN+c77o2ZxakZd+E2P+ViYgOgQmdwRXGZY3+Ayivpdez8qh/pwP3z9cOToYzsqU2iHGdsWnrAJ/Ckv/ANEgnEZnle3wPPcUynURsGALqT9gf37u6IEuw7R6wEctFhRdR9gCWVapDJjcdFyCrb3lYTVyyGeV3FVSTCgCnHRvvSUs1eGWN2HW/ntGV88nXlp3+/Q0n+U6vqKsFuw5CKeyi2z4XiKzQU88x1lvCscplthC8e3+YRUF6arRVSsVyw3ofiI6PHKwgjT5TsHhenGfGIUeEZmPSODXVRQUZ8VztSgcA2SojaFQ0haO8LDSFqbNoSkRh9JYfusrz8cDG7IgxmKdWR1OoPDqsGOO6h23IhZyQFaIorZWlUCRfpesi40l8vQI+G1tqJSMyeDfqnZdEUUayoeW0qEosgboAYy5HZ4F8y3yGHlEkhgOQVcHNRf314MYBmZRVcBJrMBTMa7Kj91gMJqu2lc69N9rmnWbjUj31i0wVbTVN4wl91qGj8tDGLFGor9qYM06FPYPinm2AkUypoeyJq+Fm2/+XeKtrcqtI39LaKt2d4IZRJoORA5Zy2WvvF3iqW/rrBU/1vEUs0vE6NYQrBaIxGjPXwpi4ExJUcKw2JgAk4MMdBADEymOKq6iIJva52uyNYeQhu29kXY37QWNShFOErwsvexkZOUajto75TrUMl+usl32WND0C1sVT6uFCaJT/TfG9X3psTDbS7wFoP9E3g/P6MkgI3Fdilli5DRGmy/5kXezLETioTok90uLs0i3xV/uaLfXlQfazhef0yL6a65pOku352pK9NdKFAlWssPFe6p2n7MwdhcL7tHL6yazpTcLyi+qdoYw9K9+9ARUvBh63Kco48vNKtb2036Zo1HYdo0XNgumCYehoE8BYtTOW9zOXYNn7MuiLWRKLf5+JzvM/N69g+x5jfmWCmgI3x+SYvk8JwuGpDWcPs6wkQZROLh/SyiQIhS7+6pwhyFerhO8XwHaQvdbocjHSmJBnCE1T2dIspmhg5PnG17+h58CtqDs5rBV4OvK9UBzeC7bg+cCcWjI5WQItL7Bn7PaekHaz1gSHR0ih1xGQ8W9lgN9qrla9DhJwu3mExeJjhlQibgc5rfnmO1d5sHoTp+YPuLBpns47tGP5T+/mv2v23L3djB4KSI7wxM5Tb3gE8L5J5gWxi5N5BHgkmQw0QbhHHkgWY3Nb6ubfWA7yWbgABT6JzPxf4PPMVf0lIJhlz7EYZ/x1E+UQpQdcC+fFwZ5jO0QB5RqwfAfI71FXRoNa0qwe/jB+6WetBgWgFU+nFAeEWyFVgvaZh3GmlMOO7DUkcRtKGdpxDx0EtfFYB/jhnqO2P+9IGjAsSsefoAb3Wt+O/psVArpbTHJvxBYQsXSLHncLXfoPfGBy1GtrubfnCLUHBm7+CewGygDyT8sHnkK+Twrd3mMsh5mAKvBHtJy2Sr0GSkb4EnQo7aARYtYfYEJ3D6xACApDzaggHagmG02XZVnKxH2wbYqlBRRO0irOZ5Y5gHAC2Bn9G2YigBprpYnAWY5H46Rwvd+W7T9LEtN6UKqOc0Rey8DjwdnSoMm7OJg80u8ZuSEdrFnu9pocEX/BwzZYVpzGfokZwJXcAXnLuEzy0pSH9DvEHYRSI76EOVFFqujoPyJVic8re2e1/mjHRFgQ3Spdz0LN9LiUXDR7h6MOFxiCO3a3Llil+Rpvs+Z+/Ak6Xp1zQ7rvANecxjYMRs/CKPac/I3I2wR4Eo8eFKnLP1kjkycBDHYfIeH7LMF3Dc1lD6Xh8QTCop+zrfhF8Qgi/9rYQv+mVTgtgfiEZyg151ePqydk/w5SgKbq3ypTDuSTFuEm8eccCGa6NXHL2ks9vEIQWk4Z40bU+Xpr0oQJLJfgEk+oL2XXhB5yYVB1sX3F31dNQbUIk3oFSlps1F3R46iR/1VFaVX+TQcf6GOQw8J43EAxn2nIzEc9JrMsUQJGaNpNz7g42m10sgmtriFLwqy8qtcqSYErRJNwvTxk5NXl+fkWn/2gwfBgaLMvVe0dXJqWj9X9DBXDW3/akHz222Ruhkt/mJ/4L2GnO4bvb16MNFArILzZANoryLZ8UxTL/WafPMgUpNzKyl4BsPklnzjP/6TdZ/QcOhps239TJi2j/jK+eIP/3F1Huim81Hc+gk5j0ki1QQ+UOKjZBeeYauxx47hipxDA28h+HCCHd6TuMwCX6i0iHrnaTJip+or3OYC6m+Y7phExvTZ+rGmbunhp27qyb0cBO6akKLY/f6Jtix2zcz1fJKG890L1vlpaGGqRaWQrDNP450fUU4e4wJLILiy3IU4BdH3zdbQpvI6Q+XchOGrH4cA6yEvr5dMdSLmq+RuDggvLjtQwNUbD2WBdTKkiXWZ7YvLTzNQD+r5RRCZs/DbO4UiN+n1xBDcwhbYkrunvJ2WF4touDC5083An+2ccVl4eL1LHQvcZmHXk5QfOXpvBcG+lOdCaakMPu4fGPCkyQIMPAp0lLBMwf4kmPWGvr1uy1dQnQKxTchD03zxw/wsYinJTbJ9WwZntaQU1KxpgkWqxXhnBdauOpCs9adg3IOpnSRkJ1ha26e1EW03OtgZJ7R4hMfCjyarTX4nA97oeUeJVU2QSwA1KQ7bKwsA2b5TKh+UPNJW520zM9gXTe4A+YoayCNe8IcbQ5EADmbYsoTmezpA4VhGxSxSXq5YjiFJnPUzrmvsFMK70HcVwy2HvNY7ftBNnlqIKgRuwSD0QnW4MCvyRxjNaFpQ/EpcqAXFeyKXLnsuWN187KAFBK8vqCzfPpAmt7Dq71nmVWT7I017RHG3BOEcSn8yYGbYtMAQZ0cZKc/NKa1Yh5Btu97HnMWL9/zKPqRhluHn6Yitbbdk2D1js+lj/n934+91ImAFXJ2m9c92aQU8tGUBMPQ7aJJQXlQKbl893EtoT3Pa9zThs+ZD4SCLXlaCklqWA6zJHRQKcr4iUmKj1oDf99Po4R57jhLzHja8ot89dSWJ37lWy44i0MYU2Jxse4Nvehj48Pl4CsmLcynmdI1cxZDrDcx4oJnqOnhNTlHAm+RprFO5S2hIWfH7IjAd730Qzek/64+EI6SgXDkxaOV9cLR/JB0tNhBOJL5JiNaoj4MyUZpbqsVG2P/PV0xx1nzokY8DNmwvaBxUzRrolkouHu9QGX7ApXNfsFHmwhceLRvm6XFOTdYaGoXVHsMLzy5Rwky23CDqZAP71lFHAkWB5GJhpdgmXKjQlnBtPaidiu9clQyG4pYsYlktj7Hu5HMkvchmX2PY/+1h0fiZYmsUjLDjqFsELX/6zMynV6bGRXIgv5myx7DwiubI2HZaABswctm36tkMz/CLIh9Z0RAkfUwXgD1VLLTIGaF2jBmxSVkEcPy3rT5zoBtCaeUKC1/N9LZQPoaloXMcBeNdLHaOWzSzWEpdyBHDAl+fSzYUNbvEWRvUKRh+H7P/79hTOhkWKjEHvxdCJXBexEqzeWrvCKhEgylBTuCT/bXxPV6aj1qfL0uGUbLsXLfDjKb/vtIx7D9/7FqF/X9Ck6ClZKVHTRClx1lzU7kNC4Ae/QrHA6ew6Zd+AZ8h7B/rbwSJ5fd3i+5qQ7HK+6AGS33KOwV8lrj23gp6rEpD76HzvpfKVnryI3URdgrOG/o4rNdtpdCqKCz3R6sapf50lR+RnFn+bnn/kL1blEvfIOd5xawpqk8ci98Q7u/ALmwZbKEI0B9RUrR9chd8ME4w6yXe0UNIQoq8DO53Wq5i8jO7H3dxa7zhWc0x9GZfHDWvHBBnjM8f1ueEzy/oIfNnC98Q2JCiPOVvb9A5KNZ85rmeCohm+8lwYooyVf4ki2z7HZDhtIU3jGVY/Q1heISSOkChxI2y4RgABI6mKPbxBSeKWpy63LyYHaYg/YiKIC+6LsJkb0nHjU1ZxfIuN13QN0dZYdhPQ3HF2w1BhEFoPIY8kiFg0PwhpbfVZiy/pES5ehrf/xn//DhWfOMIXX4rT/4P//kP3z9v/it7FBwHu+P/oun//AbP/8//vLMoeCckbIX5HzUZp+CYUB2u5tAZAk2vXI/hVgPImO31ItqgWdRBHMMvkXJR0mCtTf7zsKqYbYHotfy8iPVEyPYAdzvCT5U7y6q7FMOLvuM8qIGY7Namc2PYga+f3X3YwW3pDj9JHgNr7egSDji99/gFq/c5Fl5mVzuQtE2lJwsd7vp7+jK/05dF1wwkCifPxw8+TDDFUGWc5/s8P7HXfT4/zYLgxcV394hF70DUutDQLtzHFMrzI7A+Zys+2R5zK6gXxDKbZkdIevm2hJhQy6Bg0pW1GolaudsPqR0+m915bGXsceewMk2ueHh5O9B4nKrycDsMvuU++kEGCGyHX4jeOzwxeAXRb0ClzaXgA4AY24rk1U3IVYGpmSrgoc7TJE4mXDBsniHiPGn+HmG3+KaSooO30whQpycuw0GNAhXEXpfo4lsQTCFQV3oD3TgsnK/SqfBMhWcvCcxRP0b7lT/hjvFN9yl/0uuP70iDpg3FQFHNRnkDvq5A38bPPJRYZDPDPKZfj4j+WrIl1w+31Z2/Lx8voler+f0g4VB/usLjr5iB/ltP7+V/C3km7h8vjryNS6fr+Hbt8h/c3G5ewOLEPn2FxHyRYN8UT9fJPmaBFtVZS+fc9JDECGYjp5Wk0WMIvGgSNwvEkuRbVixyHIx3H/QwtrCb2M9VDFdJLJE9KtI+lUkUkVKtR4Zzn3b5XPDxFtlRYZ82SBf1s+XSb7ttLVHqYCSoczuYhxlxgdlxvtlxqXMEar3KJAy4/z/nbBkRf/4jYPo9SiWtyn+/27UfUMBzkR6ULfu162lbkfbaHuPV179YKGpSUd6lEhN10Dt0+tRSK5Hukdj/HUP/39vD0y6R3t6tJs/EI3RNT3aK0XzHqUolfXoGv5Q4Pr2Ho1L8j441fdop7ztJ0vjPdolbx+gmHb2aErerqUx2oU2+O2DNIUWSd6m+f/XkUZdBdrG+4doHIDskzwfpr14pD3I8KEe5fz1ev7/TI8I367v0XX84QDl9OEezUjRgz3aiVL7e/Rh/nAD7aJ9PfqAJN9IU0i6Vt4+QrvpAz36oLx9lIiu7dG0vN1EOX0QbfDbx2gaLR6Qt1n+/yHaD0BuQNt4v5k+AEBulDwfpxk80vXIcHOPDvLXW/j/t/boAL7d0qND/OEwHaSP9+hWKbrQo2tR6iM9+jh/uI0+SDf26KOS/As0jaSb5O0TdB19tEcfk7dP0gG6qUez8nYHHaSPoQ1+W6RZtHhY3o7x/z9NHwEgt6FtvM/RLXRbr0cL/HYnfRRg/UKP5vj9U/QJ+hgdoBm6gT5AU3zNAUIV1eUw6m6aEHXi7S58sCzlmOgoH0MVrFtIioleh+Z7pfut//jVH4RlscPtebDYUlKDjuKpXtIkzZdUp4ke3d6hiV5JO1BXlX+SttDtyNnodajRK2krTZS0A9dr9DpU75U0OZx9pOxdxK3VaRI/W3sd2tpDy9tRwRbChy29ku4aLtMYftnuga3RXXhK0fo21FCn1Le+fTj/VtpCDeSs9TpU66FbR0rajrsrcIczoN+0rW1SMqWtDLOvHne/cHtbPLDbhss0h1+2cMPw6N2GpwStt0pqYrx861uG87dQOXIGvQ4FPYRpcCVtYQbQoaRXUmvTtlIpmVALP61eh1q9UmSgJvRVvvvpcJnaaG1ouOQriVAEr7gOZ8+DRdjrUNhDXKRWyVcpV+CMQGCGXyIBxgjqcR9nKQEvex3SPYiowyV7XraC1qzm+z5SneaX/+rf/9VfI7wRKrU4EuDdHgCUhkyPS+IiElhe9LilYLjo+noiqSHukaFrIGiFGxXr4Xx5J8fSljbWVDT0Yjx0Ee1CLQwdN6GxKALqAr2NekO93LSeSGqIsWbs8dCtKybQ7fPQmSuEbv8m0O19b9DtvjR0H3pX0F3rYQI8tBk8bIos7YOg6MOlLKxoIhytdRgcIZUA8teeB4uxDoiy00VLOWAc2wBGqeCbT/5nv4ZzJkZaSTf2YfS4GKMPshtOlyAkkEGldrikobALe6UQKQFdj+aiLukOfvFtpB09/BJIY7brCb2DnSOKRDTtGw37jQabVsNdjkq6WRAX+OmD4DofQTVBl2wfIeFINRR1kcJwWroOYxpzT0OK8W0U3NFuBx52QRibbAnGP+objfqNmk2rqWA/6FHgyRc2dx/HdBfYzeVhv8nDbt4f7Le9B9gt/YInF8OGgoC/OwCDbrlMR0YbGExeC+41yxOlS3G/r6OEwLP7Vr5egaH2FLRB53//zdefg9bcQx3S3ADZQ7zC0iE0OTLpfdH19fi5Cu5KnwTdxhsUExgPszvg8DzctFbG6cKG0IV0B68q7xq6myCJfaJHn5Jdz6VhXXyXsB7bBNaPQcD7ZLVTSN4L5Leiik/16M5qi3RpyGfRxzuwZeHd0bvoB93tLZjmKaRP0Bygpkx2jJ6jbAy9cNxS7uCaoEPo8CK2Nk4/yGEPmSmRHubhQy37mxCP0hwdRjfp01xQg6SjnkgoI/0s5Zqv2+mTwEuCjZ7TD5bEUs7Y+s7C2JYj4rDG3q2JWtX2AUp+N9dbV0Tvk3KkJlYXB1WMguxTUDb9WJd5hohZuszHERlAl/kW3B1qynwrdCumzCdIuTc5QJlyb+gy304mH2NfZb5UMJBje9QYih7sDX1YP8zax+3ZPG3L5vOYJrJ58YpTvcK6sbPuzbgzzWpZtjzbms1Dl7y9+v6M7omLmO0VsYuqz9/WPe8xAm10FWbzhRd0jy3DoBdeU/UkjHEH+cgOV0bRSPZwpP1eDxrxEYjY+i0aqS8cqS8eqc+uq68+2hU2rbMj9UUj9YUj9cXr6rPrcDANNK7BwX6qj7RRG2kjuQzM8TocXC+a901wWh+pr7auvnAdDggG1kP1JSP1jVJL/QpwcNMGdHADhZfA8+XGbT0d3HxJuhodt+gK6OC2NXQVXwIH4RXgYG4DOrjrKtPB7VeZDu64ynTwyxvQwS9dZTr4zFWmg89eZTr44gZ0cN9VpoNTV5kO7r3KdLC8AR08cJXp4KGrTAcPX2U6WNXA9BokPKXfFyU01mHhcf2+SKG1Dg3n9Puihdo6PDyre2Ld8oym1iVW8salQRWPoaf1GipqjNQxSnStdXXE3gqucYkxaF16pPOQ4Aa5hY0YdNFw6R3wH+gbPjEtb95Lexm6HMW9t4a+Ynkq3mDeDOeG45u+pPwTX4bO62sp+jl9yXkTXoai1+PXimnMGrKuX6LWTWjlxbVzLbwErSQb08oLa7F/qfla34BWxqnhmoueQn6kxV7r6lLIy1eZQi5eZQr5/t8Ihbx6FSjkB1eBQl55vxSSpbh4XvVxPqNknKTcjPrvX2DDiAoNM+offVuMI6phmVH/3TNiHNG77KEqLDNSwkX3failvWhte/G69ux7as9Ke0mf5qU9u7a9aF174XtqL5H2Gn2ak/bCte3Zde3FG7R3uaN8aCw0NUu5+JRtaZttl8HuJIXpkcWPzWP8JHlIER4aFE2rRm9WNRDRCC9Jb1YlUMrgxfZmlSXY9ETTSvVmOegm2zCPwewDLsLweBUT+RT2PmzS42+B4cBDY3AEH6Mm3z8vF8OkYsnxiNY+pK2BaYr1Kg0y2e3v0RKIjZLYFIjtWSb4V2e3Q9nx7QC2JBmb+yKabZpwmypNA6XSp5o6HNyzNIilmwcCYbRfuUcYq8q70MFIcZI3sIXyXs3wc3Z8OYFbOTKVB7hc06k7YMBDph36EMNOwxwcF0TJBRtZG47nfM1XcqSIO3x5CgWudrTbbSr3MGIyTZtpp92FA6TGAyXtIdC4U+6ZA2+mUMDgbiVSDpceSjS4VXbSZBjdh0THpCWemCazjBwPkzr89tuPrr6iDrHV/uHV1a+svqYPmWd13x/rcS3RxacBVdfBSsXQeKBm2VJUUthQeyjlvO5/f1YPEmBXBKQ97b1v4d/iVlf1rPnZjK8Kr85WBQBjIhaSP5txZnnWNCpfPXh5eKe785VH49P8YOQ2d76XDi4OCTCgs127+q6+D8Px3risZAMs669Ls5VngyRzLGfTb6LvPME9eFWLW+8PONz7LWp/BWTh7TdnEfGJzeFPOWjsXp8B8ZDOZpsc6H3WXA/yQvc0YhFPoMu7YfYsQRUC8aLk0NoFk9AchxAU0+1JBE3+uPsQbGePFGqKewoz/cFl6rijwV/CnuI+9cA9wrfx5cY98/XKIlT50K27JRSsWS54XC58XTteLFfHlxFcH32+cwpOPErsxDjUsrtwXleXXw8HiubQr0pe3e/8pna7/RXn/gonE8y5jO9jQVRdvghnzxExcYPVOg7MXLw8i3BCDK6mEPGEXNzmG6y8GWY4CG1t3YWnES12AMnwtVWiGWVrOR8qW+LhmUE8vAH4bAQcHdSZRBx353Eljzuv5esWRhfs7Pk6Y7LuNcQG3OJWjWQY8xme6WeYLG/VY+4Z49u+4FFnll1yq/7dx/Uw6hA14hkYQGccofV3DMK19a3s9lQlC+XCW/Xvfk2maIhY3Re+NlwRBpjNWCU8g4vXtuS/1zb5nqz/Hg5o4x9UtLHlkrTxm9qHmxrqoNyEVtFGSgEo/6kD4hnjwzMH7qfZrDm3gwL3g2zWvLmdAncxmzWvbWeu+v1t8CTfwc+vbi1nzevy/SfQov90OwXZ9TKTVDWTZ71nf/+6RC2sojBVUG9/A58eTO9nD8gvwgRwFE86xOb1gPc7evDtOe/SUHmW/UC7xqlCu9e3wt9m1vyYOaR7zb/+SF7/b//6irz+tX/9vk4RlRmGqTZN/xLG36tJ+o/tqjp5uvelz3/+5ImTS6eX6f6l+890v6xuPPDRAzceuHHm/jPLp5a+rE6ePnv81Mn76NTJ5aXu8VMHTy2d/sLyF3vUW1rup504c98SDSd86XT79JkHT9MXl47ft9Slz586/oXREved7C0fP31iafTr504u+2qou/TA0vFltXzmDN1//PSXq89nuv2i1Pvy/Z87c6rXL91bPtNduo8+d+rMiXYFjfrclz7/+aUuLXW7Z7qqt9xdOn6/fxkBfmaG7j/Z6508/QVaOn3fzJnPz3A16uTpE2e63aUTy1VXTnxxaeSzh2vt5/uOLx/vfxztMqFPnz/epc8dP9FWVbXdEwDg/uPLJ77YL/HgydP3nXmQeid/ZWmAIu7d8pcfWNpkZLg/6xvlr9WwnDhz/wPdpV7v5JnTdP/S8hfP3KfwX6bG1RalVKJiVVORqqtQpcqqhgpUUxk1prRqKXexkf6BDZRVoYpUrBJVU3WVqqZqqXG1Ve1QU2qv2qc+rD6qblWfUv+JOqF66jH1e+qP1V8oo5Vva/Rv3P9t8X9b/d+E/9vm/zK1qL7HkSeMEhgAa1ONq50qVzcqp46rR9UfKa0fxS2wgbY60olu6ExPatI36Dl973D7VZtVW2hju9qudqgdalJNqp1qp9qldqkpNaV2q93qGnWNmlNz6r32P5Duq9U1f4/6v6/4v8f83+P+7wn/d/4q9F+v6ovD7VbtVe08qZ5Uv6Z+TZ1T59RX1VfVr6tfV7+hfkM9pZ5SX1NfU19XX1d0WKnVRCmtldqjlWoppS4cUUrVpH97lHzjvvpvW5VSsXIXxtNjEjxk8M+s+Res+WfX/AtH/rnzW9KltVWtLVplj/y/2P9L/L+a/1f3/1L/r+H/Nfmfu7g13VdVH/sOZuNbVBLXonqY2kbQNGO6pdwbW9P7Y27bqoT/KR6vTCX+OWIfncTnATXWGJaMv1fPGCV5pneelcYznoxWVp6NNlplNeV+NpHWbvhlLVj9/wA=")))), e) });
}
const Kt = "deflate", qn = "deflate-raw", ss = "deflate64-raw", Fn = "gzip", Hn = [Kt, qn, Fn], Zn = [Kt, qn, Fn, ss];
let is;
function Wn(t, e, n = {}) {
  if (!(t ? Hn : Zn).includes(e))
    throw new TypeError("Unsupported format: " + e);
  {
    const a = new Error("WASM module not loaded");
    throw a.cause = is, a;
  }
}
class we {
  constructor(e = Kt, n) {
    return Wn(!0, e, n);
  }
}
class me {
  constructor(e = Kt, n) {
    return Wn(!1, e, n);
  }
}
we.requiresModule = !0;
me.requiresModule = !0;
we.supportedFormats = Hn;
me.supportedFormats = Zn;
function os(t, e) {
  return pe(t, e);
}
kr(os);
Gt({
  CompressionStreamFallback: we,
  DecompressionStreamFallback: me
});
rs(Gt);
Ga(Gt);
class Ut extends Error {
  constructor() {
    super("ZIP cache could not be written. Free some disk space, then Resume.");
  }
}
let $t;
async function U(t, e = {}) {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length || ($t ||= chrome.offscreen.createDocument({ url: "offscreen/index.html", reasons: [chrome.offscreen.Reason.BLOBS], justification: "Validate archived image bytes, decode dimensions, and create local blob URLs for browser downloads and exports." }).finally(() => {
    $t = void 0;
  }), await $t);
  const n = await chrome.runtime.sendMessage({ target: "offscreen", action: t, ...e });
  if (!n?.ok)
    throw n?.error === new J().message ? new J() : n?.error === new Ut().message ? new Ut() : new Error(n?.error || "Image validator did not respond");
  return n.data;
}
async function C(t) {
  t && await U("release", { url: t }).catch(() => {
  });
}
async function ce(t, e, n = "application/json", a = !1) {
  const { blobUrl: r } = await U("export", { text: t, mime: n });
  try {
    return { id: await chrome.downloads.download({ url: r, filename: e, conflictAction: a ? "overwrite" : "uniquify", saveAs: !1 }), blobUrl: r };
  } catch (s) {
    throw await C(r), s;
  }
}
const yt = 3;
function ct(t, e = 0) {
  return Math.max(2e3 * 2 ** Math.max(0, t - 1), e);
}
async function cs(t, e) {
  const n = Ra(t, e);
  if (!n.length)
    return t.status = "skipped", t.errorMessage = e.mode === "original" ? "No original URL was exposed by the archive. No URL was invented." : "No observed or supported thumbnail URL is available.", await F(t), 0;
  t.status = "transferring", t.attempts++, await F(t);
  let a = 0, r = !1;
  for (const s of n)
    if (!t.candidateFailures.some((i) => i.url === s.url && /Image HTTP (400|401|403|404|410|422)\b/.test(i.reason)))
      try {
        const i = new URL(s.url).hostname;
        if (!Z.includes(new URL(s.url).origin) && !ua.includes(i) && !await chrome.permissions.contains({ origins: [`https://${i}/*`] })) {
          t.candidateFailures.push({ url: s.url, reason: "Optional permission for this original host was not granted" });
          continue;
        }
        const o = await U("image", { url: s.url });
        if (o.failure) {
          if (t.candidateFailures.push({ url: s.url, reason: o.failure }), o.status === 429) {
            a = ct(t.attempts, o.retryAfterMs), r = !0;
            break;
          }
          (!o.status || o.status >= 500) && (r = !0);
          continue;
        }
        if (t.resolvedUrl = s.url, t.quality = s.quality, t.bytes = o.bytes, t.sha256 = o.sha256, t.mime = o.mime, t.width = o.width, t.height = o.height, t.blobUrl = o.blobUrl, t.savedPath = ba(t, o.ext), await F(t), e.destination?.kind === "zip")
          return await U("stage-image", { jobId: e.id, recordId: t.id, url: o.blobUrl }), t.status = "staged", t.downloadId = null, await C(t.blobUrl), t.blobUrl = null, t.errorMessage = null, await F(t), 0;
        if (e.destination?.kind === "folder") {
          const l = await U("save-image", { jobId: V(e), path: t.savedPath, url: o.blobUrl });
          return t.savedPath = l.path, t.status = "downloaded", t.downloadId = null, await C(t.blobUrl), t.blobUrl = null, t.errorMessage = null, await F(t), 0;
        }
        return t.downloadId = await chrome.downloads.download({ url: o.blobUrl, filename: t.savedPath, conflictAction: "uniquify", saveAs: !1 }), t.errorMessage = null, await F(t), 0;
      } catch (i) {
        if (i instanceof J || i instanceof Ut)
          throw t.status = "queued", t.attempts--, t.errorMessage = i.message, await C(t.blobUrl), t.blobUrl = null, await F(t), i;
        r = !0, t.candidateFailures.push({ url: s.url, reason: "Image fetch, decoding, or browser download failed" }), await C(t.blobUrl), t.blobUrl = null, t.downloadId = null;
      }
  return t.errorMessage = t.candidateFailures.at(-1)?.reason || "All allowed image candidates failed", r && t.attempts < yt ? (t.status = "queued", t.nextAttemptAt = Date.now() + (a || ct(t.attempts))) : t.status = "failed", await F(t), a;
}
async function ge(t, e = !1, n) {
  if (n?.destination?.kind === "zip") {
    const { ids: r } = await U("zip-matches", { jobId: n.id, records: [t] });
    t.status = r.includes(t.id) ? "staged" : t.attempts < yt ? "queued" : "failed", t.errorMessage = t.status === "staged" ? null : "ZIP image collection was interrupted", await C(t.blobUrl), t.blobUrl = null, t.downloadId = null, await F(t);
    return;
  }
  if (n?.destination?.kind === "folder") {
    t.savedPath && t.sha256 && t.bytes !== null && await $e(V(n), t.savedPath, t.sha256, t.bytes) ? (t.status = "downloaded", t.errorMessage = null) : (t.status = t.attempts < yt ? "queued" : "failed", t.errorMessage = "Folder write was interrupted before completion", t.nextAttemptAt = Date.now() + ct(t.attempts)), await C(t.blobUrl), t.blobUrl = null, t.downloadId = null, await F(t);
    return;
  }
  let a;
  if (t.downloadId !== null ? [a] = await chrome.downloads.search({ id: t.downloadId }) : t.savedPath && t.blobUrl && (a = (await chrome.downloads.search({ query: [t.savedPath.split("/").at(-1)], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === t.blobUrl), a && (t.downloadId = a.id)), a?.state === "complete") {
    if (a.exists === !1 ? (t.status = "failed", t.errorMessage = "The completed file was removed outside the extension") : (t.status = "downloaded", t.errorMessage = null), a.filename) {
      const r = a.filename.replaceAll("\\", "/"), s = r.lastIndexOf("/ArchiveRoot/");
      s >= 0 && (t.savedPath = r.slice(s + 1));
    }
    await C(t.blobUrl), t.blobUrl = null;
  } else (a?.state === "interrupted" || !a && e) && (t.errorMessage = a?.error || "Worker/browser interrupted an uncommitted transfer", t.status = t.attempts < yt ? "queued" : "failed", t.nextAttemptAt = Date.now() + ct(t.attempts), await C(t.blobUrl), t.blobUrl = null, t.downloadId = null);
  await F(t);
}
const ze = 60 * 1e3;
function Xt(t) {
  return ["scanning", "downloading", "paused"].includes(t.status) || ["building", "saving"].includes(t.archiveState || "");
}
async function ls(t) {
  const e = await fe();
  if (t.type === "LOCAL_SETTINGS") {
    if (t.retentionMinutes !== void 0 && (!Number.isInteger(t.retentionMinutes) || t.retentionMinutes < 0 || t.retentionMinutes > 10)) throw new Error("Choose 1–10 minutes, or turn automatic cleanup off.");
    if (t.clearAfterDownload !== void 0 && typeof t.clearAfterDownload != "boolean") throw new Error("Choose whether to clear temporary data after a successful download.");
    t.retentionMinutes !== void 0 && (e.retentionMinutes = t.retentionMinutes), t.clearAfterDownload !== void 0 && (e.clearAfterDownload = t.clearAfterDownload), await Qe(e);
  }
  return e;
}
async function ds() {
  const [t, e] = await Promise.all([ue(), U("cache-list")]), n = new Map(t.map((r) => [r.id, r])), a = e.map((r) => {
    const s = n.get(r.id);
    return { ...r, title: s?.title || `Unused cache ${r.id.slice(0, 8)}`, service: s?.service || "orphan", status: s?.status || "unused", protected: !!s && Xt(s) };
  });
  return { caches: a, bytes: a.reduce((r, s) => r + s.bytes, 0) };
}
async function ye(t, e) {
  if (await C(t.archive?.blobUrl || null), t.archive?.state === "saved") {
    t.archive.cacheCleared = !0, t.archive.cacheCleanupError = null, t.archive.blobUrl = null, t.service === "posts" ? await P(t) : await E(t);
    return;
  }
  if (t.service === "posts")
    t.destination?.kind !== "folder" && (t.archive = void 0, t.tasks = [], t.status = t.scan.complete ? "ready" : "cancelled", t.error = e, await P(t));
  else if (t.destination?.kind === "zip") {
    const n = await N(t.id);
    for (const a of n) ["downloaded", "staged"].includes(a.status) && (a.status = "discovered", a.attempts = 0, a.nextAttemptAt = 0);
    t.archive = void 0, t.status = "indexed", t.autoManifest = !1, t.manifestState = "pending", t.destinationError = e, await Bt(t, n);
  }
}
async function be(t) {
  if (typeof t != "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(t)) throw new Error("Invalid cache to remove.");
  const [e, n] = await Promise.all([vt(t), zt(t)]), a = [e, n].filter((r) => !!r);
  if (a.some((r) => Xt({ status: r.status, archiveState: r.archive?.state }))) throw new Error("This cache is in use or kept for a paused download. Finish or cancel the job before clearing it.");
  await U("cache-remove", { jobId: t });
  for (const r of a) await ye(r, "Temporary ZIP data cleared. Download again to prepare a new ZIP.");
}
async function ve(t) {
  if (!(t.archive?.state !== "saved" || t.archive.cacheCleared || !(await fe()).clearAfterDownload))
    try {
      await U("cache-remove", { jobId: t.id }), await ye(t, "");
    } catch {
      t.archive.cacheCleanupError = "ZIP saved. Temporary data could not be cleared; cleanup will retry.", t.service === "posts" ? await P(t) : await E(t);
    }
}
async function Yn(t = Date.now()) {
  const e = await fe();
  if (!e.retentionMinutes && !e.clearAfterDownload || t - e.lastCheckAt < ze) return;
  const n = await ue();
  let a = 0;
  if (e.clearAfterDownload) for (const r of n) {
    if (r.archiveState !== "saved" || r.cacheCleared || Xt(r)) continue;
    const s = r.service === "posts" ? await zt(r.id) : await vt(r.id);
    s && (await ve(s), s.archive?.cacheCleared && a++);
  }
  if (e.retentionMinutes) {
    const { removed: r } = await U("zip-prune", { cleanup: {
      before: t - e.retentionMinutes * ze,
      protectedJobIds: n.filter(Xt).map((o) => o.id),
      jobUpdatedAt: Object.fromEntries(n.map((o) => [o.id, Date.parse(o.updatedAt) || Date.parse(o.createdAt) || t]))
    } }), s = new Set(r), i = `Temporary ZIP data expired after ${e.retentionMinutes} minutes without use. Download again to prepare a new ZIP.`;
    for (const o of n) if (s.has(o.id)) {
      const l = o.service === "posts" ? await zt(o.id) : await vt(o.id);
      l && await ye(l, i);
    }
    a += r.length;
  }
  e.lastCheckAt = t, e.removedCaches = a, await Qe(e);
}
function Tt(t) {
  return { state: "pending", filename: `kemono-discord_${t.serverId}_${nt(t.serverName, "server")}_${t.id.slice(0, 8)}.zip`, blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null };
}
async function Xn(t) {
  const e = t.archive;
  if (e?.cacheCleared) throw new Error("Temporary ZIP data was cleared. Download again to prepare a new ZIP.");
  if (!e || !["ready", "saved", "saving"].includes(e.state)) throw new Error("The ZIP is still being prepared");
  if (e.state === "saving") return;
  await C(e.blobUrl);
  const n = await U("zip-open", { jobId: t.id });
  e.blobUrl = n.blobUrl, e.bytes = n.bytes, e.downloadId = null, e.state = "saving", e.error = null, t.manifestState = "saving", await E(t);
  try {
    e.downloadId = await chrome.downloads.download({ url: n.blobUrl, filename: e.filename, conflictAction: "uniquify", saveAs: !0 });
  } catch {
    e.state = "ready", e.error = "ZIP saving was cancelled or blocked. Click Save ZIP to try again; images remain cached.", t.manifestState = "pending", await C(e.blobUrl), e.blobUrl = null;
  }
  await E(t);
}
async function us(t, e) {
  t.archive ||= Tt(t);
  const n = t.archive;
  if (n.state === "pending") {
    n.state = "building", n.error = null, t.manifestState = "pending", await E(t), await U("zip-build-start", { job: t, records: e });
    return;
  }
  if (n.state !== "building") return;
  const a = await U("zip-build-status", { jobId: t.id });
  if (!a) {
    n.state = "pending", await E(t);
    return;
  }
  Object.assign(n, a), a.state === "ready" ? (t.status = "finished", await E(t), await Xn(t)) : a.state === "failed" ? (t.status = "finished", t.manifestState = "failed", await E(t)) : await E(t);
}
async function Vn(t, e = !1) {
  const n = t.archive;
  if (!n || n.state !== "saving") return;
  let a;
  if (n.downloadId !== null ? [a] = await chrome.downloads.search({ id: n.downloadId }) : n.blobUrl && (a = (await chrome.downloads.search({ query: [n.filename], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === n.blobUrl), a && (n.downloadId = a.id)), a?.state === "complete" && a.exists !== !1) {
    n.state = "saved", n.error = null, t.manifestState = "saved", await C(n.blobUrl), n.blobUrl = null;
    const r = await N(t.id, ["staged"]);
    for (const s of r) s.status = "downloaded";
    await Ua(t, r), await ve(t);
  } else (a?.state === "interrupted" || a?.exists === !1 || !a && e) && (n.state = "ready", n.error = "ZIP download was interrupted. Click Save ZIP to retry without fetching images again.", t.manifestState = "pending", await C(n.blobUrl), n.blobUrl = null, n.downloadId = null, await E(t));
}
const Jn = new Je();
function z(t) {
  return t.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), t;
}
async function Be(t) {
  const e = await vt(t);
  if (!e) throw new Error("Archive job was not found");
  return e;
}
async function qe(t) {
  const e = Ot(t);
  if (!e) throw new Error("Open or paste a Kemono or Pawchive Discord server or channel URL");
  const n = new URL(t).origin, r = (await chrome.tabs.query({ url: `${n}/discord/server/*` })).filter((y) => y.id !== void 0 && Ot(y.url || "")?.serverId === e.serverId && new URL(y.url).origin === n).map(async (y) => {
    try {
      const c = await chrome.tabs.sendMessage(y.id, { type: "DISCOVER_CHANNELS" });
      return c?.serverId === e.serverId && Array.isArray(c.channels) ? c : null;
    } catch {
      return null;
    }
  }), [s, ...i] = await Promise.allSettled([Jn.server(e.serverId, n), ...r]), o = s.status === "fulfilled" ? s.value : null, l = i.flatMap((y) => y.status === "fulfilled" && y.value ? [y.value] : []), f = wa(e.serverId, o, l);
  e.serverName = f?.name || null, e.channelName = f?.channels.find((y) => y.id === e.channelId)?.name || null;
  let h = null;
  return o || (h = `${s.status === "rejected" && s.reason instanceof Error ? s.reason.message : "Server metadata is unavailable."} ${f?.channels.length ? "Using channel links from the open page; hidden or unloaded channels may be missing." : e.channelId ? "Current-channel scanning is still available." : "Open the server page, reload it, and discover its channel links again."}`), { scope: e, server: f, warning: h, apiChannelCount: o?.channels.length || 0, domChannelCount: f?.channels.filter((y) => y.sources?.includes("dom")).length || 0 };
}
async function Fe(t, e) {
  if (t.type === "DISCOVER") return qe(t.url);
  if (t.type === "LIST") {
    const a = (await j()).sort((r, s) => s.createdAt.localeCompare(r.createdAt));
    return Promise.all(a.map(async (r) => ({ job: r, totals: ae(r, await N(r.id)) })));
  }
  if (t.type === "DETAIL") {
    const a = await Be(t.jobId), r = await N(a.id), s = r.some((o) => [o.originalUrl, o.thumbnailUrl].some((l) => l && new URL(l).hostname.endsWith(".kemono.cr"))) ? ["https://*.kemono.cr/*"] : [];
    return { job: t.includeMedia === !1 ? { ...a, channels: a.channels.map((o) => ({ ...o, messageIds: [], pageFingerprints: [], messageCount: o.messageIds.length })) } : a, ...t.includeMedia === !1 ? {} : { media: r }, originalOrigins: s, hasDiscordCdn: r.some((o) => o.discordCdnUrl), totals: ae(a, r) };
  }
  if (t.type === "DASHBOARD")
    return await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") }), null;
  if (t.type === "START") {
    if (!["thumbnail", "best", "original"].includes(t.mode)) throw new Error("Invalid quality mode");
    const { scope: a, server: r, warning: s, apiChannelCount: i, domChannelCount: o } = await qe(t.url), l = new URL(t.url).origin, f = !!t.allChannels || !a.channelId && !t.channelIds.length, h = [...new Set(f ? r?.channels.map((u) => u.id) || [] : t.channelIds.length ? t.channelIds.map(X) : a.channelId ? [a.channelId] : [])];
    if (!h.length) throw new Error(s || "No channels were discovered in this server. Open the server page and try Discover channels again.");
    if (h.some((u) => u !== a.channelId && !r?.channels.some((w) => w.id === u))) throw new Error("Selected channel was not discovered in this server");
    for (const u of await j(["scanning", "downloading"]))
      u.resumeStatus = u.status, u.status = "paused", await E(z(u));
    const y = {
      service: "discord",
      id: crypto.randomUUID(),
      serverId: a.serverId,
      serverName: a.serverName,
      mode: t.mode,
      tryOriginal: !!t.tryOriginal,
      channels: h.map((u) => {
        const w = r?.channels.find((m) => m.id === u);
        return { channelId: u, channelName: w?.name || null, postCount: w?.postCount ?? null, offset: 0, pages: 0, messageIds: [], pageFingerprints: [], coverage: "pending", terminal: null, failures: [], attempts: 0, nextAttemptAt: 0, error: null, domMessages: 0 };
      }),
      status: "scanning",
      resumeStatus: "scanning",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      warnings: s ? [s] : [],
      autoManifest: !1,
      manifestState: "pending",
      manifestDownloads: [],
      apiNextAt: 0,
      mediaNextAt: 0,
      scope: f ? "server" : h.length === 1 ? "channel" : "selected",
      sourceUrl: `${l}/discord/server/${a.serverId}${a.channelId ? "/" + a.channelId : ""}`,
      discoveredChannelCount: r?.channels.length || h.length,
      channelDiscovery: i ? o ? "api+dom" : "api" : o ? "dom" : "current-channel",
      destination: { kind: "zip" }
    };
    await E(y);
    const c = await chrome.tabs.query({ url: `${l}/discord/server/*` });
    for (const u of c) u.id && Ot(u.url || "")?.serverId === y.serverId && new URL(u.url).origin === l && chrome.tabs.sendMessage(u.id, { type: "SCAN_DOM" }).catch(() => {
    });
    return { jobId: y.id };
  }
  if (t.type === "DOM") {
    const a = Se(t.url), r = Se(e.tab?.url || "");
    if (!a || !r || r.channelId !== a.channelId || r.serverId !== a.serverId || new URL(t.url).origin !== new URL(e.tab.url).origin) return null;
    const s = new URL(t.url).origin;
    for (const i of await j()) {
      if (i.serverId !== a.serverId || new URL(i.sourceUrl || Z[0]).origin !== s || !["scanning", "indexed", "paused"].includes(i.status)) continue;
      const o = i.channels.find((f) => f.channelId === a.channelId);
      if (!o) continue;
      const l = t.records.slice(0, 1e4).filter((f) => f.serverId === a.serverId && f.channelId === a.channelId).map((f) => ({
        ...f,
        jobId: i.id,
        service: i.service,
        serverName: i.serverName,
        channelName: o.channelName,
        originalUrl: $(f.originalUrl),
        discordCdnUrl: $(f.discordCdnUrl),
        thumbnailUrl: $(f.thumbnailUrl)
      }));
      o.domMessages = Math.max(o.domMessages, t.messageCount), await Bt(z(i), Ke(await N(i.id), l));
    }
    return null;
  }
  const n = await Be(t.jobId);
  if (n.archive?.state === "saving" && (t.type === "DESTINATION" || t.type === "ACTION" && ["download", "retry"].includes(t.action))) throw new Error("Finish or cancel the current ZIP save before starting another");
  if (t.type === "DESTINATION") {
    if (n.status === "downloading") throw new Error("Pause the job before choosing its save destination");
    const a = await N(n.id);
    if (t.kind === "folder") {
      const r = t.directoryId || n.id, s = await wt(r);
      for (const i of a)
        ["downloaded", "staged"].includes(i.status) && (!i.savedPath || !i.sha256 || i.bytes === null || !await $e(r, i.savedPath, i.sha256, i.bytes)) || i.status === "transferring" ? (i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await C(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = n.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null) : i.status === "staged" && (i.status = "downloaded");
      for (const i of n.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await C(i.blobUrl);
      n.destination = { kind: "folder", name: s.name, ...t.directoryId ? { directoryId: r } : {} }, n.manifestState = "pending", n.manifestPaths = [], n.manifestDownloads = [], n.archive = void 0;
    } else if (t.kind === "zip") {
      const r = a.filter((i) => ["downloaded", "staged", "transferring"].includes(i.status)), s = new Set((await U("zip-matches", { jobId: n.id, records: r })).ids);
      for (const i of r)
        i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await C(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = s.has(i.id) ? "staged" : n.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null;
      for (const i of n.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await C(i.blobUrl);
      n.destination = { kind: "zip" }, n.archive = Tt(n), n.manifestState = "pending", n.manifestDownloads = [], n.manifestPaths = [];
    } else if (t.kind === "browser") {
      if (a.some((r) => ["downloaded", "staged"].includes(r.status)) && n.destination?.kind !== "browser" && n.destination) throw new Error("Create a new job to switch collected files to individual Browser downloads.");
      n.destination = { kind: "browser" }, n.archive = void 0;
    } else throw new Error("Unsupported save destination");
    return n.destinationError = null, await Bt(z(n), a), null;
  }
  if (t.type === "EXPORT") {
    const a = await N(n.id), r = Mt(n), s = n.id.slice(0, 8), i = `${r}/${t.format === "csv" ? "links" : t.format === "failures" ? "failures" : "manifest"}-${s}.${t.format === "csv" ? "csv" : "json"}`, o = t.format === "csv" ? ka(a) : pt(n, t.format === "failures" ? a.filter((f) => f.status === "failed" || f.status === "skipped") : a), l = t.format === "csv" ? "text/csv;charset=utf-8" : "application/json";
    return n.destination?.kind === "folder" ? await U("save-text", { jobId: V(n), path: i, text: o, mime: l }) : await ce(o, i, l), null;
  }
  if (t.action === "pause") {
    ["scanning", "downloading"].includes(n.status) && (n.resumeStatus = n.status, n.status = "paused");
    for (const a of await N(n.id)) a.status === "transferring" && a.downloadId !== null && await chrome.downloads.pause(a.downloadId).catch(() => {
    });
    n.destination?.kind === "zip" && n.archive?.state === "building" && (await U("zip-stop", { jobId: n.id }), n.archive.state = "pending");
  } else if (t.action === "cancel") {
    n.status = "cancelled", n.destination?.kind === "zip" && (await U("zip-stop", { jobId: n.id }), n.archive?.state === "saving" && n.archive.downloadId !== null && await chrome.downloads.cancel(n.archive.downloadId).catch(() => {
    }), n.archive?.state === "building" && (n.archive.state = "pending"));
    for (const a of await N(n.id))
      a.status === "transferring" && a.downloadId !== null && await chrome.downloads.cancel(a.downloadId).catch(() => {
      }), ["queued", "transferring"].includes(a.status) && (a.status = "skipped", a.errorMessage = "Cancelled by user", await C(a.blobUrl), a.blobUrl = null, await F(a));
  } else if (t.action === "resume") {
    if (n.status !== "paused") throw new Error("Only paused jobs can be resumed");
    n.destination?.kind === "folder" && n.resumeStatus === "downloading" && await wt(V(n)), n.destinationError = null, n.status = n.resumeStatus;
    for (const a of await N(n.id)) a.status === "transferring" && a.downloadId !== null && await chrome.downloads.resume(a.downloadId).catch(() => {
    });
  } else if (t.action === "retry") {
    for (const a of n.channels) a.coverage === "incomplete" && (a.coverage = "pending", a.attempts = 0, a.error = null, a.nextAttemptAt = 0);
    for (const a of await N(n.id)) (a.status === "failed" || a.status === "skipped") && (a.status = n.autoManifest ? "queued" : "discovered", a.attempts = 0, a.nextAttemptAt = 0, a.errorMessage = null, a.candidateFailures = [], await F(a));
    if (n.status = n.channels.some((a) => a.coverage !== "complete") ? "scanning" : n.autoManifest ? "downloading" : "indexed", n.manifestState = "pending", n.destination?.kind === "zip") {
      if (n.archive?.cacheCleared) {
        const a = await N(n.id, ["downloaded", "staged"]);
        for (const r of a)
          r.status = "queued", r.attempts = 0, r.nextAttemptAt = 0;
        await xe(a);
      }
      n.archive = Tt(n);
    }
  } else if (t.action === "save-zip") {
    if (n.destination?.kind !== "zip") throw new Error("Select ZIP output first");
    return await Xn(n), null;
  } else {
    if (t.action === "clear-cache")
      return await be(n.id), null;
    if (t.action === "download") {
      if (n.status === "scanning" || n.channels.some((i) => ["pending", "scanning"].includes(i.coverage))) throw new Error("Pause or finish the scan before downloading the indexed results");
      if (!n.destination) throw new Error("Choose a save folder or explicitly select Browser downloads before starting the batch");
      n.destination.kind === "folder" && await wt(V(n));
      const a = await N(n.id);
      let r;
      n.destination.kind === "zip" && (r = new Set((await U("zip-matches", { jobId: n.id, records: a.filter((i) => ["downloaded", "staged"].includes(i.status)) })).ids), n.archive = Tt(n));
      const s = [];
      for (const i of a) (i.status === "discovered" || r && ["staged", "downloaded"].includes(i.status) && !r.has(i.id)) && (i.status = "queued", i.attempts = 0, i.nextAttemptAt = 0, s.push(i));
      await xe(s), n.status = "downloading", n.autoManifest = !0, n.manifestState = "pending", n.destinationError = null;
    }
  }
  return await E(z(n)), null;
}
async function fs(t) {
  if (!t.channels.some((n) => ["pending", "scanning"].includes(n.coverage))) {
    t.status = t.autoManifest ? "downloading" : "indexed", await E(z(t));
    return;
  }
  if (Date.now() < t.apiNextAt) return;
  const e = t.channels.find((n) => ["pending", "scanning"].includes(n.coverage) && n.nextAttemptAt <= Date.now());
  if (!e) {
    t.channels.some((n) => ["pending", "scanning"].includes(n.coverage)) || (t.status = t.autoManifest ? "downloading" : "indexed", await E(z(t)));
    return;
  }
  try {
    const n = new URL(t.sourceUrl || Z[0]).origin, a = await Jn.channel(e.channelId, e.offset, n), r = ya(e, a), s = ma(a, { serverId: t.serverId, serverName: t.serverName, channelId: e.channelId, channelName: e.channelName, service: t.service }, t.id, n);
    if (t.autoManifest) for (const i of s) i.status = "queued";
    t.channels[t.channels.indexOf(e)] = r, r.coverage === "complete" && r.postCount !== null && r.postCount !== r.messageIds.length && t.warnings.push(`Channel ${r.channelId}: metadata post_count=${r.postCount}; API unique messages=${r.messageIds.length}.`), t.apiNextAt = Date.now() + 1100, await Bt(z(t), Ke(await N(t.id), s));
  } catch (n) {
    e.attempts++, e.error = n instanceof Error ? n.message : "Page scan failed", e.failures.push({ offset: e.offset, reason: e.error, at: (/* @__PURE__ */ new Date()).toISOString() });
    const a = n instanceof O && n.retryable;
    if (n instanceof O && n.status === 429 && (t.apiNextAt = Date.now() + ct(e.attempts, n.retryAfterMs)), a && e.attempts < yt) {
      const r = ct(e.attempts, n.retryAfterMs);
      e.nextAttemptAt = Date.now() + r, t.apiNextAt = e.nextAttemptAt;
    } else e.coverage = "incomplete";
    await E(z(t));
  }
}
async function ps(t, e) {
  t.manifestState = "saving", t.manifestDownloads = [], await E(z(t));
  try {
    if (t.destination?.kind === "folder") {
      t.manifestPaths = [];
      for (const s of t.channels) {
        const i = `${ne({ ...t, channelId: s.channelId, channelName: s.channelName })}/channel-manifest.json`;
        await U("save-text", { jobId: V(t), path: i, text: pt(t, e, s.channelId), overwrite: !0 }), t.manifestPaths.push(i), await E(t);
      }
      const r = `${Mt(t)}/manifest.json`;
      await U("save-text", { jobId: V(t), path: r, text: pt(t, e), overwrite: !0 }), t.manifestPaths.push(r), t.manifestState = "saved", await E(z(t));
      return;
    }
    for (const r of t.channels) {
      const s = `${ne({ ...t, channelId: r.channelId, channelName: r.channelName })}/channel-manifest.json`, i = await ce(pt(t, e, r.channelId), s, "application/json", !0);
      t.manifestDownloads.push({ ...i, path: s, state: "in_progress" }), await E(t);
    }
    const n = `${Mt(t)}/manifest.json`, a = await ce(pt(t, e), n, "application/json", !0);
    t.manifestDownloads.push({ ...a, path: n, state: "in_progress" }), await E(t);
  } catch (n) {
    n instanceof J ? (t.manifestState = "pending", await Vt(t, n)) : (t.manifestState = "failed", t.warnings.push("One or more manifest saves failed. Use Export JSON to save the current state."), await E(z(t)));
  }
}
async function Vt(t, e) {
  t.resumeStatus = "downloading", t.status = "paused", t.destinationError = e.message, await E(z(t));
}
async function hs() {
  const t = await j(["scanning", "downloading"]), e = Math.max(0, ...t.map((a) => a.apiNextAt)), n = Math.max(0, ...t.map((a) => a.mediaNextAt));
  for (const a of t) {
    if (a.status === "scanning") {
      (Date.now() >= e || a.channels.every((o) => !["pending", "scanning"].includes(o.coverage))) && await fs(a);
      return;
    }
    if (a.status !== "downloading") continue;
    if (a.destination?.kind === "folder")
      try {
        await wt(V(a));
      } catch (o) {
        await Vt(a, o instanceof Error ? o : new J());
        return;
      }
    const r = await N(a.id);
    for (const o of r) o.status === "transferring" && (o.downloadId !== null || ["folder", "zip"].includes(a.destination?.kind || "")) && await ge(o, !0, a);
    const s = r.filter((o) => o.status === "transferring").length, i = r.filter((o) => o.status === "queued" && o.nextAttemptAt <= Date.now()).slice(0, Math.max(0, 2 - s));
    if (i.length && Date.now() >= n) {
      const o = await Promise.allSettled(i.map((h) => cs(h, a))), l = o.find((h) => h.status === "rejected");
      if (l?.status === "rejected") {
        if (l.reason instanceof J || l.reason instanceof Ut) {
          await Vt(a, l.reason);
          return;
        }
        throw l.reason;
      }
      const f = o.flatMap((h) => h.status === "fulfilled" ? [h.value] : []);
      a.mediaNextAt = Date.now() + Math.max(a.destination?.kind === "zip" ? 250 : 1100, ...f), await E(a);
    }
    if (!r.some((o) => o.status === "queued" || o.status === "transferring")) {
      if (a.destination?.kind === "zip") {
        await us(a, r);
        return;
      }
      a.status = "finished", await E(z(a)), a.autoManifest && a.manifestState === "pending" && await ps(a, r);
    }
    if (a.destination?.kind === "zip") {
      const o = r.filter((l) => l.status === "queued");
      if (o.length) {
        const l = Math.max(n, a.mediaNextAt, Math.min(...o.map((f) => f.nextAttemptAt)));
        return Math.max(100, Math.min(1200, l - Date.now()));
      }
    }
    return;
  }
}
async function ws() {
  const t = await Promise.all([j(["downloading", "paused"]), Ia(), je()]), e = new Map(t.flat().map((n) => [n.id, n]));
  for (const n of e.values()) {
    n.destination?.kind === "zip" && await Vn(n, !0);
    try {
      for (const a of await N(n.id, ["transferring"])) await ge(a, !0, n);
    } catch (a) {
      if (!(a instanceof J || a instanceof Ut)) throw a;
      n.status === "downloading" && await Vt(n, a);
    }
    if (n.manifestState === "saving") {
      if (n.destination?.kind === "zip") continue;
      if (n.destination?.kind === "folder") {
        n.manifestState = "pending", n.status === "finished" && (n.status = "downloading"), await E(n);
        continue;
      }
      for (const a of n.manifestDownloads) {
        const [r] = await chrome.downloads.search({ id: a.id });
        a.state = r?.state === "complete" ? "complete" : r?.state === "in_progress" ? "in_progress" : "interrupted";
      }
      n.manifestDownloads.length !== n.channels.length + 1 ? (n.manifestState = "pending", n.status === "finished" && (n.status = "downloading")) : n.manifestDownloads.every((a) => a.state === "complete") ? n.manifestState = "saved" : n.manifestDownloads.some((a) => a.state === "interrupted") && (n.manifestState = "failed"), await E(n);
    }
  }
}
async function ms(t) {
  if (!t.state || !["complete", "interrupted"].includes(t.state.current || "")) return;
  for (const n of await Sa(t.id)) n.destination?.kind === "zip" && await Vn(n);
  for (const n of await xa(t.id)) n.status === "transferring" && await ge(n);
  for (const n of await je()) {
    const a = n.manifestDownloads.find((r) => r.id === t.id);
    a && (a.state = t.state.current === "complete" ? "complete" : "interrupted", await C(a.blobUrl), n.manifestDownloads.length === n.channels.length + 1 && n.manifestDownloads.every((r) => r.state === "complete") && (n.manifestState = "saved"), a.state === "interrupted" && (n.manifestState = "failed"), await E(z(n)));
  }
  const [e] = await chrome.downloads.search({ id: t.id });
  e?.url.startsWith(`blob:chrome-extension://${chrome.runtime.id}/`) && await C(e.url);
}
function Et(t) {
  try {
    const e = new URL(t);
    return Z.includes(e.origin) && !e.username && !e.password;
  } catch {
    return !1;
  }
}
function le(t) {
  if (!Et(t)) return null;
  const e = new URL(t), n = /^\/(fanbox|patreon)\/user\/(\d+)(?:\/post\/(\d+))?\/?$/.exec(e.pathname);
  return n ? { origin: e.origin, platform: n[1], creatorId: n[2], postId: n[3] || null } : null;
}
function He(t) {
  return `${t.origin}/${t.platform}/user/${t.creatorId}${t.postId ? `/post/${t.postId}` : ""}`;
}
class gs extends Je {
  validate(e, n) {
    const a = e;
    if (!a || typeof a != "object" || typeof a.id != "string" || !/^\d+$/.test(a.id) || a.user !== n.creatorId || a.service !== n.platform) throw new O("Post response belongs to a different creator or service.", 422);
    if (a.attachments != null && (!Array.isArray(a.attachments) || a.attachments.some((r) => !r || typeof r != "object"))) throw new O("Invalid post attachment list.", 422);
    if (a.content != null && typeof a.content != "string") throw new O("Invalid post text.", 422);
    return a;
  }
  async profile(e) {
    const n = await this.json(`/${e.platform}/user/${e.creatorId}/profile`, e.origin);
    return n && n.id === e.creatorId && typeof n.name == "string" ? n.name : e.creatorId;
  }
  async total(e) {
    const n = await fetch(`${e.origin}/${e.platform}/user/${e.creatorId}`, { headers: { Accept: "text/html" }, credentials: "omit", redirect: "error", signal: AbortSignal.timeout(1e4) });
    if (!n.ok) return null;
    const a = /Showing\s+[\d,]+\s*[-–]\s*[\d,]+\s+of\s+([\d,]+)/i.exec(await n.text()), r = a ? Number(a[1].replaceAll(",", "")) : NaN;
    return Number.isSafeInteger(r) && r >= 0 ? r : null;
  }
  async posts(e, n) {
    const a = `/${e.platform}/user/${e.creatorId}`;
    let r;
    try {
      r = await this.json(`${a}${e.origin === "https://kemono.cr" ? "/posts" : ""}?o=${n}`, e.origin);
    } catch (i) {
      if (!(i instanceof O) || i.status !== 404) throw i;
      r = await this.json(`${a}${e.origin === "https://kemono.cr" ? "" : "/posts"}?o=${n}`, e.origin);
    }
    const s = Array.isArray(r) ? r : r?.posts;
    if (!Array.isArray(s)) throw new O("Post list is not an array.", 422);
    return s.map((i) => this.validate(i, e));
  }
  async post(e) {
    const n = await this.json(`/${e.platform}/user/${e.creatorId}/post/${e.postId}`, e.origin), a = this.validate(n?.post || n, e);
    if (a.id !== e.postId) throw new O("The API returned a different post.", 422);
    return a;
  }
}
const Gn = /^\/[0-9a-f]{2}\/[0-9a-f]{2}\/[0-9a-f]{64}(?:\.[a-z0-9_-]{1,16})?$/i, Ze = /\.(png|jpe?g|webp|gif|avif|bmp|tiff?|svg|heic|heif|jxl)$/i;
function Ct(t) {
  if (typeof t != "string") return null;
  try {
    const e = new URL(t);
    if (e.protocol !== "https:" || e.port || e.username || e.password) return null;
    const n = Nt(e.href) ? "/thumbnail/data" : "/data";
    return !ee(e.hostname) || !e.pathname.startsWith(n + "/") || !Gn.test(e.pathname.slice(n.length)) ? null : (e.hash = "", e.href);
  } catch {
    return null;
  }
}
function ys(t, e, n) {
  if (typeof t != "string" || !t) return null;
  try {
    const a = new URL(t.includes("://") ? t : `https://${t}`);
    a.pathname === "/" && !a.search && !a.hash && (a.pathname = `/data${e}`, a.search = `?f=${encodeURIComponent(n)}`);
    const r = Ct(a.href);
    return r && new URL(r).pathname === `/data${e}` ? r : null;
  } catch {
    return null;
  }
}
function We(t, e, n, a) {
  const r = t.path;
  if (typeof r != "string" || !Gn.test(r)) return null;
  const s = typeof t.name == "string" && t.name ? t.name : r.split("/").at(-1), i = Ze.test(r) || Ze.test(s) ? "image" : "file", o = new URL(e.origin).hostname, l = Number.isSafeInteger(t.node) && t.node >= 1 ? t.node : null, f = l ? `n${l}.${o}` : o === "pawchive.pw" ? "file.pawchive.pw" : o, h = n === !1 ? null : ys(t.server, r, s) || Ct(`https://${f}/data${r}?f=${encodeURIComponent(s)}`);
  return { id: `${a}:${r}`, name: s, path: r, kind: i, thumbnailUrl: i === "image" ? Ct(`https://img.${o}/thumbnail/data${r}`) : null, originalUrl: h };
}
function Ye(t, e) {
  const n = typeof t.has_full == "boolean" ? t.has_full : null, a = [];
  for (const r of [t.file, ...t.attachments || []]) {
    if (!r) continue;
    const s = We(r, e, n, a.length + 1);
    s && !a.some((i) => i.path === s.path) && a.push(s);
  }
  for (const r of (t.content || "").matchAll(/(?:src|href)=["']([^"']+)["']/gi)) {
    let s = null;
    try {
      s = Ct(new URL(r[1].replaceAll("&amp;", "&"), e.origin).href);
    } catch {
    }
    if (!s) continue;
    const i = new URL(s).pathname.replace(/^\/(?:thumbnail\/)?data/, ""), o = a.find((f) => f.path === i);
    if (o) {
      Nt(s) ? o.thumbnailUrl = s : n !== !1 && (o.originalUrl = s);
      continue;
    }
    const l = We({ path: i }, e, n, a.length + 1);
    l && (Nt(s) ? l.thumbnailUrl = s : l.originalUrl = n === !1 ? null : s, a.push(l));
  }
  return { id: t.id, title: t.title || `Post ${t.id}`, content: t.content || "", published: t.published || null, hasFull: n, media: a, embed: t.embed || null };
}
function Kn(t) {
  return `${t.source.platform}_${t.source.creatorId}_${nt(t.creatorName, "creator")}`;
}
function jn(t) {
  const e = ot(t.path), n = e.indexOf(t.quality);
  if (n < 0 || e.length !== n + 3 || !Qn(e[n + 1], t.postId)) throw new Error("Unsafe post archive path");
  return e.slice(n).join("/");
}
function Qn(t, e) {
  return t.startsWith(e + "_") || /^(?:\d{4}-\d{2}-\d{2}|unknown-date)_/.test(t) && t.slice(t.indexOf("_") + 1).startsWith(e + "_");
}
function bs(t) {
  return `${Ge(t.published)?.slice(0, 10) || "unknown-date"}_${t.id}_${nt(t.title, "post")}`;
}
function _n(t, e) {
  if (t.kind !== "image" || t.quality !== "full res" || !t.fallbackUrl || !Ct(t.fallbackUrl) || !Nt(t.fallbackUrl)) return null;
  const n = ot(t.path), a = n.indexOf("full res");
  return jn(t), n[a] = "thumbnail", { ...t, id: t.id.replace(":full res:", ":thumbnail:"), quality: "thumbnail", url: t.fallbackUrl, path: n.join("/"), status: "queued", bytes: null, attempts: 0, nextAt: 0, error: null, synced: !1, fallback: !0, fallbackReason: e, fallbackChecked: !1 };
}
function $n(t) {
  const e = Kn(t);
  return { ...t, tasks: t.tasks.map((n) => ({ ...n, path: `${e}/${jn(n)}` })) };
}
function vs(t) {
  const e = t.lastIndexOf("."), n = e >= 0 && /^[a-z0-9_-]{1,16}$/i.test(t.slice(e + 1)) ? t.slice(e) : "";
  return nt(n ? t.slice(0, e) : t, "attachment") + n;
}
function Is(t, e) {
  const n = [], a = e.quality === "both" ? ["thumbnail", "full res"] : [e.quality];
  for (const r of t.posts) for (const s of a) {
    const i = `${t.destination?.kind === "folder" ? "" : Kn(t) + "/"}${s}/${bs(r)}`;
    for (const [o, l] of r.media.entries()) {
      if (l.kind === "image" ? !e.images : !e.files || s === "thumbnail") continue;
      const f = s === "thumbnail" ? l.thumbnailUrl : l.originalUrl, h = { id: `${r.id}:${s}:${l.id}`, postId: r.id, quality: s, kind: l.kind, url: f, path: `${i}/${String(o + 1).padStart(3, "0")}_${vs(l.name)}`, status: f ? "queued" : "unavailable", bytes: null, attempts: 0, nextAt: 0, error: f ? null : "Full-resolution file was not archived." };
      e.quality === "full res" && e.fallbackToThumbnail && l.kind === "image" && l.thumbnailUrl && (h.fallbackUrl = l.thumbnailUrl), n.push(f ? h : _n(h, h.error) || h);
    }
    e.text && n.push({ id: `${r.id}:${s}:text`, postId: r.id, quality: s, kind: "text", url: null, path: `${i}/post.txt`, status: "queued", bytes: null, attempts: 0, nextAt: 0, error: null });
  }
  return n;
}
const rt = (t) => {
  if (!t || typeof t != "object" || Array.isArray(t)) throw new Error("Invalid post sync JSON.");
  return t;
};
function ta(t) {
  return t.replace(/^(\d+:(?:thumbnail|full res):)\d+:(\/)/, "$1$2");
}
function ea(t) {
  const e = rt(t);
  if (!["thumbnail", "full res", "both"].includes(String(e.quality)) || ["images", "files", "text"].some((n) => typeof e[n] != "boolean")) throw new Error("Invalid content selection.");
  if (e.fallbackToThumbnail !== void 0 && typeof e.fallbackToThumbnail != "boolean") throw new Error("Invalid thumbnail fallback selection.");
  return { quality: e.quality, images: e.images, files: e.files, text: e.text, ...e.fallbackToThumbnail !== void 0 ? { fallbackToThumbnail: e.fallbackToThumbnail } : {} };
}
function Ie(t, e) {
  if (t.source.origin !== e.origin || t.source.platform !== e.platform || t.source.creatorId !== e.creatorId) throw new Error("This JSON belongs to a different website, service, or creator. Open that creator’s profile to sync it.");
}
function Ss(t, e, n = !1) {
  const a = rt(t);
  if (typeof a.id != "string" || a.id.length > 500 || !["thumbnail", "full res"].includes(String(a.quality)) || !["image", "file", "text"].includes(String(a.kind)) || typeof a.path != "string" || a.path.length > 2e3 || !Number.isSafeInteger(a.bytes) || a.bytes <= 0) throw new Error("Invalid downloaded file in sync JSON.");
  const r = ta(a.id);
  if (!r.startsWith(`${e}:${a.quality}:`) || (a.kind === "text" ? r !== `${e}:${a.quality}:text` : !/^\/[a-f0-9]{2}\/[a-f0-9]{2}\/[a-f0-9]{64}(?:\.[a-z0-9_-]{1,16})?$/i.test(r.slice(`${e}:${a.quality}:`.length)))) throw new Error("Invalid downloaded file ID in sync JSON.");
  let s = a.path;
  if (n) {
    const o = ot(s), l = o.findIndex((f) => f === a.quality);
    if (l < 0) throw new Error("Invalid legacy archive path.");
    s = o.slice(l).join("/");
  }
  const i = ot(s);
  if (i.length !== 3 || i[0] !== a.quality || !Qn(i[1], e)) throw new Error("Downloaded paths must stay inside this post’s quality folder.");
  return { id: r, quality: a.quality, kind: a.kind, path: s, bytes: a.bytes };
}
function As(t, e) {
  const n = rt(t), a = n.schemaVersion === 1 && typeof n.sourceUrl == "string" && Array.isArray(n.files) && Array.isArray(n.posts);
  let r;
  if (a) r = le(n.sourceUrl);
  else {
    if (n.format !== "archive-ripper-post-sync" || n.version !== 1) throw new Error("Choose sync.json or a post archive manifest.json. A failures.json is not a download history.");
    const f = rt(n.source);
    if (r = le(`${f.origin}/${f.platform}/user/${f.creatorId}`), !r || f.origin !== r.origin || f.platform !== r.platform || f.creatorId !== r.creatorId) throw new Error("Invalid creator in sync JSON.");
  }
  if (!r) throw new Error("Invalid creator in sync JSON.");
  const s = { format: "archive-ripper-post-sync", version: 1, source: { origin: r.origin, platform: r.platform, creatorId: r.creatorId }, creatorName: String(a ? n.creator || r.creatorId : n.creatorName || r.creatorId).slice(0, 300), updatedAt: (/* @__PURE__ */ new Date()).toISOString(), selection: ea(n.selection), posts: [] };
  if (Ie(s, e), !Array.isArray(n.posts) || n.posts.length > 1e5) throw new Error("Invalid post list in sync JSON.");
  let i = 0;
  const o = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Map();
  if (a) for (const f of n.files) {
    const h = rt(f);
    if (!["staged", "downloaded"].includes(String(h.status))) continue;
    const y = String(h.postId), c = l.get(y) || [];
    c.push(h), l.set(y, c);
  }
  for (const f of n.posts) {
    const h = rt(f);
    if (typeof h.id != "string" || !/^\d{1,40}$/.test(h.id) || o.has(h.id)) throw new Error("Invalid or duplicate post ID in sync JSON.");
    o.add(h.id);
    const y = a ? l.get(h.id) || [] : h.files;
    if (!Array.isArray(y) || (i += y.length) > 2e5) throw new Error("Invalid file list in sync JSON.");
    const c = y.map((u) => Ss(u, h.id, a));
    if (new Set(c.map((u) => u.id)).size !== c.length) throw new Error("Duplicate file ID in sync JSON.");
    c.length && s.posts.push({ id: h.id, title: String(h.title || `Post ${h.id}`).slice(0, 500), files: c });
  }
  return s;
}
function na(t) {
  const { origin: e, platform: n, creatorId: a } = t.source;
  return { format: "archive-ripper-post-sync", version: 1, source: { origin: e, platform: n, creatorId: a }, creatorName: t.creatorName, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), selection: t.selection, posts: [] };
}
function Xe(t, e) {
  if (!t) return structuredClone(e);
  Ie(e, { ...t.source });
  const n = structuredClone(t), a = new Map(n.posts.map((r) => [r.id, r]));
  for (const r of e.posts) {
    const s = a.get(r.id);
    if (s) {
      const i = new Map(s.files.map((o) => [o.id, o]));
      for (const o of r.files) i.set(o.id, { ...o });
      s.files = [...i.values()];
    } else {
      const i = structuredClone(r);
      n.posts.push(i), a.set(i.id, i);
    }
  }
  return n.selection = e.selection, n.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), n;
}
function xs(t, e, n) {
  if (!["downloaded", "staged"].includes(e.status) || !e.bytes) return;
  let a = t.posts.find((i) => i.id === e.postId);
  a || (a = { id: e.postId, title: n, files: [] }, t.posts.push(a));
  const r = { id: ta(e.id), quality: e.quality, kind: e.kind, path: e.path, bytes: e.bytes }, s = a.files.findIndex((i) => i.id === r.id);
  s < 0 ? a.files.push(r) : a.files[s] = r, t.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
}
const bt = new gs(), aa = (t, e = 0) => Math.max(e, 2e3 * 2 ** Math.max(0, t - 1));
async function Us(t) {
  const e = await zt(t);
  if (!e) throw new Error("Post archive was not found.");
  return e;
}
function te(t) {
  t.posts = [], t.detailQueue = [], t.tasks = [], t.status = "scanning", t.resumeStatus = "scanning", t.scan = { offset: 0, pages: 0, total: t.source.postId ? 1 : null, complete: !1, error: null, attempts: 0, nextAt: 0, fingerprints: [] }, t.nextAt = 0, t.error = null, t.archive = void 0, t.autoDownload = void 0;
}
async function ra(t) {
  const e = t.autoDownload;
  if (!(!e || !t.scan.complete)) {
    t.autoDownload = void 0, t.status = "ready", await P(t);
    try {
      await ia({ type: "POST_DOWNLOAD", jobId: t.id, selection: e, destination: "folder" });
    } catch (n) {
      t.autoDownload = e, t.status = "paused", t.resumeStatus = "downloading", t.error = n instanceof Error ? n.message : "Could not start sync.", await P(t);
    }
  }
}
async function tt() {
  for (const t of await Jt(["scanning", "downloading"])) {
    t.resumeStatus = t.status, t.status = "paused", await U("post-transfer-stop", { jobId: t.id });
    for (const e of t.tasks) e.status === "transferring" && (e.status = "queued", e.attempts = Math.max(0, e.attempts - 1));
    t.archive?.state === "building" && (await U("zip-stop", { jobId: t.id }), t.archive.state = "pending"), await P(t);
  }
}
function Es(t, e = 100) {
  const { posts: n, tasks: a, sync: r, detailQueue: s, ...i } = t, { fingerprints: o, ...l } = i.scan, f = new Set(r?.posts.map((c) => c.id)), h = /* @__PURE__ */ new Set(), y = {
    synced: 0,
    thumbnails: 0,
    syncPosts: r?.posts.length || 0,
    newPosts: 0,
    posts: n.length,
    discovered: n.length - s.length,
    total: t.scan.total,
    images: 0,
    files: 0,
    fullPosts: 0,
    selected: a.length,
    saved: 0,
    failed: 0,
    retryable: 0,
    processed: 0
  };
  for (const c of n) {
    f.has(c.id) || y.newPosts++, c.hasFull !== !1 && y.fullPosts++;
    for (const u of c.media)
      if (u.kind === "image" ? y.images++ : u.kind === "file" && y.files++, u.originalUrl) {
        const w = new URL(u.originalUrl);
        w.hostname.endsWith(".kemono.cr") && h.add(`${w.origin}/*`);
      }
  }
  for (const c of a) {
    const u = c.status === "staged" || c.status === "downloaded", w = c.status === "downloaded" || t.destination?.kind !== "folder" && c.status === "staged";
    c.synced && y.synced++, c.fallback && u && y.thumbnails++, w && y.saved++, (c.status === "failed" || c.status === "unavailable") && y.failed++, c.status === "failed" && y.retryable++, (w || c.status === "failed" || c.status === "unavailable") && y.processed++;
  }
  return {
    job: { ...i, scan: l },
    originalOrigins: [...h],
    totals: y,
    posts: n.slice(0, Math.min(1e3, Math.max(1, e))).map((c) => ({ id: c.id, title: c.title, files: c.media.length, hasFull: c.hasFull }))
  };
}
async function sa(t) {
  const e = t.archive;
  if (e?.cacheCleared) throw new Error("Temporary ZIP data was cleared. Download again to prepare a new ZIP.");
  if (!e || !["ready", "saved"].includes(e.state)) throw new Error("The ZIP is still being prepared.");
  const n = $n(t);
  if (n.tasks.some((r, s) => r.path !== t.tasks[s].path)) {
    await tt();
    for (const r of await j(["scanning", "downloading"]))
      r.resumeStatus = r.status, r.status = "paused", await E(r);
    await C(e.blobUrl), t.tasks = n.tasks, t.status = "downloading", t.resumeStatus = "downloading", t.error = null, Object.assign(e, { state: "pending", blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null }), await P(t);
    return;
  }
  await C(e.blobUrl);
  const a = await U("zip-open", { jobId: t.id });
  Object.assign(e, a, { state: "saving", downloadId: null, error: null }), await P(t);
  try {
    e.downloadId = await chrome.downloads.download({ url: a.blobUrl, filename: e.filename, conflictAction: "uniquify", saveAs: !0 });
  } catch {
    e.state = "ready", e.error = "Save was cancelled. Choose Save ZIP to try again.", await C(e.blobUrl), e.blobUrl = null;
  }
  await P(t);
}
async function ia(t) {
  if (t.type === "POST_START") {
    const n = le(t.url);
    if (!n) throw new Error("Open a Patreon or Fanbox profile or post on Kemono or Pawchive.");
    await tt();
    for (const s of await j(["scanning", "downloading"]))
      s.resumeStatus = s.status, s.status = "paused", await E(s);
    const a = {
      id: crypto.randomUUID(),
      service: "posts",
      source: n,
      sourceUrl: He(n),
      creatorName: n.creatorId,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      status: "scanning",
      resumeStatus: "scanning",
      selection: { quality: "full res", images: !0, files: !0, text: !0, fallbackToThumbnail: !0 },
      scan: { offset: 0, pages: 0, total: n.postId ? 1 : Number.isSafeInteger(t.expectedPosts) && t.expectedPosts > 0 ? t.expectedPosts : null, complete: !1, error: null, attempts: 0, nextAt: 0, fingerprints: [] },
      posts: [],
      detailQueue: [],
      tasks: [],
      archive: void 0,
      destination: { kind: "folder", directoryId: "", name: "" },
      nextAt: 0,
      error: null
    }, r = await Promise.allSettled([bt.profile(n), a.scan.total === null ? bt.total(n) : Promise.resolve(a.scan.total)]);
    return r[0].status === "fulfilled" && (a.creatorName = r[0].value), r[1].status === "fulfilled" && (a.scan.total = r[1].value), await P(a), { jobId: a.id };
  }
  const e = await Us(t.jobId);
  if (t.type === "POST_DETAIL") return Es(e, t.limit);
  if (e.archive?.state === "saving" && !(t.type === "POST_ACTION" && t.action === "cancel")) throw new Error("Finish or cancel the current ZIP save first.");
  if (t.type === "POST_FOLDER") {
    if (e.status === "downloading") throw new Error("Pause this download before changing its folder.");
    if (typeof t.directoryId != "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(t.directoryId)) throw new Error("Invalid folder selection.");
    const n = await U("post-folder-read", { directoryId: t.directoryId, postJob: e });
    e.destination = { kind: "folder", directoryId: t.directoryId, name: String(t.name).slice(0, 300) }, await C(e.archive?.blobUrl || null), e.archive = void 0, e.tasks = [], e.autoDownload = void 0, e.scan.complete && (e.status = "ready"), n && (e.sync = Xe(e.sync, n), e.tasks.length || (e.selection = n.selection));
  } else if (t.type === "POST_SYNC_IMPORT") {
    if (e.status === "downloading") throw new Error("Pause this download before importing a sync JSON.");
    const n = As(t.json, e.source);
    await tt(), e.sync = Xe(e.sync, n), e.selection = n.selection, e.source.postId = null, e.sourceUrl = He(e.source), await C(e.archive?.blobUrl || null), te(e), e.destination?.kind !== "folder" && (e.destination = { kind: "folder", directoryId: "", name: "" });
  } else if (t.type === "POST_DOWNLOAD") {
    if (!e.scan.complete || ["scanning", "downloading"].includes(e.status)) throw new Error("Finish scanning before starting another download.");
    const n = ea(t.selection), a = t.destination || e.destination?.kind || "zip";
    if (!["folder", "zip"].includes(a)) throw new Error("Invalid download destination.");
    if (a === "zip" && e.sync) throw new Error("Sync extends an existing folder. Choose Save to folder.");
    if (a === "folder" && (e.destination?.kind !== "folder" || !e.destination.directoryId)) throw new Error("Choose the creator folder before saving. For an older ZIP, choose its extracted creator folder containing thumbnail or full res.");
    if (a === "folder" && e.status === "finished" && !e.source.postId)
      return te(e), e.autoDownload = n, await P(e), null;
    a === "zip" && (e.destination = { kind: "zip" }), e.autoDownload = void 0;
    const r = new Map(e.tasks.map((s) => [s.id, s]));
    if (e.tasks = Is(e, n), !e.tasks.length) throw new Error("Choose at least one available content type.");
    for (const s of e.tasks) {
      const i = r.get(s.id);
      i && ["staged", "downloaded"].includes(i.status) && await U("post-cached", { jobId: e.id, task: i }) && (Object.assign(s, { status: "staged", bytes: i.bytes }), s.kind === "image" && (s.path = s.path.replace(/\.[^/.]+$/, i.path.slice(i.path.lastIndexOf(".")))));
    }
    if (a === "folder") {
      const s = await U("post-folder-check", { postJob: e });
      e.sync = s.sync || na(e);
      const i = new Map(s.files.map((o) => [o.id, o]));
      for (const o of e.tasks) {
        const l = i.get(o.id);
        l && Object.assign(o, l, { status: "downloaded", synced: !0, error: null }), o.fallback && (o.fallbackChecked = !0);
      }
      e.sync.selection = n;
    }
    e.selection = n, e.status = "downloading", e.resumeStatus = "downloading", e.error = null, e.archive && await C(e.archive.blobUrl), e.archive = a === "zip" ? { state: "pending", filename: `${e.source.platform}_${e.source.creatorId}_${nt(e.creatorName)}${e.source.postId ? "_post-" + e.source.postId : ""}_${e.id.slice(0, 8)}.zip`, blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null } : void 0;
  } else {
    if (t.action === "pause")
      return await tt(), null;
    if (t.action === "rescan") {
      if (["scanning", "downloading"].includes(e.status)) throw new Error("Pause or finish this job before scanning again.");
      await C(e.archive?.blobUrl || null), te(e);
    } else if (t.action === "resume" || t.action === "retry") {
      if (t.action === "resume" && e.status !== "paused") throw new Error("Only paused jobs can be resumed.");
      if (e.error = null, e.scan.error = null, e.scan.attempts = 0, e.scan.nextAt = 0, e.scan.complete && e.autoDownload)
        return await ra(e), null;
      for (const n of e.tasks) n.status === "failed" && (n.status = "queued", n.attempts = 0, n.nextAt = 0, n.error = null);
      if (e.archive?.cacheCleared)
        for (const n of e.tasks) ["downloaded", "staged"].includes(n.status) && (n.status = "queued", n.attempts = 0, n.nextAt = 0, n.bytes = null);
      e.status = e.scan.complete ? e.tasks.length ? "downloading" : "ready" : "scanning", e.archive && e.archive.state !== "pending" && (await C(e.archive.blobUrl), e.archive.blobUrl = null, e.archive.downloadId = null, e.archive.error = null, e.archive.cacheCleared = !1, e.archive.cacheCleanupError = null, await U("zip-stop", { jobId: e.id }), e.archive.state = "pending");
    } else if (t.action === "cancel") {
      await U("post-transfer-stop", { jobId: e.id }), await U("zip-stop", { jobId: e.id });
      for (const n of e.tasks) n.status === "transferring" && (n.status = "queued");
      e.archive?.state === "saving" && e.archive.downloadId !== null && await chrome.downloads.cancel(e.archive.downloadId).catch(() => {
      }), e.archive?.state === "building" && (e.archive.state = "pending"), e.status = "cancelled";
    } else {
      if (t.action === "save-zip")
        return await sa(e), null;
      if (t.action === "clear-cache")
        return await be(e.id), null;
    }
  }
  return await P(e), null;
}
async function Cs(t) {
  try {
    if (t.detailQueue.length) {
      const e = await bt.post({ ...t.source, postId: t.detailQueue[0] }), n = t.posts.findIndex((a) => a.id === e.id);
      t.posts[n] = Ye(e, t.source), t.detailQueue.shift();
    } else {
      const e = t.source.postId ? [await bt.post(t.source)] : await bt.posts(t.source, t.scan.offset), n = e.map((r) => r.id).join(",");
      if (e.length && t.scan.fingerprints.includes(n)) throw new Error("The API repeated a page. Retry to finish this scan.");
      if (t.scan.pages >= 1e4) throw new Error("The profile exceeded the scan page limit.");
      e.length && t.scan.fingerprints.push(n);
      const a = new Set(t.posts.map((r) => r.id));
      for (const r of e) a.has(r.id) || (t.posts.push(Ye(r, t.source)), a.add(r.id), !t.source.postId && (r.detail_fetched === !1 || r.content === void 0 || r.attachments === void 0) && t.detailQueue.push(r.id));
      t.scan.offset += 50, t.scan.pages++, (!e.length || t.source.postId) && (t.scan.complete = !0, t.scan.total = t.posts.length, t.status = "ready");
    }
    t.scan.attempts = 0, t.scan.error = null, t.scan.nextAt = Date.now() + 1e3;
  } catch (e) {
    t.scan.attempts++, t.scan.error = e instanceof Error ? e.message : "Post discovery failed.", e instanceof O && e.retryable && t.scan.attempts < 3 ? t.scan.nextAt = Date.now() + aa(t.scan.attempts, e.retryAfterMs) : (t.status = "paused", t.resumeStatus = "scanning", t.error = t.scan.error);
  }
  await P(t), t.scan.complete && t.autoDownload && await ra(t);
}
async function oa(t) {
  for (const e of t.tasks) if (e.status === "transferring") {
    const n = e.id, a = await U("post-transfer-status", { jobId: t.id, recordId: n });
    if (a?.state === "transferring") continue;
    if (a?.bytes !== void 0)
      e.bytes = a.bytes, e.status = "staged", e.error = null, e.kind === "image" && a.ext && (e.path = e.path.replace(/\.[^/.]+$/, "." + a.ext));
    else {
      e.error = a?.failure || "Transfer interrupted; retrying.";
      const r = !a?.status || a.status === 429 || a.status >= 500;
      if (e.status = r && e.attempts < 3 ? "queued" : "failed", e.nextAt = Date.now() + aa(e.attempts, a?.retryAfterMs), a?.status === 429 && (t.nextAt = Math.max(t.nextAt, e.nextAt)), a?.status === 404 || a?.status === 410) {
        const s = _n(e, e.error);
        s && Object.assign(e, s);
      }
    }
    await P(t), await U("post-transfer-forget", { jobId: t.id, recordId: n });
  }
}
async function ks() {
  const t = await Jt(["scanning", "downloading"]), e = Math.max(0, ...t.map((n) => Math.max(n.nextAt, n.scan.nextAt)));
  for (const n of t) {
    if (n.status === "scanning")
      return Date.now() >= e && await Cs(n), !0;
    if (n.status !== "downloading") continue;
    if (await oa(n), n.destination?.kind === "folder")
      try {
        const i = n.tasks.filter((o) => o.fallback && !o.fallbackChecked && o.status === "queued");
        if (i.length) {
          const o = await U("post-folder-check", { postJob: n });
          n.sync = o.sync || n.sync, n.sync && (n.sync.selection = n.selection);
          const l = new Map(o.files.map((f) => [f.id, f]));
          for (const f of i) {
            const h = l.get(f.id);
            h && Object.assign(f, h, { status: "downloaded", synced: !0, error: null }), f.fallbackChecked = !0;
          }
          await P(n);
        }
        for (const o of n.tasks) if (o.status === "staged") {
          const l = await U("post-folder-write", { postJob: n, recordId: o.id });
          Object.assign(o, l, { status: "downloaded" }), n.sync ||= na(n), Ie(n.sync, n.source), xs(n.sync, o, n.posts.find((f) => f.id === o.postId)?.title || o.postId), await P(n), await U("post-folder-index", { postJob: n }), await U("post-cache-remove", { jobId: n.id, recordId: o.id }).catch(() => {
          });
        }
      } catch (i) {
        await U("post-transfer-stop", { jobId: n.id });
        for (const o of n.tasks) o.status === "transferring" && (o.status = "queued", o.attempts = Math.max(0, o.attempts - 1));
        return n.status = "paused", n.resumeStatus = "downloading", n.error = i instanceof Error ? i.message : "Could not write to the creator folder. Check folder access and free disk space, then Resume.", await P(n), !0;
      }
    const a = n.tasks.filter((i) => i.status === "transferring").length, r = Date.now() >= e ? n.tasks.filter((i) => i.status === "queued" && i.nextAt <= Date.now()).slice(0, Math.max(0, 2 - a)) : [];
    for (const i of r)
      i.status = "transferring", i.attempts++, await P(n), await U("post-transfer-start", { jobId: n.id, task: i, post: n.posts.find((o) => o.id === i.postId), source: n.source });
    if (r.length && (n.nextAt = Date.now() + 400, await P(n)), n.tasks.some((i) => ["queued", "transferring"].includes(i.status))) return !0;
    if (n.destination?.kind === "folder") {
      try {
        await U("post-folder-index", { postJob: n }), n.status = "finished", await U("zip-clear", { jobId: n.id }).catch(() => {
        });
      } catch (i) {
        n.status = "paused", n.error = i instanceof Error ? i.message : "Could not update sync.json. Check folder access, then Resume.";
      }
      return await P(n), !0;
    }
    const s = n.archive;
    if (s.state === "pending")
      n.tasks = $n(n).tasks, await U("post-zip-build-start", { postJob: n }), s.state = "building";
    else if (s.state === "building") {
      const i = await U("zip-build-status", { jobId: n.id });
      if (!i) s.state = "pending";
      else {
        if (Object.assign(s, i), i.state === "ready")
          return n.status = "finished", await P(n), await sa(n), !0;
        i.state === "failed" && (n.status = "finished", n.error = i.error);
      }
    }
    return await P(n), !0;
  }
  return !1;
}
async function ca(t = !1, e) {
  const n = e === void 0 ? await Ea() : await Aa(e), a = new Map(n.map((r) => [r.id, r]));
  if (t) for (const r of await Jt(["downloading"])) a.set(r.id, r);
  for (const r of a.values()) {
    const s = r.archive;
    if (s?.state === "saving") {
      let i;
      if (s.downloadId !== null ? [i] = await chrome.downloads.search({ id: s.downloadId }) : s.blobUrl && (i = (await chrome.downloads.search({ query: [s.filename], limit: 20 })).find((o) => o.url === s.blobUrl)), i?.state === "complete" && i.exists !== !1) {
        s.state = "saved", s.error = null;
        for (const o of r.tasks) o.status === "staged" && (o.status = "downloaded");
      } else if (i?.state === "interrupted" || i?.exists === !1 || !i && t)
        s.state = "ready", s.error = "ZIP saving was interrupted. Choose Save ZIP to retry.";
      else continue;
      await C(s.blobUrl), s.blobUrl = null, await P(r), s.state === "saved" && await ve(r);
    }
    t && r.status === "downloading" && await oa(r);
  }
}
async function Rs(t) {
  if (t.scope !== "all" && t.scope !== "job") throw new Error("Choose which local data to clear.");
  const e = t.scope === "job" ? t.jobId : void 0;
  if (t.scope === "job" && (typeof e != "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(e))) throw new Error("Invalid job to remove.");
  const [n, a] = await Promise.all([j(), Jt()]), r = n.filter((l) => e === void 0 || l.id === e), s = a.filter((l) => e === void 0 || l.id === e);
  if (e !== void 0 && !r.length && !s.length) throw new Error("This job was already removed.");
  const i = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  for (const l of [...r, ...s])
    l.archive?.blobUrl && i.add(l.archive.blobUrl), l.archive?.state === "saving" && l.archive.downloadId !== null && o.add(l.archive.downloadId);
  for (const l of r) {
    l.status = "cancelled", await E(l);
    for (const f of await N(l.id))
      f.blobUrl && i.add(f.blobUrl), f.status === "transferring" && f.downloadId !== null && o.add(f.downloadId);
    for (const f of l.manifestDownloads)
      i.add(f.blobUrl), f.state === "in_progress" && o.add(f.id);
  }
  for (const l of s)
    l.status = "cancelled", l.autoDownload = void 0, await P(l);
  for (const l of o) await chrome.downloads.cancel(l).catch(() => {
  });
  if (await U("local-purge", { ...e !== void 0 ? { jobId: e } : {}, blobUrls: [...i] }), e === void 0) await Ce();
  else {
    const l = /* @__PURE__ */ new Set([
      e,
      ...r.filter((f) => f.destination?.kind === "folder").map(V),
      ...s.flatMap((f) => f.destination?.kind === "folder" && f.destination.directoryId ? [f.destination.directoryId] : [])
    ]);
    for (const f of n) f.id !== e && f.destination?.kind === "folder" && l.delete(V(f));
    for (const f of a) f.id !== e && f.destination?.kind === "folder" && l.delete(f.destination.directoryId);
    await Ce([...l]);
  }
  await Ca(e);
}
function Ps(t) {
  return ["PAGE_CONTEXT", "SERVICE_JOBS", "DETAIL", "POST_DETAIL", "LOCAL_STATUS", "CACHE_LIST"].includes(t.type);
}
async function Ve(t, e) {
  const n = e.id === chrome.runtime.id && e.tab?.url?.split("#")[0] === chrome.runtime.getURL("folder/index.html");
  if (e.tab?.url && !Et(e.tab.url) && !n) throw new Error("Archive Ripper works only on Kemono and Pawchive.");
  if (t.type === "LOCAL_CLEAR")
    return await Rs(t), null;
  if (t.type === "LOCAL_STATUS" || t.type === "LOCAL_SETTINGS") return ls(t);
  if (t.type === "CACHE_LIST") return ds();
  if (t.type === "CACHE_REMOVE")
    return await be(t.jobId), null;
  if (t.type === "PAGE_CONTEXT") {
    const a = e.tab?.id !== void 0 ? await chrome.tabs.get(e.tab.id) : (await chrome.tabs.query({ active: !0, lastFocusedWindow: !0 }))[0];
    if (!a?.id || !Et(a.url || "")) return null;
    try {
      const r = await chrome.tabs.sendMessage(a.id, { type: "PAGE_CONTEXT" });
      if (r?.url === a.url) return r;
    } catch {
    }
    return { url: a.url, expectedPosts: null };
  }
  if (t.type === "SERVICE_JOBS")
    return (await ue()).sort((a, r) => r.createdAt.localeCompare(a.createdAt));
  if (t.type.startsWith("POST_")) {
    if (t.type === "POST_DOWNLOAD" || t.type === "POST_SYNC_IMPORT" || t.type === "POST_ACTION" && ["resume", "retry", "rescan"].includes(t.action)) {
      await tt();
      for (const a of await j(["scanning", "downloading"]))
        a.resumeStatus = a.status, a.status = "paused", await E(a);
    }
    return ia(t);
  }
  if (t.type === "DISCORD_DOWNLOAD") {
    const a = await vt(t.jobId);
    if (!a || !["thumbnail", "full res", "best"].includes(t.quality)) throw new Error("Invalid Discord download.");
    if (!["indexed", "finished"].includes(a.status)) throw new Error("Finish scanning before downloading.");
    return a.mode = t.quality === "full res" ? "original" : t.quality, a.tryOriginal = t.quality === "best", await E(a), await tt(), Fe({ type: "ACTION", jobId: a.id, action: "download" }, e);
  }
  return (t.type === "START" || t.type === "ACTION" && ["download", "resume", "retry"].includes(t.action)) && await tt(), Fe(t, e);
}
class Ds {
  tail = Promise.resolve();
  run(e) {
    const n = this.tail.then(() => e());
    return this.tail = n.catch(() => {
    }), n;
  }
}
class Ts {
  constructor(e) {
    this.tick = e;
  }
  tick;
  timer;
  due = 1 / 0;
  running = !1;
  rerun = !1;
  wake(e = 0) {
    if (this.running) {
      this.rerun = !0;
      return;
    }
    const n = Date.now() + Math.max(0, e);
    this.timer && this.due <= n || (this.timer && clearTimeout(this.timer), this.due = n, this.timer = setTimeout(() => {
      this.timer = void 0, this.due = 1 / 0, this.run();
    }, Math.max(0, e)));
  }
  async run() {
    this.running = !0;
    let e;
    try {
      e = await this.tick();
    } catch {
      e = 5e3;
    } finally {
      this.running = !1, this.rerun ? (this.rerun = !1, this.wake()) : e !== void 0 && this.wake(e);
    }
  }
}
const dt = new Ds(), Rt = new Ts(() => dt.run(async () => {
  const e = await ks() ? 750 : await hs();
  return await va() ? e || 1200 : void 0;
}));
chrome.runtime.onMessage.addListener((t, e, n) => {
  if (e.id !== chrome.runtime.id || t.target === "offscreen") return;
  const a = Ps(t);
  return (a ? Ve(t, e) : dt.run(() => Ve(t, e))).then((s) => n({ ok: !0, data: s }), (s) => n({ ok: !1, error: s instanceof Error ? s.message : "Archive operation failed" })).finally(() => {
    a || Rt.wake();
  }), !0;
});
chrome.downloads.onChanged.addListener((t) => {
  !t.state || !["complete", "interrupted"].includes(t.state.current || "") || dt.run(async () => {
    await ms(t), await ca(!1, t.id);
  }).catch(() => {
  }).finally(() => Rt.wake());
});
chrome.alarms.onAlarm.addListener((t) => {
  t.name === "archive-tick" && Rt.wake(), t.name === "archive-maintenance" && dt.run(() => Yn()).catch(() => {
  });
});
async function la() {
  await ws(), await ca(!0), await Yn();
}
chrome.runtime.onStartup.addListener(() => {
  dt.run(la).catch(() => {
  }).finally(() => Rt.wake());
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
});
chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
chrome.alarms.create("archive-maintenance", { periodInMinutes: 1 });
dt.run(la).catch(() => {
}).finally(() => Rt.wake());
chrome.action.onClicked.addListener((t) => {
  !t.id || !Et(t.url || "") || (async () => {
    try {
      await chrome.tabs.sendMessage(t.id, { type: "TOGGLE_OVERLAY" });
    } catch {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["content.js"] }), await chrome.tabs.sendMessage(t.id, { type: "TOGGLE_OVERLAY" });
    }
  })().catch(() => {
    chrome.action.setTitle({ tabId: t.id, title: "Refresh this page, then open Archive Ripper." });
  });
});
async function da(t) {
  t.id !== void 0 && await (Et(t.url || "") ? chrome.action.enable(t.id) : chrome.action.disable(t.id));
}
chrome.tabs.onUpdated.addListener((t, e, n) => {
  da(n);
});
chrome.action.disable().then(async () => {
  for (const t of await chrome.tabs.query({ url: ["https://kemono.cr/*", "https://pawchive.pw/*"] })) await da(t);
});
