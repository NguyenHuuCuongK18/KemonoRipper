function M(e) {
  try {
    const a = new URL(e), t = /^\/discord\/server\/(\d+)\/(\d+)\/?$/.exec(a.pathname);
    return a.origin !== "https://kemono.cr" || a.username || a.password || !t ? null : { serverId: t[1], channelId: t[2], serverName: null, channelName: null };
  } catch {
    return null;
  }
}
function g(e) {
  if (typeof e != "string" || !/^\d+$/.test(e)) throw new Error("Expected a Discord ID encoded as a string");
  return e;
}
const ne = /^\/([0-9a-f]{2})\/([0-9a-f]{2})\/([0-9a-f]{64})\.(png|jpe?g|webp|gif|avif)$/i;
function T(e) {
  if (typeof e != "string") return null;
  const a = ne.exec(e);
  return a ? { path: e, hash: a[3].toLowerCase() } : null;
}
function ae(e) {
  const a = T(e);
  return a ? `https://img.kemono.cr/thumbnail/data${a.path}` : null;
}
function y(e) {
  if (typeof e != "string") return null;
  try {
    const a = new URL(e);
    if (a.protocol !== "https:" || a.username || a.password || a.port) return null;
    const t = a.hostname;
    return t === "img.kemono.cr" && a.pathname.startsWith("/thumbnail/data/") && T(a.pathname.slice(15)) || (t === "kemono.cr" || /^n[1-4]\.kemono\.cr$/.test(t)) && a.pathname.startsWith("/data/") && T(a.pathname.slice(5)) || (t === "cdn.discordapp.com" || t === "media.discordapp.net") && /^\/attachments\/\d+\/\d+\/[^/]+\.(png|jpe?g|webp|gif|avif)$/i.test(a.pathname) ? (a.hash = "", a.href) : null;
  } catch {
    return null;
  }
}
class w extends Error {
  constructor(a, t, n = 0) {
    super(a), this.status = t, this.retryAfterMs = n, this.name = "RequestError";
  }
  status;
  retryAfterMs;
  get retryable() {
    return this.status === 0 || this.status === 429 || this.status >= 500;
  }
}
function se(e, a = Date.now()) {
  if (!e) return 0;
  const t = Number(e);
  return Math.max(0, Number.isFinite(t) ? t * 1e3 : Date.parse(e) - a || 0);
}
class ie {
  constructor(a = (t, n) => fetch(t, n)) {
    this.transport = a;
  }
  transport;
  async json(a) {
    let t;
    try {
      t = await this.transport(`https://kemono.cr/api/v1${a}`, {
        headers: { Accept: "text/css" },
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(2e4)
      });
    } catch {
      throw new w("API network request failed or timed out. Open the channel to check site access.", 0);
    }
    if (!t.ok) {
      const n = t.status === 403 ? " Access denied; the required Accept: text/css header was sent. Check access in the site tab." : "";
      throw new w(`API HTTP ${t.status}.${n}`, t.status, se(t.headers.get("retry-after")));
    }
    try {
      return JSON.parse(await t.text());
    } catch {
      throw new w("API returned invalid JSON; this page is incomplete.", 422);
    }
  }
  async channel(a, t) {
    if (g(a), !Number.isSafeInteger(t) || t < 0) throw new Error("Invalid page offset");
    const n = await this.json(`/discord/channel/${a}?o=${t}`);
    if (!Array.isArray(n)) throw new w("Channel response is not an array", 422);
    for (const s of n) {
      if (!s || typeof s != "object") throw new w("Invalid message object", 422);
      if (g(s.id), s.channel !== void 0 && g(s.channel) !== a) throw new w("Channel response contains a different channel", 422);
      if (s.server !== void 0 && g(s.server), s.attachments != null && (!Array.isArray(s.attachments) || s.attachments.some((i) => !i || typeof i != "object" || Array.isArray(i)))) throw new w("Invalid attachment list", 422);
    }
    return n;
  }
  async server(a) {
    g(a);
    const t = await this.json(`/discord/server/${a}`);
    if (!t || g(t.id) !== a || !Array.isArray(t.channels)) throw new w("Invalid server metadata", 422);
    return {
      id: a,
      name: typeof t.name == "string" ? t.name : a,
      channels: t.channels.map((n) => ({
        id: g(n.id),
        name: typeof n.name == "string" ? n.name : n.id,
        parentId: typeof n.parent_channel_id == "string" ? g(n.parent_channel_id) : null,
        type: typeof n.type == "number" ? n.type : null,
        postCount: Number.isSafeInteger(n.post_count) && n.post_count >= 0 ? n.post_count : null
      }))
    };
  }
}
function R(e) {
  let a = 0xcbf29ce484222325n;
  for (const t of e) a = BigInt.asUintN(64, (a ^ BigInt(t.codePointAt(0))) * 0x100000001b3n);
  return a.toString(16).padStart(16, "0");
}
function re(e) {
  if (typeof e != "string") return null;
  const a = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$/.exec(e);
  if (!a) return null;
  const [, t, n, s, i, o, r, c, l] = a, h = Number(t), d = Number(n), m = Number(s);
  if (d < 1 || d > 12 || m < 1 || m > new Date(Date.UTC(h, d, 0)).getUTCDate() || Number(i) > 23 || Number(o) > 59 || Number(r) > 59) return null;
  const I = `${t}-${n}-${s}T${i}:${o}:${r}.${(c || "").padEnd(3, "0").slice(0, 3)}${l || "Z"}`, z = Date.parse(I);
  return Number.isFinite(z) ? new Date(z).toISOString() : null;
}
function H(e, a, t, n, s) {
  return {
    ...e,
    jobId: a,
    id: `${e.serverId}:${e.channelId}:${t || "dom"}:${n}:${R(s)}`,
    messageId: t,
    attachmentIndex: n,
    attachmentId: null,
    publishedRaw: null,
    publishedAtUtc: null,
    originalFilename: null,
    kemonoPath: null,
    kemonoFileHash: null,
    originalUrl: null,
    discordCdnUrl: null,
    thumbnailUrl: null,
    resolvedUrl: null,
    mediaType: "unknown",
    sourceType: "api",
    provenance: [],
    warnings: [],
    status: "discovered",
    savedPath: null,
    errorMessage: null,
    attempts: 0,
    nextAttemptAt: 0,
    downloadId: null,
    blobUrl: null,
    quality: null,
    bytes: null,
    sha256: null,
    mime: null,
    width: null,
    height: null,
    candidateFailures: []
  };
}
function oe(e, a, t) {
  const n = [];
  for (const s of e) {
    if (s.server && s.server !== a.serverId) throw new Error("Message belongs to a different server");
    const i = (l) => (l.publishedRaw = typeof s.published == "string" ? s.published : null, l.publishedAtUtc = re(l.publishedRaw), l.provenance = ["api"], l.publishedAtUtc ? /(Z|[+-]\d\d:\d\d)$/.test(l.publishedRaw) || l.warnings.push("Archive timestamp has no timezone; interpreted as UTC") : l.warnings.push("Missing or invalid publication timestamp"), l), o = s.attachments || [];
    o.forEach((l, h) => {
      const d = typeof l.path == "string" ? l.path : null, m = i(H(a, t, s.id, h + 1, d || l.name || `attachment-${h}`));
      m.originalFilename = typeof l.name == "string" ? l.name : null;
      const I = T(d);
      I ? (m.kemonoPath = I.path, m.kemonoFileHash = I.hash, m.thumbnailUrl = ae(I.path), m.mediaType = "image") : (m.discordCdnUrl = y(d), m.discordCdnUrl?.includes("discordapp.") ? m.mediaType = "image" : (m.discordCdnUrl = null, m.warnings.push("Unsupported attachment path; needs an observed image URL"))), n.push(m);
    });
    const r = typeof s.content == "string" ? s.content.match(/https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\/[^\s<>"')]+/g) || [] : [];
    [...new Set(r.map(y).filter((l) => !!l))].forEach((l, h) => {
      const d = i(H(a, t, s.id, o.length + h + 1, l));
      d.discordCdnUrl = l, d.mediaType = "image", d.originalFilename = new URL(l).pathname.split("/").at(-1);
      try {
        d.originalFilename = decodeURIComponent(d.originalFilename);
      } catch {
      }
      d.provenance.push("inline-content"), n.push(d);
    });
  }
  return n;
}
function V(e, a) {
  const t = new Map(e.map((n) => [n.id, n]));
  for (const n of a) {
    let s = t.get(n.id);
    if (!s && n.messageId) {
      const r = [...t.values()].filter((c) => (c.sourceType === "dom" || n.sourceType === "dom") && c.sourceType !== n.sourceType && c.serverId === n.serverId && c.channelId === n.channelId && c.messageId === n.messageId && (c.kemonoPath && c.kemonoPath === n.kemonoPath || c.discordCdnUrl && c.discordCdnUrl === n.discordCdnUrl));
      s = r.find((c) => c.attachmentIndex === n.attachmentIndex) || (r.length === 1 ? r[0] : void 0);
    }
    if (!s) {
      t.set(n.id, n);
      continue;
    }
    const i = n.sourceType === "api" && s.sourceType === "dom" ? n : s, o = {
      ...s,
      id: i.id,
      attachmentIndex: i.attachmentIndex,
      publishedRaw: i.publishedRaw || s.publishedRaw || n.publishedRaw,
      publishedAtUtc: i.publishedAtUtc || s.publishedAtUtc || n.publishedAtUtc,
      originalFilename: i.originalFilename || s.originalFilename || n.originalFilename,
      kemonoPath: s.kemonoPath || n.kemonoPath,
      kemonoFileHash: s.kemonoFileHash || n.kemonoFileHash,
      thumbnailUrl: s.thumbnailUrl || n.thumbnailUrl,
      originalUrl: s.originalUrl || n.originalUrl,
      discordCdnUrl: s.discordCdnUrl || n.discordCdnUrl,
      mediaType: s.mediaType === "unknown" ? n.mediaType : s.mediaType,
      sourceType: s.sourceType === n.sourceType ? s.sourceType : "merged",
      provenance: [.../* @__PURE__ */ new Set([...s.provenance, ...n.provenance])],
      warnings: [.../* @__PURE__ */ new Set([...s.warnings, ...n.warnings])]
    };
    t.delete(s.id), t.set(o.id, o);
  }
  return [...t.values()];
}
const le = 150;
function ce(e, a) {
  const t = structuredClone(e);
  if (t.attempts = 0, t.nextAttemptAt = 0, t.error = null, !a.length)
    return t.pages++, t.coverage = "complete", t.terminal = "empty-page", t;
  const n = R(a.map((s) => s.id).join(","));
  if (t.pageFingerprints.includes(n)) throw new Error("API repeated an earlier page; pagination stopped with incomplete coverage");
  if (t.pages >= 1e4) throw new Error("Safety page limit reached; coverage is incomplete");
  return t.pageFingerprints.push(n), t.pages++, t.messageIds = [.../* @__PURE__ */ new Set([...t.messageIds, ...a.map((s) => s.id)])], t.offset += le, t.coverage = "scanning", t;
}
function X(e, a = "unnamed") {
  let t = (e || a).normalize("NFKC").replace(/[<>:"/\\|?*\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "_").replace(/^[. ]+|[. ]+$/g, "").slice(0, 40).trim().replace(/[. ]+$/g, "");
  return (!t || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(t)) && (t = "_" + (t || a)), t;
}
function q(e) {
  return `ArchiveRoot/${e.serverId}_${X(e.serverName, "server")}`;
}
function G(e) {
  return `${q(e)}/${e.channelId}_${X(e.channelName, "channel")}`;
}
function de(e, a) {
  if (!/^(png|jpg|webp|gif|avif)$/.test(a)) throw new Error("Unvalidated image format");
  const t = e.publishedAtUtc ? e.publishedAtUtc.slice(0, 19).replace("T", "_").replace(/:(\d{2})/g, "$1") + "Z" : "unknown-date";
  return `${G(e)}/${t}_${e.messageId || "unknown-message"}_${String(e.attachmentIndex).padStart(3, "0")}_${R(e.id).slice(0, 8)}.${a}`;
}
let N;
function U() {
  return N || (N = new Promise((e, a) => {
    const t = indexedDB.open("kemono-archive", 1);
    t.onupgradeneeded = () => {
      t.result.createObjectStore("jobs", { keyPath: "id" }), t.result.createObjectStore("media", { keyPath: ["jobId", "id"] }).createIndex("jobId", "jobId");
    }, t.onsuccess = () => e(t.result), t.onerror = () => {
      N = void 0, a(t.error);
    };
  })), N;
}
function O(e) {
  return new Promise((a, t) => {
    e.onsuccess = () => a(e.result), e.onerror = () => t(e.error);
  });
}
function _(e) {
  return new Promise((a, t) => {
    e.oncomplete = () => a(), e.onerror = e.onabort = () => t(e.error || new Error("Database transaction aborted"));
  });
}
async function A() {
  return O((await U()).transaction("jobs").objectStore("jobs").getAll());
}
async function ue(e) {
  return O((await U()).transaction("jobs").objectStore("jobs").get(e));
}
async function u(e) {
  return O((await U()).transaction("media").objectStore("media").index("jobId").getAll(e));
}
async function f(e) {
  const a = (await U()).transaction("jobs", "readwrite"), t = _(a);
  a.objectStore("jobs").put(e), await t;
}
async function v(e) {
  const a = (await U()).transaction("media", "readwrite"), t = _(a);
  a.objectStore("media").put(e), await t;
}
async function Q(e, a) {
  const t = (await U()).transaction(["jobs", "media"], "readwrite"), n = _(t);
  t.objectStore("jobs").put(e);
  const s = t.objectStore("media"), i = s.index("jobId").openKeyCursor(IDBKeyRange.only(e.id));
  i.onsuccess = () => {
    const o = i.result;
    if (o)
      s.delete(o.primaryKey), o.continue();
    else for (const r of a) s.put(r);
  }, await n;
}
function E(e, a) {
  return {
    discovered: a.length,
    downloaded: a.filter((t) => t.status === "downloaded").length,
    failed: a.filter((t) => t.status === "failed").length,
    skipped: a.filter((t) => t.status === "skipped").length,
    queued: a.filter((t) => t.status === "queued" || t.status === "transferring").length,
    pages: e.channels.reduce((t, n) => t + n.pages, 0),
    messages: e.channels.reduce((t, n) => t + n.messageIds.length, 0),
    incomplete: e.channels.some((t) => t.coverage !== "complete") || a.some((t) => ["failed", "skipped", "queued", "transferring"].includes(t.status) || t.mediaType === "unknown" || !t.messageId || !(t.thumbnailUrl || t.originalUrl || t.discordCdnUrl)) || e.status === "cancelled"
  };
}
function C(e, a, t) {
  const n = t ? a.filter((i) => i.channelId === t) : a, s = t ? { ...e, channels: e.channels.filter((i) => i.channelId === t) } : e;
  return JSON.stringify({
    schemaVersion: 1,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    job: { ...s, manifestDownloads: s.manifestDownloads.map(({ blobUrl: i, ...o }) => o) },
    totals: E(s, n),
    coverageNote: "Complete means every requested API page reached a validated empty array. DOM coverage is limited to observed messages. Indexed links are not a claim that every image is available.",
    timestampPolicy: "Timezone-less archive publication times are interpreted as UTC; raw values are retained.",
    media: n.map(({ blobUrl: i, ...o }) => o)
  }, null, 2);
}
const J = ["serverId", "serverName", "channelId", "channelName", "messageId", "publishedRaw", "publishedAtUtc", "attachmentIndex", "originalFilename", "kemonoPath", "kemonoFileHash", "originalUrl", "discordCdnUrl", "thumbnailUrl", "resolvedUrl", "quality", "sourceType", "status", "savedPath", "sha256", "errorMessage"];
function me(e) {
  const a = (t) => {
    let n = t == null ? "" : String(t);
    return /^[\s]*[=+\-@\t\r]/.test(n) && (n = "'" + n), '"' + n.replaceAll('"', '""') + '"';
  };
  return "\uFEFF" + [J.join(","), ...e.map((t) => J.map((n) => a(t[n])).join(","))].join(`\r
`);
}
function fe(e, a) {
  const t = [e.originalUrl, e.discordCdnUrl].map(y).filter((o) => !!o).map((o) => ({ url: o, quality: "original" })), n = y(e.thumbnailUrl), s = n ? [{ url: n, quality: "thumbnail" }] : [], i = a.mode === "original" ? t : a.mode === "best" && a.tryOriginal ? [...t, ...s] : s;
  return i.filter((o, r) => i.findIndex((c) => c.url === o.url) === r);
}
let P;
async function L(e, a = {}) {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length || (P ||= chrome.offscreen.createDocument({ url: "offscreen/index.html", reasons: [chrome.offscreen.Reason.BLOBS], justification: "Validate archived image bytes, decode dimensions, and create local blob URLs for browser downloads and exports." }).finally(() => {
    P = void 0;
  }), await P);
  const t = await chrome.runtime.sendMessage({ target: "offscreen", action: e, ...a });
  if (!t?.ok) throw new Error(t?.error || "Image validator did not respond");
  return t.data;
}
async function b(e) {
  e && await L("release", { url: e }).catch(() => {
  });
}
async function x(e, a, t = "application/json", n = !1) {
  const { blobUrl: s } = await L("export", { text: e, mime: t });
  try {
    return { id: await chrome.downloads.download({ url: s, filename: a, conflictAction: n ? "overwrite" : "uniquify", saveAs: !1 }), blobUrl: s };
  } catch (i) {
    throw await b(s), i;
  }
}
const j = 3;
function S(e, a = 0) {
  return Math.max(2e3 * 2 ** Math.max(0, e - 1), a);
}
async function he(e, a) {
  const t = fe(e, a);
  if (!t.length)
    return e.status = "skipped", e.errorMessage = a.mode === "original" ? "No original URL was exposed by the archive. No URL was invented." : "No observed or supported thumbnail URL is available.", await v(e), 0;
  e.status = "transferring", e.attempts++, await v(e);
  let n = 0, s = !1;
  for (const i of t)
    if (!e.candidateFailures.some((o) => o.url === i.url && /Image HTTP (400|401|403|404|410|422)\b/.test(o.reason)))
      try {
        const o = new URL(i.url).hostname;
        if (!["kemono.cr", "img.kemono.cr"].includes(o) && !await chrome.permissions.contains({ origins: [`https://${o}/*`] })) {
          e.candidateFailures.push({ url: i.url, reason: "Optional permission for this original host was not granted" });
          continue;
        }
        const r = await L("image", { url: i.url });
        if (r.failure) {
          if (e.candidateFailures.push({ url: i.url, reason: r.failure }), r.status === 429) {
            n = S(e.attempts, r.retryAfterMs), s = !0;
            break;
          }
          (!r.status || r.status >= 500) && (s = !0);
          continue;
        }
        return e.resolvedUrl = i.url, e.quality = i.quality, e.bytes = r.bytes, e.sha256 = r.sha256, e.mime = r.mime, e.width = r.width, e.height = r.height, e.blobUrl = r.blobUrl, e.savedPath = de(e, r.ext), await v(e), e.downloadId = await chrome.downloads.download({ url: r.blobUrl, filename: e.savedPath, conflictAction: "uniquify", saveAs: !1 }), e.errorMessage = null, await v(e), 0;
      } catch {
        s = !0, e.candidateFailures.push({ url: i.url, reason: "Image fetch, decoding, or browser download failed" }), await b(e.blobUrl), e.blobUrl = null, e.downloadId = null;
      }
  return e.errorMessage = e.candidateFailures.at(-1)?.reason || "All allowed image candidates failed", s && e.attempts < j ? (e.status = "queued", e.nextAttemptAt = Date.now() + (n || S(e.attempts))) : e.status = "failed", await v(e), n;
}
async function B(e, a = !1) {
  let t;
  if (e.downloadId !== null ? [t] = await chrome.downloads.search({ id: e.downloadId }) : e.savedPath && e.blobUrl && (t = (await chrome.downloads.search({ query: [e.savedPath.split("/").at(-1)], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === e.blobUrl), t && (e.downloadId = t.id)), t?.state === "complete") {
    if (t.exists === !1 ? (e.status = "failed", e.errorMessage = "The completed file was removed outside the extension") : (e.status = "downloaded", e.errorMessage = null), t.filename) {
      const n = t.filename.replaceAll("\\", "/"), s = n.lastIndexOf("/ArchiveRoot/");
      s >= 0 && (e.savedPath = n.slice(s + 1));
    }
    await b(e.blobUrl), e.blobUrl = null;
  } else (t?.state === "interrupted" || !t && a) && (e.errorMessage = t?.error || "Worker/browser interrupted an uncommitted transfer", e.status = e.attempts < j ? "queued" : "failed", e.nextAttemptAt = Date.now() + S(e.attempts), await b(e.blobUrl), e.blobUrl = null, e.downloadId = null);
  await v(e);
}
const Y = new ie();
function p(e) {
  return e.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), e;
}
async function K(e) {
  const a = await ue(e);
  if (!a) throw new Error("Archive job was not found");
  return a;
}
async function Z(e) {
  const a = M(e);
  if (!a) throw new Error("Open or paste a supported https://kemono.cr/discord/server/{server}/{channel} URL");
  try {
    const t = await Y.server(a.serverId);
    return a.serverName = t.name, a.channelName = t.channels.find((n) => n.id === a.channelId)?.name || null, { scope: a, server: t, warning: null };
  } catch (t) {
    return { scope: a, server: null, warning: `${t instanceof Error ? t.message : "Server discovery failed"} Current-channel scanning is still available.` };
  }
}
async function pe(e, a) {
  if (e.type === "DISCOVER") return Z(e.url);
  if (e.type === "LIST") {
    const n = (await A()).sort((s, i) => i.createdAt.localeCompare(s.createdAt));
    return Promise.all(n.map(async (s) => ({ job: s, totals: E(s, await u(s.id)) })));
  }
  if (e.type === "DETAIL") {
    const n = await K(e.jobId), s = await u(n.id);
    return { job: n, media: s, totals: E(n, s) };
  }
  if (e.type === "DASHBOARD")
    return await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") }), null;
  if (e.type === "START") {
    if (!["thumbnail", "best", "original"].includes(e.mode)) throw new Error("Invalid quality mode");
    const { scope: n, server: s, warning: i } = await Z(e.url), o = [...new Set(e.channelIds.length ? e.channelIds.map(g) : [n.channelId])];
    if (o.some((l) => l !== n.channelId && !s?.channels.some((h) => h.id === l))) throw new Error("Selected channel was not discovered in this server");
    for (const l of await A()) ["scanning", "downloading"].includes(l.status) && (l.resumeStatus = l.status, l.status = "paused", await f(p(l)));
    const r = {
      id: crypto.randomUUID(),
      serverId: n.serverId,
      serverName: n.serverName,
      mode: e.mode,
      tryOriginal: !!e.tryOriginal,
      channels: o.map((l) => {
        const h = s?.channels.find((d) => d.id === l);
        return { channelId: l, channelName: h?.name || null, postCount: h?.postCount ?? null, offset: 0, pages: 0, messageIds: [], pageFingerprints: [], coverage: "pending", terminal: null, failures: [], attempts: 0, nextAttemptAt: 0, error: null, domMessages: 0 };
      }),
      status: "scanning",
      resumeStatus: "scanning",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      warnings: i ? [i] : [],
      autoManifest: !1,
      manifestState: "pending",
      manifestDownloads: [],
      apiNextAt: 0,
      mediaNextAt: 0
    };
    await f(r);
    const c = await chrome.tabs.query({ url: "https://kemono.cr/discord/server/*" });
    for (const l of c) l.id && M(l.url || "")?.serverId === r.serverId && chrome.tabs.sendMessage(l.id, { type: "SCAN_DOM" }).catch(() => {
    });
    return { jobId: r.id };
  }
  if (e.type === "DOM") {
    const n = M(e.url), s = M(a.tab?.url || "");
    if (!n || !s || s.channelId !== n.channelId || s.serverId !== n.serverId) return null;
    for (const i of await A()) {
      if (i.serverId !== n.serverId || !["scanning", "indexed", "paused"].includes(i.status)) continue;
      const o = i.channels.find((c) => c.channelId === n.channelId);
      if (!o) continue;
      const r = e.records.slice(0, 1e4).filter((c) => c.serverId === n.serverId && c.channelId === n.channelId).map((c) => ({
        ...c,
        jobId: i.id,
        serverName: i.serverName,
        channelName: o.channelName,
        originalUrl: y(c.originalUrl),
        discordCdnUrl: y(c.discordCdnUrl),
        thumbnailUrl: y(c.thumbnailUrl)
      }));
      o.domMessages = Math.max(o.domMessages, e.messageCount), await Q(p(i), V(await u(i.id), r));
    }
    return null;
  }
  const t = await K(e.jobId);
  if (e.type === "EXPORT") {
    const n = await u(t.id), s = q(t), i = t.id.slice(0, 8);
    return e.format === "csv" ? await x(me(n), `${s}/links-${i}.csv`, "text/csv;charset=utf-8") : e.format === "failures" ? await x(C(t, n.filter((o) => o.status === "failed" || o.status === "skipped")), `${s}/failures-${i}.json`) : await x(C(t, n), `${s}/manifest-${i}.json`), null;
  }
  if (e.action === "pause") {
    ["scanning", "downloading"].includes(t.status) && (t.resumeStatus = t.status, t.status = "paused");
    for (const n of await u(t.id)) n.status === "transferring" && n.downloadId !== null && await chrome.downloads.pause(n.downloadId).catch(() => {
    });
  } else if (e.action === "cancel") {
    t.status = "cancelled";
    for (const n of await u(t.id))
      n.status === "transferring" && n.downloadId !== null && await chrome.downloads.cancel(n.downloadId).catch(() => {
      }), ["queued", "transferring"].includes(n.status) && (n.status = "skipped", n.errorMessage = "Cancelled by user", await b(n.blobUrl), n.blobUrl = null, await v(n));
  } else if (e.action === "resume") {
    if (t.status !== "paused") throw new Error("Only paused jobs can be resumed");
    t.status = t.resumeStatus;
    for (const n of await u(t.id)) n.status === "transferring" && n.downloadId !== null && await chrome.downloads.resume(n.downloadId).catch(() => {
    });
  } else if (e.action === "retry") {
    for (const n of t.channels) n.coverage === "incomplete" && (n.coverage = "pending", n.attempts = 0, n.error = null, n.nextAttemptAt = 0);
    for (const n of await u(t.id)) (n.status === "failed" || n.status === "skipped") && (n.status = t.autoManifest ? "queued" : "discovered", n.attempts = 0, n.nextAttemptAt = 0, n.errorMessage = null, n.candidateFailures = [], await v(n));
    t.status = t.channels.some((n) => n.coverage !== "complete") ? "scanning" : t.autoManifest ? "downloading" : "indexed", t.manifestState = "pending";
  } else if (e.action === "download") {
    if (t.status === "scanning" || t.channels.some((n) => ["pending", "scanning"].includes(n.coverage))) throw new Error("Pause or finish the scan before downloading the indexed results");
    for (const n of await u(t.id)) n.status === "discovered" && (n.status = "queued", await v(n));
    t.status = "downloading", t.autoManifest = !0, t.manifestState = "pending";
  }
  return await f(p(t)), null;
}
async function we(e) {
  if (!e.channels.some((t) => ["pending", "scanning"].includes(t.coverage))) {
    e.status = e.autoManifest ? "downloading" : "indexed", await f(p(e));
    return;
  }
  if (Date.now() < e.apiNextAt) return;
  const a = e.channels.find((t) => ["pending", "scanning"].includes(t.coverage) && t.nextAttemptAt <= Date.now());
  if (!a) {
    e.channels.some((t) => ["pending", "scanning"].includes(t.coverage)) || (e.status = e.autoManifest ? "downloading" : "indexed", await f(p(e)));
    return;
  }
  try {
    const t = await Y.channel(a.channelId, a.offset), n = ce(a, t), s = oe(t, { serverId: e.serverId, serverName: e.serverName, channelId: a.channelId, channelName: a.channelName }, e.id);
    if (e.autoManifest) for (const i of s) i.status = "queued";
    e.channels[e.channels.indexOf(a)] = n, n.coverage === "complete" && n.postCount !== null && n.postCount !== n.messageIds.length && e.warnings.push(`Channel ${n.channelId}: metadata post_count=${n.postCount}; API unique messages=${n.messageIds.length}.`), e.apiNextAt = Date.now() + 1100, await Q(p(e), V(await u(e.id), s));
  } catch (t) {
    a.attempts++, a.error = t instanceof Error ? t.message : "Page scan failed", a.failures.push({ offset: a.offset, reason: a.error, at: (/* @__PURE__ */ new Date()).toISOString() });
    const n = t instanceof w && t.retryable;
    if (t instanceof w && t.status === 429 && (e.apiNextAt = Date.now() + S(a.attempts, t.retryAfterMs)), n && a.attempts < j) {
      const s = S(a.attempts, t.retryAfterMs);
      a.nextAttemptAt = Date.now() + s, e.apiNextAt = a.nextAttemptAt;
    } else a.coverage = "incomplete";
    await f(p(e));
  }
}
async function ge(e, a) {
  e.manifestState = "saving", e.manifestDownloads = [], await f(p(e));
  try {
    for (const s of e.channels) {
      const i = `${G({ ...e, channelId: s.channelId, channelName: s.channelName })}/channel-manifest.json`, o = await x(C(e, a, s.channelId), i, "application/json", !0);
      e.manifestDownloads.push({ ...o, path: i, state: "in_progress" }), await f(e);
    }
    const t = `${q(e)}/manifest.json`, n = await x(C(e, a), t, "application/json", !0);
    e.manifestDownloads.push({ ...n, path: t, state: "in_progress" }), await f(e);
  } catch {
    e.manifestState = "failed", e.warnings.push("One or more manifest downloads failed. Use Export JSON to save the current state."), await f(p(e));
  }
}
async function ve() {
  const e = await A(), a = Math.max(0, ...e.map((n) => n.apiNextAt)), t = Math.max(0, ...e.map((n) => n.mediaNextAt));
  for (const n of e) {
    if (n.status === "scanning") {
      (Date.now() >= a || n.channels.every((r) => !["pending", "scanning"].includes(r.coverage))) && await we(n);
      return;
    }
    if (n.status !== "downloading") continue;
    let s = await u(n.id);
    for (const r of s) r.status === "transferring" && r.downloadId !== null && await B(r);
    s = await u(n.id);
    const i = s.filter((r) => r.status === "transferring").length, o = s.filter((r) => r.status === "queued" && r.nextAttemptAt <= Date.now()).slice(0, Math.max(0, 2 - i));
    if (o.length && Date.now() >= t) {
      const r = await Promise.all(o.map((c) => he(c, n)));
      n.mediaNextAt = Date.now() + Math.max(1100, ...r), await f(n);
    }
    s = await u(n.id), s.some((r) => r.status === "queued" || r.status === "transferring") || (n.status = "finished", await f(p(n)), n.autoManifest && n.manifestState === "pending" && await ge(n, s));
    return;
  }
}
async function ee() {
  for (const e of await A()) {
    for (const a of await u(e.id)) a.status === "transferring" && await B(a, !0);
    if (e.manifestState === "saving") {
      for (const a of e.manifestDownloads) {
        const [t] = await chrome.downloads.search({ id: a.id });
        a.state = t?.state === "complete" ? "complete" : t?.state === "in_progress" ? "in_progress" : "interrupted";
      }
      e.manifestDownloads.length !== e.channels.length + 1 ? (e.manifestState = "pending", e.status === "finished" && (e.status = "downloading")) : e.manifestDownloads.every((a) => a.state === "complete") ? e.manifestState = "saved" : e.manifestDownloads.some((a) => a.state === "interrupted") && (e.manifestState = "failed"), await f(e);
    }
  }
}
async function ye(e) {
  if (!e.state || !["complete", "interrupted"].includes(e.state.current || "")) return;
  for (const t of await A()) {
    for (const s of await u(t.id)) s.downloadId === e.id && s.status === "transferring" && await B(s);
    const n = t.manifestDownloads.find((s) => s.id === e.id);
    n && (n.state = e.state.current === "complete" ? "complete" : "interrupted", await b(n.blobUrl), t.manifestDownloads.length === t.channels.length + 1 && t.manifestDownloads.every((s) => s.state === "complete") && (t.manifestState = "saved"), n.state === "interrupted" && (t.manifestState = "failed"), await f(p(t)));
  }
  const [a] = await chrome.downloads.search({ id: e.id });
  a?.url.startsWith(`blob:chrome-extension://${chrome.runtime.id}/`) && await b(a.url);
}
let W = Promise.resolve(), F, D = !1;
function k(e) {
  const a = W.then(e);
  return W = a.catch(() => {
  }), a;
}
function te() {
  D || (D = !0, k(ve).catch(() => {
  }).finally(() => {
    D = !1, $();
  }));
}
function $() {
  F || D || (F = setTimeout(() => {
    F = void 0, te();
  }, 1200));
}
chrome.runtime.onMessage.addListener((e, a, t) => {
  if (!(a.id !== chrome.runtime.id || e.target === "offscreen"))
    return k(() => pe(e, a)).then((n) => t({ ok: !0, data: n }), (n) => t({ ok: !1, error: n instanceof Error ? n.message : "Archive operation failed" })).finally($), !0;
});
chrome.downloads.onChanged.addListener((e) => {
  k(() => ye(e)).catch(() => {
  }).finally($);
});
chrome.alarms.onAlarm.addListener((e) => {
  e.name === "archive-tick" && te();
});
chrome.runtime.onStartup.addListener(() => {
  k(ee).finally($);
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
});
chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
k(ee).catch(() => {
}).finally($);
