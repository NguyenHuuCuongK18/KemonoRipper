const No = new Date(1980, 0, 1), P = void 0, fs = "Local file header not found", ls = "Overlapping entry found", Kn = "Zip64 extra field not found", Dt = "undefined", Pe = "function", xn = "string", ds = "number", Di = "boolean", nt = new Uint8Array(), Es = Symbol.asyncDispose || /* @__PURE__ */ Symbol(), hs = "filenameEncoding", ps = "commentEncoding", _s = "decodeText", ms = "extractPrependedData", ws = "extractAppendedData", gs = "password", ys = "rawPassword", As = "passThrough", Rs = "signal", Ts = "checkPasswordOnly", vs = "checkOverlappingEntryOnly", bs = "checkOverlappingEntry", Oi = "checkAmbiguity", Ss = "checkLocalDirectory", Is = "checkLocalFilename", Ns = "checkSignature", Ds = "checkCrc32", Os = "checkAuthenticationCode", Ls = "useWebWorkers", Ps = "useCompressionStream", Cs = "preventClose", Li = "strictness", Fs = "filenameValidation", Ms = "normalizeFilename", Us = "maxAppendedDataSize", xs = "decryptCentralDirectory", ks = "filename", Bs = "comment", $t = "strict", Lr = "balanced", Ut = "tolerant", Hs = "compressed", zs = "Invalid option (must be a function)", Ws = "Invalid signal (must be an AbortSignal instance)", Gs = "Invalid password (password must be a string, rawPassword must be a Uint8Array)", Ys = "Invalid passThrough option (must be a boolean or 'compressed')", Xs = "The operation was aborted", Zs = "AbortError";
function Pi(n) {
  if (n && typeof n != Pe)
    throw new Error(zs);
  return n;
}
function js(n) {
  if (n && (typeof n.addEventListener != Pe || typeof n.aborted != Di))
    throw new Error(Ws);
  return n || P;
}
function Do(n) {
  if (n && n.aborted)
    throw n.reason === P ? new DOMException(Xs, Zs) : n.reason;
}
function Vs(n, e) {
  if (n && typeof n != xn || e && !(e instanceof Uint8Array))
    throw new Error(Gs);
}
function Ks(n) {
  if (n !== P && typeof n != Di && n !== Hs)
    throw new Error(Ys);
  return n;
}
function Pr(n) {
  return typeof n == xn && n.trim() ? Number(n) : n;
}
const Ci = 256 * 1024, qs = 64, Fi = 1, Js = "Invalid maxWorkers (must be an integer greater than 0)", Qs = "Invalid baseURI (must be a string)", $s = "Invalid URI (must be a string or a function returning a string)";
let Mi = 2;
try {
  typeof navigator != Dt && navigator.hardwareConcurrency && (Mi = navigator.hardwareConcurrency);
} catch {
}
const Ui = {
  workerURI: "./core/web-worker-wasm.js",
  wasmURI: "./core/streams/zlib-wasm/zlib-streams.wasm",
  chunkSize: Ci,
  maxWorkers: Mi,
  terminateWorkerTimeout: 5e3,
  workerStarvationTimeout: 5e3,
  workerStartupTimeout: 5e3,
  useWebWorkers: !0,
  useCompressionStream: !0,
  CompressionStream: typeof CompressionStream != Dt && CompressionStream,
  DecompressionStream: typeof DecompressionStream != Dt && DecompressionStream
}, xi = "maxWorkers", ki = "baseURI", Bi = [
  "wasmURI",
  "workerURI"
], ec = [
  "useCompressionStream",
  "useWebWorkers"
], Hi = [
  "chunkSize",
  xi,
  "terminateWorkerTimeout",
  "workerStarvationTimeout",
  "workerStartupTimeout"
], zi = [
  "createWorker",
  "CompressionStream",
  "DecompressionStream",
  "CompressionStreamFallback",
  "DecompressionStreamFallback"
], tc = [
  ki,
  ...Bi,
  ...ec,
  ...Hi,
  ...zi
], Wi = { ...Ui };
function Gi() {
  return Wi;
}
function Cr(n) {
  return Yi(n.chunkSize);
}
function Yi(n) {
  return n = Pr(n), Number.isInteger(n) && n >= Fi ? Math.max(n, qs) : Ci;
}
function nc(n) {
  const e = {};
  for (const o of tc) {
    const i = n[o];
    i !== P && (e[o] = rc(o, i));
  }
  return e;
}
function rc(n, e) {
  if (Hi.includes(n)) {
    if (e = Pr(e), n == xi && (!Number.isInteger(e) || e < Fi))
      throw new Error(Js);
  } else if (zi.includes(n))
    Pi(e);
  else if (n == ki) {
    if (e && typeof e != xn)
      throw new Error(Qs);
  } else if (Bi.includes(n) && e && typeof e != xn && typeof e != Pe)
    throw new Error($s);
  return e;
}
function oc(n) {
  n = n || {};
  const { CompressionStreamZlib: e, DecompressionStreamZlib: o } = n;
  if (e === P && o === P)
    return n;
  const i = Object.assign({}, n);
  return i.CompressionStreamFallback === P && (i.CompressionStreamFallback = e), i.DecompressionStreamFallback === P && (i.DecompressionStreamFallback = o), i;
}
function qn(n) {
  const e = nc(oc(n));
  Object.assign(Ui, e), Object.assign(Wi, e);
}
const Sn = new Uint8Array(288);
Sn.fill(8, 0, 144), Sn.fill(9, 144, 256), Sn.fill(7, 256, 280), Sn.fill(8, 280, 288), new Uint8Array(30).fill(5);
const wt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", ic = (n) => n({ workerURI: (e) => {
  const o = "text/javascript";
  let i = `!function(t){"function"==typeof define&&define.amd?define(t):t()}(function(){"use strict";const{Array:t,Object:n,Number:e,Math:o,Error:r,Uint8Array:c,Uint16Array:s,Uint32Array:a,Int32Array:i,Map:f,DataView:u,Promise:w,TextEncoder:l,crypto:d,postMessage:p,TransformStream:h,ReadableStream:y,WritableStream:m,CompressionStream:S,DecompressionStream:g}=self,v=void 0,b="undefined",k="function",z=new c,C=[[],[],[],[],[],[],[],[]];for(let t=0;t<256;t++){let n=t;for(let t=0;t<8;t++)n=1&n?n>>>1^3988292384:n>>>1;C[0][t]=n}for(let t=0;t<256;t++)for(let n=1;n<8;n++){const e=C[n-1][t];C[n][t]=e>>>8^C[0][255&e]}const[I,M,A,E,R,x,P,D]=C;class F{constructor(t){this.o=t||-1}append(t){let n=0|this.o;const e=0|t.length;let o=0;if(e>=8&&t.buffer){const r=new u(t.buffer,t.byteOffset,e),c=e-8;for(;o<=c;o+=8){const t=n^r.getInt32(o,!0),e=r.getInt32(o+4,!0);n=D[255&t]^P[t>>>8&255]^x[t>>>16&255]^R[t>>>24&255]^E[255&e]^A[e>>>8&255]^M[e>>>16&255]^I[e>>>24&255]}}for(;o<e;o++)n=n>>>8^I[255&(n^t[o])];this.o=n}get(){return~this.o}}class U extends h{constructor(){let t;const n=new F;super({transform(t,e){n.append(t),e.enqueue(t)},flush(){const e=new c(4);new u(e.buffer).setUint32(0,n.get()),t.value=e}}),t=this}}function B(t,n){const e=new c(t.length+n.length);return e.set(t),e.set(n,t.length),e}function W(t){return new u(t.buffer,t.byteOffset,t.byteLength)}const O=64,V=20,K=new c([128]),T=new c(1),_=new i([1732584193,4023233417,2562383102,271733878,3285377520]),j=new c(256),H=new i(256),L=new i(256),Z=new i(256),N=new i(256);let q=!1;function G(t,n){!function(){if(!q){let t=1,n=1;do{t=255&(t^t<<1^(128&t?27:0)),n=255&(n^n<<1),n=255&(n^n<<2),n=255&(n^n<<4),128&n&&(n^=9),j[t]=255&(n^(n<<1|n>>7)^(n<<2|n>>6)^(n<<3|n>>5)^(n<<4|n>>4)^99)}while(1!=t);j[0]=99;for(let t=0;t<256;t++){const n=j[t],e=Y(n),o=e<<24|n<<16|n<<8|e^n;H[t]=o,L[t]=o>>>8|o<<24,Z[t]=o>>>16|o<<16,N[t]=o>>>24|o<<8}q=!0}}();const e=new i(60),o=function(t,n){const e=t.length>>2,o=e+6,r=4*(o+1);let c=1;for(let o=0;o<e;o++)n[o]=t[4*o]<<24|t[4*o+1]<<16|t[4*o+2]<<8|t[4*o+3];for(let t=e;t<r;t++){let o=n[t-1];t%e==0?(o=Q(o<<8|o>>>24)^c<<24,c=Y(c)):e>6&&t%e==4&&(o=Q(o)),n[t]=n[t-e]^o}return o}(t,e),r=new i(4),c=J(n);let s=0,a=0,f=0,w=0;return{process(t,n){n&&c.update(t,0,t.length),function(t){const n=new u(t.buffer,t.byteOffset,t.byteLength),e=t.length;let o=0;for(;o+16<=e;o+=16)l(),n.setInt32(o,n.getInt32(o)^r[0]),n.setInt32(o+4,n.getInt32(o+4)^r[1]),n.setInt32(o+8,n.getInt32(o+8)^r[2]),n.setInt32(o+12,n.getInt32(o+12)^r[3]);if(o<e){l();for(let n=0;o<e;o++,n++)t[o]^=r[n>>2]>>>24-8*(3&n)}}(t),n||c.update(t,0,t.length)},digest:()=>c.digest()};function l(){s=s+1|0,s||(a=a+1|0,a||(f=f+1|0,f||(w=w+1|0)));let t=X(s)^e[0],n=X(a)^e[1],c=X(f)^e[2],i=X(w)^e[3],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[4],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[5],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[6],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[7];t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[8],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[9],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[10],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[11],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[12],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[13],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[14],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[15],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[16],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[17],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[18],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[19],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[20],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[21],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[22],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[23],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[24],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[25],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[26],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[27],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[28],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[29],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[30],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[31],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[32],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[33],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[34],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[35],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[36],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[37],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[38],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[39];let h=40;o>10&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[40],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[41],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[42],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[43],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[44],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[45],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[46],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[47],h=48),o>12&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[48],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[49],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[50],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[51],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[52],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[53],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[54],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[55],h=56),r[0]=(j[u>>>24]<<24|j[l>>>16&255]<<16|j[d>>>8&255]<<8|j[255&p])^e[h],r[1]=(j[l>>>24]<<24|j[d>>>16&255]<<16|j[p>>>8&255]<<8|j[255&u])^e[h+1],r[2]=(j[d>>>24]<<24|j[p>>>16&255]<<16|j[u>>>8&255]<<8|j[255&l])^e[h+2],r[3]=(j[p>>>24]<<24|j[u>>>16&255]<<16|j[l>>>8&255]<<8|j[255&d])^e[h+3]}}function J(t){const n=function(){const t=new i(_),n=new i(16),e=new c(O),r=new u(e.buffer),s=new c(8);let a=0,f=0;return{update:w,digest:function(){const n=8*f,e=o.floor(n/4294967296),r=n>>>0;for(w(K,0,1);56!=a;)w(T,0,1);s[0]=e>>>24,s[1]=e>>>16,s[2]=e>>>8,s[3]=e,s[4]=r>>>24,s[5]=r>>>16,s[6]=r>>>8,s[7]=r,w(s,0,8);const i=new c(V),l=new u(i.buffer);for(let n=0;n<t.length;n++)l.setInt32(4*n,t[n]);return t.set(_),a=0,f=0,i}};function w(t,n,o){const c=n+o;if(f+=o,a){for(;n<c&&a<O;)e[a++]=t[n++];a==O&&(l(r,0),a=0)}if(n+O<=c){const e=new u(t.buffer,t.byteOffset,t.byteLength);for(;n+O<=c;n+=O)l(e,n)}for(;n<c;)e[a++]=t[n++]}function l(e,o){for(let t=0;t<16;t++)n[t]=e.getInt32(o+4*t);let r,c=t[0],s=t[1],a=t[2],i=t[3],f=t[4];for(let t=0;t<15;t+=5)f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[t]|0,s=s<<30|s>>>2,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+n[t+1]|0,c=c<<30|c>>>2,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+n[t+2]|0,f=f<<30|f>>>2,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+n[t+3]|0,i=i<<30|i>>>2,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+n[t+4]|0,a=a<<30|a>>>2;f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[15]|0,s=s<<30|s>>>2,r=n[13]^n[8]^n[2]^n[0],r=r<<1|r>>>31,n[0]=r,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+r|0,c=c<<30|c>>>2,r=n[14]^n[9]^n[3]^n[1],r=r<<1|r>>>31,n[1]=r,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+r|0,f=f<<30|f>>>2,r=n[15]^n[10]^n[4]^n[2],r=r<<1|r>>>31,n[2]=r,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+r|0,i=i<<30|i>>>2,r=n[0]^n[11]^n[5]^n[3],r=r<<1|r>>>31,n[3]=r,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+r|0,a=a<<30|a>>>2;for(let t=20;t<40;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+1859775393+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+1859775393+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+1859775393+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+1859775393+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+1859775393+r|0,a=a<<30|a>>>2;for(let t=40;t<60;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s&a|(s|a)&i)+f+2400959708+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c&s|(c|s)&a)+i+2400959708+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f&c|(f|c)&s)+a+2400959708+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i&f|(i|f)&c)+s+2400959708+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a&i|(a|i)&f)+c+2400959708+r|0,a=a<<30|a>>>2;for(let t=60;t<80;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+3395469782+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+3395469782+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+3395469782+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+3395469782+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+3395469782+r|0,a=a<<30|a>>>2;t[0]=t[0]+c|0,t[1]=t[1]+s|0,t[2]=t[2]+a|0,t[3]=t[3]+i|0,t[4]=t[4]+f|0}}(),e=new c(O),r=new c(O);t.length>O&&(n.update(t,0,t.length),t=n.digest());for(let n=0;n<O;n++){const o=n<t.length?t[n]:0;e[n]=54^o,r[n]=92^o}return n.update(e,0,O),{update(t,e,o){n.update(t,e,o)},digest(){const t=n.digest();n.update(r,0,O),n.update(t,0,V);const o=n.digest();return n.update(e,0,O),o}}}function Q(t){return j[t>>>24]<<24|j[t>>>16&255]<<16|j[t>>>8&255]<<8|j[255&t]}function X(t){return t<<24|(65280&t)<<8|t>>>8&65280|t>>>24}function Y(t){return 255&(t<<1^27*(t>>7))}const $=typeof d!=b&&typeof d.getRandomValues==k,tt="Invalid password",nt="zipjs-abort-check-password";function et(t){if($)return d.getRandomValues(t);throw new r("Crypto API not supported")}const ot={name:"PBKDF2"},rt=n.assign({hash:{name:"HMAC"}},ot),ct=n.assign({iterations:1e3,hash:{name:"SHA-1"}},ot),st=["deriveBits"],at=[8,12,16],it=[16,24,32],ft=10,ut=typeof d!=b,wt=ut&&d.subtle;let lt=ut&&typeof wt!=b&&typeof wt.importKey==k&&typeof wt.deriveBits==k,dt=G;class pt extends h{constructor({password:t,rawPassword:n,encryptionStrength:e,checkPasswordOnly:o,checkAuthenticationCode:s=!0}){const a={};super({start(){yt(a,t,n,e)},async transform(t,n){const{password:e,strength:s,l:i,ready:f}=a;if(e?(await async function(t,n,e,o){const c=await vt(t,n,e,kt(o,0,at[n])),s=kt(o,at[n]);if(c[0]!=s[0]||c[1]!=s[1])throw gt(t),new r(tt)}(a,s,e,kt(t,0,at[s]+2)),t=kt(t,at[s]+2),o?(gt(a),n.error(new r(nt))):i()):await f,a.h)return;const u=new c(t.length-ft-(t.length-ft)%16);n.enqueue(St(a,t,u,0,ft,!0))},async flush(t){const{m:n,S:e,ready:o}=a;if(n){if(await o,a.h)return;const i=kt(e,e.length-ft),f=new c(kt(e,0,e.length-ft));n.process(f,!0);const u=n.digest();let w=e.length<ft?1:0;for(let t=0;t<ft;t++)w|=u[t]^i[t];if(w&&s)return void t.error(new r("Invalid authentication code"));t.enqueue(f)}}}),mt(this,a)}}class ht extends h{constructor({password:t,rawPassword:n,encryptionStrength:e}){const o={};super({start(){yt(o,t,n,e)},async transform(t,n){const{password:e,strength:r,l:s,ready:a}=o;let i=z;if(e?(i=await async function(t,n,e){const o=et(new c(at[n]));return B(o,await vt(t,n,e,o))}(o,r,e),s()):await a,o.h)return;const f=new c(i.length+t.length-t.length%16);f.set(i,0),n.enqueue(St(o,t,f,i.length,0,!1))},async flush(t){const{m:n,S:e,ready:r}=o;if(n){if(await r,o.h)return;const s=new c(e);n.process(s,!1);const a=kt(n.digest(),0,ft);t.enqueue(B(s,a))}}}),mt(this,o)}}function yt(t,e,o,r){n.assign(t,{ready:new w(n=>t.l=n),password:bt(e,o),strength:r-1,S:z,h:!1})}function mt(t,e){const o=t.readable.getReader(),r=new y({async pull(t){try{const{value:n,done:e}=await o.read();e?t.close():t.enqueue(n)}catch(t){throw gt(e),o.cancel(t).catch(()=>{}),t}},cancel:t=>(gt(e),o.cancel(t))});n.defineProperty(t,"readable",{get:()=>r})}function St(t,n,e,o,r,s){const{m:a,S:i}=t;i.length&&(n=B(i,n));const f=n.length-r,u=f-f%16;if(e=function(t,n){if(n&&n>t.length){const e=t;(t=new c(n)).set(e,0)}return t}(e,o+u),u){const t=kt(e,o,o+u);t.set(kt(n,0,u)),a.process(t,s)}return t.S=kt(n,u),e}function gt(t){const{m:n}=t;t.h=!0,n&&n.dispose&&n.dispose()}async function vt(t,e,r,s){t.password=null;const a=it[e],i=await async function(t,e,r){if(lt)try{const o=await wt.importKey("raw",t,rt,!1,st);return new c(await wt.deriveBits(n.assign({salt:e},ct),o,8*r))}catch{lt=!1}return function(t,n,e,r){const s=J(t),a=new c(r),i=new c(n.length+4),f=new u(i.buffer);i.set(n);for(let t=1,e=0;e<r;t++,e+=V){f.setUint32(n.length,t),s.update(i,0,i.length);let c=s.digest();const u=c.slice();for(let t=1;t<1e3;t++){s.update(c,0,V),c=s.digest();for(let t=0;t<V;t++)u[t]^=c[t]}a.set(u.subarray(0,o.min(V,r-e)),e)}return a}(t,e,0,r)}(r,s,2*a+2);return t.m=dt(kt(i,0,a),kt(i,a,2*a)),t.h&&gt(t),kt(i,2*a)}function bt(t,n){return n===v?function(t){if(typeof l==b){t=unescape(encodeURIComponent(t));const n=new c(t.length);for(let e=0;e<n.length;e++)n[e]=t.charCodeAt(e);return n}return(new l).encode(t)}(t):n}function kt(t,n,e){return t.subarray(n,e)}class zt extends h{constructor({password:t,rawPassword:n,passwordVerification:e,checkPasswordOnly:o}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;if(e.password||e.rawPassword){const n=Mt(e,t.subarray(0,12));if(e.password=e.rawPassword=null,0!=(n[11]^e.passwordVerification))throw new r(tt);t=t.subarray(12)}o?n.error(new r(nt)):n.enqueue(Mt(e,t))}})}}class Ct extends h{constructor({password:t,rawPassword:n,passwordVerification:e}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;let o,r;if(e.password||e.rawPassword){e.password=e.rawPassword=null;const n=et(new c(12));n[11]=e.passwordVerification,o=new c(t.length+n.length),o.set(At(e,n),0),r=12}else o=new c(t.length),r=0;o.set(At(e,t),r),n.enqueue(o)}})}}function It(t,e,o,r){n.assign(t,{password:e,rawPassword:o,passwordVerification:r}),function(t,e,o){const r=[305419896,591751049,878082192];if(n.assign(t,{v:r,C:new F(r[0]),I:new F(r[2])}),o)for(let n=0;n<o.length;n++)Et(t,o[n]);else for(let n=0;n<e.length;n++)Et(t,e.charCodeAt(n))}(t,e,o)}function Mt(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,e[o]);return e}function At(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,n[o]);return e}function Et(t,n){let[,e]=t.v;t.C.append([n]);const r=~t.C.get();e=Pt(o.imul(Pt(e+xt(r)),134775813)+1),t.I.append([e>>>24]);const c=~t.I.get();t.v=[r,e,c]}function Rt(t){const n=2|t.v[2];return xt(o.imul(n,1^n)>>>8)}function xt(t){return 255&t}function Pt(t){return 4294967295&t}function Dt(t){return Boolean(t)&&"object"==typeof t}const Ft=new f;function Ut(t){return Ft.get(t)}const Bt="Invalid uncompressed size",Wt="Codec out of memory",Ot="Invalid CRC32",Vt="deflate-raw",Kt="gzip",Tt=[31,139,8];class _t extends h{constructor(t,{chunkSize:n,CompressionStreamFallback:e,CompressionStream:o}){super({});const{compressed:r,encrypted:c,useCompressionStream:s,zipCrypto:a,computeCrc32:i,level:f,deflate64:w,format:l,compressionMethod:d,inputSize:p}=t,h=this;let y,m,S,g=super.readable;const v=l&&Ut(l),b=qt(s,o,e),k=i&&r&&!w&&!v&&(!c||a)&&Boolean(b);if(c&&!a||!i||k||(y=new U,g=Jt(g,y)),r)if(v)g=Qt(g,Nt(v.CompressionStream,l,{level:f,chunkSize:n,compressionMethod:d,uncompressedSize:p}));else if(k)S=new jt,g=Qt(g,new b(Kt,{level:f,chunkSize:n})),g=Jt(g,S);else try{g=Gt(g,s,{level:f,chunkSize:n},o,e)}catch(t){if(!s&&e)throw nn(t);let n;try{n=new o(Kt)}catch{throw nn(t)}g=Qt(g,n),g=Jt(g,new jt)}c&&(a?g=Jt(g,new Ct(t)):(m=new ht(t),g=Jt(g,m))),Zt(h,g,()=>{c&&!a||!i||(h.crc32=k?S.crc32:new u(y.value.buffer).getUint32(0))})}}class jt extends h{constructor(){let t,n=10,e=new c(0);super({transform(t,r){if(n){const e=o.min(n,t.length);if(n-=e,!(t=t.subarray(e)).length)return}const c=e.length+t.length;if(c<=8)return void(e=B(e,t));const s=c-8,a=o.min(s,e.length);r.enqueue(B(e.subarray(0,a),t.subarray(0,s-a))),e=B(e.subarray(a),t.subarray(s-a))},flush(){const n=W(e);t.crc32=n.getUint32(0,!0),t.uncompressedSize=n.getUint32(4,!0)}}),t=this}}class Ht extends h{constructor(t,{chunkSize:n,DecompressionStreamFallback:e,DecompressionStream:o}){super({});const{zipCrypto:s,encrypted:a,checkCrc32:i,crc32:f,compressed:l,useCompressionStream:d,deflate64:p,format:h,compressionMethod:m,rawBitFlag:S,outputSize:g}=t;let b,k,z,C=super.readable;if(a&&(s?C=Jt(C,new zt(t)):(k=new pt(t),C=Jt(C,k))),l){const t=new Set,s=h&&Ut(h);let a;if(s)C=Qt(C,Nt(s.DecompressionStream,h,{chunkSize:n,compressionMethod:m,rawBitFlag:S,uncompressedSize:g}),t);else{const r=qt(d,o,e);if(i&&!p&&f!==v&&g!==v&&r)try{a=new r(Kt,{chunkSize:n})}catch{a=v}if(!a)try{C=Gt(C,d,{chunkSize:n,deflate64:p},o,e,t)}catch(t){if(p||g===v||!d&&e)throw nn(t);try{a=new o(Kt)}catch{throw nn(t)}}}a?(z=!0,C=function(t,n,e,o,s){const a=n.writable.getWriter(),i=n.readable.getReader(),f=o===v?new F:v;let u,l,d=0,p=!1,h=!1;const m=new y({start(t){l=t},pull(){b()},cancel:t=>(h=!0,b(),i.cancel(t))});return async function(){const n=t.getReader();try{const t=new c(10);for(t.set(Tt),await a.write(t);;){await g(),await a.ready;const{value:t,done:e}=await $t(n,s);if(e)break;await a.write(t)}f&&await a.write(new c(0));const r=new c(8),i=W(r);i.setUint32(0,f?f.get():o,!0),i.setUint32(4,e,!0),p=!0,await a.write(r),await a.close()}catch(t){await Xt(a,t),await Yt(n,t)}}(),async function(){try{for(;;){const{value:t,done:n}=await S();if(n)break;if(d+=t.length,d>e)throw new r(Bt);f&&f.append(t),l.enqueue(t)}h||(h=!0,l.close())}catch(t){!function(t){h||(h=!0,l.error(t),b())}(t),await Yt(i,t)}}(),m;function S(){return i.read().catch(t=>{if(p){if(!f)throw on(t,Ot);if(d!=e)throw on(t,Bt);return{done:!0}}throw tn(t,s)})}function g(){if(!h&&l.desiredSize<=0)return new w(t=>u=t)}function b(){if(u){const t=u;u=v,t()}}}(C,a,g,f,t)):C=function(t,n){const e=t.getReader();return new y({async pull(t){try{const{value:n,done:o}=await e.read();o?t.close():t.enqueue(n)}catch(t){throw await Yt(e,t),tn(t,n)}},cancel:t=>e.cancel(t)})}(C,t)}i&&!z&&(b=new U,C=Jt(C,b)),Zt(this,C,()=>{if(b){const t=new u(b.value.buffer).getUint32(0,!1);if(f!=t)throw new r(Ot)}})}}const Lt=new f;function Zt(t,e,o){e=Jt(e,new h({flush:o})),n.defineProperty(t,"readable",{get:()=>e})}function Nt(t,n,e){if(!t)throw new r("Compression method not supported");return new t(n,e)}function qt(t,n,e){return t&&n?n:e&&e.requiresModule?e:void 0}function Gt(t,n,e,o,r,c){const s=n&&o?o:r||o,a=e.deflate64?"deflate64-raw":Vt;let i;try{i=new s(a,e)}catch(t){if(!n||!r||s==r)throw t;i=new r(a,e)}return Qt(t,i,c)}function Jt(t,n){return function(t){if(t instanceof y)return t;const n=t.getReader();return new y({async pull(t){try{const{value:e,done:o}=await n.read();o?t.close():t.enqueue(e)}catch(t){throw n.cancel(t).catch(()=>{}),t}},cancel:t=>n.cancel(t)})}(t).pipeThrough(n)}function Qt(t,n,e){const o=n.writable.getWriter(),r=t.getReader();return async function(){try{for(;;){await o.ready;const t=await $t(r,e);if(t.done){await o.close();break}await o.write(t.value)}}catch(t){await Xt(o,t),await Yt(r,t)}}(),n.readable}async function Xt(t,n){try{await t.abort(n)}catch{}}async function Yt(t,n){try{await t.cancel(n)}catch{}}function $t(t,n){const e=t.read();return n?e.catch(t=>{throw n.add(t),t}):e}function tn(t,n){return n.has(t)?t:on(t,en(t)?Wt:"Invalid compressed data")}function nn(t){return en(t)?on(t,Wt):t}function en(t){return Dt(t)&&"Z_MEM_ERROR"==t.code}function on(t,n){const e=new r(n);return e.cause=t,e}const rn="data",cn="deflate";class sn extends h{constructor(t,e){super({});const o=this,{codecType:c}=t;let s;c.startsWith(cn)?s=_t:c.startsWith("inflate")&&(s=Ht),o.outputSize=0;let a=0;const i=new s(t,e),f=super.readable,u=new h({transform(t,n){t&&t.length&&(a+=t.length,n.enqueue(t))},flush(){n.assign(o,{inputSize:a})}}),w=new h({transform(n,e){if(n&&n.length&&(e.enqueue(n),o.outputSize+=n.length,t.outputSize!==v&&o.outputSize>t.outputSize))throw new r(Bt)},flush(){const{crc32:t}=i;n.assign(o,{crc32:t,inputSize:a})}});n.defineProperty(o,"readable",{get:()=>f.pipeThrough(u).pipeThrough(i).pipeThrough(w)})}}class an extends h{constructor(t){const o=[];let r=0,s=0;function a(){const n=new c(t);let e=0;for(;e<t;){const r=o[0],c=t-e;r.length<=c?(n.set(r,e),e+=r.length,o.shift()):(n.set(r.subarray(0,c),e),o[0]=r.subarray(c),e+=c)}return r-=t,n}(!e.isFinite(t)||t<1)&&(t=262144),super({transform(n,e){for(o.push(n),r+=n.length;r>t;)s+=t,e.enqueue(a())},flush(t){r&&(s+=r,t.enqueue(function(t,n){const e=new c(n);let o=0;for(const n of t)e.set(n,o),o+=n.length;return e}(o,r)))}}),n.defineProperty(this,"outputSize",{get:()=>s})}}let fn=2;try{typeof navigator!=b&&navigator.hardwareConcurrency&&(fn=navigator.hardwareConcurrency)}catch{}const un=new f,wn=new f,ln=function(){try{return structuredClone(new r)instanceof r}catch{return!1}}();let dn=0;async function pn(t){let n,c,s;try{const{options:a,config:i}=t;if(a.format)try{await async function(t,n){!Ft.has(t)&&n&&function(t,n){const{CompressionStream:e,DecompressionStream:o}=n;if(typeof e!=k&&typeof o!=k)throw new r("Invalid codec module");Ft.set(t,{CompressionStream:e,DecompressionStream:o})}(t,await(import(n)))}(a.format,a.codecURI)}catch(t){if(Dt(t))try{t.codecImportFailed=!0}catch{}throw t}if(i.CompressionStream=self.CompressionStream,i.DecompressionStream=self.DecompressionStream,a.compressed&&!a.format)if(a.useCompressionStream){if(!function(t,n){if(!t)return!1;let e=Lt.get(t);e||(e=new f,Lt.set(t,e));let o=e.get(n);if(o===v){try{new t(n),o=!0}catch{o=!1}e.set(n,o)}return o}(a.codecType.startsWith(cn)?i.CompressionStream:i.DecompressionStream,Vt))try{await self.initModule(t.config)}catch{}}else try{await self.initModule(t.config)}catch{a.useCompressionStream=!0}if(a.encrypted&&!a.zipCrypto)try{await self.initModule(t.config)}catch{}!i.CompressionStreamFallback&&i.CompressionStreamZlib&&(i.CompressionStreamFallback=i.CompressionStreamZlib),!i.DecompressionStreamFallback&&i.DecompressionStreamZlib&&(i.DecompressionStreamFallback=i.DecompressionStreamZlib);const u={highWaterMark:1},l=new y({async pull(t){const n=new w(t=>un.set(dn,t));hn({type:"pull",messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER;const{value:o,done:r}=await n;t.enqueue(o),r&&t.close()}},u);s=new m({async write(t){let n;const o=new w(t=>n=t);wn.set(dn,n),hn({type:rn,value:t,messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER,await o}},u),n=new sn(a,i),c=new an(function(t){return r="string"==typeof(n=r=t.chunkSize)&&n.trim()?e(n):n,e.isInteger(r)&&r>=1?o.max(r,64):262144;var n,r}(i)),await l.pipeThrough(n).pipeThrough(c).pipeTo(s,{preventClose:!0,preventAbort:!0}),await s.getWriter().close();const{crc32:d,inputSize:p,outputSize:h}=n;hn({type:"close",result:{crc32:d,inputSize:p,outputSize:h}})}catch(t){const n=c?c.outputSize:0;if(Dt(t))try{t.outputSize=n}catch{}if(s&&!s.locked)try{await s.getWriter().close()}catch{}yn(t,n)}}function hn(t){const{value:n}=t;if(n)if(n.length)try{t.value=(e=n,e.byteOffset||e.byteLength!=e.buffer.byteLength?new c(e):e).buffer,p(t,[t.value])}catch{p(t)}else p(t);else p(t);var e}function yn(t,n){const{message:e,stack:o,code:c,name:s,outputSize:a,cause:i,codecImportFailed:f}=function(t=new r("Unknown error")){return Dt(t)?t:new r(String(t))}(t),u={message:e,stack:o,code:c,name:s,outputSize:a===v?n:a};if(Dt(i)&&(u.cause={name:i.name,message:i.message,code:i.code}),f&&(u.codecImportFailed=!0),ln)try{return void p({error:u,errorValue:{value:t}})}catch{}p({error:u})}addEventListener("message",({data:t})=>{const{type:n,messageId:e,value:o,done:r}=t;try{if("start"==n&&pn(t),n==rn){const t=un.get(e);un.delete(e),t({value:o||new c,done:r})}if("ack"==n){const t=wn.get(e);wn.delete(e),t()}}catch(t){yn(t)}}),p({type:"ready"});const mn="deflate",Sn="deflate-raw",gn="deflate64-raw",vn="gzip",bn=[mn,Sn,vn],kn=[mn,Sn,vn,gn];let zn,Cn,In,Mn,An;function En(t,n){return-4===n&&(t.code="Z_MEM_ERROR"),t}function Rn(t,n,e={}){if(!(t?bn:kn).includes(n))throw new TypeError("Unsupported format: "+n);if(!zn){const t=new r("WASM module not loaded");throw t.cause=An,t}const s="number"==typeof e.level?e.level:-1,a="number"==typeof e.outBuffer?e.outBuffer:65536,i="number"==typeof e.inBufferSize?e.inBufferSize:65536,f={M:0,in:0,inBufferSize:0,A:0,R:!1};let u,l,d,p,h=!0,S=!1;return function(){try{let e;if(f.M=Cn(a),f.in=Cn(i),f.inBufferSize=i,!f.M||!f.in)throw En(new r("allocation failed"),-4);if(t?(f.P=zn.deflate_process,f.D=zn.deflate_last_consumed,f.F=zn.deflate_end,f.A=zn.deflate_new(),e=n===vn?zn.deflate_init_gzip(f.A,s):n===Sn?zn.deflate_init_raw(f.A,s):zn.deflate_init(f.A,s)):n===gn?(f.P=zn.inflate9_process,f.D=zn.inflate9_last_consumed,f.F=zn.inflate9_end,f.A=zn.inflate9_new(),e=zn.inflate9_init_raw(f.A)):(f.P=zn.inflate_process,f.D=zn.inflate_last_consumed,f.F=zn.inflate_end,f.A=zn.inflate_new(),e=n===Sn?zn.inflate_init_raw(f.A):n===vn?zn.inflate_init_gzip(f.A):zn.inflate_init(f.A)),0!==e)throw En(new r("init failed:"+e),e)}catch(t){throw b(f),t}}(),{readable:new y({start(t){u=t},pull(){h=!1,v()},cancel(t){S=!0,p=t,b(f),l.error(t),v()}},{highWaterMark:0}),writable:new m({start(t){l=t},async write(t){if(h&&await new w(t=>d=t),S)throw p;try{!function(t){const n=new c(Mn.buffer),e=f.P,s=f.D,i=f.M;let u=0;for(;u<t.length;){if(f.R)throw new r("trailing data after the end of the stream");const c=o.min(t.length-u,32768);if((!f.in||f.inBufferSize<c)&&(f.in&&In&&(In(f.in),f.in=0),f.in=Cn(c),f.inBufferSize=c,!f.in))throw En(new r("allocation failed"),-4);n.set(t.subarray(u,u+c),f.in);const w=e(f.A,f.in,c,i,a,0),l=w>>24&255,d=128&l?l-256:l;if(d<0)throw En(new r("process error:"+d),d);const p=16777215&w;p&&g(n.slice(i,i+p));const h=s(f.A);if(1===l)f.R=!0;else if(0===h&&0===p)break;u+=h}}(t)}catch(t){throw b(f),u.error(t),t}},close(){if(S)return;try{!function(){const t=new c(Mn.buffer),n=f.P,e=f.M;for(;;){const o=n(f.A,0,0,e,a,4),c=o>>24&255,s=128&c?c-256:c;if(s<0)throw En(new r("process error:"+s),s);const i=16777215&o;if(i&&g(t.slice(e,e+i)),1===c||0===i)break}}()}catch(t){throw b(f),u.error(t),t}const t=b(f);if(0!==t){const n=En(new r("end error:"+t),t);throw u.error(n),n}u.close()},abort(t){b(f),u.error(t)}},{highWaterMark:1})};function g(t){h=!0,u.enqueue(t)}function v(){if(d){const t=d;d=null,t()}}function b(t){let n=0;return t.A&&t.F&&(n=t.F(t.A)),t.A=0,t.in&&In&&In(t.in),t.in=0,t.M&&In&&In(t.M),t.M=0,n}}class xn{constructor(t=mn,n){return Rn(!0,t,n)}}class Pn{constructor(t=mn,n){return Rn(!1,t,n)}}xn.requiresModule=!0,Pn.requiresModule=!0,xn.supportedFormats=bn,Pn.supportedFormats=kn;const Dn=65536;let Fn,Un;function Bn(t){return new c(t.memory.buffer)}let Wn=!1;!function(t={}){const{init:n,U:e}=t,o=t.CompressionStreamFallback||t.CompressionStreamZlib,r=t.DecompressionStreamFallback||t.DecompressionStreamZlib;e&&(dt=e||G),self.initModule=async t=>{n&&await n(t),o&&(t.CompressionStreamFallback=o),r&&(t.DecompressionStreamFallback=r)}}({CompressionStreamFallback:xn,DecompressionStreamFallback:Pn,U:function(t,n){const e=Fn;let o=e?function(t,n,e){Un||(Un=t.malloc(Dn));const o=Un?t.aes_hmac_new():0;if(o){const r=Bn(t);if(r.set(n,Un),r.set(e,Un+n.length),t.aes_hmac_init(o,Un,n.length,Un+n.length,e.length))return t.aes_hmac_end(o,0),0}return o}(e,t,n):0;if(!o)return G(t,n);const r=Un;return{process(t,n){for(let c=0;c<t.length;c+=Dn){const s=t.subarray(c,c+Dn),a=Bn(e);a.set(s,r),e.aes_hmac_process(o,r,s.length,n?1:0),s.set(a.subarray(r,r+s.length))}},digest:()=>(e.aes_hmac_end(o,r),o=0,Bn(e).slice(r,r+20)),dispose(){o&&(e.aes_hmac_end(o,0),o=0)}}},init:t=>async function(t,{baseURI:n}){if(!Wn)try{await async function(t,n){let e,o;try{try{o=new URL(t,n)}catch{}const r=await fetch(o);e=await r.arrayBuffer()}catch(n){if(!t.startsWith("data:application/wasm;base64,"))throw n;e=function(t){const n=t.split(",")[1],e=atob(n),o=e.length,r=new c(o);for(let t=0;t<o;++t)r[t]=e.charCodeAt(t);return r.buffer}(t)}const s=await WebAssembly.instantiate(e);var a;(function(t){if(zn=t,({malloc:Cn,free:In,memory:Mn}=zn),"function"!=typeof Cn||"function"!=typeof In||!Mn)throw zn=Cn=In=Mn=null,new r("Invalid WASM module")})(s.instance.exports),typeof(a=s.instance.exports).aes_hmac_new==k&&(Fn=a,Un=0)}(t,n),Wn=!0}catch(t){throw function(t){An=t}(t),t}}(t.wasmURI,t)})});
`;
  if (typeof i == "string" && (i = new TextEncoder().encode(i)), e) {
    const s = new Blob([i], { type: o });
    return URL.createObjectURL(s);
  }
  return "data:" + o + ";base64," + (function(s) {
    let f = "";
    const c = s.length;
    let d = 0;
    for (; d + 2 < c; d += 3) {
      const _ = s[d] << 16 | s[d + 1] << 8 | s[d + 2];
      f += wt[_ >> 18 & 63] + wt[_ >> 12 & 63] + wt[_ >> 6 & 63] + wt[63 & _];
    }
    const p = c - d;
    if (p === 1) {
      const _ = s[d] << 16;
      f += wt[_ >> 18 & 63] + wt[_ >> 12 & 63] + "==";
    } else if (p === 2) {
      const _ = s[d] << 16 | s[d + 1] << 8;
      f += wt[_ >> 18 & 63] + wt[_ >> 12 & 63] + wt[_ >> 6 & 63] + "=";
    }
    return f;
  })(i);
} });
function Ft(n, e) {
  const o = new Uint8Array(n.length + e.length);
  return o.set(n), o.set(e, n.length), o;
}
function ac(n) {
  return n.byteOffset || n.byteLength != n.buffer.byteLength ? new Uint8Array(n) : n;
}
function ae(n) {
  return new DataView(n.buffer, n.byteOffset, n.byteLength);
}
function ft(n) {
  return !!n && typeof n == "object";
}
const dn = [[], [], [], [], [], [], [], []];
for (let n = 0; n < 256; n++) {
  let e = n;
  for (let o = 0; o < 8; o++)
    e = e & 1 ? e >>> 1 ^ 3988292384 : e >>> 1;
  dn[0][n] = e;
}
for (let n = 0; n < 256; n++)
  for (let e = 1; e < 8; e++) {
    const o = dn[e - 1][n];
    dn[e][n] = o >>> 8 ^ dn[0][o & 255];
  }
const [Oo, sc, cc, uc, fc, lc, dc, Ec] = dn;
class _n {
  constructor(e) {
    this.crc = e || -1;
  }
  append(e) {
    let o = this.crc | 0;
    const i = e.length | 0;
    let s = 0;
    if (i >= 8 && e.buffer) {
      const f = new DataView(e.buffer, e.byteOffset, i), c = i - 8;
      for (; s <= c; s += 8) {
        const d = o ^ f.getInt32(s, !0), p = f.getInt32(s + 4, !0);
        o = Ec[d & 255] ^ dc[d >>> 8 & 255] ^ lc[d >>> 16 & 255] ^ fc[d >>> 24 & 255] ^ uc[p & 255] ^ cc[p >>> 8 & 255] ^ sc[p >>> 16 & 255] ^ Oo[p >>> 24 & 255];
      }
    }
    for (; s < i; s++)
      o = o >>> 8 ^ Oo[(o ^ e[s]) & 255];
    this.crc = o;
  }
  get() {
    return ~this.crc;
  }
}
class Xi extends TransformStream {
  constructor() {
    let e;
    const o = new _n();
    super({
      transform(i, s) {
        o.append(i), s.enqueue(i);
      },
      flush() {
        const i = new Uint8Array(4);
        new DataView(i.buffer).setUint32(0, o.get()), e.value = i;
      }
    }), e = this;
  }
}
function hc(n) {
  if (typeof TextEncoder == Dt) {
    n = unescape(encodeURIComponent(n));
    const e = new Uint8Array(n.length);
    for (let o = 0; o < e.length; o++)
      e[o] = n.charCodeAt(o);
    return e;
  } else
    return new TextEncoder().encode(n);
}
const ir = 16, pc = 60, Ve = 64, Zt = 20, _c = 16, mc = 56, wc = new Uint8Array([128]), gc = new Uint8Array(1), Lo = new Int32Array([1732584193, 4023233417, 2562383102, 271733878, 3285377520]), yc = 54, Ac = 92, ge = new Uint8Array(256), Y = new Int32Array(256), X = new Int32Array(256), Z = new Int32Array(256), j = new Int32Array(256);
let Po = !1;
function Fr(n, e) {
  vc();
  const o = new Int32Array(pc), i = bc(n, o), s = new Int32Array(ir / 4), f = Zi(e);
  let c = 0, d = 0, p = 0, _ = 0;
  return {
    process(h, y) {
      y && f.update(h, 0, h.length), T(h), y || f.update(h, 0, h.length);
    },
    digest() {
      return f.digest();
    }
  };
  function T(h) {
    const y = new DataView(h.buffer, h.byteOffset, h.byteLength), R = h.length;
    let m = 0;
    for (; m + ir <= R; m += ir)
      A(), y.setInt32(m, y.getInt32(m) ^ s[0]), y.setInt32(m + 4, y.getInt32(m + 4) ^ s[1]), y.setInt32(m + 8, y.getInt32(m + 8) ^ s[2]), y.setInt32(m + 12, y.getInt32(m + 12) ^ s[3]);
    if (m < R) {
      A();
      for (let v = 0; m < R; m++, v++)
        h[m] ^= s[v >> 2] >>> 24 - 8 * (v & 3);
    }
  }
  function A() {
    c = c + 1 | 0, c || (d = d + 1 | 0, d || (p = p + 1 | 0, p || (_ = _ + 1 | 0)));
    let h = In(c) ^ o[0], y = In(d) ^ o[1], R = In(p) ^ o[2], m = In(_) ^ o[3], v = Y[h >>> 24] ^ X[y >>> 16 & 255] ^ Z[R >>> 8 & 255] ^ j[m & 255] ^ o[4], g = Y[y >>> 24] ^ X[R >>> 16 & 255] ^ Z[m >>> 8 & 255] ^ j[h & 255] ^ o[5], b = Y[R >>> 24] ^ X[m >>> 16 & 255] ^ Z[h >>> 8 & 255] ^ j[y & 255] ^ o[6], N = Y[m >>> 24] ^ X[h >>> 16 & 255] ^ Z[y >>> 8 & 255] ^ j[R & 255] ^ o[7];
    h = Y[v >>> 24] ^ X[g >>> 16 & 255] ^ Z[b >>> 8 & 255] ^ j[N & 255] ^ o[8], y = Y[g >>> 24] ^ X[b >>> 16 & 255] ^ Z[N >>> 8 & 255] ^ j[v & 255] ^ o[9], R = Y[b >>> 24] ^ X[N >>> 16 & 255] ^ Z[v >>> 8 & 255] ^ j[g & 255] ^ o[10], m = Y[N >>> 24] ^ X[v >>> 16 & 255] ^ Z[g >>> 8 & 255] ^ j[b & 255] ^ o[11], v = Y[h >>> 24] ^ X[y >>> 16 & 255] ^ Z[R >>> 8 & 255] ^ j[m & 255] ^ o[12], g = Y[y >>> 24] ^ X[R >>> 16 & 255] ^ Z[m >>> 8 & 255] ^ j[h & 255] ^ o[13], b = Y[R >>> 24] ^ X[m >>> 16 & 255] ^ Z[h >>> 8 & 255] ^ j[y & 255] ^ o[14], N = Y[m >>> 24] ^ X[h >>> 16 & 255] ^ Z[y >>> 8 & 255] ^ j[R & 255] ^ o[15], h = Y[v >>> 24] ^ X[g >>> 16 & 255] ^ Z[b >>> 8 & 255] ^ j[N & 255] ^ o[16], y = Y[g >>> 24] ^ X[b >>> 16 & 255] ^ Z[N >>> 8 & 255] ^ j[v & 255] ^ o[17], R = Y[b >>> 24] ^ X[N >>> 16 & 255] ^ Z[v >>> 8 & 255] ^ j[g & 255] ^ o[18], m = Y[N >>> 24] ^ X[v >>> 16 & 255] ^ Z[g >>> 8 & 255] ^ j[b & 255] ^ o[19], v = Y[h >>> 24] ^ X[y >>> 16 & 255] ^ Z[R >>> 8 & 255] ^ j[m & 255] ^ o[20], g = Y[y >>> 24] ^ X[R >>> 16 & 255] ^ Z[m >>> 8 & 255] ^ j[h & 255] ^ o[21], b = Y[R >>> 24] ^ X[m >>> 16 & 255] ^ Z[h >>> 8 & 255] ^ j[y & 255] ^ o[22], N = Y[m >>> 24] ^ X[h >>> 16 & 255] ^ Z[y >>> 8 & 255] ^ j[R & 255] ^ o[23], h = Y[v >>> 24] ^ X[g >>> 16 & 255] ^ Z[b >>> 8 & 255] ^ j[N & 255] ^ o[24], y = Y[g >>> 24] ^ X[b >>> 16 & 255] ^ Z[N >>> 8 & 255] ^ j[v & 255] ^ o[25], R = Y[b >>> 24] ^ X[N >>> 16 & 255] ^ Z[v >>> 8 & 255] ^ j[g & 255] ^ o[26], m = Y[N >>> 24] ^ X[v >>> 16 & 255] ^ Z[g >>> 8 & 255] ^ j[b & 255] ^ o[27], v = Y[h >>> 24] ^ X[y >>> 16 & 255] ^ Z[R >>> 8 & 255] ^ j[m & 255] ^ o[28], g = Y[y >>> 24] ^ X[R >>> 16 & 255] ^ Z[m >>> 8 & 255] ^ j[h & 255] ^ o[29], b = Y[R >>> 24] ^ X[m >>> 16 & 255] ^ Z[h >>> 8 & 255] ^ j[y & 255] ^ o[30], N = Y[m >>> 24] ^ X[h >>> 16 & 255] ^ Z[y >>> 8 & 255] ^ j[R & 255] ^ o[31], h = Y[v >>> 24] ^ X[g >>> 16 & 255] ^ Z[b >>> 8 & 255] ^ j[N & 255] ^ o[32], y = Y[g >>> 24] ^ X[b >>> 16 & 255] ^ Z[N >>> 8 & 255] ^ j[v & 255] ^ o[33], R = Y[b >>> 24] ^ X[N >>> 16 & 255] ^ Z[v >>> 8 & 255] ^ j[g & 255] ^ o[34], m = Y[N >>> 24] ^ X[v >>> 16 & 255] ^ Z[g >>> 8 & 255] ^ j[b & 255] ^ o[35], v = Y[h >>> 24] ^ X[y >>> 16 & 255] ^ Z[R >>> 8 & 255] ^ j[m & 255] ^ o[36], g = Y[y >>> 24] ^ X[R >>> 16 & 255] ^ Z[m >>> 8 & 255] ^ j[h & 255] ^ o[37], b = Y[R >>> 24] ^ X[m >>> 16 & 255] ^ Z[h >>> 8 & 255] ^ j[y & 255] ^ o[38], N = Y[m >>> 24] ^ X[h >>> 16 & 255] ^ Z[y >>> 8 & 255] ^ j[R & 255] ^ o[39];
    let C = 40;
    i > 10 && (h = Y[v >>> 24] ^ X[g >>> 16 & 255] ^ Z[b >>> 8 & 255] ^ j[N & 255] ^ o[40], y = Y[g >>> 24] ^ X[b >>> 16 & 255] ^ Z[N >>> 8 & 255] ^ j[v & 255] ^ o[41], R = Y[b >>> 24] ^ X[N >>> 16 & 255] ^ Z[v >>> 8 & 255] ^ j[g & 255] ^ o[42], m = Y[N >>> 24] ^ X[v >>> 16 & 255] ^ Z[g >>> 8 & 255] ^ j[b & 255] ^ o[43], v = Y[h >>> 24] ^ X[y >>> 16 & 255] ^ Z[R >>> 8 & 255] ^ j[m & 255] ^ o[44], g = Y[y >>> 24] ^ X[R >>> 16 & 255] ^ Z[m >>> 8 & 255] ^ j[h & 255] ^ o[45], b = Y[R >>> 24] ^ X[m >>> 16 & 255] ^ Z[h >>> 8 & 255] ^ j[y & 255] ^ o[46], N = Y[m >>> 24] ^ X[h >>> 16 & 255] ^ Z[y >>> 8 & 255] ^ j[R & 255] ^ o[47], C = 48), i > 12 && (h = Y[v >>> 24] ^ X[g >>> 16 & 255] ^ Z[b >>> 8 & 255] ^ j[N & 255] ^ o[48], y = Y[g >>> 24] ^ X[b >>> 16 & 255] ^ Z[N >>> 8 & 255] ^ j[v & 255] ^ o[49], R = Y[b >>> 24] ^ X[N >>> 16 & 255] ^ Z[v >>> 8 & 255] ^ j[g & 255] ^ o[50], m = Y[N >>> 24] ^ X[v >>> 16 & 255] ^ Z[g >>> 8 & 255] ^ j[b & 255] ^ o[51], v = Y[h >>> 24] ^ X[y >>> 16 & 255] ^ Z[R >>> 8 & 255] ^ j[m & 255] ^ o[52], g = Y[y >>> 24] ^ X[R >>> 16 & 255] ^ Z[m >>> 8 & 255] ^ j[h & 255] ^ o[53], b = Y[R >>> 24] ^ X[m >>> 16 & 255] ^ Z[h >>> 8 & 255] ^ j[y & 255] ^ o[54], N = Y[m >>> 24] ^ X[h >>> 16 & 255] ^ Z[y >>> 8 & 255] ^ j[R & 255] ^ o[55], C = 56), s[0] = (ge[v >>> 24] << 24 | ge[g >>> 16 & 255] << 16 | ge[b >>> 8 & 255] << 8 | ge[N & 255]) ^ o[C], s[1] = (ge[g >>> 24] << 24 | ge[b >>> 16 & 255] << 16 | ge[N >>> 8 & 255] << 8 | ge[v & 255]) ^ o[C + 1], s[2] = (ge[b >>> 24] << 24 | ge[N >>> 16 & 255] << 16 | ge[v >>> 8 & 255] << 8 | ge[g & 255]) ^ o[C + 2], s[3] = (ge[N >>> 24] << 24 | ge[v >>> 16 & 255] << 16 | ge[g >>> 8 & 255] << 8 | ge[b & 255]) ^ o[C + 3];
  }
}
function Rc(n, e, o, i) {
  const s = Zi(n), f = new Uint8Array(i), c = new Uint8Array(e.length + 4), d = new DataView(c.buffer);
  c.set(e);
  for (let p = 1, _ = 0; _ < i; p++, _ += Zt) {
    d.setUint32(e.length, p), s.update(c, 0, c.length);
    let T = s.digest();
    const A = T.slice();
    for (let h = 1; h < o; h++) {
      s.update(T, 0, Zt), T = s.digest();
      for (let y = 0; y < Zt; y++)
        A[y] ^= T[y];
    }
    f.set(A.subarray(0, Math.min(Zt, i - _)), _);
  }
  return f;
}
function Zi(n) {
  const e = Tc(), o = new Uint8Array(Ve), i = new Uint8Array(Ve);
  n.length > Ve && (e.update(n, 0, n.length), n = e.digest());
  for (let s = 0; s < Ve; s++) {
    const f = s < n.length ? n[s] : 0;
    o[s] = f ^ yc, i[s] = f ^ Ac;
  }
  return e.update(o, 0, Ve), {
    update(s, f, c) {
      e.update(s, f, c);
    },
    digest() {
      const s = e.digest();
      e.update(i, 0, Ve), e.update(s, 0, Zt);
      const f = e.digest();
      return e.update(o, 0, Ve), f;
    }
  };
}
function Tc() {
  const n = new Int32Array(Lo), e = new Int32Array(_c), o = new Uint8Array(Ve), i = new DataView(o.buffer), s = new Uint8Array(8);
  let f = 0, c = 0;
  return {
    update: d,
    digest: p
  };
  function d(T, A, h) {
    const y = A + h;
    if (c += h, f) {
      for (; A < y && f < Ve; )
        o[f++] = T[A++];
      f == Ve && (_(i, 0), f = 0);
    }
    if (A + Ve <= y) {
      const R = new DataView(T.buffer, T.byteOffset, T.byteLength);
      for (; A + Ve <= y; A += Ve)
        _(R, A);
    }
    for (; A < y; )
      o[f++] = T[A++];
  }
  function p() {
    const T = c * 8, A = Math.floor(T / 4294967296), h = T >>> 0;
    for (d(wc, 0, 1); f != mc; )
      d(gc, 0, 1);
    s[0] = A >>> 24, s[1] = A >>> 16, s[2] = A >>> 8, s[3] = A, s[4] = h >>> 24, s[5] = h >>> 16, s[6] = h >>> 8, s[7] = h, d(s, 0, 8);
    const y = new Uint8Array(Zt), R = new DataView(y.buffer);
    for (let m = 0; m < n.length; m++)
      R.setInt32(4 * m, n[m]);
    return n.set(Lo), f = 0, c = 0, y;
  }
  function _(T, A) {
    for (let b = 0; b < 16; b++)
      e[b] = T.getInt32(A + 4 * b);
    let h = n[0], y = n[1], R = n[2], m = n[3], v = n[4], g;
    for (let b = 0; b < 15; b += 5)
      v = (h << 5 | h >>> 27) + ((R ^ m) & y ^ m) + v + 1518500249 + e[b] | 0, y = y << 30 | y >>> 2, m = (v << 5 | v >>> 27) + ((y ^ R) & h ^ R) + m + 1518500249 + e[b + 1] | 0, h = h << 30 | h >>> 2, R = (m << 5 | m >>> 27) + ((h ^ y) & v ^ y) + R + 1518500249 + e[b + 2] | 0, v = v << 30 | v >>> 2, y = (R << 5 | R >>> 27) + ((v ^ h) & m ^ h) + y + 1518500249 + e[b + 3] | 0, m = m << 30 | m >>> 2, h = (y << 5 | y >>> 27) + ((m ^ v) & R ^ v) + h + 1518500249 + e[b + 4] | 0, R = R << 30 | R >>> 2;
    v = (h << 5 | h >>> 27) + ((R ^ m) & y ^ m) + v + 1518500249 + e[15] | 0, y = y << 30 | y >>> 2, g = e[13] ^ e[8] ^ e[2] ^ e[0], g = g << 1 | g >>> 31, e[0] = g, m = (v << 5 | v >>> 27) + ((y ^ R) & h ^ R) + m + 1518500249 + g | 0, h = h << 30 | h >>> 2, g = e[14] ^ e[9] ^ e[3] ^ e[1], g = g << 1 | g >>> 31, e[1] = g, R = (m << 5 | m >>> 27) + ((h ^ y) & v ^ y) + R + 1518500249 + g | 0, v = v << 30 | v >>> 2, g = e[15] ^ e[10] ^ e[4] ^ e[2], g = g << 1 | g >>> 31, e[2] = g, y = (R << 5 | R >>> 27) + ((v ^ h) & m ^ h) + y + 1518500249 + g | 0, m = m << 30 | m >>> 2, g = e[0] ^ e[11] ^ e[5] ^ e[3], g = g << 1 | g >>> 31, e[3] = g, h = (y << 5 | y >>> 27) + ((m ^ v) & R ^ v) + h + 1518500249 + g | 0, R = R << 30 | R >>> 2;
    for (let b = 20; b < 40; b += 5)
      g = e[b - 3 & 15] ^ e[b - 8 & 15] ^ e[b - 14 & 15] ^ e[b & 15], g = g << 1 | g >>> 31, e[b & 15] = g, v = (h << 5 | h >>> 27) + (y ^ R ^ m) + v + 1859775393 + g | 0, y = y << 30 | y >>> 2, g = e[b - 2 & 15] ^ e[b - 7 & 15] ^ e[b - 13 & 15] ^ e[b + 1 & 15], g = g << 1 | g >>> 31, e[b + 1 & 15] = g, m = (v << 5 | v >>> 27) + (h ^ y ^ R) + m + 1859775393 + g | 0, h = h << 30 | h >>> 2, g = e[b - 1 & 15] ^ e[b - 6 & 15] ^ e[b - 12 & 15] ^ e[b + 2 & 15], g = g << 1 | g >>> 31, e[b + 2 & 15] = g, R = (m << 5 | m >>> 27) + (v ^ h ^ y) + R + 1859775393 + g | 0, v = v << 30 | v >>> 2, g = e[b & 15] ^ e[b - 5 & 15] ^ e[b - 11 & 15] ^ e[b + 3 & 15], g = g << 1 | g >>> 31, e[b + 3 & 15] = g, y = (R << 5 | R >>> 27) + (m ^ v ^ h) + y + 1859775393 + g | 0, m = m << 30 | m >>> 2, g = e[b + 1 & 15] ^ e[b - 4 & 15] ^ e[b - 10 & 15] ^ e[b + 4 & 15], g = g << 1 | g >>> 31, e[b + 4 & 15] = g, h = (y << 5 | y >>> 27) + (R ^ m ^ v) + h + 1859775393 + g | 0, R = R << 30 | R >>> 2;
    for (let b = 40; b < 60; b += 5)
      g = e[b - 3 & 15] ^ e[b - 8 & 15] ^ e[b - 14 & 15] ^ e[b & 15], g = g << 1 | g >>> 31, e[b & 15] = g, v = (h << 5 | h >>> 27) + (y & R | (y | R) & m) + v + 2400959708 + g | 0, y = y << 30 | y >>> 2, g = e[b - 2 & 15] ^ e[b - 7 & 15] ^ e[b - 13 & 15] ^ e[b + 1 & 15], g = g << 1 | g >>> 31, e[b + 1 & 15] = g, m = (v << 5 | v >>> 27) + (h & y | (h | y) & R) + m + 2400959708 + g | 0, h = h << 30 | h >>> 2, g = e[b - 1 & 15] ^ e[b - 6 & 15] ^ e[b - 12 & 15] ^ e[b + 2 & 15], g = g << 1 | g >>> 31, e[b + 2 & 15] = g, R = (m << 5 | m >>> 27) + (v & h | (v | h) & y) + R + 2400959708 + g | 0, v = v << 30 | v >>> 2, g = e[b & 15] ^ e[b - 5 & 15] ^ e[b - 11 & 15] ^ e[b + 3 & 15], g = g << 1 | g >>> 31, e[b + 3 & 15] = g, y = (R << 5 | R >>> 27) + (m & v | (m | v) & h) + y + 2400959708 + g | 0, m = m << 30 | m >>> 2, g = e[b + 1 & 15] ^ e[b - 4 & 15] ^ e[b - 10 & 15] ^ e[b + 4 & 15], g = g << 1 | g >>> 31, e[b + 4 & 15] = g, h = (y << 5 | y >>> 27) + (R & m | (R | m) & v) + h + 2400959708 + g | 0, R = R << 30 | R >>> 2;
    for (let b = 60; b < 80; b += 5)
      g = e[b - 3 & 15] ^ e[b - 8 & 15] ^ e[b - 14 & 15] ^ e[b & 15], g = g << 1 | g >>> 31, e[b & 15] = g, v = (h << 5 | h >>> 27) + (y ^ R ^ m) + v + 3395469782 + g | 0, y = y << 30 | y >>> 2, g = e[b - 2 & 15] ^ e[b - 7 & 15] ^ e[b - 13 & 15] ^ e[b + 1 & 15], g = g << 1 | g >>> 31, e[b + 1 & 15] = g, m = (v << 5 | v >>> 27) + (h ^ y ^ R) + m + 3395469782 + g | 0, h = h << 30 | h >>> 2, g = e[b - 1 & 15] ^ e[b - 6 & 15] ^ e[b - 12 & 15] ^ e[b + 2 & 15], g = g << 1 | g >>> 31, e[b + 2 & 15] = g, R = (m << 5 | m >>> 27) + (v ^ h ^ y) + R + 3395469782 + g | 0, v = v << 30 | v >>> 2, g = e[b & 15] ^ e[b - 5 & 15] ^ e[b - 11 & 15] ^ e[b + 3 & 15], g = g << 1 | g >>> 31, e[b + 3 & 15] = g, y = (R << 5 | R >>> 27) + (m ^ v ^ h) + y + 3395469782 + g | 0, m = m << 30 | m >>> 2, g = e[b + 1 & 15] ^ e[b - 4 & 15] ^ e[b - 10 & 15] ^ e[b + 4 & 15], g = g << 1 | g >>> 31, e[b + 4 & 15] = g, h = (y << 5 | y >>> 27) + (R ^ m ^ v) + h + 3395469782 + g | 0, R = R << 30 | R >>> 2;
    n[0] = n[0] + h | 0, n[1] = n[1] + y | 0, n[2] = n[2] + R | 0, n[3] = n[3] + m | 0, n[4] = n[4] + v | 0;
  }
}
function vc() {
  if (!Po) {
    let n = 1, e = 1;
    do
      n = (n ^ n << 1 ^ (n & 128 ? 27 : 0)) & 255, e = (e ^ e << 1) & 255, e = (e ^ e << 2) & 255, e = (e ^ e << 4) & 255, e & 128 && (e ^= 9), ge[n] = (e ^ (e << 1 | e >> 7) ^ (e << 2 | e >> 6) ^ (e << 3 | e >> 5) ^ (e << 4 | e >> 4) ^ 99) & 255;
    while (n != 1);
    ge[0] = 99;
    for (let o = 0; o < 256; o++) {
      const i = ge[o], s = ji(i), f = s << 24 | i << 16 | i << 8 | s ^ i;
      Y[o] = f, X[o] = f >>> 8 | f << 24, Z[o] = f >>> 16 | f << 16, j[o] = f >>> 24 | f << 8;
    }
    Po = !0;
  }
}
function bc(n, e) {
  const o = n.length >> 2, i = o + 6, s = 4 * (i + 1);
  let f = 1;
  for (let c = 0; c < o; c++)
    e[c] = n[4 * c] << 24 | n[4 * c + 1] << 16 | n[4 * c + 2] << 8 | n[4 * c + 3];
  for (let c = o; c < s; c++) {
    let d = e[c - 1];
    c % o == 0 ? (d = Co(d << 8 | d >>> 24) ^ f << 24, f = ji(f)) : o > 6 && c % o == 4 && (d = Co(d)), e[c] = e[c - o] ^ d;
  }
  return i;
}
function Co(n) {
  return ge[n >>> 24] << 24 | ge[n >>> 16 & 255] << 16 | ge[n >>> 8 & 255] << 8 | ge[n & 255];
}
function In(n) {
  return n << 24 | (n & 65280) << 8 | n >>> 8 & 65280 | n >>> 24;
}
function ji(n) {
  return (n << 1 ^ (n >> 7) * 27) & 255;
}
const Sc = typeof crypto != Dt && typeof crypto.getRandomValues == Pe, Vi = "Invalid password", Ic = "Invalid authentication code", Mr = "zipjs-abort-check-password", Nc = "Crypto API not supported";
function Ki(n) {
  if (Sc)
    return crypto.getRandomValues(n);
  throw new Error(Nc);
}
const Ur = 16, Dc = "raw", qi = { name: "PBKDF2" }, Oc = { name: "HMAC" }, Lc = "SHA-1", Ji = 1e3, Pc = Object.assign({ hash: Oc }, qi), Cc = Object.assign({ iterations: Ji, hash: { name: Lc } }, qi), Fc = ["deriveBits"], mn = [8, 12, 16], Mc = [16, 24, 32], It = 10, Er = 2, Qi = typeof crypto != Dt, wn = Qi && crypto.subtle, Uc = Qi && typeof wn != Dt;
let Fo = Uc && typeof wn.importKey == Pe && typeof wn.deriveBits == Pe, $i = Fr;
class xc extends TransformStream {
  constructor({ password: e, rawPassword: o, encryptionStrength: i, checkPasswordOnly: s, checkAuthenticationCode: f = !0 }) {
    const c = {};
    super({
      start() {
        ea(c, e, o, i);
      },
      async transform(d, p) {
        const {
          password: _,
          strength: T,
          resolveReady: A,
          ready: h
        } = c;
        if (_ ? (await Hc(c, T, _, Ke(d, 0, mn[T] + Er)), d = Ke(d, mn[T] + Er), s ? (gn(c), p.error(new Error(Mr))) : A()) : await h, c.discarded)
          return;
        const y = new Uint8Array(d.length - It - (d.length - It) % Ur);
        p.enqueue(na(c, d, y, 0, It, !0));
      },
      async flush(d) {
        const {
          engine: p,
          pendingInput: _,
          ready: T
        } = c;
        if (p) {
          if (await T, c.discarded)
            return;
          const A = Ke(_, _.length - It), h = new Uint8Array(Ke(_, 0, _.length - It));
          p.process(h, !0);
          const y = p.digest();
          let R = _.length < It ? 1 : 0;
          for (let m = 0; m < It; m++)
            R |= y[m] ^ A[m];
          if (R && f) {
            d.error(new Error(Ic));
            return;
          }
          d.enqueue(h);
        }
      }
    }), ta(this, c);
  }
}
class kc extends TransformStream {
  constructor({ password: e, rawPassword: o, encryptionStrength: i }) {
    const s = {};
    super({
      start() {
        ea(s, e, o, i);
      },
      async transform(f, c) {
        const {
          password: d,
          strength: p,
          resolveReady: _,
          ready: T
        } = s;
        let A = nt;
        if (d ? (A = await zc(s, p, d), _()) : await T, s.discarded)
          return;
        const h = new Uint8Array(A.length + f.length - f.length % Ur);
        h.set(A, 0), c.enqueue(na(s, f, h, A.length, 0, !1));
      },
      async flush(f) {
        const {
          engine: c,
          pendingInput: d,
          ready: p
        } = s;
        if (c) {
          if (await p, s.discarded)
            return;
          const _ = new Uint8Array(d);
          c.process(_, !1);
          const T = Ke(c.digest(), 0, It);
          f.enqueue(Ft(_, T));
        }
      }
    }), ta(this, s);
  }
}
function Bc(n) {
  $i = n || Fr;
}
function ea(n, e, o, i) {
  Object.assign(n, {
    ready: new Promise((s) => n.resolveReady = s),
    password: Gc(e, o),
    strength: i - 1,
    pendingInput: nt,
    discarded: !1
  });
}
function ta(n, e) {
  const o = n.readable.getReader(), i = new ReadableStream({
    async pull(s) {
      try {
        const { value: f, done: c } = await o.read();
        c ? s.close() : s.enqueue(f);
      } catch (f) {
        throw gn(e), o.cancel(f).catch(() => {
        }), f;
      }
    },
    cancel(s) {
      return gn(e), o.cancel(s);
    }
  });
  Object.defineProperty(n, "readable", {
    get() {
      return i;
    }
  });
}
function na(n, e, o, i, s, f) {
  const {
    engine: c,
    pendingInput: d
  } = n;
  d.length && (e = Ft(d, e));
  const p = e.length - s, _ = p - p % Ur;
  if (o = Yc(o, i + _), _) {
    const T = Ke(o, i, i + _);
    T.set(Ke(e, 0, _)), c.process(T, f);
  }
  return n.pendingInput = Ke(e, _), o;
}
async function Hc(n, e, o, i) {
  const s = await ra(n, e, o, Ke(i, 0, mn[e])), f = Ke(i, mn[e]);
  if (s[0] != f[0] || s[1] != f[1])
    throw gn(n), new Error(Vi);
}
function gn(n) {
  const { engine: e } = n;
  n.discarded = !0, e && e.dispose && e.dispose();
}
async function zc(n, e, o) {
  const i = Ki(new Uint8Array(mn[e])), s = await ra(n, e, o, i);
  return Ft(i, s);
}
async function ra(n, e, o, i) {
  n.password = null;
  const s = Mc[e], f = await Wc(o, i, s * 2 + Er);
  return n.engine = $i(Ke(f, 0, s), Ke(f, s, s * 2)), n.discarded && gn(n), Ke(f, s * 2);
}
async function Wc(n, e, o) {
  if (Fo)
    try {
      const i = await wn.importKey(Dc, n, Pc, !1, Fc);
      return new Uint8Array(await wn.deriveBits(Object.assign({ salt: e }, Cc), i, o * 8));
    } catch {
      Fo = !1;
    }
  return Rc(n, e, Ji, o);
}
function Gc(n, e) {
  return e === P ? hc(n) : e;
}
function Yc(n, e) {
  if (e && e > n.length) {
    const o = n;
    n = new Uint8Array(e), n.set(o, 0);
  }
  return n;
}
function Ke(n, e, o) {
  return n.subarray(e, o);
}
const Vt = 12;
class Xc extends TransformStream {
  constructor({ password: e, rawPassword: o, passwordVerification: i, checkPasswordOnly: s }) {
    super({
      start() {
        oa(this, e, o, i);
      },
      transform(f, c) {
        const d = this;
        if (d.password || d.rawPassword) {
          const p = Mo(d, f.subarray(0, Vt));
          if (d.password = d.rawPassword = null, (p[Vt - 1] ^ d.passwordVerification) != 0)
            throw new Error(Vi);
          f = f.subarray(Vt);
        }
        s ? c.error(new Error(Mr)) : c.enqueue(Mo(d, f));
      }
    });
  }
}
class Zc extends TransformStream {
  constructor({ password: e, rawPassword: o, passwordVerification: i }) {
    super({
      start() {
        oa(this, e, o, i);
      },
      transform(s, f) {
        const c = this;
        let d, p;
        if (c.password || c.rawPassword) {
          c.password = c.rawPassword = null;
          const _ = Ki(new Uint8Array(Vt));
          _[Vt - 1] = c.passwordVerification, d = new Uint8Array(s.length + _.length), d.set(Uo(c, _), 0), p = Vt;
        } else
          d = new Uint8Array(s.length), p = 0;
        d.set(Uo(c, s), p), f.enqueue(d);
      }
    });
  }
}
function oa(n, e, o, i) {
  Object.assign(n, {
    password: e,
    rawPassword: o,
    passwordVerification: i
  }), jc(n, e, o);
}
function Mo(n, e) {
  const o = new Uint8Array(e.length);
  for (let i = 0; i < e.length; i++)
    o[i] = ia(n) ^ e[i], kn(n, o[i]);
  return o;
}
function Uo(n, e) {
  const o = new Uint8Array(e.length);
  for (let i = 0; i < e.length; i++)
    o[i] = ia(n) ^ e[i], kn(n, e[i]);
  return o;
}
function jc(n, e, o) {
  const i = [305419896, 591751049, 878082192];
  if (Object.assign(n, {
    cryptoKeys: i,
    crcKey0: new _n(i[0]),
    crcKey2: new _n(i[2])
  }), o)
    for (let s = 0; s < o.length; s++)
      kn(n, o[s]);
  else
    for (let s = 0; s < e.length; s++)
      kn(n, e.charCodeAt(s));
}
function kn(n, e) {
  let [, o] = n.cryptoKeys;
  n.crcKey0.append([e]);
  const i = ~n.crcKey0.get();
  o = xo(Math.imul(xo(o + aa(i)), 134775813) + 1), n.crcKey2.append([o >>> 24]);
  const s = ~n.crcKey2.get();
  n.cryptoKeys = [i, o, s];
}
function ia(n) {
  const e = n.cryptoKeys[2] | 2;
  return aa(Math.imul(e, e ^ 1) >>> 8);
}
function aa(n) {
  return n & 255;
}
function xo(n) {
  return n & 4294967295;
}
function Jt(n) {
  if (n instanceof ReadableStream)
    return n;
  const e = n.getReader();
  return new ReadableStream({
    async pull(o) {
      try {
        const { value: i, done: s } = await e.read();
        s ? o.close() : o.enqueue(i);
      } catch (i) {
        throw e.cancel(i).catch(() => {
        }), i;
      }
    },
    cancel(o) {
      return e.cancel(o);
    }
  });
}
function hr(n, e) {
  n = Jt(n);
  const o = {};
  if (Vc())
    return new Response(n).blob().then((s) => s);
  const i = [];
  return n.pipeTo(new WritableStream({
    write(s) {
      i.push(s);
    }
  })).then(() => new Blob(i, o));
}
function Vc() {
  return typeof Blob.prototype.stream != Pe || new Blob([]).stream() instanceof ReadableStream;
}
function Kc(n) {
  if (n instanceof WritableStream)
    return n;
  const e = n.getWriter();
  return new WritableStream({
    write(o) {
      return e.write(o);
    },
    close() {
      return e.close();
    },
    abort(o) {
      return e.abort(o);
    }
  });
}
const qc = "Invalid codec module", pr = "Compression method not supported", Jc = /* @__PURE__ */ new Map(), xr = /* @__PURE__ */ new Map();
function Qc(n) {
  return Jc.get(n);
}
function sa(n) {
  return xr.get(n);
}
function $c(n, e) {
  const { CompressionStream: o, DecompressionStream: i } = e;
  if (typeof o != Pe && typeof i != Pe)
    throw new Error(qc);
  xr.set(n, { CompressionStream: o, DecompressionStream: i });
}
async function eu(n, e) {
  !xr.has(n) && e && $c(n, await import(
    /* webpackIgnore: true */
    /* @vite-ignore */
    e
  ));
}
const Bn = "Invalid uncompressed size", tu = "Invalid compressed data", ca = "Codec out of memory", ua = "Invalid CRC32", nu = "Z_MEM_ERROR", fa = "deflate-raw", ru = "deflate64-raw", Hn = "gzip", la = 10, _r = 8, ou = [31, 139, 8];
class iu extends TransformStream {
  constructor(e, { chunkSize: o, CompressionStreamFallback: i, CompressionStream: s }) {
    super({});
    const { compressed: f, encrypted: c, useCompressionStream: d, zipCrypto: p, computeCrc32: _, level: T, deflate64: A, format: h, compressionMethod: y, inputSize: R } = e, m = this;
    let v, g, b, N = super.readable;
    const C = h && sa(h), L = ha(d, s, i), x = _ && f && !A && !C && (!c || p) && !!L;
    if ((!c || p) && _ && !x && (v = new Xi(), N = Rt(N, v)), f)
      if (C)
        N = En(N, Ea(C.CompressionStream, h, { level: T, chunkSize: o, compressionMethod: y, uncompressedSize: R }));
      else if (x)
        b = new ko(), N = En(N, new L(Hn, { level: T, chunkSize: o })), N = Rt(N, b);
      else
        try {
          N = pa(N, d, { level: T, chunkSize: o }, s, i);
        } catch (B) {
          if (!d && i)
            throw Wn(B);
          let $;
          try {
            $ = new s(Hn);
          } catch {
            throw Wn(B);
          }
          N = En(N, $), N = Rt(N, new ko());
        }
    c && (p ? N = Rt(N, new Zc(e)) : (g = new kc(e), N = Rt(N, g))), da(m, N, () => {
      (!c || p) && _ && (m.crc32 = x ? b.crc32 : new DataView(v.value.buffer).getUint32(0));
    });
  }
}
class ko extends TransformStream {
  constructor() {
    let e, o = la, i = new Uint8Array(0);
    super({
      transform(s, f) {
        if (o) {
          const _ = Math.min(o, s.length);
          if (o -= _, s = s.subarray(_), !s.length)
            return;
        }
        const c = i.length + s.length;
        if (c <= _r) {
          i = Ft(i, s);
          return;
        }
        const d = c - _r, p = Math.min(d, i.length);
        f.enqueue(Ft(
          i.subarray(0, p),
          s.subarray(0, d - p)
        )), i = Ft(
          i.subarray(p),
          s.subarray(d - p)
        );
      },
      flush() {
        const s = ae(i);
        e.crc32 = s.getUint32(0, !0), e.uncompressedSize = s.getUint32(4, !0);
      }
    }), e = this;
  }
}
function au(n, e, o, i, s) {
  const f = e.writable.getWriter(), c = e.readable.getReader(), d = i === P ? new _n() : P;
  let p = 0, _ = !1, T = !1, A, h;
  const y = new ReadableStream({
    start(C) {
      h = C;
    },
    pull() {
      b();
    },
    cancel(C) {
      return T = !0, b(), c.cancel(C);
    }
  });
  return R(), m(), y;
  async function R() {
    const C = n.getReader();
    try {
      const L = new Uint8Array(la);
      for (L.set(ou), await f.write(L); ; ) {
        await g(), await f.ready;
        const { value: $, done: se } = await ma(C, s);
        if (se)
          break;
        await f.write($);
      }
      d && await f.write(new Uint8Array(0));
      const x = new Uint8Array(_r), B = ae(x);
      B.setUint32(0, d ? d.get() : i, !0), B.setUint32(4, o, !0), _ = !0, await f.write(x), await f.close();
    } catch (L) {
      await _a(f, L), await zn(C, L);
    }
  }
  async function m() {
    try {
      for (; ; ) {
        const { value: C, done: L } = await v();
        if (L)
          break;
        if (p += C.length, p > o)
          throw new Error(Bn);
        d && d.append(C), h.enqueue(C);
      }
      T || (T = !0, h.close());
    } catch (C) {
      N(C), await zn(c, C);
    }
  }
  function v() {
    return c.read().catch((C) => {
      if (_) {
        if (!d)
          throw Gn(C, ua);
        if (p != o)
          throw Gn(C, Bn);
        return { done: !0 };
      }
      throw wa(C, s);
    });
  }
  function g() {
    if (!T && h.desiredSize <= 0)
      return new Promise((C) => A = C);
  }
  function b() {
    if (A) {
      const C = A;
      A = P, C();
    }
  }
  function N(C) {
    T || (T = !0, h.error(C), b());
  }
}
class su extends TransformStream {
  constructor(e, { chunkSize: o, DecompressionStreamFallback: i, DecompressionStream: s }) {
    super({});
    const { zipCrypto: f, encrypted: c, checkCrc32: d, crc32: p, compressed: _, useCompressionStream: T, deflate64: A, format: h, compressionMethod: y, rawBitFlag: R, outputSize: m } = e;
    let v, g, b, N = super.readable;
    if (c && (f ? N = Rt(N, new Xc(e)) : (g = new xc(e), N = Rt(N, g))), _) {
      const C = /* @__PURE__ */ new Set(), L = h && sa(h);
      let x;
      if (L)
        N = En(N, Ea(L.DecompressionStream, h, { chunkSize: o, compressionMethod: y, rawBitFlag: R, uncompressedSize: m }), C);
      else {
        const B = ha(T, s, i);
        if (d && !A && p !== P && m !== P && B)
          try {
            x = new B(Hn, { chunkSize: o });
          } catch {
            x = P;
          }
        if (!x)
          try {
            N = pa(N, T, { chunkSize: o, deflate64: A }, s, i, C);
          } catch ($) {
            if (A || m === P || !T && i)
              throw Wn($);
            try {
              x = new s(Hn);
            } catch {
              throw Wn($);
            }
          }
      }
      x ? (b = !0, N = au(N, x, m, p, C)) : N = fu(N, C);
    }
    d && !b && (v = new Xi(), N = Rt(N, v)), da(this, N, () => {
      if (v) {
        const C = new DataView(v.value.buffer).getUint32(0, !1);
        if (p != C)
          throw new Error(ua);
      }
    });
  }
}
const Bo = /* @__PURE__ */ new Map();
function cu(n, e) {
  if (!n)
    return !1;
  let o = Bo.get(n);
  o || (o = /* @__PURE__ */ new Map(), Bo.set(n, o));
  let i = o.get(e);
  if (i === P) {
    try {
      new n(e), i = !0;
    } catch {
      i = !1;
    }
    o.set(e, i);
  }
  return i;
}
function uu(n) {
  return cu(n, fa);
}
function da(n, e, o) {
  e = Rt(e, new TransformStream({ flush: o })), Object.defineProperty(n, "readable", {
    get() {
      return e;
    }
  });
}
function Ea(n, e, o) {
  if (!n)
    throw new Error(pr);
  return new n(e, o);
}
function ha(n, e, o) {
  if (n && e)
    return e;
  if (o && o.requiresModule)
    return o;
}
function pa(n, e, o, i, s, f) {
  const c = e && i ? i : s || i, d = o.deflate64 ? ru : fa;
  let p;
  try {
    p = new c(d, o);
  } catch (_) {
    if (e && s && c != s)
      p = new s(d, o);
    else
      throw _;
  }
  return En(n, p, f);
}
function Rt(n, e) {
  return Jt(n).pipeThrough(e);
}
function En(n, e, o) {
  const i = e.writable.getWriter(), s = n.getReader();
  return f(), e.readable;
  async function f() {
    try {
      for (; ; ) {
        await i.ready;
        const c = await ma(s, o);
        if (c.done) {
          await i.close();
          break;
        }
        await i.write(c.value);
      }
    } catch (c) {
      await _a(i, c), await zn(s, c);
    }
  }
}
async function _a(n, e) {
  try {
    await n.abort(e);
  } catch {
  }
}
async function zn(n, e) {
  try {
    await n.cancel(e);
  } catch {
  }
}
function ma(n, e) {
  const o = n.read();
  return e ? o.catch((i) => {
    throw e.add(i), i;
  }) : o;
}
function wa(n, e) {
  return e.has(n) ? n : Gn(n, ga(n) ? ca : tu);
}
function Wn(n) {
  return ga(n) ? Gn(n, ca) : n;
}
function ga(n) {
  return ft(n) && n.code == nu;
}
function Gn(n, e) {
  const o = new Error(e);
  return o.cause = n, o;
}
function fu(n, e) {
  const o = n.getReader();
  return new ReadableStream({
    async pull(i) {
      try {
        const { value: s, done: f } = await o.read();
        f ? i.close() : i.enqueue(s);
      } catch (s) {
        throw await zn(o, s), wa(s, e);
      }
    },
    cancel(i) {
      return o.cancel(i);
    }
  });
}
const lu = 256 * 1024, du = "message", Eu = "start", hu = "pull", Ho = "data", pu = "ack", _u = "close", ya = "deflate", Aa = "inflate";
class mu extends TransformStream {
  constructor(e, o) {
    super({});
    const i = this, { codecType: s } = e;
    let f;
    s.startsWith(ya) ? f = iu : s.startsWith(Aa) && (f = su), i.outputSize = 0;
    let c = 0;
    const d = new f(e, o), p = super.readable, _ = new TransformStream({
      transform(A, h) {
        A && A.length && (c += A.length, h.enqueue(A));
      },
      flush() {
        Object.assign(i, {
          inputSize: c
        });
      }
    }), T = new TransformStream({
      transform(A, h) {
        if (A && A.length && (h.enqueue(A), i.outputSize += A.length, e.outputSize !== P && i.outputSize > e.outputSize))
          throw new Error(Bn);
      },
      flush() {
        const { crc32: A } = d;
        Object.assign(i, {
          crc32: A,
          inputSize: c
        });
      }
    });
    Object.defineProperty(i, "readable", {
      get() {
        return p.pipeThrough(_).pipeThrough(d).pipeThrough(T);
      }
    });
  }
}
class Ra extends TransformStream {
  constructor(e) {
    const o = [];
    let i = 0, s = 0;
    (!Number.isFinite(e) || e < 1) && (e = lu), super({
      transform(d, p) {
        for (o.push(d), i += d.length; i > e; )
          s += e, p.enqueue(f());
      },
      flush(d) {
        i && (s += i, d.enqueue(c(o, i)));
      }
    }), Object.defineProperty(this, "outputSize", {
      get: () => s
    });
    function f() {
      const d = new Uint8Array(e);
      let p = 0;
      for (; p < e; ) {
        const _ = o[0], T = e - p;
        _.length <= T ? (d.set(_, p), p += _.length, o.shift()) : (d.set(_.subarray(0, T), p), o[0] = _.subarray(T), p += T);
      }
      return i -= e, d;
    }
    function c(d, p) {
      const _ = new Uint8Array(p);
      let T = 0;
      for (const A of d)
        _.set(A, T), T += A.length;
      return _;
    }
  }
}
const Ta = "Worker startup timeout";
let Ln, va, mr, wr = () => {
};
function wu({ initModule: n }) {
  wr = n;
}
function gu(n) {
  mr = n;
}
async function yu(n) {
  if (wr)
    try {
      return await wr(n), !0;
    } catch {
    }
  return !1;
}
function zo(n) {
  n.createWorker ? va = !0 : Ln = !1;
}
class hn {
  constructor(e, { readable: o, writable: i }, s, f) {
    const { options: c, config: d, streamOptions: p, useWebWorkers: _, workerURI: T } = s;
    let { createWorker: A } = s;
    const { signal: h } = p;
    return va && (A = P), Object.assign(e, {
      busy: !0,
      generation: (e.generation || 0) + 1,
      readable: o.pipeThrough(new Ra(Cr(d))).pipeThrough(new Au(p), { signal: h }),
      writable: i,
      options: Object.assign({}, c),
      workerOptions: s,
      workerURI: T,
      createWorker: A,
      terminate() {
        return new Promise((y) => {
          const { worker: R, busy: m } = e;
          m ? (e.terminateResolvers = e.terminateResolvers || [], e.terminateResolvers.push(y)) : (R && (R.terminate(), e.worker = null), y()), e.interface = null;
        });
      },
      onTaskFinished() {
        if (e.busy) {
          const { terminateResolvers: y, worker: R } = e;
          y && (e.terminateResolvers = null, R && (e.terminated = !0, R.terminate())), e.busy = !1;
          const m = f(e);
          y && y.forEach((v) => v(m));
        }
      }
    }), Ln === P && (Ln = typeof Worker != Dt), (_ && mr && (Ln && T || A) ? mr : ba)(e, d);
  }
}
class Au extends TransformStream {
  constructor({ onstart: e, onprogress: o, size: i, onend: s }) {
    let f = 0;
    super({
      async start() {
        e && await ar(e, i);
      },
      async transform(c, d) {
        f += c.length, o && await ar(o, f, i), d.enqueue(c);
      },
      async flush() {
        s && await ar(s, f);
      }
    });
  }
}
async function ar(n, ...e) {
  try {
    await n(...e);
  } catch {
  }
}
function ba(n, e) {
  return {
    run: () => gr(n, e)
  };
}
async function gr({ options: n, readable: e, writable: o, onTaskFinished: i, workerOptions: s }, f) {
  let c, d, p;
  try {
    if (n.compressed && !n.format) {
      const R = n.codecType.startsWith(ya), m = R ? f.CompressionStreamFallback : f.DecompressionStreamFallback, v = R ? f.CompressionStream : f.DecompressionStream;
      n.useCompressionStream ? m && m.requiresModule && !uu(v) && await _() : !await _() && (!m || m.requiresModule) && (n.useCompressionStream = !0);
    }
    n.encrypted && !n.zipCrypto && await _(), c = new mu(n, f), d = new Ra(Cr(f));
    const { signal: T } = s.streamOptions;
    await e.pipeThrough(c).pipeThrough(d).pipeTo(o, { preventClose: !0, preventAbort: !0, signal: T });
    const {
      crc32: A,
      inputSize: h,
      outputSize: y
    } = c;
    return {
      crc32: A,
      inputSize: h,
      outputSize: y
    };
  } catch (T) {
    if (c) {
      const A = d ? d.outputSize : 0;
      if (s.outputSize = A, ft(T))
        try {
          T.outputSize = A;
        } catch {
        }
    }
    throw T;
  } finally {
    i();
  }
  function _() {
    return p || (p = yu(f)), p;
  }
}
const Wo = { type: "module" }, yr = "error", Ru = "messageerror", Go = "abort";
let Yo, sr, Xo;
gu(Tu);
function Tu(n, e) {
  const { baseURI: o, chunkSize: i, workerStartupTimeout: s } = e;
  let { wasmURI: f } = e;
  if (!n.interface) {
    typeof f == Pe && (f = f());
    let c;
    try {
      c = Pn(n.workerURI, o, n);
    } catch {
      return zo(n), ba(n, e);
    }
    Object.assign(n, {
      worker: c,
      workerAlive: !1,
      terminated: !1,
      startupError: null,
      interface: {
        run: async () => {
          try {
            return await vu(n, { chunkSize: i, wasmURI: f, baseURI: o, workerStartupTimeout: s });
          } catch (d) {
            if (d && d.workerStartupFailed)
              return zo(n), Zo(n), gr(n, e);
            if (d && d.codecImportFailed) {
              if (n.reader)
                return Zo(n), gr(n, e);
              n.onTaskFinished();
            }
            throw d;
          }
        }
      }
    });
  }
  return n.interface;
}
async function vu(n, e) {
  if (!n.worker) {
    const { startupError: h } = n;
    n.startupError = null;
    const y = h || new Error(Ta);
    throw y.workerStartupFailed = !0, y;
  }
  let o, i;
  const s = new Promise((h, y) => {
    o = h, i = (R) => {
      const { outputSize: m, workerOptions: v } = n;
      if (v.outputSize = m, ft(R))
        try {
          R.outputSize = m;
        } catch {
        }
      y(R);
    };
  });
  Object.assign(n, {
    reader: null,
    writer: null,
    outputSize: 0,
    destinationFailed: !1,
    destinationError: null,
    resolveResult: o,
    rejectResult: i,
    result: s
  });
  const { readable: f, options: c } = n, { writable: d, closed: p, abortPipe: _ } = bu(n.writable, n);
  try {
    Ar({
      type: Eu,
      options: c,
      config: e
    }, n);
  } catch (h) {
    _();
    try {
      await p;
    } catch {
    }
    throw n.onTaskFinished(), h;
  }
  Object.assign(n, {
    reader: f.getReader(),
    writer: d.getWriter()
  });
  const { workerStartupTimeout: T } = e;
  !n.workerAlive && Number.isFinite(T) && T >= 0 && (n.startupTimeout = setTimeout(() => Su(n), T));
  try {
    const h = await s;
    return await A(), await p, h;
  } catch (h) {
    await A(), _();
    try {
      await p;
    } catch {
    }
    const { outputSize: y, workerOptions: R, destinationFailed: m, destinationError: v } = n;
    R.outputSize = y;
    const g = ft(h) && (h.codecImportFailed || h.workerStartupFailed), b = m && !g ? v : h;
    if (ft(b))
      try {
        b.outputSize = y;
      } catch {
      }
    throw b;
  }
  async function A() {
    if (!d.locked)
      try {
        await d.getWriter().close();
      } catch {
      }
  }
}
function bu(n, e) {
  const o = new AbortController();
  let i;
  const { writable: s, readable: f } = new TransformStream({
    transform(p, _) {
      e.outputSize += p.length, _.enqueue(p);
    }
  }), c = f.pipeTo(n, { preventClose: !0, preventAbort: !0, signal: o.signal });
  c.catch((p) => {
    i || Object.assign(e, { destinationFailed: !0, destinationError: p });
  });
  const { signal: d } = e.workerOptions.streamOptions;
  if (d) {
    const p = () => o.abort(d.reason), _ = () => d.removeEventListener(Go, p);
    d.addEventListener(Go, p), c.then(_, _);
  }
  return {
    writable: s,
    closed: c,
    abortPipe: () => {
      i = !0, o.abort();
    }
  };
}
function Zo(n) {
  const { reader: e } = n;
  e && e.releaseLock(), n.reader = null, n.writer = null;
}
function kr(n) {
  const { worker: e } = n;
  if (e)
    try {
      e.terminate();
    } catch {
    }
  n.interface = null;
}
function Pn(n, e, o, i, s = !0) {
  const { createWorker: f } = o;
  let c, d, p;
  if (f)
    c = f();
  else if (sr === P || Yo !== n) {
    const _ = typeof n == Pe;
    _ ? d = n(s) : d = n;
    const T = d.startsWith("data:"), A = d.startsWith("blob:");
    if (T || A) {
      i === P && (i = !1), i && (p = Wo);
      try {
        c = new Worker(d, p);
      } catch (h) {
        if (A)
          try {
            URL.revokeObjectURL(d);
          } catch {
          }
        if (_ && A)
          return Pn(n, e, o, i, !1);
        if (i)
          throw h;
        return Pn(n, e, o, !0, !1);
      }
    } else {
      i === P && (i = !0), i && (p = Wo);
      try {
        d = new URL(d, e);
      } catch {
      }
      try {
        c = new Worker(d, p);
      } catch (h) {
        if (i)
          return Pn(n, e, o, !1, s);
        throw h;
      }
    }
    Yo = n, sr = d, Xo = p;
  } else
    c = new Worker(sr, Xo);
  return c.addEventListener(du, (_) => {
    o.workerAlive = !0, Sa(o), Iu(_, o);
  }), c.addEventListener(yr, (_) => jo(_, o)), c.addEventListener(Ru, (_) => jo(_, o)), c;
}
function Su(n) {
  if (n.startupTimeout = null, n.workerAlive)
    return;
  const { rejectResult: e, writer: o } = n;
  if (kr(n), n.worker = null, e) {
    const i = new Error(Ta);
    i.workerStartupFailed = !0, e(i), o && o.releaseLock();
  }
}
function Sa(n) {
  const { startupTimeout: e } = n;
  e && (clearTimeout(e), n.startupTimeout = null);
}
function jo(n, e) {
  n.preventDefault && n.preventDefault(), Sa(e);
  const { workerAlive: o, rejectResult: i, writer: s, onTaskFinished: f } = e;
  kr(e), o || (e.worker = null);
  let c = n.error || new Error(n.message || yr);
  o || (c = Object.assign(new Error(c.message || yr), { workerStartupFailed: !0 }), e.startupError = c), i && (i(c), s && s.releaseLock(), o && f());
}
function Ar(n, { worker: e, writer: o }) {
  try {
    const { value: i } = n;
    if (i) {
      n.value = ac(i);
      try {
        e.postMessage(n, [n.value.buffer]);
      } catch {
        e.postMessage(n);
      }
    } else
      e.postMessage(n);
  } catch (i) {
    throw o && o.releaseLock(), i;
  }
}
async function Iu({ data: n }, e) {
  const { type: o, value: i, messageId: s, result: f, error: c, errorValue: d } = n, { reader: p, writer: _, resolveResult: T, rejectResult: A, onTaskFinished: h, generation: y } = e, R = () => e.generation != y;
  try {
    if (c)
      m(Nu(c, d));
    else {
      if (o == hu) {
        const { value: b, done: N } = await p.read();
        R() || Ar({ type: Ho, value: b, done: N, messageId: s }, e);
      }
      if (o == Ho) {
        const b = new Uint8Array(i);
        await _.ready, await _.write(b), R() || Ar({ type: pu, messageId: s }, e);
      }
      o == _u && v(f);
    }
  } catch (b) {
    R() || (kr(e), m(b));
  }
  function m(b) {
    R() || (A(b), g(), ft(b) && b.codecImportFailed || h());
  }
  function v(b) {
    R() || (T(b), g(), h());
  }
  function g() {
    _ && _.releaseLock();
  }
}
function Nu(n, e) {
  const { message: o, stack: i, code: s, name: f, outputSize: c, cause: d, codecImportFailed: p } = n;
  let _;
  if (e ? _ = e.value : _ = Object.assign(new Error(o), { stack: i, code: s, name: f }), ft(_))
    try {
      c !== P && (_.outputSize = c), p && (_.codecImportFailed = !0), d && (ft(_.cause) || (_.cause = Object.assign(new Error(d.message), { name: d.name })), d.code !== P && _.cause.code !== d.code && (_.cause.code = d.code)), e && (_.name !== f && (_.name = f), _.code !== s && (_.code = s));
    } catch {
    }
  return _;
}
let Ct = [];
const Mt = [];
let Kt, Cn, Vo = 0;
async function Du(n, e) {
  const { options: o, config: i } = e, { useWebWorkers: s, useCompressionStream: f, compressed: c, checkCrc32: d, computeCrc32: p, encrypted: _, format: T, codecURI: A } = o, { workerURI: h, createWorker: y, maxWorkers: R } = i;
  T && (A && (o.codecURI = Ou(A, i.baseURI)), await eu(T, o.codecURI));
  const m = !c && !d && !p && !_, v = T === P || !!o.codecURI;
  return e.useWebWorkers = !m && v && (s || s === P && i.useWebWorkers), e.workerURI = e.useWebWorkers && h ? h : P, e.createWorker = e.useWebWorkers && y ? y : P, o.useCompressionStream = f || f === P && i.useCompressionStream, (await g()).run();
  async function g() {
    const N = Ct.find((C) => !C.busy);
    if (N)
      return Ko(N), new hn(N, n, e, b);
    if (Ct.length < R) {
      const C = { indexWorker: Vo };
      return Vo++, Ct.push(C), new hn(C, n, e, b);
    } else
      return new Promise((C) => {
        Mt.push({ resolve: C, stream: n, workerOptions: e }), Cn = i.workerStarvationTimeout, Yn();
      });
  }
  function b(N) {
    if (Br(), N.terminated)
      return N.terminated = !1, Pu();
    if (Mt.length) {
      const [{ resolve: C, stream: L, workerOptions: x }] = Mt.splice(0, 1);
      C(new hn(N, L, x, b)), Yn();
    } else N.worker ? (Ko(N), Cu(N, e)) : Ct = Ct.filter((C) => C != N);
  }
}
function Ou(n, e) {
  try {
    return new URL(n, e).toString();
  } catch {
    return n;
  }
}
function Yn() {
  !Kt && Mt.length && Number.isFinite(Cn) && Cn >= 0 && (Kt = setTimeout(Lu, Cn));
}
function Br() {
  Kt && (clearTimeout(Kt), Kt = null);
}
function Lu() {
  if (Kt = null, Mt.length) {
    const [{ resolve: n, stream: e, workerOptions: o }] = Mt.splice(0, 1);
    n(new hn({}, e, Ia(o), Na)), Yn();
  }
}
function Pu() {
  const n = Mt.splice(0).map(({ resolve: e, stream: o, workerOptions: i }) => new Promise((s) => {
    e(new hn({}, o, Ia(i), () => {
      Na(), s();
    }));
  }));
  return Br(), Promise.all(n);
}
function Ia(n) {
  return Object.assign({}, n, { useWebWorkers: !1, workerURI: P, createWorker: P });
}
function Na() {
  Br(), Yn();
}
function Cu(n, e) {
  const { config: o } = e, { terminateWorkerTimeout: i } = o;
  Number.isFinite(i) && i >= 0 && (n.terminateTimeout = setTimeout(async () => {
    Ct = Ct.filter((s) => s != n);
    try {
      await n.terminate();
    } catch {
    }
  }, i));
}
function Ko(n) {
  const { terminateTimeout: e } = n;
  e && (clearTimeout(e), n.terminateTimeout = null);
}
const Fu = "\0☺☻♥♦♣♠•◘○◙♂♀♪♫☼►◄↕‼¶§▬↨↑↓→←∟↔▲▼ !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~⌂ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ ".split("");
function Mu(n) {
  let e = "";
  for (let o = 0; o < n.length; o++)
    e += Fu[n[o]];
  return e;
}
function Fn(n, e) {
  return Uu(n, e, !0);
}
function qo(n) {
  if (n.some((e) => e > 127))
    try {
      return new TextDecoder("utf-8", { fatal: !0 }).decode(n), !0;
    } catch {
      return !1;
    }
  else
    return !1;
}
function Uu(n, e, o) {
  return e && e.trim().toLowerCase() == "cp437" ? Mu(n) : new TextDecoder(e, { ignoreBOM: o }).decode(n);
}
const xu = "Writer iterator completed too soon", ku = "Invalid writer (size must be writable)", Bu = "writable", Jo = /* @__PURE__ */ Symbol();
class Da {
  constructor() {
    this.size = 0;
  }
  init() {
    this.initialized = !0;
  }
}
class Oa extends Da {
  get readable() {
    return this.createReadable();
  }
  createReadable({ offset: e = 0, size: o, chunkSize: i = Cr(Gi()) } = {}) {
    const s = this;
    let f = 0;
    return i = Yi(i), new ReadableStream({
      async pull(c) {
        const d = o === P ? i : Math.min(i, o - f), p = await pe(s, e + f, d);
        p.length && (c.enqueue(p), f += p.length), (o !== P && f >= o || !p.length && d) && c.close();
      }
    });
  }
}
let Rr, La;
function Hu() {
  La = (async () => {
    try {
      const e = new Blob([new Uint8Array(3)]).slice(1, 2).stream().getReader();
      let o = 0, i = await e.read();
      for (; !i.done; )
        o += i.value.length, i = await e.read();
      Rr = o == 1;
    } catch {
      Rr = !1;
    }
  })();
}
class Hr extends Oa {
  constructor(e) {
    super(), Object.assign(this, {
      sourceBlob: e,
      size: e.size
    }), La || Hu();
  }
  createReadable(e) {
    const o = this, { sourceBlob: i, size: s } = o, { offset: f = 0, size: c = s - f } = e || {};
    if (typeof i.stream == Pe) {
      if (!f && c >= s)
        return Jt(i.stream());
      if (Rr)
        return Jt(i.slice(f, f + c).stream());
    }
    return super.createReadable(e);
  }
  async readUint8Array(e, o) {
    const i = this, s = e + o;
    let d = await (!e && s >= i.size ? i.sourceBlob : i.sourceBlob.slice(e, s)).arrayBuffer();
    return d.byteLength > o && (d = d.slice(e, s)), new Uint8Array(d);
  }
}
class zu extends Oa {
  constructor(e) {
    super(), this.readers = e;
  }
  async init() {
    const e = this;
    e.lastDiskNumber = 0;
    const o = e.readers = await Promise.all(e.readers.map(Xu));
    e.diskOffsets = o.map((i) => {
      const s = e.size;
      return e.size += i.size, s;
    }), super.init();
  }
  getDiskOffset(e) {
    const { diskOffsets: o, size: i } = this, s = o[e];
    return s === P ? i : s;
  }
  async readUint8Array(e, o) {
    const i = this, { readers: s } = this;
    let f, c = 0, d = e;
    for (; s[c] && d >= s[c].size; )
      d -= s[c].size, c++;
    const p = s[c];
    if (p) {
      const _ = p.size;
      if (d + o <= _)
        f = await pe(p, d, o);
      else {
        const T = _ - d, A = await pe(p, d, T), h = await i.readUint8Array(e + T, o - T);
        f = Ft(A, h);
      }
    } else
      f = nt;
    return i.lastDiskNumber = Math.max(c, i.lastDiskNumber), f;
  }
}
class Wu extends Da {
  constructor(e, o = 4294967295) {
    super();
    const i = this;
    Object.assign(i, {
      diskNumber: 0,
      diskOffset: 0,
      size: 0,
      maxSize: o,
      availableSize: o
    });
    let s, f, c;
    const d = new WritableStream({
      async write(A) {
        if (A === Jo) {
          c && await _();
          return;
        }
        const { availableSize: h } = i;
        if (c)
          A.length >= h ? (await p(A.subarray(0, h)), await _(), A.length > h && await this.write(A.subarray(h))) : await p(A);
        else {
          const { value: y, done: R } = await e.next();
          if (R && !y)
            throw new Error(xu);
          s = y, s.size = 0, s.maxSize && (i.maxSize = s.maxSize), i.availableSize = i.maxSize, await Qt(s), f = y.writable, c = f.getWriter(), await this.write(A);
        }
      },
      async close() {
        c && (await c.ready, await T());
      },
      async abort(A) {
        c && await c.abort(A);
      }
    });
    Object.defineProperty(i, Bu, {
      get() {
        return d;
      }
    });
    async function p(A) {
      const h = A.length;
      h && (await c.ready, await c.write(A), s.size += h, i.availableSize -= h);
    }
    async function _() {
      await T(), i.diskOffset += s.size, i.diskNumber++, c = null, i.availableSize = i.maxSize;
    }
    async function T() {
      await c.close();
    }
  }
  async closeDisk() {
    const e = this.writable.getWriter();
    try {
      await e.ready, await e.write(Jo);
    } finally {
      e.releaseLock();
    }
  }
}
class Pa {
  constructor(e) {
    return Array.isArray(e) && (e = new zu(e)), (e instanceof ReadableStream || typeof e.getReader == Pe) && (e = {
      readable: Jt(e)
    }), e;
  }
}
class Gu {
  constructor(e) {
    e.writable === P && typeof e.next == Pe && (e = new Wu(e)), (e instanceof WritableStream || typeof e.getWriter == Pe) && (e = {
      writable: Kc(e)
    });
    try {
      e.size = e.size === P ? 0 : e.size;
    } catch {
      throw new Error(ku);
    }
    return e;
  }
}
function Yu(n) {
  return !!(n && n.getData);
}
async function Qt(n, e) {
  if (n.init && !n.initialized)
    await n.init(e);
  else
    return Promise.resolve();
}
async function Xu(n) {
  return n = new Pa(n), await Qt(n), (n.size === P || !n.readUint8Array) && (n = new Hr(await hr(n.readable)), await Qt(n)), n;
}
function pe(n, e, o) {
  return n.readUint8Array(e, o);
}
function je(n, e, o) {
  if (!n.some((i) => i.reason == e)) {
    const i = { reason: e };
    o !== P && (i.filename = o), n.push(i);
  }
}
const Ca = "filename", Fa = "rawFilename", Ma = "comment", Ua = "rawComment", xa = "uncompressedSize", ka = "compressedSize", Ba = "offset", Ha = "diskNumberStart", Tr = "lastModDate", vr = "rawLastModDate", za = "lastAccessDate", Wa = "rawLastAccessDate", Ga = "creationDate", Ya = "rawCreationDate", Zu = "internalFileAttributes", ju = "externalFileAttributes", Vu = "msdosAttributesRaw", Ku = "msdosAttributes", qu = "msDosCompatible", Ju = "zip64", Qu = "encrypted", $u = "version", ef = "versionMadeBy", tf = "zipCrypto", nf = "directory", rf = "executable", of = "symlink", af = "compressionMethod", sf = "signature", cf = "crc32", uf = "extraField", ff = "extraFieldInfoZip", lf = "extraFieldUnix", df = "extraFieldUnixType1", Ef = "extraFieldPkwareUnix", hf = "uid", pf = "gid", _f = "unixMode", mf = "setuid", wf = "setgid", gf = "sticky", yf = "bitFlag", Af = "rawBitFlag", Rf = "filenameLength", Tf = "extraFieldLength", vf = "unixExternalUpper", bf = "filenameUTF8", Sf = "commentUTF8", If = "rawExtraField", Nf = "extraFieldZip64", Df = "extraFieldUnicodePath", Of = "extraFieldUnicodeComment", Lf = "extraFieldAES", Pf = "extraFieldNTFS", Cf = "extraFieldExtendedTimestamp", Ff = "extraFieldUSDZ", Mf = [
  Ca,
  Fa,
  xa,
  ka,
  Tr,
  vr,
  Ma,
  Ua,
  za,
  Wa,
  Ga,
  Ya,
  Ba,
  Ha,
  Zu,
  ju,
  Vu,
  Ku,
  qu,
  Ju,
  Qu,
  $u,
  ef,
  tf,
  nf,
  rf,
  of,
  af,
  sf,
  cf,
  uf,
  lf,
  ff,
  df,
  Ef,
  hf,
  pf,
  _f,
  vf,
  mf,
  wf,
  gf,
  yf,
  Af,
  Rf,
  Tf,
  bf,
  Sf,
  If,
  Nf,
  Df,
  Of,
  Lf,
  Pf,
  Cf,
  Ff
];
class Qo {
  constructor(e) {
    Mf.forEach((o) => this[o] = e[o]);
  }
}
function Uf(n, e, o) {
  return n ? e ? 12 : 16 + o * 4 : 0;
}
const cn = "File format is not recognized", xf = "End of central directory not found", $o = "End of Zip64 central directory locator not found", kf = "Central directory header not found", Bf = "File contains encrypted entry", ei = "Encryption method not supported", ti = "Split zip file", Hf = "Entry data out of bounds", zf = "Ambiguous archive", Wf = "Encrypted central directory is not supported", Gf = "Unsafe filename", Yf = "Invalid strictness (must be 'strict', 'balanced' or 'tolerant')", Xf = "Invalid filenameValidation (must be 'strict', 'balanced' or 'tolerant')", Zf = "Invalid maxAppendedDataSize (must be a number greater than or equal to 0)", jf = "64-bit value exceeds Number.MAX_SAFE_INTEGER", Vf = "unsorted central directory", Kf = "unknown version needed to extract", qf = "compressed patched data", Xa = "malformed extra field", Jf = "unknown zip64 extensible data", ni = "wrapped entries count", ri = "appended data", oi = "prepended data", Qf = "prepended central directory", $f = "trailing central directory data", el = "mismatched central directory offset", tl = "missing zip64 extra field", nl = "duplicate filename", Nn = "mismatched zip64 end of central directory record", rl = "multiple end of central directory records", ol = "mismatched local file header (filename)", il = "mismatched local file header (general purpose bit flag)", al = "mismatched local file header (compression method)", Za = "mismatched local file header (crc32 or sizes)", sl = 63, cl = /^[a-zA-Z]:/, ul = /(^|[\\/])\.\.([\\/]|$)/, ii = "utf-8", fl = "UTF8", ai = "cp437", si = 2121, ja = 1, Va = [
  [xa, 4294967295],
  [ka, 4294967295],
  [Ba, 4294967295],
  [Ha, 65535]
], ci = {
  65535: {
    getValue: V,
    bytes: 4
  },
  4294967295: {
    getValue: We,
    bytes: 8
  }
}, ll = BigInt(Number.MAX_SAFE_INTEGER), dl = 64, El = 1032, ui = 0, zr = 1, Xn = 2;
class hl {
  constructor(e, o = {}) {
    Object.assign(this, {
      reader: new Pa(e),
      options: o || {},
      readRanges: { indexes: /* @__PURE__ */ new Set(), sortedRanges: [], pendingRanges: [] },
      entriesMissingZip64ExtraField: /* @__PURE__ */ new WeakSet()
    });
  }
  async *getEntriesGenerator(e = {}) {
    const o = this;
    let { reader: i } = o;
    if (await Qt(i), (i.size === P || !i.readUint8Array) && (i = new Hr(await hr(i.readable)), await Qt(i)), i.size < 22)
      throw new Error(cn);
    const s = o.warnings = [], f = $a(e, o.options), c = f == $t, d = f != Ut, p = xl(ye(o, e, Us), f), _ = Ml(ye(o, e, Fs), f), T = ye(o, e, Ms), { endOfDirectoryInfo: A, endOfDirectoryReachingEndCount: h } = await kl(i, d, p);
    if (!A)
      throw await Ol(i) ? new Error(ti) : new Error(xf);
    d && h > 1 && Mn(rl);
    const y = ae(A);
    let R = V(y, 12), m = V(y, 16);
    const v = A.offset, g = J(y, 20), b = v + 22 + g, N = i.size - b;
    N > p && Mn(ri), N > 0 && je(s, ri);
    let C = J(y, 4);
    const L = i.lastDiskNumber || 0;
    let x = J(y, 6), B = J(y, 10), $ = 0, se, Ee, Se, Ne, De = 56, Ue;
    const Ge = m == 4294967295 || R == 4294967295 || B == 65535 || x == 65535;
    if (m != 4294967295 && x != 65535 && (m += jt(i, x)), Ge) {
      const te = A.offset >= 20 ? await pe(i, A.offset - 20, 20) : nt, k = ae(te);
      if (te.length == 20 && V(k, 0) == 117853008) {
        m = jt(i, V(k, 4)) + We(k, 8);
        let Ie = await pe(i, m, 56), oe = ae(Ie);
        if (Ie.length < 56 || V(oe, 0) != 101075792) {
          const ce = A.offset - 20;
          let fe = ce - 56;
          if (await Zn(i, fe, 101075792) || (fe = await ml(i, ce)), fe !== P && fe >= 0 && m != fe) {
            const Oe = m;
            m = fe, m > Oe && ($ = m - Oe), Ie = await pe(i, m, 56), oe = ae(Ie);
          }
        }
        if (Ie.length < 56 || V(oe, 0) != 101075792)
          throw new Error($o);
        if (Se = !0, Ne = We(oe, 4) > 44, Ne) {
          const ce = Math.min(
            We(oe, 4) - 44,
            i.size - m - 56
          );
          if (ce > 0) {
            De += ce;
            const fe = await pe(i, m + 56, ce);
            Ue = Al(fe);
          }
        }
        C == 65535 ? C = V(oe, 16) : C != V(oe, 16) && Je(c, s, Nn), x == 65535 ? x = V(oe, 20) : x != V(oe, 20) && Je(c, s, Nn), B == 65535 ? B = We(oe, 32) : B != We(oe, 32) && Je(c, s, Nn), R == 4294967295 ? R = We(oe, 40) : R != We(oe, 40) && Je(c, s, Nn), m = jt(i, x) + We(oe, 48) + $;
      } else if (m == 4294967295 || R == 4294967295 || x == 65535)
        throw new Error($o);
    }
    let Ye = R;
    const xe = A.offset - (Se ? De + 20 : 0);
    if (L != C)
      throw new Error(ti);
    if (m < 0)
      throw new Error(cn);
    let re = 0, ue = m < i.size ? await pe(i, m, R) : nt, le = ae(ue);
    if (R) {
      let te = xe - R;
      if (m != te && x == C) {
        const k = ue.length >= 4 && (V(le, re) == 33639248 || !!(Ue && Ue.compressedSize) || cr(le));
        if (!k && te < 0)
          throw new Error(cn);
        let Ie = !k;
        if (te >= 0 && te + 4 <= i.size) {
          let oe = await li(i, te);
          if (!oe) {
            const ce = await _l(i, xe), fe = ce - R;
            ce !== P && fe >= 0 && await li(i, fe) && (te = fe, oe = !0);
          }
          k && (Ie = oe);
        }
        if (Ie && te != m) {
          const oe = m;
          m = te, ue = await pe(i, m, R), le = ae(ue);
          const ce = m - oe, { localHeaderFound: fe, shiftedLocalHeaderFound: Oe } = await wl(i, ue, le, ce);
          ce > 0 && !(fe && !Oe) ? ($ += ce, se = k) : (Je(c, s, el), ce < 0 && !fe && Oe && ($ += ce));
        }
      }
      if (ue.length < 4)
        throw new Error(cn);
    } else !B && m < xe && x == C && ($ += xe - m, m = xe);
    const Tt = xe - m;
    if (R != Tt && Tt >= 0 && x == C && (R = Tt, ue = await pe(i, m, R), le = ae(ue)), m < 0 || m >= i.size)
      throw new Error(cn);
    o.directoryOffset = m, o.directoryLength = Ye;
    const Ot = wi(o, e, xs);
    let qe, rt;
    if (Ot && B && ue.length >= 4 && V(le, 0) != 33639248 && (Ne || cr(le))) {
      const te = yl(Ue, Ye, ue.length);
      rt = ue.subarray(te), ue = await Ot(ue.subarray(0, te), Ue), le = ae(ue), Ye = ue.length, qe = !0;
    }
    Ue && !qe && (ue.length < 4 || V(le, 0) == 33639248) && je(s, Jf), Ee = m;
    const lt = ye(o, e, hs), O = ye(o, e, ps), vt = /* @__PURE__ */ new Set();
    let dt, bt = -1 / 0;
    const Qe = !c && !Se;
    !B && Qe && (B = fi(le, ue, re), B && je(s, ni));
    const ke = Object.assign({}, o.options, e, { [Li]: f });
    delete ke[Oi];
    for (let te = 0; te < B; te++) {
      const k = new pl(i, ke);
      if (re + 46 > ue.length || V(le, re) != 33639248)
        throw te == 0 && !qe && (Ne || cr(le)) ? new Error(Wf) : new Error(kf);
      Ka(k, le, re + 6);
      const Ie = !!k.bitFlag.languageEncodingFlag, oe = re + 46, fe = oe + k.filenameLength + k.extraFieldLength, Oe = J(le, re + 4), it = Oe >> 8 == 0, He = Oe >> 8 == 3, at = J(le, re + 32), ht = fe + at, F = new Uint8Array(ue.subarray(oe, ht)), _e = F.subarray(0, k.filenameLength), Xe = F.subarray(k.filenameLength + k.extraFieldLength), de = Ie || !lt && qo(_e), Fe = Ie || !O && qo(Xe), pt = V(le, re + 38), W = pt & 255, Te = {
        readOnly: !!(W & 1),
        hidden: !!(W & 2),
        system: !!(W & 4),
        directory: !!(W & 16),
        archive: !!(W & 32)
      }, yn = V(le, re + 42), xt = wi(o, e, _s) || Fn, kt = de ? ii : lt || ai, en = Fe ? ii : O || ai;
      let Me = xt(_e, kt, ks);
      Me === P && (Me = Fn(_e, kt));
      let Bt = xt(Xe, en, Bs);
      Bt === P && (Bt = Fn(Xe, en)), Object.assign(k, {
        index: te,
        decryptedDirectory: qe,
        versionMadeBy: Oe,
        msDosCompatible: it,
        zip64: !1,
        compressedSize: 0,
        uncompressedSize: 0,
        commentLength: at,
        offset: yn,
        diskNumberStart: J(le, re + 34),
        internalFileAttributes: J(le, re + 36),
        externalFileAttributes: pt,
        msdosAttributesRaw: W,
        msdosAttributes: Te,
        rawFilename: _e,
        filenameUTF8: de,
        commentUTF8: Fe,
        rawExtraField: F.subarray(k.filenameLength, k.filenameLength + k.extraFieldLength),
        rawComment: Xe,
        filename: Me,
        comment: Bt
      });
      let tn;
      try {
        tn = qa(k, k, le, re + 6);
      } catch (Ae) {
        if (c || Ae.message != Kn)
          throw Ae;
        k.zip64ExtraFieldMissing = !0, je(s, tl, k.filename);
      }
      if (Me = k.filename, T) {
        const Ae = T(Me);
        Ae !== P && (Me = k.filename = Ae);
      }
      if (Ul(Me, _)) {
        const Ae = new Error(Gf);
        throw Ae.filename = Me, Ae;
      }
      if (tn && je(s, Xa, Me), k.zip64ExtraFieldMissing && k.offset == 4294967295)
        Ee = 0;
      else {
        k.offset += $;
        const Ae = jt(i, k.diskNumberStart) + k.offset;
        Ee = Math.min(Ae, Ee), Ae < bt && je(s, Vf, Me), bt = Ae;
      }
      (k.version & 255) > sl && je(s, Kf, Me), (k.rawBitFlag & 32) == 32 && je(s, qf, Me), vt.has(k.filename) && (dt = !0), vt.add(k.filename);
      const _t = k.externalFileAttributes >> 16 & 65535;
      k.unixMode === P && (_t & 16877) != 0 && (k.unixMode = _t);
      const An = !!(k.unixMode & 2048), ie = !!(k.unixMode & 1024), Rn = !!(k.unixMode & 512), st = ((k.unixMode === P ? _t : k.unixMode) & 61440) == 40960, nn = k.unixMode !== P && (k.unixMode & 61440) == 16384, mt = (_t & 61440) == 16384, Lt = nn || mt || it && Te.directory || k.filename.endsWith("/"), Ht = !st && !Lt && (k.unixMode !== P ? (k.unixMode & 73) != 0 : He && (_t & 73) != 0);
      Object.assign(k, {
        setuid: An,
        setgid: ie,
        sticky: Rn,
        symlink: st,
        unixExternalUpper: _t,
        executable: Ht,
        directory: Lt,
        zipCrypto: k.encrypted && !k.extraFieldAES
      });
      const $e = new Qo(k);
      if (k.zip64ExtraFieldMissing && o.entriesMissingZip64ExtraField.add($e), $e.getData = (Ae, ze) => k.getData(Ae, $e, o, ze), $e.arrayBuffer = async (Ae) => {
        const ze = new TransformStream(), rn = hr(ze.readable).then((on) => on.arrayBuffer());
        return rn.catch(() => {
        }), await k.getData(
          ze,
          $e,
          o,
          Object.assign({}, Ae, { preventClose: !1 })
        ), rn;
      }, re = ht, te == B - 1 && Qe) {
        const Ae = fi(le, ue, re);
        Ae && (B += Ae, je(s, ni));
      }
      const { onprogress: zt } = e;
      if (zt)
        try {
          await zt(te + 1, B, new Qo(k));
        } catch {
        }
      yield $e;
    }
    let Ce = re, Be = ur(ue.subarray(re)) || (qe ? ur(rt) : P);
    if (!Be && !qe) {
      const te = m + re, k = Math.min(xe - te, 65541);
      k >= 6 && (Be = ur(await pe(i, te, k)));
    }
    Be && (o.digitalSignature = Be, Ce = re + 6 + Be.length), (re != Ye && Ce != Ye || !qe && re != R && Ce != R) && Je(c, s, $f), dt && Je(c, s, nl);
    const ot = ye(o, e, ms), Et = ye(o, e, ws), ve = (c || ot) && B && Ee == 4 && await Ll(i) ? 4 : 0;
    return c && ($ > 0 || B && Ee > ve) && Mn(oi), ($ > 0 || B && Ee > 4) && je(s, oi), se && je(s, Qf), ot && (o.prependedData = Ee > ve ? await pe(i, ve, Ee - ve) : nt), o.comment = g ? await pe(i, v + 22, g) : nt, Et && (o.appendedData = b < i.size ? await pe(i, b, i.size - b) : nt), !0;
  }
  async getEntries(e = {}) {
    const o = [];
    for await (const i of this.getEntriesGenerator(e))
      o.push(i);
    return o;
  }
  async close() {
    const { reader: e } = this;
    !e.readUint8Array && e.readable && !e.readable.locked && await e.readable.cancel();
  }
  [Es]() {
    return this.close();
  }
}
class pl {
  constructor(e, o) {
    Object.assign(this, {
      reader: e,
      options: o
    });
  }
  async getData(e, o, i, s = {}) {
    const f = this, { readRanges: c, directoryOffset: d } = i;
    if (f.zip64ExtraFieldMissing)
      throw new Error(Kn);
    const p = Gi(), {
      reader: _,
      index: T,
      offset: A,
      diskNumberStart: h,
      extraFieldAES: y,
      extraFieldZip64: R,
      compressionMethod: m,
      bitFlag: v,
      rawBitFlag: g,
      crc32: b,
      rawLastModDate: N,
      uncompressedSize: C,
      compressedSize: L
    } = f, {
      dataDescriptor: x
    } = v, B = o.localDirectory = {}, $ = o.warnings = [], se = jt(_, h) + A, Ee = await pe(_, se, 30), Se = ae(Ee);
    let Ne = ye(f, s, gs), De = ye(f, s, ys);
    const Ue = Ks(ye(f, s, As)), Ge = !!Ue, Ye = Ue === !0;
    if (Vs(Ne, De), Ne = Ne && Ne.length ? Ne : P, De = De && De.length ? De : P, y && y.originalCompressionMethod != 99)
      throw new Error(pr);
    if (Ee.length < 30 || V(Se, 0) != 67324752)
      throw new Error(fs);
    Ka(B, Se, 4);
    const {
      extraFieldLength: xe,
      filenameLength: re
    } = B, ue = B.dataOffset = se + 30 + re + xe, le = ye(f, s, Ss), Tt = $a(s, f.options), Ot = Cl(le, Tt), qe = ye(f, s, Is), rt = Fl(
      qe === P ? le : qe,
      Tt
    );
    let lt = nt;
    if (rt && (re || xe)) {
      const de = await pe(_, se + 30, re + xe);
      lt = de.subarray(0, re), B.rawExtraField = de.subarray(re);
    } else
      B.rawExtraField = xe ? await pe(_, se + 30 + re, xe) : nt;
    rt && (B.rawFilename = lt), qa(f, B, Se, 4, !0) && je($, Xa), Hl(f, B, lt, rt, Ot ? P : $);
    const { lastAccessDate: O, creationDate: vt, uid: dt, gid: bt } = B;
    O && o.lastAccessDate === P && (o.lastAccessDate = O), vt && o.creationDate === P && (o.creationDate = vt), dt !== P && o.uid === P && (o.uid = dt), bt !== P && o.gid === P && (o.gid = bt);
    const Qe = ye(f, s, Ts), ke = f.encrypted && (!Ye || Qe), Ce = ke && !y;
    if (Ye || (o.zipCrypto = Ce), ke && (f.rawBitFlag & 64) == 64)
      throw new Error(ei);
    const Be = Ge ? P : Qc(m);
    if (m != 0 && m != 8 && m != 9 && !Be && !Ge)
      throw new Error(pr);
    if (ke) {
      if (!Ce && (y.strength < 1 || y.strength > 3))
        throw new Error(ei);
      if (!Ne && !De)
        throw new Error(Bf);
    }
    if (ue + L > Math.min(_.size, d))
      throw new Error(Hf);
    const ot = L, Et = js(ye(f, s, Rs));
    Do(Et);
    let ve = ye(f, s, bs);
    const te = ye(f, s, vs);
    te && (ve = !0);
    const { onstart: k, onprogress: Ie, onend: oe } = s, ce = m != 0 && !Ge, fe = Ge ? L - Uf(ke, Ce, y && y.strength) : C, Oe = m == 9;
    let it = ye(f, s, Ps);
    Oe && (it = !1);
    const He = ye(f, s, Ds), at = (He === P ? ye(f, s, Ns) : He) && !Ge && (!ke || Ce || y && y.vendorVersion == ja), ht = {
      options: {
        codecType: Aa,
        password: Ne,
        rawPassword: De,
        zipCrypto: Ce,
        encryptionStrength: y && y.strength,
        checkCrc32: at,
        checkAuthenticationCode: ye(f, s, Os),
        passwordVerification: Ce && (x ? N >>> 8 & 255 : b >>> 24 & 255),
        outputSize: fe,
        crc32: b,
        compressed: ce,
        encrypted: ke,
        useWebWorkers: ye(f, s, Ls),
        useCompressionStream: it,
        deflate64: Oe,
        format: Be ? Be.format : P,
        codecURI: Be ? Be.codecURI : P,
        compressionMethod: m,
        rawBitFlag: g,
        checkPasswordOnly: Qe
      },
      config: p,
      streamOptions: { signal: Et, size: ot, onstart: k, onprogress: Ie, onend: oe }
    };
    ve && (await Sl({
      reader: _,
      fileEntry: o,
      index: T,
      offset: se,
      crc32: b,
      compressedSize: L,
      uncompressedSize: C,
      dataOffset: ue,
      dataDescriptor: x || B.bitFlag.dataDescriptor,
      extraFieldZip64: R || B.extraFieldZip64,
      readRanges: c
    }), zl(f, B, Ot ? P : $));
    let F, _e, Xe;
    try {
      if (!te) {
        Qe && (e = new WritableStream()), e = new Gu(e), await Qt(e, Pl(fe, L, ce)), { writable: F } = e;
        const de = Jt(_.createReadable({ offset: ue, size: ot })), { outputSize: Fe } = await Du({ readable: de, writable: F }, ht);
        if (Do(Et), Fe != fe)
          throw Object.assign(new Error(Bn), { outputSize: Fe });
        e.size += Fe;
      }
    } catch (de) {
      if (ft(de) && de.outputSize !== P && (e.size += de.outputSize), !Qe || !ft(de) || de.message != Mr)
        throw _e = de, Xe = !0, de;
    } finally {
      if (!(!Yu(e) && ye(f, s, Cs)) && F && !F.locked) {
        const Fe = F.getWriter();
        if (Xe)
          try {
            await Fe.abort(_e);
          } catch {
          }
        else
          await Fe.close();
      }
    }
    return Qe || te ? P : e.getData ? e.getData() : F;
  }
}
function cr(n) {
  return n.byteLength >= 4 && V(n, 0) == 134630224;
}
function fi(n, e, o) {
  let i = 0;
  for (; o + 46 <= e.length && V(n, o) == 33639248; )
    o += 46 + J(n, o + 28) + J(n, o + 30) + J(n, o + 32), i++;
  return i % 65536 ? 0 : i;
}
function li(n, e) {
  return Zn(n, e, 33639248);
}
async function Zn(n, e, o) {
  if (e < 0 || e + 4 > n.size)
    return !1;
  const i = await pe(n, e, 4);
  return V(ae(i), 0) == o;
}
async function _l(n, e) {
  const o = Math.max(0, e - 65541), i = await pe(n, o, e - o), s = ae(i);
  for (let f = i.length - 6; f >= 0; f--)
    if (V(s, f) == 84233040 && f + 6 + J(s, f + 4) == i.length)
      return o + f;
}
async function ml(n, e) {
  const o = Math.max(0, e - 65591), i = await pe(n, o, e - o), s = ae(i);
  for (let f = i.length - 56; f >= 0; f--)
    if (V(s, f) == 101075792 && f + 12 + Number(s.getBigUint64(f + 4, !0)) == i.length)
      return o + f;
}
async function wl(n, e, o, i) {
  let s = { localHeaderFound: !1, shiftedLocalHeaderFound: !1 }, f = 0;
  for (; f + 46 <= e.length && V(o, f) == 33639248; ) {
    const c = gl(e, o, f);
    if (c !== P) {
      const d = await Zn(n, c, 67324752), p = await Zn(n, c + i, 67324752);
      if (f || (s = { localHeaderFound: d, shiftedLocalHeaderFound: p }), d != p)
        return { localHeaderFound: d, shiftedLocalHeaderFound: p };
    }
    f += 46 + J(o, f + 28) + J(o, f + 30) + J(o, f + 32);
  }
  return s;
}
function gl(n, e, o) {
  const i = V(e, o + 42);
  if (i != 4294967295)
    return i;
  let s = o + 46 + J(e, o + 28);
  const f = Math.min(s + J(e, o + 30), n.length);
  for (; s + 4 <= f; ) {
    const c = J(e, s), d = J(e, s + 2);
    if (c == 1) {
      let p = s + 4;
      return V(e, o + 24) == 4294967295 && (p += 8), V(e, o + 20) == 4294967295 && (p += 8), p + 8 <= f ? We(e, p) : P;
    }
    s += 4 + d;
  }
  return P;
}
function ur(n) {
  if (n.length >= 6) {
    const e = ae(n);
    if (V(e, 0) == 84233040) {
      const o = J(e, 4);
      if (6 + o <= n.length)
        return new Uint8Array(n.subarray(6, 6 + o));
    }
  }
}
function yl(n, e, o) {
  const i = n && n.compressedSize ? n.compressedSize : e;
  return i > 0 && i <= o ? i : o;
}
function Al(n) {
  const e = { rawExtensibleData: n };
  if (n.length >= 28) {
    const o = ae(n), i = J(o, 26);
    Object.assign(e, {
      compressionMethod: J(o, 0),
      compressedSize: We(o, 2),
      uncompressedSize: We(o, 10),
      encryptionAlgorithm: J(o, 18),
      bitLength: J(o, 20),
      flags: J(o, 22),
      hashAlgorithm: J(o, 24),
      hashData: n.subarray(28, 28 + i)
    });
  }
  return e;
}
function Ka(n, e, o) {
  const i = n.rawBitFlag = J(e, o + 2), s = (i & 1) == 1, f = V(e, o + 6);
  Object.assign(n, {
    encrypted: s,
    version: J(e, o),
    bitFlag: {
      level: (i & 6) >> 1,
      dataDescriptor: (i & 8) == 8,
      languageEncodingFlag: (i & 2048) == 2048
    },
    rawLastModDate: f,
    lastModDate: Wl(f),
    filenameLength: J(e, o + 22),
    extraFieldLength: J(e, o + 24)
  });
}
function qa(n, e, o, i, s) {
  const { rawExtraField: f } = e, c = e.extraField = /* @__PURE__ */ new Map(), d = ae(f);
  let p = 0, _ = !1;
  try {
    for (; p < f.length; ) {
      const $ = J(d, p), se = J(d, p + 2);
      c.set($, {
        type: $,
        data: f.slice(p + 4, p + 4 + se)
      }), p += 4 + se;
    }
  } catch {
    _ = !0;
  }
  p > f.length && (_ = !0);
  const T = J(o, i + 4);
  Object.assign(e, {
    signature: V(o, i + 10),
    crc32: V(o, i + 10),
    compressedSize: V(o, i + 14),
    uncompressedSize: V(o, i + 18)
  });
  const A = c.get(1);
  let h;
  A ? (Rl(A, e, s) || (_ = !0), e.extraFieldZip64 = A) : Va.some(([$, se]) => e[$] == se) && (s ? _ = !0 : h = !0);
  const y = c.get(28789);
  y && (di(y, Ca, Fa, e, n), e.extraFieldUnicodePath = y);
  const R = c.get(25461);
  R && (di(R, Ma, Ua, e, n), e.extraFieldUnicodeComment = R);
  const m = c.get(39169);
  m && (T == 99 || e.encrypted) && m.data.length >= 7 ? (Tl(m, e, T), e.extraFieldAES = m) : (m && (_ = !0), e.compressionMethod = T);
  const v = c.get(13);
  v && (Ei(v, e), e.extraFieldPkwareUnix = v);
  const g = c.get(22613);
  g && (Ei(g, e), e.extraFieldUnixType1 = g);
  const b = c.get(21589);
  b && (bl(b, e, s), e.extraFieldExtendedTimestamp = b);
  const N = c.get(10);
  N && (vl(N, e), e.extraFieldNTFS = N);
  const C = c.get(30837);
  let L;
  C && (L = hi(C, e, !0), e.extraFieldInfoZip = C);
  const x = c.get(30805);
  x && (hi(x, L ? {} : e, !1), e.extraFieldUnix = x);
  const B = c.get(6534);
  if (B && (e.extraFieldUSDZ = B), h)
    throw new Error(Kn);
  return _;
}
function Rl(n, e, o) {
  e.zip64 = !0;
  const i = ae(n.data), s = Va.filter(([d, p]) => e[d] == p), f = s.reduce((d, [, p]) => d + ci[p].bytes, 0);
  if (n.data.length < f) {
    if (o)
      return !1;
    throw new Error(Kn);
  }
  const c = [];
  try {
    for (let d = 0, p = 0; d < s.length; d++) {
      const [, _] = s[d], T = ci[_];
      c.push(T.getValue(i, p)), p += T.bytes;
    }
  } catch (d) {
    if (o)
      return !1;
    throw d;
  }
  return s.forEach(([d], p) => {
    e[d] = n[d] = c[p];
  }), !0;
}
function di(n, e, o, i, s) {
  if (n.data.length < 5) {
    n.valid = !1;
    return;
  }
  const f = ae(n.data), c = new _n();
  c.append(s[o]);
  const d = ae(new Uint8Array(4));
  d.setUint32(0, c.get(), !0);
  const p = V(f, 1), _ = Nt(f, 0);
  Object.assign(n, {
    version: _,
    [e]: Fn(n.data.subarray(5)),
    valid: _ == 1 && !s.bitFlag.languageEncodingFlag && p == V(d, 0)
  }), n.valid && (i[e] = n[e], i[e + fl] = !0);
}
function Tl(n, e, o) {
  const i = ae(n.data), s = Nt(i, 4);
  Object.assign(n, {
    vendorVersion: Nt(i, 0),
    vendorId: Nt(i, 2),
    strength: s,
    originalCompressionMethod: o,
    compressionMethod: J(i, 5)
  }), e.compressionMethod = n.compressionMethod, n.vendorVersion != ja && (e.crc32 = P);
}
function vl(n, e) {
  const o = ae(n.data);
  let i = 4, s;
  try {
    for (; i < n.data.length && !s; ) {
      const f = J(o, i), c = J(o, i + 2);
      f == 1 && (s = n.data.slice(i + 4, i + 4 + c)), i += 4 + c;
    }
  } catch {
  }
  if (s && s.length == 24) {
    const f = ae(s), c = f.getBigUint64(0, !0), d = f.getBigUint64(8, !0), p = f.getBigUint64(16, !0);
    Object.assign(n, {
      rawLastModDate: c,
      rawLastAccessDate: d,
      rawCreationDate: p
    });
    const _ = lr(c), T = lr(d), A = lr(p), h = { lastModDate: _, lastAccessDate: T, creationDate: A };
    Object.assign(n, h), Object.assign(e, h, { rawLastAccessDate: d, rawCreationDate: p });
  }
}
function Ei(n, e) {
  if (n.data.length < 8)
    return;
  const o = ae(n.data), i = new Date((V(o, 0) | 0) * 1e3), s = new Date((V(o, 4) | 0) * 1e3), f = { lastAccessDate: i, lastModDate: s };
  n.data.length >= 12 && (f.uid = J(o, 8), f.gid = J(o, 10)), Object.assign(n, f), Object.assign(e, f);
}
function hi(n, e, o) {
  try {
    const i = ae(n.data);
    let s, f;
    if (o) {
      let c = 0;
      const d = Nt(i, c++), p = Nt(i, c++);
      s = pi(n.data.subarray(c, c + p)), c += p;
      const _ = Nt(i, c++);
      f = pi(n.data.subarray(c, c + _)), Object.assign(n, { version: d, uid: s, gid: f });
    } else n.data.length >= 4 && (s = J(i, 0), f = J(i, 2), Object.assign(n, { uid: s, gid: f }));
    return s !== P && (e.uid = s), f !== P && (e.gid = f), s !== P || f !== P;
  } catch {
  }
}
function pi(n) {
  const e = new Uint8Array(4);
  return e.set(n, 0), new DataView(e.buffer, e.byteOffset, 4).getUint32(0, !0);
}
function bl(n, e, o) {
  if (!n.data.length)
    return;
  const i = ae(n.data), s = Nt(i, 0), f = [], c = [];
  o ? ((s & 1) == 1 && (f.push(Tr), c.push(vr)), (s & 2) == 2 && (f.push(za), c.push(Wa)), (s & 4) == 4 && (f.push(Ga), c.push(Ya))) : n.data.length >= 5 && (f.push(Tr), c.push(vr));
  let d = 1;
  f.forEach((p, _) => {
    if (n.data.length >= d + 4) {
      const T = V(i, d);
      e[p] = n[p] = new Date((T | 0) * 1e3);
      const A = c[_];
      n[A] = T;
    }
    d += 4;
  });
}
async function Sl({
  reader: n,
  fileEntry: e,
  index: o,
  offset: i,
  crc32: s,
  compressedSize: f,
  uncompressedSize: c,
  dataOffset: d,
  dataDescriptor: p,
  extraFieldZip64: _,
  readRanges: T
}) {
  let A = 0;
  if (p) {
    const v = !!_, g = await Dl(n, d + f, { crc32: s, compressedSize: f, uncompressedSize: c, zip64: v });
    g ? (e.localDirectory.dataDescriptor = g, A = Sr(g.zip64, g.signature)) : A = Sr(v, !1);
  }
  const h = {
    start: i,
    end: d + f + A,
    fileEntry: e
  }, { indexes: y, sortedRanges: R, pendingRanges: m } = T;
  if (!y.has(o)) {
    const v = Il(R, h) || m.find((g) => br(h, g));
    if (v) {
      const g = new Error(ls);
      throw g.overlappingEntry = v.fileEntry, g;
    }
    y.add(o), m.push(h), m.length * m.length > R.length && (m.sort((g, b) => g.start - b.start), T.sortedRanges = Nl(R, m), m.length = 0);
  }
}
function Il(n, e) {
  let o = 0, i = n.length;
  for (; o < i; ) {
    const c = o + i >>> 1;
    n[c].start < e.start ? o = c + 1 : i = c;
  }
  const s = n[o - 1], f = n[o];
  if (s && br(e, s))
    return s;
  if (f && br(e, f))
    return f;
}
function br(n, e) {
  return n.start < e.end && e.start < n.end;
}
function Nl(n, e) {
  const o = [];
  let i = 0, s = 0;
  for (; i < n.length || s < e.length; )
    s == e.length || i < n.length && n[i].start < e[s].start ? o.push(n[i++]) : o.push(e[s++]);
  return o;
}
async function Dl(n, e, { crc32: o, compressedSize: i, uncompressedSize: s, zip64: f }) {
  const d = Math.min(24, Math.max(0, n.size - e)), p = d ? await pe(n, e, d) : nt, _ = ae(p), T = [[f, !0], [f, !1], [!f, !0], [!f, !1]].map(([A, h]) => fr(_, A, h)).filter((A) => A && A.compressedSize == i && A.uncompressedSize == s);
  return T.find((A) => A.crc32 == o) || T[0] || fr(_, f, !0) || fr(_, f, !1);
}
function fr(n, e, o) {
  const i = o ? 4 : 0;
  if (n.byteLength < Sr(e, o) || o && V(n, 0) != 134695760)
    return P;
  const s = V(n, i);
  let f, c;
  try {
    e ? (f = We(n, i + 4), c = We(n, i + 12)) : (f = V(n, i + 4), c = V(n, i + 8));
  } catch {
    return P;
  }
  return { signature: o, zip64: e, crc32: s, compressedSize: f, uncompressedSize: c };
}
function Sr(n, e) {
  return (n ? 20 : 12) + (e ? 4 : 0);
}
function jt(n, e) {
  return n.getDiskOffset ? n.getDiskOffset(e) : 0;
}
async function Ol(n) {
  return await Ja(n) == 134695760;
}
async function Ll(n) {
  const e = await Ja(n);
  return e == 134695760 || e == 808471376;
}
async function Ja(n) {
  const e = await pe(n, 0, 4);
  return V(ae(e));
}
function Qa(n) {
  return n === $t || n === Lr || n === Ut;
}
function Pl(n, e, o) {
  return Math.min(n, o ? e * El : e);
}
function $a(n, e) {
  return _i(n, _i(e, Lr));
}
function _i(n, e) {
  const o = n[Li];
  if (o !== P) {
    if (!Qa(o))
      throw new Error(Yf);
    return o;
  }
  const i = n[Oi];
  return i === P ? e : i ? $t : e == Ut ? Ut : Lr;
}
function Cl(n, e) {
  return n === P ? e != Ut : !!n;
}
function Fl(n, e) {
  return n === P ? e == $t : !!n;
}
function Ml(n, e) {
  if (n === P)
    return e;
  if (!Qa(n))
    throw new Error(Xf);
  return n;
}
function Ul(n, e) {
  if (e == Ut)
    return !1;
  const o = n.split("/");
  return o.length > 1 && o[o.length - 1] === "" && o.pop(), ul.test(n) || n.startsWith("/") || n.startsWith("\\") || cl.test(n) ? !0 : e == $t && (o.includes(".") || o.includes("") || n.includes("\0"));
}
function xl(n, e) {
  if (n !== P) {
    const o = Pr(n);
    if (typeof o != ds || Number.isNaN(o) || o < 0)
      throw new Error(Zf);
    return o;
  }
  return e == $t ? 0 : e == Ut ? 1 / 0 : 65535;
}
async function kl(n, e, o) {
  const { size: i } = n, s = Math.min(i, 65557), f = { remaining: dl };
  let c, d, p = 0;
  for await (const [_, T, A, h, y] of es(n, s)) {
    const R = J(_, h + 20);
    if (y + 22 + R == i) {
      const m = await ts(n, _, T, h, y, i, f);
      if (m == Xn) {
        if (c || (c = Ir(A, h, y)), p++, !e || p > 1)
          break;
      } else m == zr && !d && (d = Ir(A, h, y));
    }
  }
  return c || (c = d), c || (c = await Bl(n, o, f)), { endOfDirectoryInfo: c, endOfDirectoryReachingEndCount: p };
}
async function Bl(n, e, o) {
  const { size: i } = n, s = Math.min(i, e == 1 / 0 ? i : 65557 + e);
  let f, c;
  for await (const [d, p, _, T, A] of es(n, s)) {
    const h = Ir(_, T, A);
    f || (f = h);
    const y = await ts(n, d, p, T, A, i, o);
    if (y == Xn)
      return h;
    y == zr && !c && (c = h);
  }
  return c || f;
}
async function* es(n, e) {
  const o = n.size - e, i = await pe(n, o, e), s = ae(i);
  for (let f = i.length - 22; f >= 0; f--)
    V(s, f) == 101010256 && (yield [s, o, i, f, o + f]);
}
function Ir(n, e, o) {
  return { offset: o, buffer: new Uint8Array(n.subarray(e, e + 22)).buffer };
}
async function ts(n, e, o, i, s, f, c) {
  const d = J(e, i + 10), p = V(e, i + 12), _ = V(e, i + 16);
  if (d == 65535 || p == 4294967295 || _ == 4294967295)
    return await mi(n, e, o, s - 20, f, c) == 117853008 ? Xn : ui;
  if (!d && !p)
    return zr;
  const T = J(e, i + 6);
  for (const A of [s - p, jt(n, T) + _])
    if (await mi(n, e, o, A, f, c) == 33639248)
      return Xn;
  return ui;
}
async function mi(n, e, o, i, s, f) {
  if (i < 0 || i + 4 > s)
    return P;
  if (i >= o)
    return V(e, i - o);
  if (f.remaining > 0) {
    f.remaining--;
    const c = await pe(n, i, 4);
    return V(ae(c), 0);
  }
  return P;
}
function Hl(n, e, o, i, s) {
  const { rawFilename: f } = n, c = !s, d = n.decryptedDirectory && (e.rawBitFlag & 8192) == 8192;
  i && !d && (o.length != f.length || o.some((p, _) => p != f[_])) && Je(c, s, ol), (e.rawBitFlag & si) != (n.rawBitFlag & si) && Je(c, s, il), e.compressionMethod != n.compressionMethod && Je(c, s, al), !e.bitFlag.dataDescriptor && !d && (e.crc32 || e.compressedSize || e.uncompressedSize) && (e.crc32 != n.crc32 || e.compressedSize != n.compressedSize || e.uncompressedSize != n.uncompressedSize) && Je(c, s, Za);
}
function zl(n, e, o) {
  const { dataDescriptor: i } = e, s = n.decryptedDirectory && (e.rawBitFlag & 8192) == 8192;
  i && !s && (n.crc32 !== P && i.crc32 != n.crc32 || i.compressedSize != n.compressedSize || i.uncompressedSize != n.uncompressedSize) && Je(!o, o, Za);
}
function Je(n, e, o) {
  n ? Mn(o) : je(e, o);
}
function Mn(n) {
  const e = new Error(zf);
  throw e.reason = n, e;
}
function ye(n, e, o) {
  return e[o] === P ? n.options[o] : e[o];
}
function wi(n, e, o) {
  return Pi(ye(n, e, o));
}
function Wl(n) {
  const e = (n & 4294901760) >> 16, o = n & 65535, i = new Date(1980 + ((e & 65024) >> 9), ((e & 480) >> 5) - 1, e & 31, (o & 63488) >> 11, (o & 2016) >> 5, (o & 31) * 2, 0);
  return i < No ? No : i;
}
function lr(n) {
  return new Date(Number(n / BigInt(1e4) - BigInt(116444736e5)));
}
function Nt(n, e) {
  return n.getUint8(e);
}
function J(n, e) {
  return n.getUint16(e, !0);
}
function V(n, e) {
  return n.getUint32(e, !0);
}
function We(n, e) {
  const o = n.getBigUint64(e, !0);
  if (o > ll)
    throw new Error(jf);
  return Number(o);
}
BigInt(0);
BigInt("0x7fffffffffffffff");
try {
  qn({ baseURI: import.meta.url });
} catch {
}
const Gl = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258], Yl = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], Xl = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577], Zl = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], jl = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], ln = new Uint8Array(288);
ln.fill(8, 0, 144), ln.fill(9, 144, 256), ln.fill(7, 256, 280), ln.fill(8, 280, 288);
const Vl = new Uint8Array(30).fill(5);
function un(n) {
  const e = new Uint16Array(16);
  for (const s of n) e[s]++;
  e[0] = 0;
  const o = new Uint16Array(17);
  for (let s = 1; s <= 15; s++) o[s + 1] = o[s] + e[s];
  const i = new Uint16Array(n.length);
  for (let s = 0; s < n.length; s++) n[s] && (i[o[n[s]]++] = s);
  return { lengthCounts: e, symbols: i };
}
const Ze = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function Kl(n) {
  let e;
  n({ wasmURI: () => (e || (e = "data:application/wasm;base64," + (function(o) {
    let i = "";
    const s = o.length;
    let f = 0;
    for (; f + 2 < s; f += 3) {
      const d = o[f] << 16 | o[f + 1] << 8 | o[f + 2];
      i += Ze[d >> 18 & 63] + Ze[d >> 12 & 63] + Ze[d >> 6 & 63] + Ze[63 & d];
    }
    const c = s - f;
    if (c === 1) {
      const d = o[f] << 16;
      i += Ze[d >> 18 & 63] + Ze[d >> 12 & 63] + "==";
    } else if (c === 2) {
      const d = o[f] << 16 | o[f + 1] << 8;
      i += Ze[d >> 18 & 63] + Ze[d >> 12 & 63] + Ze[d >> 6 & 63] + "=";
    }
    return i;
  })((function(o) {
    let i = 0, s = 0, f = 0, c = new Uint8Array(1024), d = 0, p = 0;
    for (; !p; ) {
      p = T(1);
      const v = T(2);
      if (v == 0) A();
      else if (v == 1) h(un(ln), un(Vl));
      else {
        if (v != 2) throw new Error("invalid deflate block type");
        h(...y());
      }
    }
    return c.subarray(0, d);
    function _() {
      if (i >= o.length) throw new Error("unexpected end of deflate data");
      return o[i++];
    }
    function T(v) {
      for (; f < v; ) s |= _() << f, f += 8;
      const g = s & (1 << v) - 1;
      return s >>>= v, f -= v, g;
    }
    function A() {
      s = 0, f = 0;
      const v = _() | _() << 8;
      i += 2, m(d + v);
      for (let g = 0; g < v; g++) c[d++] = _();
    }
    function h(v, g) {
      let b = R(v);
      for (; b != 256; ) {
        if (b < 256) m(d + 1), c[d++] = b;
        else {
          const N = b - 257, C = Gl[N] + T(Yl[N]), L = R(g), x = Xl[L] + T(Zl[L]);
          m(d + C);
          const B = d - x;
          for (let $ = 0; $ < C; $++) c[d++] = c[B + $];
        }
        b = R(v);
      }
    }
    function y() {
      const v = T(5) + 257, g = T(5) + 1, b = T(4) + 4, N = new Uint8Array(19);
      for (let B = 0; B < b; B++) N[jl[B]] = T(3);
      const C = un(N), L = new Uint8Array(v + g);
      let x = 0;
      for (; x < L.length; ) {
        const B = R(C);
        if (B < 16) L[x++] = B;
        else if (B == 16) {
          const $ = L[x - 1];
          let se = T(2) + 3;
          for (; se--; ) L[x++] = $;
        } else x += B == 17 ? T(3) + 3 : T(7) + 11;
      }
      return [un(L.subarray(0, v)), un(L.subarray(v))];
    }
    function R(v) {
      const { lengthCounts: g, symbols: b } = v;
      let N = 0, C = 0, L = 0;
      for (let x = 1; x <= 15; x++) {
        N |= T(1);
        const B = g[x];
        if (N - C < B) return b[L + (N - C)];
        L += B, C = C + B << 1, N <<= 1;
      }
      throw new Error("invalid huffman code");
    }
    function m(v) {
      if (c.length < v) {
        let g = 2 * c.length;
        for (; g < v; ) g *= 2;
        const b = new Uint8Array(g);
        b.set(c.subarray(0, d)), c = b;
      }
    }
  })((function(o) {
    const i = (o = String(o).replace(/[^A-Za-z0-9+/=]/g, "")).length, s = [];
    for (let f = 0; f < i; f += 4) {
      const c = Ze.indexOf(o[f]) << 18 | Ze.indexOf(o[f + 1]) << 12 | (63 & Ze.indexOf(o[f + 2])) << 6 | 63 & Ze.indexOf(o[f + 3]);
      s.push(c >> 16 & 255), o[f + 2] !== "=" && s.push(c >> 8 & 255), o[f + 3] !== "=" && s.push(255 & c);
    }
    return new Uint8Array(s);
  })("zb19kF3HdSfW3bfvx3v3vXl3gAEwwIDAuRcQNZQ4AClRA4qkpWmIg+EQhKh19Ier4ioSAkcS7gMBvvdGIOWlOUPxw5BNaRGHUdEOa43YSqRykRUmy93IDncFr+m1dq3d0BttLROpUqpYZWsTpYrKslysFEOGv3P6vo/5AEAStsMp8N17++v06dOnT58+57Q63rtfK6X0fzp2r1lZUffqFb2CJ71yb7DCP3pF8aO6V+mVe+2KPKp7oxX+T6/cG6/0H63/1Y/olXtD/zX49LFEW6W1jSJtdM3UNf4zxtSM1irQQVAP0yAIlDKN0NjY2liFYRhqYwNjjTEqaupQaaViZZPAhvoBXa+HkdZfMV8xUaJXtHvhO2Ea/5ml6P6l+890v2xU4+Tpz586vrz08XtOLz2okvH+68nTJ5fv6R5/UNWaI99UmvXfH+ieObHU66nGoJal0/ep1vb+66njveV7Tpw53fvS/Uv3qSz1CdJYVUrqHc+GX7npLeMjn77wKycfUFtb1bd+6/1aufFt1dvatu9bGm67euO2J7LhV2572/jIJ257e6v6VrW9o18r2t5pP99dWlJmW/VxDQjR/cdPnTpzQunG8aXePV+8//gJBmau2X9laFzWf6/auWNQAg0tppzz5PFTJ39lSamd99xz8vR9J7tLJ5bv+fyXTp9YPnnm9D3Lxz93akmrnfcs3d870T35wPLS6Xt6y8dPtO/pLvWWz3SXVLR7XdIXlpbvOfGlbnfp9LKKi3vuOfHQ8XtOnj7RXbp/6fTyPUsPnVh6gCvvLn3+xJkvnV5Wd9ZaWjmd1tTU7ubk0UO3fKL+0rPBMaPS735Qpyv7lMvaRX2/MnPr/0i51/UxO+ce3zZtVBG4jJRLS/dG0MHD4lQRueBsoc4W2gUdixLarfSc7pAqC+OC5UK757aVhSI9bV7cVuhpkxThEa6RAvcImQc7s0Y1dEohqVnTIEXhrElS0i4pc0WauBbjgu6ssXgtC43KrNP40khTitxTDF5yrKlJAwpnSKGQItPukia13PkiQFwuFINjSDE4ai04+sFOEfQBMgDIeIAURR4IRVFZWOL6NEXtIhRYSJEukVtRYucocQ910Fqu3TOALzdmhQKnKXHB2eUi7sz7dinuooxGo0BQmgfo6KxJKKhg0PITCCiMG/fMNrKzRrmntnGjjTR15xgR6XxTU/pFZ5anzYs7CgNsPdShqJ1bMrkOeJymTVaoectPE4Wab+oUWPE5C03Atl0s9FSOnhnSU7khlQPMlMy0mcxrZPDQKNSCncNTUuhqFPWsSRp1zjhRaLtCxk2UIV6zQs83AzIuK9M8DOYozGPShXITZR4ChIlCNxUpl/n3DO8pxU6hl7XUreQRKffdlaOcLS0L7R7q5JHvfTzfVG5vnjglPVbu9bffjo/ZOYrctaCrs18oVPssE6nTy233iTJPUk/wSYU0jdFROSgBPxS5nZQ4fbbtFCVu78LUcm4qRFY4C8je3VSk85CCwjaVU7klnatGAPJhPAfEY+uuOetsp+S+HZkiRcFUrsg4vZwbQm9RIOwKDKEzlIB0Fal2l+IORisgVQ1wrlLi8QvmhkfQkF3MNRkMpIxhiIcKpXaFtKA7LRS3GM43FVmZTBS10ZUQw5xQiAc/zOH6YU5SfJVhDnmYw/4whzzMJpgjA7KWYTZrhtkMDXMgwxwP5nUIDiRTSJk5Cpk8XXa3nZOpaEj3J2BYAiQ1mK2YVIrC/tQNR/mHU7lxKtcpZhFKYlYZroEnWaMGOM4zHGbRzrnz28gwAMj77Db3LCcJHCg2DEyfYVRVeUo6WBbWrLgfTU4bZefcT/ALOvvp5OGVQ0a5H08eXr2wurq6avH2o0mqu0bpHui4V3//3/1+2EPLr00ymtxF/7tKaaHLInCKdLuIO2BMx5qJe2mSMWjn3Iv8lJAuixolxyik2mK3WUvNnLs4OaOUs2BIFef3/ULBlydzJZSF4hgMCilhSisXmwFzjURIyKksLIxbOdIMSOeB+zG3qZxuFyGZDpgNmTZYasnE3CnzIKUAoAYeVNUHNaSgLGIKj5GieLHbtCkFWVgoMgtN3QhRzrQxG/CVKUgJUEeamgxPCkCiKXI3lBQAbpWbhk0F4ZgfFLRLXiQ6hclCyW0oKPOAswYpGbey0DQp8HwRpZwFr05J+45yj9FOFzzyWLcZ4hesIHLT5bFmmLoXJ6VD6A6P1Xf4TYGavjOJiaTSPsLtAOHSJUy1aWOLsDzSNANUoxtPC+kBk2SOTYFZPC3Ey4TmvjeJ9UK5lyf5o/vmNreC329vE9LD8ytCPxhfWc5kvQ5nzYvbSGNd+c42sMmyUI4WmirFBAjcdLtQ7iEybQdSayM/ZoNfn3k1o8GqaEo3jbl2YZv7mW+4YVNwpmNYY452pWcNl3TwRAGFJfI/u42se4gst6KkYnd+m0xHoNOQajNOscb75gzZDZoLGCWNSH4q5JE5OoQ0GfqQ8W/msDD5EQDb85jXDQPePKMA7HwzSP1omblqtCwIDWsn02IRLvqFNeG1ZBP8xRvgL74U/shS6D5IISoo3cF2ASKwLisXpwrtplhWct+fvM6oQyYj7V6Wx8R9f5JFK7S3lj48LZB2k6VMeRdX7IuUs5DHwkXwaE32CBY6YaSPdJCLxYV2YTzULMAog3X/bYiQZCpxSJkVL09qx+Ld2eXCVMKQJsPCEEtgioUhjZ5BGNL4abhGblwCdrmXl8y3/eJu3LVkNlzcVUoW02w32cOMDuXMsntxR5lrZnUiNoQOcmIRMCTnIJaFIpaxkAVwjNuJSlkEUCIC8KquRIopKknA8Ex115zFWoslXWaD7ZRFgGUu5GUO1WaATM+aSZfkhmyhc+UalRhYcLcbAkAiXUh4Yk/mxjVSsn6tA8ULG/ELlQJDxUzBGvSeliqbutVt7gYUVJX8IqsikzUFJU+1ioTLIunXoN1DpOVjQBElZWHbeVwxOAogbT/rJdf+XI6FNaKTXq7XqSz5UmAg6nrxZF0BEIlgAfgLwDKVCzpOH8HkhXxYw9dGbnhbIzQZiCxjZAcgVOkeASs8K/sSkwohexE88XVP5pEBgw4WqkpUlUtJLsPfJwplIfNDJApE4G5qClgk0sEcS4qqgGScaxGJVFOxZAzBjQuAVkLn+wVpJaVovqmk/t0FSBmE9+IORhRp0LUMlWlqd26bUDc6VfUIRSmaNhnyR8iboVv8NJGS4Z2AoWjWTHqg7Zx0LBMqmEx93yAvcsJEPyGmWpnHFFCNid3mTOqqzyMqpmYpLglcj2I/FvHG/CF+t/xBJkpDJpbnEwateD4Ru2sp3pBPGMxGM8QnTMUn1BCfYKa1XIQVn9CeT6g+n4jdTojyzCeM3yrw6iBjXlQyegw+ga0ABltEfzBf8ImwLw6HfT6hMCC26qP11KiEhK2I48IpnM86hIeUEpnZPP6JUFAICtKgIMMUhJ0wGaYgnlyKKYhivzGO+/QTUuLpJ2G6ACD8NOF3IqQoAQzSDxbUNeiH9w2T1XYB9MMJE1WCmSPrWiJiWjAqNSy4C/PpMwjsBHxyiLwB+TQw15KHg6ynLrsxddkroq5AqCsAOgPBajBEXdyKpy7rriW72SoUyCoUbLQKYWaw0qKiK1OpBXiRlgYnAZfddBkS8qq2+7a/DOlqGTKevOLBphq1Z6JnwLyuOhl48jLC3IKB+kE2aJOVaoL7hA2gkBdzvpqQl+mTV8jkBTZL4TrySoW8+sRlqOaJq9Ynrtoa4qoBArMJcZnLEpdZS1xmPXGZPnEZ5A37xGWxybTrtDzKb1G1WRnoeChYq+UZIq3A759lbBvkN9VatDxY80Kv3rEinjKKU6q7rNyvSKX/W6qTFSxn3FeXYNuhnG0LdT8EmTkPWSenOxDXnOnw+gP2rSB2BiIGLzY1665yrwSsVl6/ujWgk6ikOFnu7ELTDK+Yur9ihtUCObI8ji6i1i8genRxZH2BLI42mCPLaiFeHK0f02pxtH7sh9RCATMVy4pIFyw0A+CNySwk7ZefoC8ssLJRtTzDB2DMT80GKywTsB2ssHbTFVa/5xVWM2Y9EQ+tsFpWWE/E1RQNvWYGndUdBtVrr3iEbSVqhV7UCkZELeUlpwEyAhnvhSYULqJOeEZ+W14Iw77fi2HBiBi2vjLsyyrkggZJ8bZhlIpYh2TXyV0jVDQ6MjYVXRTIKhxSQw2TVbCpGsp4NdS7JyuTbkg//V7KxnJAMuEakgmvnGTCKyWZcBOSCTcnmXVwU0DJQlNVk6SV9mVi1Vdb91dKi6WJGZqq2Jkiu1Zp7ZeqhFS1iOjBAtESMUz1F0rlrgXLOvuFQstCqYfEsEDEsGCNGGbNipkzK6OCWDwQxITDWqHRSb9NJLWROGbBqpkc+ts21RfHbF8TS3awXtrBeonKSefWcbeDoo+FwkrfBRNuMlfY2TmV5jFrF2Td8JjhwYi9ZuabTBEaeoEVUlNg+OlTqY5XhDOHxqsYLHbYHaZY4eZKdFnayxHIBQWUX4686qKRB/2NeCAy41oWboYnn5K55tcAzm+qUTV+PvJ+xdoVUjzXWINrWTE9pPKNyRaBqHyZo9mmYhYv7xVSR1m4GWbhWli48VNQ9fesIScxC/eADVh40J+PCvPRDOajGsxHEatG56MZmo9qaD4G/fkY8HwMeD4GMh+554Yxi3krctKkR5DBfOSEiSqhz659bzfi2WqEZ2uvFBr0Xr0bnq1GePYGleHcymMTahomJuHZA7LxPDtYw7PNKM8eHooBzw6GePYoHVU8247ybDvg2e+ejphnryeYfi+FZwejPNtsyLMvRyPhldJIuAmNhJvQyEZwY1PlebauFlgZG13xbNPn2Tho1Myz9WB3EzCDNJVgn/LxkJLdjT/QMYNzHebZARrxPFv3z8+M8GxT8WxWEAXg2Up4dlDxbDO0dcY6EgxxbOs5tvH7AV6umJW6nTgpZZYdCMsOALESasA4McvWYNkBWDZ+NHKBd/dZthGW7VUX1iPW91SWJawE/fMs0bGRkh2OqnbVvIFOb9Cahe1CZ7rwIrdt4+QkgBBGvBPB+cubKZ/fpYtYQX824ZX4Li4hkhuWssmw1l6z1p7UJ5XLlo819UDrttJK3c8mBC86jRSp/Sq1ap9Kc61X3Msqs6xbUs7Mmv1YnWcNkQqdStNxRTjYdY/wqv5AVk//y0BHK+5XsIq4byQA+UYQ0iNQP0lHlGdkVAT8Ydrs97/TTrsfHaJgPFCFQbUPt7w2cDd6MWtursbPOC0fX3xLzRoLXGXXiHRK2qk7RGJxDxwpolnz6iE5qtIucy2Kpo7msehYFdKwTz3rwjLHAR1IsNWBZMOkkWC7ovOAYpGJglkzLWJiQxqUSm4iA1K8fvgbSU8TodIJsrx5tE53Zs0NqRS4TbLuf+cNR3APsARy+MW31CFsBQ8/Kt++fwhn3+7FOgvAD7xTZnXVutVVQ9EU702Bks/Kz2ccy1fTDCYwO648ynenFPLgZrV0CxME+sO6fZuNpX9wh8lXzCP7lKN2MbYfAzZZYZVX9aLmB0kV0bws1NYfN+xmPUARuO++pUStc5FHBT+YrtqF7XwvGfcjVeZExr0elvk2Mu5VVeZTZNxrqsx3SRfz7UhXZT6OSTgHWWba3CYnybbYnSeyBDbzLcPGIzgUcb+a240MS/4m/igA4bXH9oZRnNQOHLzhxnraaI61svHATGzThdo/tct+/JZbb2Pmd1eeNor+0xQ/ncobjUyeihZ+7uXz+tbiVJ42xjihkdvGjDwVwfwQXhsHcPwei34hmW9+BNYC7TyhaEYpipcphDVD5HSZR9A/lkzvOO42nXkK3e98wyx058WMYloqbs2aaaxUWMwU/rI9BfPYMeS+VWNDMuZs6Uy2hxfqf8yQyJTY7VQeNw4wqPtxrEgWp383sKZm2a2+FXTwdLZ0ex+YB/PsdJiC3O/VmX7dn1fdotC1Oi5hQdD9PF2fas8WASZoHb2yVHfxMe5FkdoVSkOZm9NkU7J3d5pbKXY4EYAIM1IZBXnYmBnF4o1XiEU20pmg0L2tNwN1BqCuXoSZEin3vyZrExlPAa/QwAvzBMVrvFu1zOANTv3kccwltyhLY5z1FhWKIczu/nDw1Dbun8iUgwmHymPp2l7ftRuutGtDcM0ayxqyGbWNpf9RmDh9BBLbh+R/2ACSCskH3wMkLjkrUhyjHOvjpeACrW6Moe+MwiUb8sCtJhimkHdoFaCsbBuB04LcRuE0qCchm4eNG3kZZuK7XWCv2zmq431CplUgI7tvAO0+GiO7MbSNfRUGkI2VoFlj3+iYzlw5ubrJZVDWW0HHJctdITk/KSfPdrsy0VmmuoGM+2fr0ZTxdKWmyDY1kVQSf5onUlU8y+rUcNbc5kw+2bgx7XOSvWsa+C43kNJeZxabHxLxsJkA5m5epygPKPGDYVjNPd+EIlrDvioY7muAvgZUH+ook4f7o7dUngwx69Dps3w+1x4LlDZBKgrjVw8VdUjikXttoizSacMmapF7c7KE+IdjxtflMZLzsCiYc+c1J5zng/px4Hu5dMmtWnnUA5Rgzq2aPKLErRrJlnC2GrIlyJb4bM8Yru0ZM1xbvLY2StyFkYqS0YpojOpudfyUO7+zhLyzm9AvAC+jM+ZqQIumcXfB0JjbXYKplLSN6hntAhFzGzTcRLimCa7xzcmSxrDeJ1ItrBWdeadaWlcrpbxB8oqkz5A5/NXV1dVX1CHzS2RAO58l4/5UmLF20UIzwPEbeHXoApxmB3lENk8aM6l7GeMp6pXnwGjBSfMklXpsuknBD6R8zpdj+x67uHOWj86tn0BrZrgdnT+Wl5fBDI8bH+YZHrq33w46BVjRSs9lZ4X7/2ltZG1B9g+A/P/50Bp5ezWhpLeqMY0cf+yngpk2t3t2BxV9sjhVBNSkgJp4mm9+kGrY62W5MIvbKWiD0+DoM68hYztH7giwJ3hLmIX4qdYohHU0Peu49l2wjr2dd7Z3j5py1tzH7+FZfLJOl7Pmi/ylfhZrti2LdNbcS7Ebk7EYO8vnAYG75pj1042s27PYZaHR/d4Izlg8cn9ScZ6WyMWnUjZ2SakFRcBWSil1W49NiS6NUtahUQqDoWDWnKJxPC8f1OcbTMEKFBzkaUOlvF/flLskV8ZdWmgokoZaQw1R6OIO2holwyhv9UlRKtguUvp2keHjWZ4J21lmzxtO0bjbSrtoirYJtjIqdjB5/dGo/JADVf/Ckxajyal8B9PQfUWGny+WeSuYowa1YPe1gk+/tOxWevlWPH4mn6Aor1OCbQ2jYoJC2tpxZrksds4oXaRkj4IWgZoAqAmoPjxJ6kBNvZokOgU/3XlQmyKpjrwaQ7gSJDHLspQyhigVDMH+xKywplUMYrP2mFHaYKBNCX6Lw7NFgYWuDJaRRiw1RNL86ugUrUNR5NfuD4I4DIpYZwCXZZ1gmScMOo2XzrQPatYZpvg+CtbedwGWJxBKz7IxO0+6GG2BuaUuXlv3nndTdzxUdyx1v606Li1T2CeneUQtSqhRLl4CISJkJLwOyLhFGDcMZ97wXMNTcwPzs1+Ovx3Ur1tB91ujs5tAsrUBwftZgBWJsg1p/r9O1lcQzZpfFv73wKz5LNYdpnkGE1RPu4jWVfQfN6joTys+s8MzYxhPN65F0vcGDPnVQ8VWSlxrsUtN97hZ7DajK5eBqEbNssjcY6ad78QLbWmXec5GSuCQ10DzjpW0MZibjWlzE28CG9Pm+mIPfm4oCtqzOAWTbf78y3kLP5/N6/j5TN7EzxzI/GPmtnwf3m7m1dy6m7sgAbY6aJs5alJ0HWjo+Sdp3+PFvm9VEz6eUUrEXzn7jmeUuUVBDR6DFbBVe5P2UfT8ufWlaqCL2nBBTTXM3Br0bZuXz2Mhdp71DbNCyqww4XOZEGX2Ufj8uXwfvqginOcT+go23yx0vi6D8B4f1CaXzWMRs0lkzHV8y61QDOx2KC3zlN6pDpWm1Mpjqos8QOFwPu5dCCikBilAIaCIuTGzgl1Cp5jw1pd5TJGYStzcxfMAy/m+Cv8uLjH/xig8qI00N8HNsfXrboppQlqb4NZqlLdhjbzIXi4hxXgrjjUVxvf7h+Bz8Jf1RiRnv/HdbBoTUNwu81CsY/bg7Khd8BeKKb2bt0YpKkqhkqqhUsqyAoZqeUxJHkJ3mS4ymn2aL4H8feEu25fXIAEmecyCYB5SRrW2O3gXvAcobDNO4/lmneuplTNKDUYMdiftPJYFmdvJ9uc1mPTjJRWAYI3Pr5wWpe6H4M8XVacZ7KI6Y5BJKJRqQiSBPJpMBUgSBIf98ZQVHLIQhY46Tb3LfTet5MjUm2BEdA2wVKOdMKJNB1PcD2ERidp4J7r7mCkLzwiuoajtxsqCOUGDLIxsA/CBhoARMBjgCKPqLLac+e5baqF5DQy/Z80rhxrXgAP9G2HIfZlVhNi4sTtl5pFHjT3VE8Ww/eAOXpOybMnywAQ0hIbqy8L5Nt6E/dO3lMfI6kXVmfI7vsZOvzdqFFYcQoCckX3nnisUHhVtoSZbiUybiVKOG8y0IbbnJD7sLOrzYIxHujK9g3bOjHd33hIgJuwctQim+HtEJ98oUCyvY8AkYS/0i4aG+oYO1FktgE11eNndLzc0dYQ1038+oo+iZr6lsSvtC+7NfAsG6H+SlWRHSs35Zo1qLJCDyKvVg5pAULNiUzu8pvmVQ8OiWCaiWGuNKNaikDLhQo1RUcxeoSzQAC/MQIDgWQ2n26yoGkM1ad5yKk8FfRnPjQm3Qik1SgaqwQwR4mCjQ+lZBiMDGC1Ky8V3BweLYbaS9bIZpfIGZQwcRixjTQlk+xKoIUstkV9ayN4AzKJnNu5fC8LH4B1DHf703Ur8lYnDSReVqNu+O6qLgy7V/csq/17Xoq1TFHXACO+qxJeUUhwCDg0F2+Rb4YjBPJ/8XEmnmcRfOUSpdMpv1kLg2PP7Fvo9KgdXMpTdYF5PbvBtxwbftsseMudT1X9V7Ttbs+YHh1Ihu1+WEcbjZzcku0ZnMN7vegcgI9swczzSRSYuU4wMOWxpUYPpbSvTWyb0ljGStzLNV/TWWENvyXuit2oY8pjnQZ7JvGhQK+dhiqshGh2KrE9FP0w3lI/Hgd8/q/CbQRBgQmJ5+I4BPQ2hl1I7SkzR+yCmO4aJCS2Owo89TT2PAOT3vSTbbLLuqtkY96z9jsJ61nyU5Qt4JhVsjnTDMWGbLGIQhIyRmdRKDVMShFS7KMN7M/53va+jXfrT3ptxsNQuUzkjhW6jTpbqi1MFhEELrUZep6Zr3QUtqWMFbI2C65Q6xMJCAmEhwE8AzZP16dNKzXK6lXTr041PP6jUrZxuJN34dBiuGWQYkUZwdl+jgOrZB0SGFSVMpXZhAL1cY3m0RO/gq1on24gOQYQS61pH0eG7eWWrgwe3OqxPGNJKosBYorQ11trAApia0+0blTr86FceP3f+wsVV/Uix75CCvLYPiKljibRe6yOwRJLWz2Jdhiw1mCvUBBjIbQU+mfZBpbJraey6IGEpc+y6IBsq67VJAdWPNGF6OijhG0b+fJ+U3x/MDZreL8OWCR6yNptIgJ/127btaaWyD15R2wENl3hvbQeCzqR9nVIjOBxuyFSV+4z5vuGK921YMRONhaRSz4MAArg9xuPNQ51yLVTDQzLSKpOQlcYtzAdkjte4NgoqGvTvTJOeA4Am66zua1Jd9Hz1hWajL240GhusB2MbfGtu8K0x2MInKSs766yziuHhLep/9weDPfFEUffnJQyYJfgKsbaSWQmfWaRgHikOaRv+aRL8fBpn4O3CgsdYapQEfQS6Lhb0raNT0G5Om4m8ziLcBidh/qAEilB/plMpQws+eBHNp9eDpmSbQKH7wyFV2e39oyN0gn2mk/lmIkoXTGjMUH+Agxbr2KK3vDR5e5HiA93NoKSsAr2dJRgKblHiToyxBcUni1NNtfk5Vb8n1amZrXS3lnsw39TwBq7OgJScAfEp1v+4YXeyoe7El+rO/rXdmf5b6k6yrjv70Z2XhonLYtB5tRycGMZXtt8Q2CqAQiijdotQ//ioPBikI0db/pQR5iQ3gBJdTY5jr0/XnoSvOb/iPf98k0WNiflmOLJJCq9wk2QZXk1cC8ElWLk/HFl1GUibB7yF9YCL4WGS0g6cUQDQVySv0zmMJa9USeUXIqzgTcU7sSa7gtkiQo1HYfvi7EITp1H/mt+9uUcwbW4W6TzwZjuwjJtedlnp2EqUYMETwV4nmm8atjC/vki4AOxebuDYFFwEG+frMXosktQpuZsN3GqUtCnJcqGUm8SP4PpZc4O3eoMUEpdUo3qbEug1IqpTRPXFIpkqoixnHSbARBY4JkZtwmc2kVtTHb/cBMcLxHFIBNj6whRnhA4uofrdbDUH9sl2DbBByZtsk5JzvA6YrdJuStqlWCVzb6J1e9+I974VoQ42vzCwQQSJQPa/dTIiak3wKXJAUbYHkMrj3lQO+XhIb2ADqWl41sMgDGepU6Vb1fIMx0QY5eATlALsxvPP8QHHVpwwC/HN/X2yU+LXy0BNga3T7iNTIIAjU/mkkNm/9WT2cD6JtZ3gGjKZ/nZNN1bEDAwGS2J/dHM+hp/bCJEMzAqN8V4u02J4NXc3Mlden3wK4GB8nZbs1IpwLzlLD+2ihl60oANpmjlqOfZyodStGthmpc6WxOdaNezQoQdnj3unl4/Bl17Jgt0seW+SSlZkKxKXoYIaOJ7Tna4zbAFZoxSRABLvj9OAyq3yxokpyTARvf1s4wjHaMBjsyyalB5j0XCD+hJp0jskwlm2csJOvLPlM4Man6pqTChdbMKFNJHCvKXasP5m39cxgTNkIt6OCTznvMu0yBYoSElVlPPGFA8HqIixVWB/oKb3B4q9pyHwUCTOdJqaHZEA4TgghBI/bedbkKOR1/kcR0xFGzB3jKm+xow3GXZ5jakOLlVHO4lvZ5L1F3VqLAxVMpLL8PeJIrYr1GBT3gYEjhi8tMGmvM1gjpp5QnFRhylvE92cKGIsghDpmlj6MrzDW3Hg8lpPKRNL3Qafc8M+IGZLXYwNxWypWwd266OWusmQpW6DMm+pmyEvW+ry00QK1RRP5AxMXoDmOR6DZXM3J1PfN16xkTDRT9giy6IfyfEBEYyPjqQM94aUuMVT9roylNCWDHIzVsY4ZbiwVDFiMHXZAnCXe9g9BFsV9vyKXdCZYg0l6sJxbHx0ikvWaIziN+uQI8YyQ7W0GPMM4t7KpvM2UjQ2a25OCcbKYzBIlAJsDJtVvh2c1wqPvVmUsCFF43B/41hBYMLtWd7Igi232YQYPh6Ty930Po3TBbviHkHu7BrPbHfDE+NmNpJeaysJ/qu9CaVeY0LJ0VsYjsyQygzp0D2Sppk3gvWml3NrrGJbWX3Nl866L3uzeloXO/lWdlf12Bk87s3uWmu2GWZj6X/4gG6Ko8ojpLJZmFoe7TbVrsqFo+GNNneLW7BFlBU24vQGrvaILBPW/Xa44I/mf47DO4ELpj8iE0xjbYJ18nR/A+vXJ5XdzBllU2ArkWRl1kxXLk32SJd9btyDjr2Oj06VbEPN74Gzd06Vd3abMOu/hMmldR9aYNPC3w4XxBcFlkGNLRIgSlSFP2fJTEJBrWrXWHarr+k2S03WG/1op+8UAfgHugicuaOp3EVIzoGLFpsKS+dF+M1HR6ZyCRxCYbcIHHWJV+eX9FQRuL0PUNB1e3vZJ+WbuK0f1B/BBzzckH0SuPTKdxEcGTrGF1DnZS00Yt3HwSO9uOntz724WZmpaZYjOCkp3V5WOG+c9hv6EonJLarvLytGpRvnU5eo428qzRlxi+OBqS28s2pYZ0WQ4WGbgk7nDj8sG9VC9hItBKKjHx0Epm6h1RaLqftz9hDdnbOQCbU/xMGcpcKM5wBXXpPKGeKabzx2asFBxEqmugx3MNV1HBpsqusyHI9NdRmGabObZfqqstBDGvqKgivLxeagkvGgjq6guhkVXz7X+0U+g924Amg4QAm8crHnvxJcTFwZLkIK0mlzPVssqmlMIcjmKIbN6Q1saDTYQhNHXpJ5yEzmT1R7LDS1Wi1gRd4PFSuk3F+phSar6IVamNcPejFHwUE9wTJ+G36jAFbOEMR6mzfEd8uMT6DukB7xIRCVrB4q+tZdjYINjCXL9fNgQKJIHO6PLRG2oF11afhorU/b4irUziN/jtdny410E0CiCoYJDnIwAgY0XRuBEQyBwRjlA5f+3nX3tNktS8NEHgtCdnsUidaZBavI9zRe30Rc8nm+b6LPPUNfkxdacXgCHYRgwhMIUShaELBxTzJ9sEEvgddq+D7KuoDIefGxploLRTCAYtDRH6rKUJrr2F/V8Tff1/3voa/vpad/NTyU18tQNip9jRFzogpQK9Chss0B6adecipXa2cFxlq+HVTEHPfJOuo/hf0ngYY9Vcy0eRn+1+ykzefvvx0eaepK5lipuJ+sijo71KjSPBM0lXWacT+Bn2zQT+R6TXbrcBuRUMnjB0SJoqXDz4G9qk9bbu2cpqCEH5UIERS0nc78mv+SnjXPMcNQ2c0ucPwRctaU9E7Nmhe0r4Sz90ffTJvXZryJ5mszcgLz05nh5fc9JMvQhexsh/AnwUFEei1hHWak1063Z83LuoKeFYez6BXXiP+/PnM5NOAcyakNUVB1n+PxpVIpq9+uBKuXrnK+GQhOX90KMzcZXbY9FdNE6V8RuccMn2oOcP+SFrspDL2eH8q32GnGFK3PTJEzR5t+3FiTN0wlRyp57GpQSdxHUu3qICn2KmkATkPmIRxgqcApF45+Ez7WhNKQn3T/ySzw5vsrpsybzgwfhYkHF841xPaKEgn3E3IhI09w0pYnu9C08hQuQNOKp2ihGclTvACVMVRlOHsKy6LG4OAY+f/RixTmASujYTnEp4ARnnBgCBIIYd/pLctwyMg+w/AN5NPC0EXe3C2E+Rof0NSo2UafOABZQBHOQqoBf20GgSVdsNjUu8Q9QeYUzyjEpdTDU66fHG44I9clo+Z2Iawd5hIz6sJ5RIOgtHSPJ2vmaMNd+E0NZ8z1s3favKDZpcsTqlAxW5i/LJtNYS8ym5liAZAc7sbMdTALg9HeBWvA7ycHG/ZuXTKFSOaxeZf8Jh1lOOp9Mxw59UOEhsA1Trk3tsInZNyotAjcIx1nxOXxt9ljigL3qx0+cec9cTPaNSwwBk4v9Bcc7IjbY6FCWHfN1rPnDsj8fepAESx3Oe5b4MY+zUwhulWfO7CZ5B1tvu2BsvmrB7xsjIpds51bZ1xGQfsse5iAkEq/1501Tx1wv/uUPqhlLYncBX5BTKLlbuGhYG1t0CZ7x2ADWS31dgOY1qYNYIIFp4csbJ/l2hGR02Vt0czbMgVIZLKD3mWXhYIZ+JsviBDzLGsWOA7qO409rYuwsv3nEFCKAjhJC30/e2CwWnu2y78YdPyCeip9BudhGUI0JbATZtqYBCXdBXNElmRAFqa/sK0fAN2XeTbPUsk8B/VH8stUNKM+ml+2reT9ZRmAU788OOmls/BhVYvnj8vOjqpHZJJNIq7sndY7qrf7cbXmU1aN/YTVUX8/3a31ypDKLNs1pIhL/5nWwQo0YFD1hX0VH7bPHCvlEpo+zURz6QznL5fhnH73ysRfZeXXz9WRqRSO2TozaY31e6cync5zbC/EWfFu89OG1njL75ZgDqwrUn4yWPeDt1Tb3bvIcKXP1ky8Ej9C2qsnzZx7+jHEb0PIzsd4QTj/mOZ1yGkcIUuqBBmdB+eD9ScfLIdwlYQXGluXs98rwiYUNXfhyf/9/3qkB6MYpzswVMd09xtOsG8oss7fKuttyOeYHG86D9yFx7Q846xBi32NoyPcRno4+UU7d/hVQ+nh4Mlfzeuc86E8cBJMp/4Ztq05rB/jB+v2djhG+YXHNAXZNCx/BA7kOcc2oyml33L15YJjXJ7/1Du85/wfI2xZv2lx14MHCMyILSxHg2xaYvv1u5Qe1g+zDWUKbOHgWEkJHCRm01j+AcOgBAeH7slRvDu42OSAy/OkXdyZFzdsnBUbwnBQ0GNzTfTk/K28GepxUAKESRk6AwZvmj5d1AC4tyVix2t9XUAUPf9E0fzWoJ5P5RESJkk9/0QxNpKgkJBR/PwTRWskIUbCOwLV808U2UhCiARFwfNPFOlIQnBY53UMzOHk78G0BqhmBPPxV/1w8GTROFeVKDnue49tBMZozXfVyyEzttZ+j3uwVads7fewl0MMTNd+D4C6OoarLqZQDDn6lY9xv/MW4yXPGG852Pw0wtHU3C+dIsMBX55/IrvueVjuP/8EP7WAK37KgE5+SoHxJ7Lr8oCDuHId3GCAkMTJooVzA9jDZUfYk4L31l/phZsWKRDQCqma1HDqIMFslhBslmA3Swg3S4g2S4jXJHAPE+lh4nuY/tOQmTb7VOYcy8nHwzrClgXoOgIn/vztoA0NhXvt7eAoTqktbmHIcOnG6uptJa8snESqi0A1fAEEzsk81v30qioMxJd7MKXIookHXLYMdozGEBqQa+y2wP5+aDguwgsfxu5Pc7jqACufr0xe4IXoH83gMRg82sFjOHiMBo/x4DEZPNYGj/XBYzp4bAwem4PHscFjC498OUXG8fE4RH5TVf3mow9+wBi98GEZpBc+XNGhsStMx9mAjq8Qo/2aw8FocuRkptuyUP7RDB6DwaMdPIaDx2jwGA8ek8FjbfBYHzymg8fG4LE5eBwbPFb40j42MkwqGRXQLMMUcLkbOp2m/7Kmt+NOmzk2LvCb2Njh4FdUv8SrZMNRSVrcqnkTs8znroP9zJCXNYeKi10Lx+hgpVXxui8Mvgrcy2oWwZRYAmwiZLrcJHHRzEL23fCz0/kYNrcxzpVhj5vHTrMpaY1P6akuG11us1a1qSuDWbC0UBLjgYttjEQxZ4rhpEW1o1P5mNNct3iWZwvibr2cp763XAFJS2gE9g3q003dsKgGXquI2jGP3i50m2LvRA00aFCzWIitQfQAx3wC3RAgPa5hfMHYDuUzO6SmQ7h3E/k4hcXWfKIKbTdmjEKYpJZbbVI0lU+4i2PuYgOPW92jJh/Hyfhq5lbHfGrLXWxKqsrHYYyFwCP6iPufI/eDiKKpYtJpGlsuWoudJqajOeL+3LpXLJJ2knxtYXh3ydnTFhpjna9xK1BHOU3Rcr49wGmvonEKaVvV36bT5dGm2kVNGl9kxUzT/ZjNNrbiU9vp5SJCzrxJEU1g057msVuhGmXtYsdyPkVbYM/OJvj5btrOA7ebEpoq2QiiLCJq3qoNRbQDXn4RxRD/E9zSwPTRXpZRKSKnz3IEwqgDHjMgpT7Rt4sqwkGbTIeiko/IcoPuIC5QzAuC+ASxObAe6qr/EeXLrg6MZI7A2OBYt8lOZXA8qx+doozGKJsqMhzHbKHt3K8tABUdjpdhH8I2JjFlZZEeZasghjX1LbSL1Kk7m5riPBoaS4wBtcqiRZNHOzyG1KKdRzvdZixTLiXBV0xjQFQsG+GYtsA2yZwFDpOcNQpoKW9W8weTC9MrlmnC1FsWQquDecK+Oge1Ail77gzTOfZ7wzYK1SsZIhxrix0nA0Yt5OGQDBZmF0pMIONW6lbSDytUFMwJA1Sif9d8KdZALuEQZ2n6n2tctRCQaov9vhH7fQhWYr/vF3rlQwgbsd9H3Gix39dQrWl/y0PKwSUl3dvva6jjkG44nYN9wUpy1xro2I5Ek8k+kKb3m2BFPyI3H6kCRt2BhGlqHZV4d9NGwYbPwkAbfrzWG2grig5VigpfOmxLLGwtdmR8SRcHBZdbNUil37Em6AfLCnCfGew2jgIYOanjqJu7fahrRp53ABiKUCX6n2EHAO7WWgeAaARK2+bI7UAg7yKaEWniLNpn4dXKr10i9YoiFPj05vwBJGCOuOmN8H31Ui9agQMADDeqEr5h5MfBOMpjtvebjmXc++slkwrHXq7arsz5r6TtQIxGfIn31nYg6BQHgGiThkxVufYOANFwxdGGFRsOPwiH2MBNltk+tpqExUCbg1FnH2ARiNhUpw3izFnDxraSOv2ywTWPPFUkJnefDAMZPezjnD3rA8Iy0RQyXQC3qjYSm5T30HpJb2gzodJCaxbfIMdx3NaS9K3cJDY6LI9vlGWWs9gqy906WPEbcbmSTFV3LfFmCy2S6njjIn22sJV2gMXDzpSwkrPVFie9UZrUPpBWtX37GPY56nBy7ok+C5JufCt9Tmu7IjPP7mfw27yDNwL5EY54oTkI4BRrHJyP5ChxQZXnlRHiVWi5PodXJ1ExswqLVyfM4ezDLCQY1GO8YIuBDEnC9hYRRGxcCACWzLyCFdT9/OlNOliR+5VgiVcEPtav00c5rr70rp3728jeZtO19Pc1W63xMZRh7PxDI1eL4ICK7xDjr3vk4/e3DX/cuuBjH5pKQBvGn9O36p/URAO1ekBiE74xI++vzYSbFdw0If1vDcMKnR7rbhXrcqErDlmbi7XCihJb+TC+fWWwYiUhK/o3SVOVopgjsPrKg0pR7Jpt8bwPvJZYZQeqmgaqSKnJDLWyLq3Sd26W/PbbQU9OWjaBs29/4iMYi+E3L065Nw+fIATRmUi/pX1sT+6LdrUh1GhfrR50/9yBoWY3SGf0iIZa3dVUl6uJbdJkYNA+8woluGNKRDgSlDx/IP1vKkDNSh9YNmp9n8BWEDgPdnIHXwlw2TpRfAC5S9o85mn6Vl3HUJXGg5tEcY4vKmWOV1mfNtdDRR/4OVVzb6++/TsrrPSLJOyVZfUnoiyByrHrYbM8fbYf9Y33CBpL10F9zjRZi/2U/33GNI2jvhIRCwsrBL0CsoYK56tzJA41Km4oESyBI3Y2AVp+ur3MbuSn1/tPP9ElOvGz7dlH+P3Vrfz+RvW+uoNzun+zDaxuC1Ywg14F2AYYOd8J4YbyytaqZyJ6S48E8W/MoMSpsgjdeDnLDGHavDnj6iWuXIWt6RQ/hcdE8/wqzqo5bEqMyCEwf8HpN2zx7VFv1MJHh9kMr4XgDXLr0FMHcov9HWcInOn6gyWzCbNYSxDmigiMT5U8zXpmodczC3fhce0ufE1nH2VChCGqB4cvbuoD4mF7PwD56dNkD2WXkW7LEsjgiM+OFaAw1EUNAQr8jaRvbMfWgxHT8PDQCM7eB1wSzmwYV7w4pW25lMTjgqwLyxSBvJ+SIdIDSGLSVwWS+NKQcDP8ZQBJ5P7ftwVJDFJzgJyrA9JG6CkST0yNtgh5VXPVd1umhfXgsT93NTNFtoyoLkJIsmZS4obIfjWXnwbJlXXAbAj70EQYhrXPD8BzCkO17KaK4xSaYn6DWdRHcfh2PZ+uquxAmv6rmh5fkUuBEn/YxjETJYRt8I6MAXnxlT9Vh8yF69ipMHDqTr4l1n37Oh5A99wOcOWVvN4X1qycAqlpc+E6XENwl5fdNF8od+E6WN3yKU2dJWQH0xJzRxFPyX1zCacWjRICj/K3gPaR9sYMGw+8AfOmOsXw9Y7mq1XozRmKeJNt2rPmzRkWf9gJRwRH6DCqgblwHRqve3jqDI+/7q5qz0i0kpi35iOipIZPh/XiMAuv6i7re8wfRIDnytW0eWEHb5t8t/lmxhd2EGsPs48JON+8jrcPs+abVQnYp8hhVtS/UW84V5XqccbGXf2eWugbElkRudssGON4nkVeGPvwFSn8hK1UtAiJG722FEATEcsPm7IPAetD6/XH9s6mSodhMx42GWDuiSgxn9oB/0k+120IxcV9isvkGrsk9+a8mQRxbyKoNxT2ooTk2Av94IAMhz9Vs6y9FBgEwZW8a9xLVhLQS/eSvWsqH+dl1khHDI3D1TTmI1ApW+Dgs9hSFnBriWnMhybCpgOFsDreVZipogX8GNGfBzm4SQM6p4gjDI7avXB08pDST7NfUcjqJG5LIuLLMj4mthoBtcpTspI3hwkb0Q22AIqSQqQLeRsOJYA9D2+FoGsk2VBFZAo+LzAMThO1j0GSoSaNOd2WnVLIiQYmLFDa3MpqqlR0fRz2z5k78b92Dhd6VD7PfdSVMs/Itpb10IiNUQzQCHxwYH0xBEL4J9yHvlBNwTdmEBKKr85s+x6HpKu5Vm1/ZZMl6hDYhkXZh0Lmwib72FC+9J8YXVshjVAhfK0ok8Dbbwe36shZF5CFxjx2v67xlPi9lzCuFQ7S7jedqedjlo+rQ7nhlS8USo/wrVjas7KKKOwRLAn4FB6F3tSsQFEt8bgCr3+N0M9QJiFbx7CiiReUKlPIyBB6SWVX9tR2fn1qOxdi2bB2TLB3UJ+XxPPbvcrioH5avjy9PUXMwLqLHG5YtEeKYKrqtgucpWDKo4Px9oNE1/ym5rUZlv9Y5Au9yBc0qgvDfzoDLzQ7owxHB+WV7qDyIeV1Ze0l+O9vKkF1UbX5q3aWLuPoAXcMFsm1+7bwEnu6oUUyGt5Y+l0rTrRgg2TEBknkw5At7IoaZnbCUD6ZjIL5eFLUfV3xchfKAFnNBdZ4CNbYwxNXG8grg7XehzVun/X1wwjP20vhsVrTa25325262/obFC98HX5QHphk2qyOF4k34GKezuKHHRaa1oJhr2SfvkZksu2zbCaYDCy6RKiUjxWsirgrchGebhcJJS4+61ZN+c77o2ZxakZd+E2P+ViYgOgQmdwRXGZY3+Ayivpdez8qh/pwP3z9cOToYzsqU2iHGdsWnrAJ/Ckv/ANEgnEZnle3wPPcUynURsGALqT9gf37u6IEuw7R6wEctFhRdR9gCWVapDJjcdFyCrb3lYTVyyGeV3FVSTCgCnHRvvSUs1eGWN2HW/ntGV88nXlp3+/Q0n+U6vqKsFuw5CKeyi2z4XiKzQU88x1lvCscplthC8e3+YRUF6arRVSsVyw3ofiI6PHKwgjT5TsHhenGfGIUeEZmPSODXVRQUZ8VztSgcA2SojaFQ0haO8LDSFqbNoSkRh9JYfusrz8cDG7IgxmKdWR1OoPDqsGOO6h23IhZyQFaIorZWlUCRfpesi40l8vQI+G1tqJSMyeDfqnZdEUUayoeW0qEosgboAYy5HZ4F8y3yGHlEkhgOQVcHNRf314MYBmZRVcBJrMBTMa7Kj91gMJqu2lc69N9rmnWbjUj31i0wVbTVN4wl91qGj8tDGLFGor9qYM06FPYPinm2AkUypoeyJq+Fm2/+XeKtrcqtI39LaKt2d4IZRJoORA5Zy2WvvF3iqW/rrBU/1vEUs0vE6NYQrBaIxGjPXwpi4ExJUcKw2JgAk4MMdBADEymOKq6iIJva52uyNYeQhu29kXY37QWNShFOErwsvexkZOUajto75TrUMl+usl32WND0C1sVT6uFCaJT/TfG9X3psTDbS7wFoP9E3g/P6MkgI3Fdilli5DRGmy/5kXezLETioTok90uLs0i3xV/uaLfXlQfazhef0yL6a65pOku352pK9NdKFAlWssPFe6p2n7MwdhcL7tHL6yazpTcLyi+qdoYw9K9+9ARUvBh63Kco48vNKtb2036Zo1HYdo0XNgumCYehoE8BYtTOW9zOXYNn7MuiLWRKLf5+JzvM/N69g+x5jfmWCmgI3x+SYvk8JwuGpDWcPs6wkQZROLh/SyiQIhS7+6pwhyFerhO8XwHaQvdbocjHSmJBnCE1T2dIspmhg5PnG17+h58CtqDs5rBV4OvK9UBzeC7bg+cCcWjI5WQItL7Bn7PaekHaz1gSHR0ih1xGQ8W9lgN9qrla9DhJwu3mExeJjhlQibgc5rfnmO1d5sHoTp+YPuLBpns47tGP5T+/mv2v23L3djB4KSI7wxM5Tb3gE8L5J5gWxi5N5BHgkmQw0QbhHHkgWY3Nb6ubfWA7yWbgABT6JzPxf4PPMVf0lIJhlz7EYZ/x1E+UQpQdcC+fFwZ5jO0QB5RqwfAfI71FXRoNa0qwe/jB+6WetBgWgFU+nFAeEWyFVgvaZh3GmlMOO7DUkcRtKGdpxDx0EtfFYB/jhnqO2P+9IGjAsSsefoAb3Wt+O/psVArpbTHJvxBYQsXSLHncLXfoPfGBy1GtrubfnCLUHBm7+CewGygDyT8sHnkK+Twrd3mMsh5mAKvBHtJy2Sr0GSkb4EnQo7aARYtYfYEJ3D6xACApDzaggHagmG02XZVnKxH2wbYqlBRRO0irOZ5Y5gHAC2Bn9G2YigBprpYnAWY5H46Rwvd+W7T9LEtN6UKqOc0Rey8DjwdnSoMm7OJg80u8ZuSEdrFnu9pocEX/BwzZYVpzGfokZwJXcAXnLuEzy0pSH9DvEHYRSI76EOVFFqujoPyJVic8re2e1/mjHRFgQ3Spdz0LN9LiUXDR7h6MOFxiCO3a3Llil+Rpvs+Z+/Ak6Xp1zQ7rvANecxjYMRs/CKPac/I3I2wR4Eo8eFKnLP1kjkycBDHYfIeH7LMF3Dc1lD6Xh8QTCop+zrfhF8Qgi/9rYQv+mVTgtgfiEZyg151ePqydk/w5SgKbq3ypTDuSTFuEm8eccCGa6NXHL2ks9vEIQWk4Z40bU+Xpr0oQJLJfgEk+oL2XXhB5yYVB1sX3F31dNQbUIk3oFSlps1F3R46iR/1VFaVX+TQcf6GOQw8J43EAxn2nIzEc9JrMsUQJGaNpNz7g42m10sgmtriFLwqy8qtcqSYErRJNwvTxk5NXl+fkWn/2gwfBgaLMvVe0dXJqWj9X9DBXDW3/akHz222Ruhkt/mJ/4L2GnO4bvb16MNFArILzZANoryLZ8UxTL/WafPMgUpNzKyl4BsPklnzjP/6TdZ/QcOhps239TJi2j/jK+eIP/3F1Huim81Hc+gk5j0ki1QQ+UOKjZBeeYauxx47hipxDA28h+HCCHd6TuMwCX6i0iHrnaTJip+or3OYC6m+Y7phExvTZ+rGmbunhp27qyb0cBO6akKLY/f6Jtix2zcz1fJKG890L1vlpaGGqRaWQrDNP450fUU4e4wJLILiy3IU4BdH3zdbQpvI6Q+XchOGrH4cA6yEvr5dMdSLmq+RuDggvLjtQwNUbD2WBdTKkiXWZ7YvLTzNQD+r5RRCZs/DbO4UiN+n1xBDcwhbYkrunvJ2WF4touDC5083An+2ccVl4eL1LHQvcZmHXk5QfOXpvBcG+lOdCaakMPu4fGPCkyQIMPAp0lLBMwf4kmPWGvr1uy1dQnQKxTchD03zxw/wsYinJTbJ9WwZntaQU1KxpgkWqxXhnBdauOpCs9adg3IOpnSRkJ1ha26e1EW03OtgZJ7R4hMfCjyarTX4nA97oeUeJVU2QSwA1KQ7bKwsA2b5TKh+UPNJW520zM9gXTe4A+YoayCNe8IcbQ5EADmbYsoTmezpA4VhGxSxSXq5YjiFJnPUzrmvsFMK70HcVwy2HvNY7ftBNnlqIKgRuwSD0QnW4MCvyRxjNaFpQ/EpcqAXFeyKXLnsuWN187KAFBK8vqCzfPpAmt7Dq71nmVWT7I017RHG3BOEcSn8yYGbYtMAQZ0cZKc/NKa1Yh5Btu97HnMWL9/zKPqRhluHn6Yitbbdk2D1js+lj/n934+91ImAFXJ2m9c92aQU8tGUBMPQ7aJJQXlQKbl893EtoT3Pa9zThs+ZD4SCLXlaCklqWA6zJHRQKcr4iUmKj1oDf99Po4R57jhLzHja8ot89dSWJ37lWy44i0MYU2Jxse4Nvehj48Pl4CsmLcynmdI1cxZDrDcx4oJnqOnhNTlHAm+RprFO5S2hIWfH7IjAd730Qzek/64+EI6SgXDkxaOV9cLR/JB0tNhBOJL5JiNaoj4MyUZpbqsVG2P/PV0xx1nzokY8DNmwvaBxUzRrolkouHu9QGX7ApXNfsFHmwhceLRvm6XFOTdYaGoXVHsMLzy5Rwky23CDqZAP71lFHAkWB5GJhpdgmXKjQlnBtPaidiu9clQyG4pYsYlktj7Hu5HMkvchmX2PY/+1h0fiZYmsUjLDjqFsELX/6zMynV6bGRXIgv5myx7DwiubI2HZaABswctm36tkMz/CLIh9Z0RAkfUwXgD1VLLTIGaF2jBmxSVkEcPy3rT5zoBtCaeUKC1/N9LZQPoaloXMcBeNdLHaOWzSzWEpdyBHDAl+fSzYUNbvEWRvUKRh+H7P/79hTOhkWKjEHvxdCJXBexEqzeWrvCKhEgylBTuCT/bXxPV6aj1qfL0uGUbLsXLfDjKb/vtIx7D9/7FqF/X9Ck6ClZKVHTRClx1lzU7kNC4Ae/QrHA6ew6Zd+AZ8h7B/rbwSJ5fd3i+5qQ7HK+6AGS33KOwV8lrj23gp6rEpD76HzvpfKVnryI3URdgrOG/o4rNdtpdCqKCz3R6sapf50lR+RnFn+bnn/kL1blEvfIOd5xawpqk8ci98Q7u/ALmwZbKEI0B9RUrR9chd8ME4w6yXe0UNIQoq8DO53Wq5i8jO7H3dxa7zhWc0x9GZfHDWvHBBnjM8f1ueEzy/oIfNnC98Q2JCiPOVvb9A5KNZ85rmeCohm+8lwYooyVf4ki2z7HZDhtIU3jGVY/Q1heISSOkChxI2y4RgABI6mKPbxBSeKWpy63LyYHaYg/YiKIC+6LsJkb0nHjU1ZxfIuN13QN0dZYdhPQ3HF2w1BhEFoPIY8kiFg0PwhpbfVZiy/pES5ehrf/xn//DhWfOMIXX4rT/4P//kP3z9v/it7FBwHu+P/oun//AbP/8//vLMoeCckbIX5HzUZp+CYUB2u5tAZAk2vXI/hVgPImO31ItqgWdRBHMMvkXJR0mCtTf7zsKqYbYHotfy8iPVEyPYAdzvCT5U7y6q7FMOLvuM8qIGY7Namc2PYga+f3X3YwW3pDj9JHgNr7egSDji99/gFq/c5Fl5mVzuQtE2lJwsd7vp7+jK/05dF1wwkCifPxw8+TDDFUGWc5/s8P7HXfT4/zYLgxcV394hF70DUutDQLtzHFMrzI7A+Zys+2R5zK6gXxDKbZkdIevm2hJhQy6Bg0pW1GolaudsPqR0+m915bGXsceewMk2ueHh5O9B4nKrycDsMvuU++kEGCGyHX4jeOzwxeAXRb0ClzaXgA4AY24rk1U3IVYGpmSrgoc7TJE4mXDBsniHiPGn+HmG3+KaSooO30whQpycuw0GNAhXEXpfo4lsQTCFQV3oD3TgsnK/SqfBMhWcvCcxRP0b7lT/hjvFN9yl/0uuP70iDpg3FQFHNRnkDvq5A38bPPJRYZDPDPKZfj4j+WrIl1w+31Z2/Lx8voler+f0g4VB/usLjr5iB/ltP7+V/C3km7h8vjryNS6fr+Hbt8h/c3G5ewOLEPn2FxHyRYN8UT9fJPmaBFtVZS+fc9JDECGYjp5Wk0WMIvGgSNwvEkuRbVixyHIx3H/QwtrCb2M9VDFdJLJE9KtI+lUkUkVKtR4Zzn3b5XPDxFtlRYZ82SBf1s+XSb7ttLVHqYCSoczuYhxlxgdlxvtlxqXMEar3KJAy4/z/nbBkRf/4jYPo9SiWtyn+/27UfUMBzkR6ULfu162lbkfbaHuPV179YKGpSUd6lEhN10Dt0+tRSK5Hukdj/HUP/39vD0y6R3t6tJs/EI3RNT3aK0XzHqUolfXoGv5Q4Pr2Ho1L8j441fdop7ztJ0vjPdolbx+gmHb2aErerqUx2oU2+O2DNIUWSd6m+f/XkUZdBdrG+4doHIDskzwfpr14pD3I8KEe5fz1ev7/TI8I367v0XX84QDl9OEezUjRgz3aiVL7e/Rh/nAD7aJ9PfqAJN9IU0i6Vt4+QrvpAz36oLx9lIiu7dG0vN1EOX0QbfDbx2gaLR6Qt1n+/yHaD0BuQNt4v5k+AEBulDwfpxk80vXIcHOPDvLXW/j/t/boAL7d0qND/OEwHaSP9+hWKbrQo2tR6iM9+jh/uI0+SDf26KOS/As0jaSb5O0TdB19tEcfk7dP0gG6qUez8nYHHaSPoQ1+W6RZtHhY3o7x/z9NHwEgt6FtvM/RLXRbr0cL/HYnfRRg/UKP5vj9U/QJ+hgdoBm6gT5AU3zNAUIV1eUw6m6aEHXi7S58sCzlmOgoH0MVrFtIioleh+Z7pfut//jVH4RlscPtebDYUlKDjuKpXtIkzZdUp4ke3d6hiV5JO1BXlX+SttDtyNnodajRK2krTZS0A9dr9DpU75U0OZx9pOxdxK3VaRI/W3sd2tpDy9tRwRbChy29ku4aLtMYftnuga3RXXhK0fo21FCn1Le+fTj/VtpCDeSs9TpU66FbR0rajrsrcIczoN+0rW1SMqWtDLOvHne/cHtbPLDbhss0h1+2cMPw6N2GpwStt0pqYrx861uG87dQOXIGvQ4FPYRpcCVtYQbQoaRXUmvTtlIpmVALP61eh1q9UmSgJvRVvvvpcJnaaG1ouOQriVAEr7gOZ8+DRdjrUNhDXKRWyVcpV+CMQGCGXyIBxgjqcR9nKQEvex3SPYiowyV7XraC1qzm+z5SneaX/+rf/9VfI7wRKrU4EuDdHgCUhkyPS+IiElhe9LilYLjo+noiqSHukaFrIGiFGxXr4Xx5J8fSljbWVDT0Yjx0Ee1CLQwdN6GxKALqAr2NekO93LSeSGqIsWbs8dCtKybQ7fPQmSuEbv8m0O19b9DtvjR0H3pX0F3rYQI8tBk8bIos7YOg6MOlLKxoIhytdRgcIZUA8teeB4uxDoiy00VLOWAc2wBGqeCbT/5nv4ZzJkZaSTf2YfS4GKMPshtOlyAkkEGldrikobALe6UQKQFdj+aiLukOfvFtpB09/BJIY7brCb2DnSOKRDTtGw37jQabVsNdjkq6WRAX+OmD4DofQTVBl2wfIeFINRR1kcJwWroOYxpzT0OK8W0U3NFuBx52QRibbAnGP+objfqNmk2rqWA/6FHgyRc2dx/HdBfYzeVhv8nDbt4f7Le9B9gt/YInF8OGgoC/OwCDbrlMR0YbGExeC+41yxOlS3G/r6OEwLP7Vr5egaH2FLRB53//zdefg9bcQx3S3ADZQ7zC0iE0OTLpfdH19fi5Cu5KnwTdxhsUExgPszvg8DzctFbG6cKG0IV0B68q7xq6myCJfaJHn5Jdz6VhXXyXsB7bBNaPQcD7ZLVTSN4L5Leiik/16M5qi3RpyGfRxzuwZeHd0bvoB93tLZjmKaRP0Bygpkx2jJ6jbAy9cNxS7uCaoEPo8CK2Nk4/yGEPmSmRHubhQy37mxCP0hwdRjfp01xQg6SjnkgoI/0s5Zqv2+mTwEuCjZ7TD5bEUs7Y+s7C2JYj4rDG3q2JWtX2AUp+N9dbV0Tvk3KkJlYXB1WMguxTUDb9WJd5hohZuszHERlAl/kW3B1qynwrdCumzCdIuTc5QJlyb+gy304mH2NfZb5UMJBje9QYih7sDX1YP8zax+3ZPG3L5vOYJrJ58YpTvcK6sbPuzbgzzWpZtjzbms1Dl7y9+v6M7omLmO0VsYuqz9/WPe8xAm10FWbzhRd0jy3DoBdeU/UkjHEH+cgOV0bRSPZwpP1eDxrxEYjY+i0aqS8cqS8eqc+uq68+2hU2rbMj9UUj9YUj9cXr6rPrcDANNK7BwX6qj7RRG2kjuQzM8TocXC+a901wWh+pr7auvnAdDggG1kP1JSP1jVJL/QpwcNMGdHADhZfA8+XGbT0d3HxJuhodt+gK6OC2NXQVXwIH4RXgYG4DOrjrKtPB7VeZDu64ynTwyxvQwS9dZTr4zFWmg89eZTr44gZ0cN9VpoNTV5kO7r3KdLC8AR08cJXp4KGrTAcPX2U6WNXA9BokPKXfFyU01mHhcf2+SKG1Dg3n9Puihdo6PDyre2Ld8oym1iVW8salQRWPoaf1GipqjNQxSnStdXXE3gqucYkxaF16pPOQ4Aa5hY0YdNFw6R3wH+gbPjEtb95Lexm6HMW9t4a+Ynkq3mDeDOeG45u+pPwTX4bO62sp+jl9yXkTXoai1+PXimnMGrKuX6LWTWjlxbVzLbwErSQb08oLa7F/qfla34BWxqnhmoueQn6kxV7r6lLIy1eZQi5eZQr5/t8Ihbx6FSjkB1eBQl55vxSSpbh4XvVxPqNknKTcjPrvX2DDiAoNM+offVuMI6phmVH/3TNiHNG77KEqLDNSwkX3failvWhte/G69ux7as9Ke0mf5qU9u7a9aF174XtqL5H2Gn2ak/bCte3Zde3FG7R3uaN8aCw0NUu5+JRtaZttl8HuJIXpkcWPzWP8JHlIER4aFE2rRm9WNRDRCC9Jb1YlUMrgxfZmlSXY9ETTSvVmOegm2zCPwewDLsLweBUT+RT2PmzS42+B4cBDY3AEH6Mm3z8vF8OkYsnxiNY+pK2BaYr1Kg0y2e3v0RKIjZLYFIjtWSb4V2e3Q9nx7QC2JBmb+yKabZpwmypNA6XSp5o6HNyzNIilmwcCYbRfuUcYq8q70MFIcZI3sIXyXs3wc3Z8OYFbOTKVB7hc06k7YMBDph36EMNOwxwcF0TJBRtZG47nfM1XcqSIO3x5CgWudrTbbSr3MGIyTZtpp92FA6TGAyXtIdC4U+6ZA2+mUMDgbiVSDpceSjS4VXbSZBjdh0THpCWemCazjBwPkzr89tuPrr6iDrHV/uHV1a+svqYPmWd13x/rcS3RxacBVdfBSsXQeKBm2VJUUthQeyjlvO5/f1YPEmBXBKQ97b1v4d/iVlf1rPnZjK8Kr85WBQBjIhaSP5txZnnWNCpfPXh5eKe785VH49P8YOQ2d76XDi4OCTCgs127+q6+D8Px3risZAMs669Ls5VngyRzLGfTb6LvPME9eFWLW+8PONz7LWp/BWTh7TdnEfGJzeFPOWjsXp8B8ZDOZpsc6H3WXA/yQvc0YhFPoMu7YfYsQRUC8aLk0NoFk9AchxAU0+1JBE3+uPsQbGePFGqKewoz/cFl6rijwV/CnuI+9cA9wrfx5cY98/XKIlT50K27JRSsWS54XC58XTteLFfHlxFcH32+cwpOPErsxDjUsrtwXleXXw8HiubQr0pe3e/8pna7/RXn/gonE8y5jO9jQVRdvghnzxExcYPVOg7MXLw8i3BCDK6mEPGEXNzmG6y8GWY4CG1t3YWnES12AMnwtVWiGWVrOR8qW+LhmUE8vAH4bAQcHdSZRBx353Eljzuv5esWRhfs7Pk6Y7LuNcQG3OJWjWQY8xme6WeYLG/VY+4Z49u+4FFnll1yq/7dx/Uw6hA14hkYQGccofV3DMK19a3s9lQlC+XCW/Xvfk2maIhY3Re+NlwRBpjNWCU8g4vXtuS/1zb5nqz/Hg5o4x9UtLHlkrTxm9qHmxrqoNyEVtFGSgEo/6kD4hnjwzMH7qfZrDm3gwL3g2zWvLmdAncxmzWvbWeu+v1t8CTfwc+vbi1nzevy/SfQov90OwXZ9TKTVDWTZ71nf/+6RC2sojBVUG9/A58eTO9nD8gvwgRwFE86xOb1gPc7evDtOe/SUHmW/UC7xqlCu9e3wt9m1vyYOaR7zb/+SF7/b//6irz+tX/9vk4RlRmGqTZN/xLG36tJ+o/tqjp5uvelz3/+5ImTS6eX6f6l+890v6xuPPDRAzceuHHm/jPLp5a+rE6ePnv81Mn76NTJ5aXu8VMHTy2d/sLyF3vUW1rup504c98SDSd86XT79JkHT9MXl47ft9Slz586/oXREved7C0fP31iafTr504u+2qou/TA0vFltXzmDN1//PSXq89nuv2i1Pvy/Z87c6rXL91bPtNduo8+d+rMiXYFjfrclz7/+aUuLXW7Z7qqt9xdOn6/fxkBfmaG7j/Z6508/QVaOn3fzJnPz3A16uTpE2e63aUTy1VXTnxxaeSzh2vt5/uOLx/vfxztMqFPnz/epc8dP9FWVbXdEwDg/uPLJ77YL/HgydP3nXmQeid/ZWmAIu7d8pcfWNpkZLg/6xvlr9WwnDhz/wPdpV7v5JnTdP/S8hfP3KfwX6bG1RalVKJiVVORqqtQpcqqhgpUUxk1prRqKXexkf6BDZRVoYpUrBJVU3WVqqZqqXG1Ve1QU2qv2qc+rD6qblWfUv+JOqF66jH1e+qP1V8oo5Vva/Rv3P9t8X9b/d+E/9vm/zK1qL7HkSeMEhgAa1ONq50qVzcqp46rR9UfKa0fxS2wgbY60olu6ExPatI36Dl973D7VZtVW2hju9qudqgdalJNqp1qp9qldqkpNaV2q93qGnWNmlNz6r32P5Duq9U1f4/6v6/4v8f83+P+7wn/d/4q9F+v6ovD7VbtVe08qZ5Uv6Z+TZ1T59RX1VfVr6tfV7+hfkM9pZ5SX1NfU19XX1d0WKnVRCmtldqjlWoppS4cUUrVpH97lHzjvvpvW5VSsXIXxtNjEjxk8M+s+Res+WfX/AtH/rnzW9KltVWtLVplj/y/2P9L/L+a/1f3/1L/r+H/Nfmfu7g13VdVH/sOZuNbVBLXonqY2kbQNGO6pdwbW9P7Y27bqoT/KR6vTCX+OWIfncTnATXWGJaMv1fPGCV5pneelcYznoxWVp6NNlplNeV+NpHWbvhlLVj9/wA=")))), e) });
}
const Jn = "deflate", jn = "deflate-raw", ns = "deflate64-raw", Vn = "gzip", Nr = -4, ql = "Z_MEM_ERROR", rs = [Jn, jn, Vn], os = [Jn, jn, Vn, ns];
let we, qt, At, pn, is;
function Jl(n) {
  if (we = n, { malloc: qt, free: At, memory: pn } = we, typeof qt != "function" || typeof At != "function" || !pn)
    throw we = qt = At = pn = null, new Error("Invalid WASM module");
}
function Ql(n) {
  is = n;
}
function Xt(n, e) {
  return e === Nr && (n.code = ql), n;
}
function as(n, e, o = {}) {
  if (!(n ? rs : os).includes(e))
    throw new TypeError("Unsupported format: " + e);
  if (!we) {
    const L = new Error("WASM module not loaded");
    throw L.cause = is, L;
  }
  const i = typeof o.level == "number" ? o.level : -1, s = typeof o.outBuffer == "number" ? o.outBuffer : 64 * 1024, f = typeof o.inBufferSize == "number" ? o.inBufferSize : 64 * 1024, c = { out: 0, in: 0, inBufferSize: 0, streamHandle: 0, streamEnded: !1 };
  let d, p, _, T, A = !0, h = !1;
  m();
  const y = new ReadableStream({
    start(L) {
      d = L;
    },
    pull() {
      A = !1, N();
    },
    cancel(L) {
      h = !0, T = L, C(c), p.error(L), N();
    }
  }, { highWaterMark: 0 }), R = new WritableStream({
    start(L) {
      p = L;
    },
    async write(L) {
      if (A && await new Promise((x) => _ = x), h)
        throw T;
      try {
        v(L);
      } catch (x) {
        throw C(c), d.error(x), x;
      }
    },
    close() {
      if (h)
        return;
      try {
        g();
      } catch (x) {
        throw C(c), d.error(x), x;
      }
      const L = C(c);
      if (L !== 0) {
        const x = Xt(new Error("end error:" + L), L);
        throw d.error(x), x;
      }
      d.close();
    },
    abort(L) {
      C(c), d.error(L);
    }
  }, { highWaterMark: 1 });
  return { readable: y, writable: R };
  function m() {
    try {
      let L;
      if (c.out = qt(s), c.in = qt(f), c.inBufferSize = f, !c.out || !c.in)
        throw Xt(new Error("allocation failed"), Nr);
      if (n ? (c._process = we.deflate_process, c._last_consumed = we.deflate_last_consumed, c._end = we.deflate_end, c.streamHandle = we.deflate_new(), e === Vn ? L = we.deflate_init_gzip(c.streamHandle, i) : e === jn ? L = we.deflate_init_raw(c.streamHandle, i) : L = we.deflate_init(c.streamHandle, i)) : e === ns ? (c._process = we.inflate9_process, c._last_consumed = we.inflate9_last_consumed, c._end = we.inflate9_end, c.streamHandle = we.inflate9_new(), L = we.inflate9_init_raw(c.streamHandle)) : (c._process = we.inflate_process, c._last_consumed = we.inflate_last_consumed, c._end = we.inflate_end, c.streamHandle = we.inflate_new(), e === jn ? L = we.inflate_init_raw(c.streamHandle) : e === Vn ? L = we.inflate_init_gzip(c.streamHandle) : L = we.inflate_init(c.streamHandle)), L !== 0)
        throw Xt(new Error("init failed:" + L), L);
    } catch (L) {
      throw C(c), L;
    }
  }
  function v(L) {
    const x = new Uint8Array(pn.buffer), B = c._process, $ = c._last_consumed, se = c.out;
    let Ee = 0;
    for (; Ee < L.length; ) {
      if (c.streamEnded)
        throw new Error("trailing data after the end of the stream");
      const Se = Math.min(L.length - Ee, 32 * 1024);
      if ((!c.in || c.inBufferSize < Se) && (c.in && At && (At(c.in), c.in = 0), c.in = qt(Se), c.inBufferSize = Se, !c.in))
        throw Xt(new Error("allocation failed"), Nr);
      x.set(L.subarray(Ee, Ee + Se), c.in);
      const Ne = B(c.streamHandle, c.in, Se, se, s, 0), De = Ne >> 24 & 255, Ue = De & 128 ? De - 256 : De;
      if (Ue < 0)
        throw Xt(new Error("process error:" + Ue), Ue);
      const Ge = Ne & 16777215;
      Ge && b(x.slice(se, se + Ge));
      const Ye = $(c.streamHandle);
      if (De === 1)
        c.streamEnded = !0;
      else if (Ye === 0 && Ge === 0)
        break;
      Ee += Ye;
    }
  }
  function g() {
    const L = new Uint8Array(pn.buffer), x = c._process, B = c.out;
    for (; ; ) {
      const $ = x(c.streamHandle, 0, 0, B, s, 4), se = $ >> 24 & 255, Ee = se & 128 ? se - 256 : se;
      if (Ee < 0)
        throw Xt(new Error("process error:" + Ee), Ee);
      const Se = $ & 16777215;
      if (Se && b(L.slice(B, B + Se)), se === 1 || Se === 0)
        break;
    }
  }
  function b(L) {
    A = !0, d.enqueue(L);
  }
  function N() {
    if (_) {
      const L = _;
      _ = null, L();
    }
  }
  function C(L) {
    let x = 0;
    return L.streamHandle && L._end && (x = L._end(L.streamHandle)), L.streamHandle = 0, L.in && At && At(L.in), L.in = 0, L.out && At && At(L.out), L.out = 0, x;
  }
}
class Wr {
  constructor(e = Jn, o) {
    return as(!0, e, o);
  }
}
class Gr {
  constructor(e = Jn, o) {
    return as(!1, e, o);
  }
}
Wr.requiresModule = !0;
Gr.requiresModule = !0;
Wr.supportedFormats = rs;
Gr.supportedFormats = os;
const Dr = 64 * 1024, $l = 20;
let ss, yt;
function ed(n) {
  typeof n.aes_hmac_new == Pe && (ss = n, yt = 0);
}
function td(n, e) {
  const o = ss;
  let i = o ? nd(o, n, e) : 0;
  if (!i)
    return Fr(n, e);
  const s = yt;
  return {
    process(f, c) {
      for (let d = 0; d < f.length; d += Dr) {
        const p = f.subarray(d, d + Dr), _ = Or(o);
        _.set(p, s), o.aes_hmac_process(i, s, p.length, c ? 1 : 0), p.set(_.subarray(s, s + p.length));
      }
    },
    digest() {
      return o.aes_hmac_end(i, s), i = 0, Or(o).slice(s, s + $l);
    },
    dispose() {
      i && (o.aes_hmac_end(i, 0), i = 0);
    }
  };
}
function nd(n, e, o) {
  yt || (yt = n.malloc(Dr));
  const i = yt ? n.aes_hmac_new() : 0;
  if (i) {
    const s = Or(n);
    if (s.set(e, yt), s.set(o, yt + e.length), n.aes_hmac_init(i, yt, e.length, yt + e.length, o.length))
      return n.aes_hmac_end(i, 0), 0;
  }
  return i;
}
function Or(n) {
  return new Uint8Array(n.memory.buffer);
}
let gi = !1;
async function rd(n, { baseURI: e }) {
  if (!gi)
    try {
      await od(n, e), gi = !0;
    } catch (o) {
      throw Ql(o), o;
    }
}
async function od(n, e) {
  let o, i;
  try {
    try {
      i = new URL(n, e);
    } catch {
    }
    o = await (await fetch(i)).arrayBuffer();
  } catch (f) {
    if (n.startsWith("data:application/wasm;base64,"))
      o = id(n);
    else
      throw f;
  }
  const s = await WebAssembly.instantiate(o);
  Jl(s.instance.exports), ed(s.instance.exports);
}
function id(n) {
  const e = n.split(",")[1], o = atob(e), i = o.length, s = new Uint8Array(i);
  for (let f = 0; f < i; ++f)
    s[f] = o.charCodeAt(f);
  return s.buffer;
}
let Dn;
Bc(td);
wu({
  initModule: (n) => {
    if (!Dn) {
      let { wasmURI: e } = n;
      typeof e == Pe && (e = e()), Dn = rd(e, n).catch((o) => {
        throw Dn = null, o;
      });
    }
    return Dn;
  }
});
qn({
  CompressionStreamFallback: Wr,
  DecompressionStreamFallback: Gr
});
Kl(qn);
ic(qn);
function ad(n) {
  if (Object.prototype.hasOwnProperty.call(n, "__esModule")) return n;
  var e = n.default;
  if (typeof e == "function") {
    var o = function i() {
      var s = !1;
      try {
        s = this instanceof i;
      } catch {
      }
      return s ? Reflect.construct(e, arguments, this.constructor) : e.apply(this, arguments);
    };
    o.prototype = e.prototype;
  } else o = {};
  return Object.defineProperty(o, "__esModule", { value: !0 }), Object.keys(n).forEach(function(i) {
    var s = Object.getOwnPropertyDescriptor(n, i);
    Object.defineProperty(o, i, s.get ? s : {
      enumerable: !0,
      get: function() {
        return n[i];
      }
    });
  }), o;
}
var gt = {}, Pt = {}, fn = {}, yi;
function sd() {
  if (yi) return fn;
  yi = 1, Object.defineProperty(fn, "__esModule", { value: !0 }), fn.ArchiveReaderEntry = void 0;
  var n = (
    /** @class */
    (function() {
      function e(o, i) {
        this.reader = o, this.pointer = i, this.readCalled = !1;
      }
      return e.prototype.free = function() {
        this.skipData(), this.reader = null, this.pointer = null;
      }, e.prototype.readData = function() {
        if (this.readCalled)
          throw new Error("It has already been called.");
        var o = this.getSize();
        if (!o) {
          this.skipData();
          return;
        }
        return this.readCalled = !0, this.reader.readData(o);
      }, e.prototype.skipData = function() {
        this.readCalled || (this.readCalled = !0, this.reader.skipData());
      }, e.prototype.getFiletype = function() {
        return this.reader.getEntryFiletype(this.pointer);
      }, e.prototype.getPathname = function() {
        return this.reader.getEntryPathname(this.pointer);
      }, e.prototype.getSize = function() {
        return this.reader.getEntrySize(this.pointer);
      }, e.prototype.getAccessTime = function() {
        return this.reader.getEntryAccessTime(this.pointer);
      }, e.prototype.getBirthTime = function() {
        return this.reader.getEntryBirthTime(this.pointer);
      }, e.prototype.getCreationTime = function() {
        return this.reader.getEntryCreationTime(this.pointer);
      }, e.prototype.getModificationTime = function() {
        return this.reader.getEntryModificationTime(this.pointer);
      }, e.prototype.isEncrypted = function() {
        return this.reader.isEntryEncrypted(this.pointer);
      }, e.prototype.getSymlinkTarget = function() {
        return this.reader.getSymlinkTarget(this.pointer);
      }, e.prototype.getHardlinkTarget = function() {
        return this.reader.getHardlinkTarget(this.pointer);
      }, e;
    })()
  );
  return fn.ArchiveReaderEntry = n, fn;
}
var Ai;
function cd() {
  if (Ai) return Pt;
  Ai = 1;
  var n = Pt && Pt.__generator || function(f, c) {
    var d = { label: 0, sent: function() {
      if (T[0] & 1) throw T[1];
      return T[1];
    }, trys: [], ops: [] }, p, _, T, A = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
    return A.next = h(0), A.throw = h(1), A.return = h(2), typeof Symbol == "function" && (A[Symbol.iterator] = function() {
      return this;
    }), A;
    function h(R) {
      return function(m) {
        return y([R, m]);
      };
    }
    function y(R) {
      if (p) throw new TypeError("Generator is already executing.");
      for (; A && (A = 0, R[0] && (d = 0)), d; ) try {
        if (p = 1, _ && (T = R[0] & 2 ? _.return : R[0] ? _.throw || ((T = _.return) && T.call(_), 0) : _.next) && !(T = T.call(_, R[1])).done) return T;
        switch (_ = 0, T && (R = [R[0] & 2, T.value]), R[0]) {
          case 0:
          case 1:
            T = R;
            break;
          case 4:
            return d.label++, { value: R[1], done: !1 };
          case 5:
            d.label++, _ = R[1], R = [0];
            continue;
          case 7:
            R = d.ops.pop(), d.trys.pop();
            continue;
          default:
            if (T = d.trys, !(T = T.length > 0 && T[T.length - 1]) && (R[0] === 6 || R[0] === 2)) {
              d = 0;
              continue;
            }
            if (R[0] === 3 && (!T || R[1] > T[0] && R[1] < T[3])) {
              d.label = R[1];
              break;
            }
            if (R[0] === 6 && d.label < T[1]) {
              d.label = T[1], T = R;
              break;
            }
            if (T && d.label < T[2]) {
              d.label = T[2], d.ops.push(R);
              break;
            }
            T[2] && d.ops.pop(), d.trys.pop();
            continue;
        }
        R = c.call(f, d);
      } catch (m) {
        R = [6, m], _ = 0;
      } finally {
        p = T = 0;
      }
      if (R[0] & 5) throw R[1];
      return { value: R[0] ? R[1] : void 0, done: !0 };
    }
  }, e;
  Object.defineProperty(Pt, "__esModule", { value: !0 }), Pt.ArchiveReader = void 0;
  var o = sd();
  function i(f) {
    return f * 1e3;
  }
  var s = (
    /** @class */
    (function() {
      function f(c, d, p) {
        var _ = c.module._malloc(d.length);
        c.module.HEAP8.set(d, _), this.libarchive = c, this.archive = c.read_new_memory(_, d.length, p), this.pointer = _;
      }
      return f.prototype.free = function() {
        this.libarchive.read_free(this.archive), this.libarchive.module._free(this.pointer), this.libarchive = null, this.archive = null, this.pointer = null;
      }, f.prototype.hasEncryptedData = function() {
        var c = this.libarchive.read_has_encrypted_entries(this.archive);
        return c < 0 ? null : !!c;
      }, f.prototype.readData = function(c) {
        var d = this.libarchive.module._malloc(c), p = this.libarchive.read_data(this.archive, d, c), _ = this.libarchive.module.HEAP8.slice(d, d + p);
        return this.libarchive.module._free(d), _;
      }, f.prototype.skipData = function() {
        this.libarchive.read_data_skip(this.archive);
      }, f.prototype.nextEntryPointer = function() {
        return this.libarchive.read_next_entry(this.archive);
      }, f.prototype.getEntryFiletype = function(c) {
        var d = String(this.libarchive.entry_filetype(c));
        return d in f.FileTypes ? f.FileTypes[d] : "Invalid";
      }, f.prototype.getEntryPathname = function(c) {
        return this.libarchive.entry_pathname(c);
      }, f.prototype.getEntrySize = function(c) {
        return this.libarchive.entry_size(c);
      }, f.prototype.getEntryAccessTime = function(c) {
        return i(this.libarchive.entry_atime(c));
      }, f.prototype.getEntryBirthTime = function(c) {
        return i(this.libarchive.entry_birthtime(c));
      }, f.prototype.getEntryCreationTime = function(c) {
        return i(this.libarchive.entry_ctime(c));
      }, f.prototype.getEntryModificationTime = function(c) {
        return i(this.libarchive.entry_mtime(c));
      }, f.prototype.isEntryEncrypted = function(c) {
        return !!this.libarchive.entry_is_encrypted(c);
      }, f.prototype.getSymlinkTarget = function(c) {
        return this.libarchive.entry_symlink(c);
      }, f.prototype.getHardlinkTarget = function(c) {
        return this.libarchive.entry_hardlink(c);
      }, f.prototype.nextEntry = function() {
        var c = this.nextEntryPointer();
        return c === 0 ? null : new o.ArchiveReaderEntry(this, c);
      }, f.prototype.forEach = function(c) {
        for (; ; ) {
          var d = this.nextEntry();
          if (!d)
            break;
          c(d), d.free();
        }
      }, f.prototype.entries = function() {
        var c;
        return n(this, function(d) {
          switch (d.label) {
            case 0:
              return c = this.nextEntry(), c ? [4, c] : [3, 3];
            case 1:
              d.sent(), c.free(), d.label = 2;
            case 2:
              return [3, 0];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      }, f.FileTypes = (e = {}, e["".concat(61440)] = "Mount", e["".concat(32768)] = "File", e["".concat(40960)] = "SymbolicLink", e["".concat(49152)] = "Socket", e["".concat(8192)] = "CharacterDevice", e["".concat(24576)] = "BlockDevice", e["".concat(16384)] = "Directory", e["".concat(4096)] = "NamedPipe", e), f;
    })()
  );
  return Pt.ArchiveReader = s, Pt;
}
var Un = { exports: {} };
const ud = {}, fd = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ud
}, Symbol.toStringTag, { value: "Module" })), Ri = /* @__PURE__ */ ad(fd);
var St = Un.exports, Ti;
function cs() {
  return Ti || (Ti = 1, (function(n, e) {
    var o = St && St.__assign || function() {
      return o = Object.assign || function(d) {
        for (var p, _ = 1, T = arguments.length; _ < T; _++) {
          p = arguments[_];
          for (var A in p) Object.prototype.hasOwnProperty.call(p, A) && (d[A] = p[A]);
        }
        return d;
      }, o.apply(this, arguments);
    }, i = St && St.__awaiter || function(d, p, _, T) {
      function A(h) {
        return h instanceof _ ? h : new _(function(y) {
          y(h);
        });
      }
      return new (_ || (_ = Promise))(function(h, y) {
        function R(g) {
          try {
            v(T.next(g));
          } catch (b) {
            y(b);
          }
        }
        function m(g) {
          try {
            v(T.throw(g));
          } catch (b) {
            y(b);
          }
        }
        function v(g) {
          g.done ? h(g.value) : A(g.value).then(R, m);
        }
        v((T = T.apply(d, p || [])).next());
      });
    }, s = St && St.__generator || function(d, p) {
      var _ = { label: 0, sent: function() {
        if (h[0] & 1) throw h[1];
        return h[1];
      }, trys: [], ops: [] }, T, A, h, y = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
      return y.next = R(0), y.throw = R(1), y.return = R(2), typeof Symbol == "function" && (y[Symbol.iterator] = function() {
        return this;
      }), y;
      function R(v) {
        return function(g) {
          return m([v, g]);
        };
      }
      function m(v) {
        if (T) throw new TypeError("Generator is already executing.");
        for (; y && (y = 0, v[0] && (_ = 0)), _; ) try {
          if (T = 1, A && (h = v[0] & 2 ? A.return : v[0] ? A.throw || ((h = A.return) && h.call(A), 0) : A.next) && !(h = h.call(A, v[1])).done) return h;
          switch (A = 0, h && (v = [v[0] & 2, h.value]), v[0]) {
            case 0:
            case 1:
              h = v;
              break;
            case 4:
              return _.label++, { value: v[1], done: !1 };
            case 5:
              _.label++, A = v[1], v = [0];
              continue;
            case 7:
              v = _.ops.pop(), _.trys.pop();
              continue;
            default:
              if (h = _.trys, !(h = h.length > 0 && h[h.length - 1]) && (v[0] === 6 || v[0] === 2)) {
                _ = 0;
                continue;
              }
              if (v[0] === 3 && (!h || v[1] > h[0] && v[1] < h[3])) {
                _.label = v[1];
                break;
              }
              if (v[0] === 6 && _.label < h[1]) {
                _.label = h[1], h = v;
                break;
              }
              if (h && _.label < h[2]) {
                _.label = h[2], _.ops.push(v);
                break;
              }
              h[2] && _.ops.pop(), _.trys.pop();
              continue;
          }
          v = p.call(d, _);
        } catch (g) {
          v = [6, g], A = 0;
        } finally {
          T = h = 0;
        }
        if (v[0] & 5) throw v[1];
        return { value: v[0] ? v[1] : void 0, done: !0 };
      }
    }, f = St && St.__spreadArray || function(d, p, _) {
      if (_ || arguments.length === 2) for (var T = 0, A = p.length, h; T < A; T++)
        (h || !(T in p)) && (h || (h = Array.prototype.slice.call(p, 0, T)), h[T] = p[T]);
      return d.concat(h || Array.prototype.slice.call(p));
    }, c = (function() {
      var d, p = typeof document < "u" ? (d = document.currentScript) === null || d === void 0 ? void 0 : d.src : void 0;
      return typeof __filename < "u" && (p = p || __filename), (function() {
        return i(this, arguments, void 0, function(_) {
          function T(M) {
            return O.locateFile ? O.locateFile(M, ve) : ve + M;
          }
          function A(M, t) {
            M || b(t);
          }
          function h() {
            var M = Oe.buffer;
            O.HEAP8 = He = new Int8Array(M), O.HEAP16 = ht = new Int16Array(M), O.HEAPU8 = at = new Uint8Array(M), O.HEAPU16 = new Uint16Array(M), O.HEAP32 = F = new Int32Array(M), O.HEAPU32 = _e = new Uint32Array(M), O.HEAPF32 = new Float32Array(M), O.HEAPF64 = new Float64Array(M);
          }
          function y() {
            if (O.preRun)
              for (typeof O.preRun == "function" && (O.preRun = [O.preRun]); O.preRun.length; )
                Bt(O.preRun.shift());
            xt(Me);
          }
          function R() {
            !O.noFSInit && !u.initialized && u.init(), ze.init(), he.root = u.mount(he, {}, null), ee.x(), u.ignorePermissions = !1;
          }
          function m() {
            if (O.postRun)
              for (typeof O.postRun == "function" && (O.postRun = [O.postRun]); O.postRun.length; )
                en(O.postRun.shift());
            xt(kt);
          }
          function v(M) {
            var t;
            de++, (t = O.monitorRunDependencies) === null || t === void 0 || t.call(O, de);
          }
          function g(M) {
            var t;
            if (de--, (t = O.monitorRunDependencies) === null || t === void 0 || t.call(O, de), de == 0 && Fe) {
              var r = Fe;
              Fe = null, r();
            }
          }
          function b(M) {
            var t;
            (t = O.onAbort) === null || t === void 0 || t.call(O, M), M = "Aborted(" + M + ")", ce(M), it = !0, M += ". Build with -sASSERTIONS for more info.";
            var r = new WebAssembly.RuntimeError(M);
            throw dt(r), r;
          }
          function N() {
            return T("libarchive.wasm");
          }
          function C(M) {
            if (M == pt && fe)
              return new Uint8Array(fe);
            if (k)
              return k(M);
            throw "both async and sync fetching of the wasm failed";
          }
          function L(M) {
            return i(this, void 0, void 0, function() {
              var t;
              return s(this, function(r) {
                switch (r.label) {
                  case 0:
                    if (fe) return [3, 4];
                    r.label = 1;
                  case 1:
                    return r.trys.push([1, 3, , 4]), [4, te(M)];
                  case 2:
                    return t = r.sent(), [2, new Uint8Array(t)];
                  case 3:
                    return r.sent(), [3, 4];
                  case 4:
                    return [2, C(M)];
                }
              });
            });
          }
          function x(M, t) {
            return i(this, void 0, void 0, function() {
              var r, a, l;
              return s(this, function(E) {
                switch (E.label) {
                  case 0:
                    return E.trys.push([0, 3, , 4]), [4, L(M)];
                  case 1:
                    return r = E.sent(), [4, WebAssembly.instantiate(r, t)];
                  case 2:
                    return a = E.sent(), [2, a];
                  case 3:
                    return l = E.sent(), ce("failed to asynchronously prepare wasm: ".concat(l)), b(l), [3, 4];
                  case 4:
                    return [
                      2
                      /*return*/
                    ];
                }
              });
            });
          }
          function B(M, t, r) {
            return i(this, void 0, void 0, function() {
              var a, l, E;
              return s(this, function(w) {
                switch (w.label) {
                  case 0:
                    if (!(!M && typeof WebAssembly.instantiateStreaming == "function" && !Xe(t) && !Ce)) return [3, 4];
                    w.label = 1;
                  case 1:
                    return w.trys.push([1, 3, , 4]), a = fetch(t, { credentials: "same-origin" }), [4, WebAssembly.instantiateStreaming(a, r)];
                  case 2:
                    return l = w.sent(), [2, l];
                  case 3:
                    return E = w.sent(), ce("wasm streaming compile failed: ".concat(E)), ce("falling back to ArrayBuffer instantiation"), [3, 4];
                  case 4:
                    return [2, x(t, r)];
                }
              });
            });
          }
          function $() {
            return { a: To };
          }
          function se() {
            return i(this, void 0, void 0, function() {
              function M(w, S) {
                return ee = w.exports, Oe = ee.w, h(), g(), ee;
              }
              function t(w) {
                return M(w.instance);
              }
              var r, a, l, E;
              return s(this, function(w) {
                switch (w.label) {
                  case 0:
                    if (v(), r = $(), O.instantiateWasm)
                      return [2, new Promise(function(S, I) {
                        O.instantiateWasm(r, function(D, U) {
                          M(D), S(D.exports);
                        });
                      })];
                    pt ?? (pt = N()), w.label = 1;
                  case 1:
                    return w.trys.push([1, 3, , 4]), [4, B(fe, pt, r)];
                  case 2:
                    return a = w.sent(), l = t(a), [2, l];
                  case 3:
                    return E = w.sent(), dt(E), [2, Promise.reject(E)];
                  case 4:
                    return [
                      2
                      /*return*/
                    ];
                }
              });
            });
          }
          function Ee(M) {
            try {
              var t = me.getStreamFromFD(M);
              return u.dupStream(t).fd;
            } catch (r) {
              if (typeof u > "u" || r.name !== "ErrnoError")
                throw r;
              return -r.errno;
            }
          }
          function Se(M, t, r) {
            me.varargs = r;
            try {
              var a = me.getStreamFromFD(M);
              switch (t) {
                case 0: {
                  var l = an();
                  if (l < 0)
                    return -28;
                  for (; u.streams[l]; )
                    l++;
                  var E;
                  return E = u.dupStream(a, l), E.fd;
                }
                case 1:
                case 2:
                  return 0;
                case 3:
                  return a.flags;
                case 4: {
                  var l = an();
                  return a.flags |= l, 0;
                }
                case 12: {
                  var l = qr(), w = 0;
                  return ht[l + w >> 1] = 2, 0;
                }
                case 13:
                case 14:
                  return 0;
              }
              return -28;
            } catch (S) {
              if (typeof u > "u" || S.name !== "ErrnoError")
                throw S;
              return -S.errno;
            }
          }
          function Ne(M, t) {
            try {
              return me.writeStat(t, u.fstat(M));
            } catch (r) {
              if (typeof u > "u" || r.name !== "ErrnoError")
                throw r;
              return -r.errno;
            }
          }
          function De(M, t) {
            try {
              return M = me.getStr(M), me.writeStat(t, u.lstat(M));
            } catch (r) {
              if (typeof u > "u" || r.name !== "ErrnoError")
                throw r;
              return -r.errno;
            }
          }
          function Ue(M, t, r, a) {
            try {
              t = me.getStr(t);
              var l = a & 256, E = a & 4096;
              return a = a & -6401, t = me.calculateAt(M, t, E), me.writeStat(r, l ? u.lstat(t) : u.stat(t));
            } catch (w) {
              if (typeof u > "u" || w.name !== "ErrnoError")
                throw w;
              return -w.errno;
            }
          }
          function Ge(M, t, r, a) {
            me.varargs = a;
            try {
              t = me.getStr(t), t = me.calculateAt(M, t);
              var l = a ? an() : 0;
              return u.open(t, r, l).fd;
            } catch (E) {
              if (typeof u > "u" || E.name !== "ErrnoError")
                throw E;
              return -E.errno;
            }
          }
          function Ye(M) {
            try {
              if (M == 0)
                throw new u.ErrnoError(21);
              var t = he.createPipe();
              return F[M >> 2] = t.readable_fd, F[M + 4 >> 2] = t.writable_fd, 0;
            } catch (r) {
              if (typeof u > "u" || r.name !== "ErrnoError")
                throw r;
              return -r.errno;
            }
          }
          function xe(M, t, r) {
            try {
              for (var a = 0, l = 0; l < t; l++) {
                var E = M + 8 * l, w = F[E >> 2], S = ht[E + 4 >> 1], I = 32, D = u.getStream(w);
                D && (I = me.DEFAULT_POLLMASK, D.stream_ops.poll && (I = D.stream_ops.poll(D, -1))), I &= S | 8 | 16, I && a++, ht[E + 6 >> 1] = I;
              }
              return a;
            } catch (U) {
              if (typeof u > "u" || U.name !== "ErrnoError")
                throw U;
              return -U.errno;
            }
          }
          function re(M, t) {
            try {
              return M = me.getStr(M), me.writeStat(t, u.stat(M));
            } catch (r) {
              if (typeof u > "u" || r.name !== "ErrnoError")
                throw r;
              return -r.errno;
            }
          }
          function ue(M, t, r) {
            var a = er(M, t), l = new Date(a * 1e3);
            F[r >> 2] = l.getSeconds(), F[r + 4 >> 2] = l.getMinutes(), F[r + 8 >> 2] = l.getHours(), F[r + 12 >> 2] = l.getDate(), F[r + 16 >> 2] = l.getMonth(), F[r + 20 >> 2] = l.getFullYear() - 1900, F[r + 24 >> 2] = l.getDay();
            var E = $n(l) | 0;
            F[r + 28 >> 2] = E, F[r + 36 >> 2] = -(l.getTimezoneOffset() * 60);
            var w = new Date(l.getFullYear(), 0, 1), S = new Date(l.getFullYear(), 6, 1).getTimezoneOffset(), I = w.getTimezoneOffset(), D = (S != I && l.getTimezoneOffset() == Math.min(I, S)) | 0;
            F[r + 32 >> 2] = D;
          }
          function le(M) {
            try {
              var t = me.getStreamFromFD(M);
              return u.close(t), 0;
            } catch (r) {
              if (typeof u > "u" || r.name !== "ErrnoError")
                throw r;
              return r.errno;
            }
          }
          function Tt(M, t, r, a) {
            try {
              var l = me.getStreamFromFD(M), E = mo(l, t, r);
              return _e[a >> 2] = E, 0;
            } catch (w) {
              if (typeof u > "u" || w.name !== "ErrnoError")
                throw w;
              return w.errno;
            }
          }
          function Ot(M, t, r, a, l) {
            var E = er(t, r);
            try {
              if (isNaN(E))
                return 61;
              var w = me.getStreamFromFD(M);
              return u.llseek(w, E, a), Te = [w.position >>> 0, (W = w.position, +Math.abs(W) >= 1 ? W > 0 ? +Math.floor(W / 4294967296) >>> 0 : ~~+Math.ceil((W - +(~~W >>> 0)) / 4294967296) >>> 0 : 0)], F[l >> 2] = Te[0], F[l + 4 >> 2] = Te[1], w.getdents && E === 0 && a === 0 && (w.getdents = null), 0;
            } catch (S) {
              if (typeof u > "u" || S.name !== "ErrnoError")
                throw S;
              return S.errno;
            }
          }
          function qe(M, t, r, a) {
            try {
              var l = me.getStreamFromFD(M), E = wo(l, t, r);
              return _e[a >> 2] = E, 0;
            } catch (w) {
              if (typeof u > "u" || w.name !== "ErrnoError")
                throw w;
              return w.errno;
            }
          }
          function rt() {
            if (de > 0) {
              Fe = rt;
              return;
            }
            if (y(), de > 0) {
              Fe = rt;
              return;
            }
            function M() {
              var t;
              O.calledRun = !0, !it && (R(), vt(O), (t = O.onRuntimeInitialized) === null || t === void 0 || t.call(O), m());
            }
            O.setStatus ? (O.setStatus("Running..."), setTimeout(function() {
              setTimeout(function() {
                return O.setStatus("");
              }, 1), M();
            }, 1)) : M();
          }
          var lt, O, vt, dt, bt, Qe, ke, Ce, Be, ot, Et, ve, te, k, Ie, oe, ce, fe, Oe, it, He, at, ht, F, _e, Xe, de, Fe, pt, W, Te, yn, xt, kt, en, Me, Bt, tn, _t, An, ie, Rn, Tn, st, nn, mt, Lt, Ht, $e, zt, Ae, ze, rn, on, K, Yr, Xr, Zr, jr, Vr, Kr, vn, u, Qn, me, an, qr, he, Jr, Qr, $r, eo, $n, er, tr, to, no, Wt, ro, oo, io, ao, bn, so, Gt, co, uo, fo, lo, Eo, ho, po, _o, mo, wo, nr, go, rr, yo, Ao, Ro, To, ee, vo, bo, So, Io, or = this;
          return _ === void 0 && (_ = {}), s(this, function(M) {
            switch (M.label) {
              case 0:
                return O = _, bt = new Promise(function(t, r) {
                  vt = t, dt = r;
                }), Qe = typeof window == "object", ke = typeof WorkerGlobalScope < "u", Ce = typeof process == "object" && typeof process.versions == "object" && typeof process.versions.node == "string" && process.type != "renderer", Be = o({}, O), ot = "./this.program", Et = function(t, r) {
                  throw r;
                }, ve = "", Ce ? (Ie = Ri, ve = __dirname + "/", k = function(t) {
                  t = Xe(t) ? new URL(t) : t;
                  var r = Ie.readFileSync(t);
                  return r;
                }, te = function(t) {
                  for (var r = [], a = 1; a < arguments.length; a++)
                    r[a - 1] = arguments[a];
                  return i(or, f([t], r, !0), void 0, function(l, E) {
                    var w;
                    return E === void 0 && (E = !0), s(this, function(S) {
                      return l = Xe(l) ? new URL(l) : l, w = Ie.readFileSync(l, E ? void 0 : "utf8"), [2, w];
                    });
                  });
                }, !O.thisProgram && process.argv.length > 1 && (ot = process.argv[1].replace(/\\/g, "/")), process.argv.slice(2), Et = function(t, r) {
                  throw process.exitCode = t, r;
                }) : (Qe || ke) && (ke ? ve = self.location.href : typeof document < "u" && document.currentScript && (ve = document.currentScript.src), p && (ve = p), ve.startsWith("blob:") ? ve = "" : ve = ve.slice(0, ve.replace(/[?#].*/, "").lastIndexOf("/") + 1), ke && (k = function(t) {
                  var r = new XMLHttpRequest();
                  return r.open("GET", t, !1), r.responseType = "arraybuffer", r.send(null), new Uint8Array(r.response);
                }), te = function(t) {
                  return i(or, void 0, void 0, function() {
                    var r;
                    return s(this, function(a) {
                      switch (a.label) {
                        case 0:
                          return Xe(t) ? [2, new Promise(function(l, E) {
                            var w = new XMLHttpRequest();
                            w.open("GET", t, !0), w.responseType = "arraybuffer", w.onload = function() {
                              if (w.status == 200 || w.status == 0 && w.response) {
                                l(w.response);
                                return;
                              }
                              E(w.status);
                            }, w.onerror = E, w.send(null);
                          })] : [4, fetch(t, { credentials: "same-origin" })];
                        case 1:
                          if (r = a.sent(), r.ok)
                            return [2, r.arrayBuffer()];
                          throw new Error(r.status + " : " + r.url);
                      }
                    });
                  });
                }), oe = O.print || console.log.bind(console), ce = O.printErr || console.error.bind(console), Object.assign(O, Be), Be = null, O.arguments && O.arguments, O.thisProgram && (ot = O.thisProgram), fe = O.wasmBinary, it = !1, Xe = function(t) {
                  return t.startsWith("file://");
                }, de = 0, Fe = null, yn = /** @class */
                /* @__PURE__ */ (function() {
                  function t(r) {
                    this.name = "ExitStatus", this.message = "Program terminated with exit(".concat(r, ")"), this.status = r;
                  }
                  return t;
                })(), xt = function(t) {
                  for (; t.length > 0; )
                    t.shift()(O);
                }, kt = [], en = function(t) {
                  return kt.unshift(t);
                }, Me = [], Bt = function(t) {
                  return Me.unshift(t);
                }, tn = O.noExitRuntime || !0, _t = function(t) {
                  return bo(t);
                }, An = function() {
                  return Io();
                }, ie = { isAbs: function(t) {
                  return t.charAt(0) === "/";
                }, splitPath: function(t) {
                  var r = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
                  return r.exec(t).slice(1);
                }, normalizeArray: function(t, r) {
                  for (var a = 0, l = t.length - 1; l >= 0; l--) {
                    var E = t[l];
                    E === "." ? t.splice(l, 1) : E === ".." ? (t.splice(l, 1), a++) : a && (t.splice(l, 1), a--);
                  }
                  if (r)
                    for (; a; a--)
                      t.unshift("..");
                  return t;
                }, normalize: function(t) {
                  var r = ie.isAbs(t), a = t.slice(-1) === "/";
                  return t = ie.normalizeArray(t.split("/").filter(function(l) {
                    return !!l;
                  }), !r).join("/"), !t && !r && (t = "."), t && a && (t += "/"), (r ? "/" : "") + t;
                }, dirname: function(t) {
                  var r = ie.splitPath(t), a = r[0], l = r[1];
                  return !a && !l ? "." : (l && (l = l.slice(0, -1)), a + l);
                }, basename: function(t) {
                  return t && t.match(/([^\/]+|\/)\/*$/)[1];
                }, join: function() {
                  for (var t = [], r = 0; r < arguments.length; r++)
                    t[r] = arguments[r];
                  return ie.normalize(t.join("/"));
                }, join2: function(t, r) {
                  return ie.normalize(t + "/" + r);
                } }, Rn = function() {
                  if (Ce) {
                    var t = Ri;
                    return function(r) {
                      return t.randomFillSync(r);
                    };
                  }
                  return function(r) {
                    return crypto.getRandomValues(r);
                  };
                }, Tn = function(t) {
                  (Tn = Rn())(t);
                }, st = { resolve: function() {
                  for (var t = [], r = 0; r < arguments.length; r++)
                    t[r] = arguments[r];
                  for (var a = "", l = !1, E = t.length - 1; E >= -1 && !l; E--) {
                    var w = E >= 0 ? t[E] : u.cwd();
                    if (typeof w != "string")
                      throw new TypeError("Arguments to path.resolve must be strings");
                    if (!w)
                      return "";
                    a = w + "/" + a, l = ie.isAbs(w);
                  }
                  return a = ie.normalizeArray(a.split("/").filter(function(S) {
                    return !!S;
                  }), !l).join("/"), (l ? "/" : "") + a || ".";
                }, relative: function(t, r) {
                  t = st.resolve(t).slice(1), r = st.resolve(r).slice(1);
                  function a(U) {
                    for (var G = 0; G < U.length && U[G] === ""; G++)
                      ;
                    for (var Q = U.length - 1; Q >= 0 && U[Q] === ""; Q--)
                      ;
                    return G > Q ? [] : U.slice(G, Q - G + 1);
                  }
                  for (var l = a(t.split("/")), E = a(r.split("/")), w = Math.min(l.length, E.length), S = w, I = 0; I < w; I++)
                    if (l[I] !== E[I]) {
                      S = I;
                      break;
                    }
                  for (var D = [], I = S; I < l.length; I++)
                    D.push("..");
                  return D = D.concat(E.slice(S)), D.join("/");
                } }, nn = typeof TextDecoder < "u" ? new TextDecoder() : void 0, mt = function(t, r, a) {
                  r === void 0 && (r = 0), a === void 0 && (a = NaN);
                  for (var l = r + a, E = r; t[E] && !(E >= l); )
                    ++E;
                  if (E - r > 16 && t.buffer && nn)
                    return nn.decode(t.subarray(r, E));
                  for (var w = ""; r < E; ) {
                    var S = t[r++];
                    if (!(S & 128)) {
                      w += String.fromCharCode(S);
                      continue;
                    }
                    var I = t[r++] & 63;
                    if ((S & 224) == 192) {
                      w += String.fromCharCode((S & 31) << 6 | I);
                      continue;
                    }
                    var D = t[r++] & 63;
                    if ((S & 240) == 224 ? S = (S & 15) << 12 | I << 6 | D : S = (S & 7) << 18 | I << 12 | D << 6 | t[r++] & 63, S < 65536)
                      w += String.fromCharCode(S);
                    else {
                      var U = S - 65536;
                      w += String.fromCharCode(55296 | U >> 10, 56320 | U & 1023);
                    }
                  }
                  return w;
                }, Lt = [], Ht = function(t) {
                  for (var r = 0, a = 0; a < t.length; ++a) {
                    var l = t.charCodeAt(a);
                    l <= 127 ? r++ : l <= 2047 ? r += 2 : l >= 55296 && l <= 57343 ? (r += 4, ++a) : r += 3;
                  }
                  return r;
                }, $e = function(t, r, a, l) {
                  if (!(l > 0))
                    return 0;
                  for (var E = a, w = a + l - 1, S = 0; S < t.length; ++S) {
                    var I = t.charCodeAt(S);
                    if (I >= 55296 && I <= 57343) {
                      var D = t.charCodeAt(++S);
                      I = 65536 + ((I & 1023) << 10) | D & 1023;
                    }
                    if (I <= 127) {
                      if (a >= w)
                        break;
                      r[a++] = I;
                    } else if (I <= 2047) {
                      if (a + 1 >= w)
                        break;
                      r[a++] = 192 | I >> 6, r[a++] = 128 | I & 63;
                    } else if (I <= 65535) {
                      if (a + 2 >= w)
                        break;
                      r[a++] = 224 | I >> 12, r[a++] = 128 | I >> 6 & 63, r[a++] = 128 | I & 63;
                    } else {
                      if (a + 3 >= w)
                        break;
                      r[a++] = 240 | I >> 18, r[a++] = 128 | I >> 12 & 63, r[a++] = 128 | I >> 6 & 63, r[a++] = 128 | I & 63;
                    }
                  }
                  return r[a] = 0, a - E;
                }, zt = function(t, r, a) {
                  var l = a > 0 ? a : Ht(t) + 1, E = new Array(l), w = $e(t, E, 0, E.length);
                  return r && (E.length = w), E;
                }, Ae = function() {
                  if (!Lt.length) {
                    var t = null;
                    if (Ce) {
                      var r = 256, a = Buffer.alloc(r), l = 0, E = process.stdin.fd;
                      try {
                        l = Ie.readSync(E, a, 0, r);
                      } catch (w) {
                        if (w.toString().includes("EOF"))
                          l = 0;
                        else
                          throw w;
                      }
                      l > 0 && (t = a.slice(0, l).toString("utf-8"));
                    } else typeof window < "u" && typeof window.prompt == "function" && (t = window.prompt("Input: "), t !== null && (t += `
`));
                    if (!t)
                      return null;
                    Lt = zt(t, !0);
                  }
                  return Lt.shift();
                }, ze = { ttys: [], init: function() {
                }, shutdown: function() {
                }, register: function(t, r) {
                  ze.ttys[t] = { input: [], output: [], ops: r }, u.registerDevice(t, ze.stream_ops);
                }, stream_ops: { open: function(t) {
                  var r = ze.ttys[t.node.rdev];
                  if (!r)
                    throw new u.ErrnoError(43);
                  t.tty = r, t.seekable = !1;
                }, close: function(t) {
                  t.tty.ops.fsync(t.tty);
                }, fsync: function(t) {
                  t.tty.ops.fsync(t.tty);
                }, read: function(t, r, a, l, E) {
                  if (!t.tty || !t.tty.ops.get_char)
                    throw new u.ErrnoError(60);
                  for (var w = 0, S = 0; S < l; S++) {
                    var I;
                    try {
                      I = t.tty.ops.get_char(t.tty);
                    } catch {
                      throw new u.ErrnoError(29);
                    }
                    if (I === void 0 && w === 0)
                      throw new u.ErrnoError(6);
                    if (I == null)
                      break;
                    w++, r[a + S] = I;
                  }
                  return w && (t.node.atime = Date.now()), w;
                }, write: function(t, r, a, l, E) {
                  if (!t.tty || !t.tty.ops.put_char)
                    throw new u.ErrnoError(60);
                  try {
                    for (var w = 0; w < l; w++)
                      t.tty.ops.put_char(t.tty, r[a + w]);
                  } catch {
                    throw new u.ErrnoError(29);
                  }
                  return l && (t.node.mtime = t.node.ctime = Date.now()), w;
                } }, default_tty_ops: { get_char: function(t) {
                  return Ae();
                }, put_char: function(t, r) {
                  r === null || r === 10 ? (oe(mt(t.output)), t.output = []) : r != 0 && t.output.push(r);
                }, fsync: function(t) {
                  var r;
                  ((r = t.output) === null || r === void 0 ? void 0 : r.length) > 0 && (oe(mt(t.output)), t.output = []);
                }, ioctl_tcgets: function(t) {
                  return { c_iflag: 25856, c_oflag: 5, c_cflag: 191, c_lflag: 35387, c_cc: [3, 28, 127, 21, 4, 0, 1, 0, 17, 19, 26, 0, 18, 15, 23, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] };
                }, ioctl_tcsets: function(t, r, a) {
                  return 0;
                }, ioctl_tiocgwinsz: function(t) {
                  return [24, 80];
                } }, default_tty1_ops: { put_char: function(t, r) {
                  r === null || r === 10 ? (ce(mt(t.output)), t.output = []) : r != 0 && t.output.push(r);
                }, fsync: function(t) {
                  var r;
                  ((r = t.output) === null || r === void 0 ? void 0 : r.length) > 0 && (ce(mt(t.output)), t.output = []);
                } } }, rn = function(t, r) {
                  return Math.ceil(t / r) * r;
                }, on = function(t) {
                  b();
                }, K = { ops_table: null, mount: function(t) {
                  return K.createNode(null, "/", 16895, 0);
                }, createNode: function(t, r, a, l) {
                  if (u.isBlkdev(a) || u.isFIFO(a))
                    throw new u.ErrnoError(63);
                  K.ops_table || (K.ops_table = { dir: { node: { getattr: K.node_ops.getattr, setattr: K.node_ops.setattr, lookup: K.node_ops.lookup, mknod: K.node_ops.mknod, rename: K.node_ops.rename, unlink: K.node_ops.unlink, rmdir: K.node_ops.rmdir, readdir: K.node_ops.readdir, symlink: K.node_ops.symlink }, stream: { llseek: K.stream_ops.llseek } }, file: { node: { getattr: K.node_ops.getattr, setattr: K.node_ops.setattr }, stream: { llseek: K.stream_ops.llseek, read: K.stream_ops.read, write: K.stream_ops.write, mmap: K.stream_ops.mmap, msync: K.stream_ops.msync } }, link: { node: { getattr: K.node_ops.getattr, setattr: K.node_ops.setattr, readlink: K.node_ops.readlink }, stream: {} }, chrdev: { node: { getattr: K.node_ops.getattr, setattr: K.node_ops.setattr }, stream: u.chrdev_stream_ops } });
                  var E = u.createNode(t, r, a, l);
                  return u.isDir(E.mode) ? (E.node_ops = K.ops_table.dir.node, E.stream_ops = K.ops_table.dir.stream, E.contents = {}) : u.isFile(E.mode) ? (E.node_ops = K.ops_table.file.node, E.stream_ops = K.ops_table.file.stream, E.usedBytes = 0, E.contents = null) : u.isLink(E.mode) ? (E.node_ops = K.ops_table.link.node, E.stream_ops = K.ops_table.link.stream) : u.isChrdev(E.mode) && (E.node_ops = K.ops_table.chrdev.node, E.stream_ops = K.ops_table.chrdev.stream), E.atime = E.mtime = E.ctime = Date.now(), t && (t.contents[r] = E, t.atime = t.mtime = t.ctime = E.atime), E;
                }, getFileDataAsTypedArray: function(t) {
                  return t.contents ? t.contents.subarray ? t.contents.subarray(0, t.usedBytes) : new Uint8Array(t.contents) : new Uint8Array(0);
                }, expandFileStorage: function(t, r) {
                  var a = t.contents ? t.contents.length : 0;
                  if (!(a >= r)) {
                    var l = 1024 * 1024;
                    r = Math.max(r, a * (a < l ? 2 : 1.125) >>> 0), a != 0 && (r = Math.max(r, 256));
                    var E = t.contents;
                    t.contents = new Uint8Array(r), t.usedBytes > 0 && t.contents.set(E.subarray(0, t.usedBytes), 0);
                  }
                }, resizeFileStorage: function(t, r) {
                  if (t.usedBytes != r)
                    if (r == 0)
                      t.contents = null, t.usedBytes = 0;
                    else {
                      var a = t.contents;
                      t.contents = new Uint8Array(r), a && t.contents.set(a.subarray(0, Math.min(r, t.usedBytes))), t.usedBytes = r;
                    }
                }, node_ops: { getattr: function(t) {
                  var r = {};
                  return r.dev = u.isChrdev(t.mode) ? t.id : 1, r.ino = t.id, r.mode = t.mode, r.nlink = 1, r.uid = 0, r.gid = 0, r.rdev = t.rdev, u.isDir(t.mode) ? r.size = 4096 : u.isFile(t.mode) ? r.size = t.usedBytes : u.isLink(t.mode) ? r.size = t.link.length : r.size = 0, r.atime = new Date(t.atime), r.mtime = new Date(t.mtime), r.ctime = new Date(t.ctime), r.blksize = 4096, r.blocks = Math.ceil(r.size / r.blksize), r;
                }, setattr: function(t, r) {
                  for (var a = 0, l = ["mode", "atime", "mtime", "ctime"]; a < l.length; a++) {
                    var E = l[a];
                    r[E] != null && (t[E] = r[E]);
                  }
                  r.size !== void 0 && K.resizeFileStorage(t, r.size);
                }, lookup: function(t, r) {
                  throw K.doesNotExistError;
                }, mknod: function(t, r, a, l) {
                  return K.createNode(t, r, a, l);
                }, rename: function(t, r, a) {
                  var l;
                  try {
                    l = u.lookupNode(r, a);
                  } catch {
                  }
                  if (l) {
                    if (u.isDir(t.mode))
                      for (var E in l.contents)
                        throw new u.ErrnoError(55);
                    u.hashRemoveNode(l);
                  }
                  delete t.parent.contents[t.name], r.contents[a] = t, t.name = a, r.ctime = r.mtime = t.parent.ctime = t.parent.mtime = Date.now();
                }, unlink: function(t, r) {
                  delete t.contents[r], t.ctime = t.mtime = Date.now();
                }, rmdir: function(t, r) {
                  var a = u.lookupNode(t, r);
                  for (var l in a.contents)
                    throw new u.ErrnoError(55);
                  delete t.contents[r], t.ctime = t.mtime = Date.now();
                }, readdir: function(t) {
                  return f([".", ".."], Object.keys(t.contents), !0);
                }, symlink: function(t, r, a) {
                  var l = K.createNode(t, r, 41471, 0);
                  return l.link = a, l;
                }, readlink: function(t) {
                  if (!u.isLink(t.mode))
                    throw new u.ErrnoError(28);
                  return t.link;
                } }, stream_ops: { read: function(t, r, a, l, E) {
                  var w = t.node.contents;
                  if (E >= t.node.usedBytes)
                    return 0;
                  var S = Math.min(t.node.usedBytes - E, l);
                  if (S > 8 && w.subarray)
                    r.set(w.subarray(E, E + S), a);
                  else
                    for (var I = 0; I < S; I++)
                      r[a + I] = w[E + I];
                  return S;
                }, write: function(t, r, a, l, E, w) {
                  if (r.buffer === He.buffer && (w = !1), !l)
                    return 0;
                  var S = t.node;
                  if (S.mtime = S.ctime = Date.now(), r.subarray && (!S.contents || S.contents.subarray)) {
                    if (w)
                      return S.contents = r.subarray(a, a + l), S.usedBytes = l, l;
                    if (S.usedBytes === 0 && E === 0)
                      return S.contents = r.slice(a, a + l), S.usedBytes = l, l;
                    if (E + l <= S.usedBytes)
                      return S.contents.set(r.subarray(a, a + l), E), l;
                  }
                  if (K.expandFileStorage(S, E + l), S.contents.subarray && r.subarray)
                    S.contents.set(r.subarray(a, a + l), E);
                  else
                    for (var I = 0; I < l; I++)
                      S.contents[E + I] = r[a + I];
                  return S.usedBytes = Math.max(S.usedBytes, E + l), l;
                }, llseek: function(t, r, a) {
                  var l = r;
                  if (a === 1 ? l += t.position : a === 2 && u.isFile(t.node.mode) && (l += t.node.usedBytes), l < 0)
                    throw new u.ErrnoError(28);
                  return l;
                }, mmap: function(t, r, a, l, E) {
                  if (!u.isFile(t.node.mode))
                    throw new u.ErrnoError(43);
                  var w, S, I = t.node.contents;
                  if (!(E & 2) && I && I.buffer === He.buffer)
                    S = !1, w = I.byteOffset;
                  else {
                    if (S = !0, w = on(r), !w)
                      throw new u.ErrnoError(48);
                    I && ((a > 0 || a + r < I.length) && (I.subarray ? I = I.subarray(a, a + r) : I = Array.prototype.slice.call(I, a, a + r)), He.set(I, w));
                  }
                  return { ptr: w, allocated: S };
                }, msync: function(t, r, a, l, E) {
                  return K.stream_ops.write(t, r, 0, l, a, !1), 0;
                } } }, Yr = function(t) {
                  return i(or, void 0, void 0, function() {
                    var r;
                    return s(this, function(a) {
                      switch (a.label) {
                        case 0:
                          return [4, te(t)];
                        case 1:
                          return r = a.sent(), [2, new Uint8Array(r)];
                      }
                    });
                  });
                }, Xr = function(t, r, a, l, E, w) {
                  u.createDataFile(t, r, a, l, E, w);
                }, Zr = O.preloadPlugins || [], jr = function(t, r, a, l) {
                  typeof Browser < "u" && Browser.init();
                  var E = !1;
                  return Zr.forEach(function(w) {
                    E || w.canHandle(r) && (w.handle(t, r, a, l), E = !0);
                  }), E;
                }, Vr = function(t, r, a, l, E, w, S, I, D, U) {
                  var G = r ? st.resolve(ie.join2(t, r)) : t;
                  function Q(q) {
                    function H(z) {
                      U?.(), I || Xr(t, r, z, l, E, D), w?.(), g();
                    }
                    jr(q, G, H, function() {
                      S?.(), g();
                    }) || H(q);
                  }
                  v(), typeof a == "string" ? Yr(a).then(Q, S) : Q(a);
                }, Kr = function(t) {
                  var r = { r: 0, "r+": 2, w: 577, "w+": 578, a: 1089, "a+": 1090 }, a = r[t];
                  if (typeof a > "u")
                    throw new Error("Unknown file open mode: ".concat(t));
                  return a;
                }, vn = function(t, r) {
                  var a = 0;
                  return t && (a |= 365), r && (a |= 146), a;
                }, u = { root: null, mounts: [], devices: {}, streams: [], nextInode: 1, nameTable: null, currentPath: "/", initialized: !1, ignorePermissions: !0, filesystems: null, syncFSRequests: 0, readFiles: {}, ErrnoError: (
                  /** @class */
                  /* @__PURE__ */ (function() {
                    function t(r) {
                      this.name = "ErrnoError", this.errno = r;
                    }
                    return t;
                  })()
                ), FSStream: (
                  /** @class */
                  (function() {
                    function t() {
                      this.shared = {};
                    }
                    return Object.defineProperty(t.prototype, "object", {
                      get: function() {
                        return this.node;
                      },
                      set: function(r) {
                        this.node = r;
                      },
                      enumerable: !1,
                      configurable: !0
                    }), Object.defineProperty(t.prototype, "isRead", {
                      get: function() {
                        return (this.flags & 2097155) !== 1;
                      },
                      enumerable: !1,
                      configurable: !0
                    }), Object.defineProperty(t.prototype, "isWrite", {
                      get: function() {
                        return (this.flags & 2097155) !== 0;
                      },
                      enumerable: !1,
                      configurable: !0
                    }), Object.defineProperty(t.prototype, "isAppend", {
                      get: function() {
                        return this.flags & 1024;
                      },
                      enumerable: !1,
                      configurable: !0
                    }), Object.defineProperty(t.prototype, "flags", {
                      get: function() {
                        return this.shared.flags;
                      },
                      set: function(r) {
                        this.shared.flags = r;
                      },
                      enumerable: !1,
                      configurable: !0
                    }), Object.defineProperty(t.prototype, "position", {
                      get: function() {
                        return this.shared.position;
                      },
                      set: function(r) {
                        this.shared.position = r;
                      },
                      enumerable: !1,
                      configurable: !0
                    }), t;
                  })()
                ), FSNode: (
                  /** @class */
                  (function() {
                    function t(r, a, l, E) {
                      this.node_ops = {}, this.stream_ops = {}, this.readMode = 365, this.writeMode = 146, this.mounted = null, r || (r = this), this.parent = r, this.mount = r.mount, this.id = u.nextInode++, this.name = a, this.mode = l, this.rdev = E, this.atime = this.mtime = this.ctime = Date.now();
                    }
                    return Object.defineProperty(t.prototype, "read", {
                      get: function() {
                        return (this.mode & this.readMode) === this.readMode;
                      },
                      set: function(r) {
                        r ? this.mode |= this.readMode : this.mode &= ~this.readMode;
                      },
                      enumerable: !1,
                      configurable: !0
                    }), Object.defineProperty(t.prototype, "write", {
                      get: function() {
                        return (this.mode & this.writeMode) === this.writeMode;
                      },
                      set: function(r) {
                        r ? this.mode |= this.writeMode : this.mode &= ~this.writeMode;
                      },
                      enumerable: !1,
                      configurable: !0
                    }), Object.defineProperty(t.prototype, "isFolder", {
                      get: function() {
                        return u.isDir(this.mode);
                      },
                      enumerable: !1,
                      configurable: !0
                    }), Object.defineProperty(t.prototype, "isDevice", {
                      get: function() {
                        return u.isChrdev(this.mode);
                      },
                      enumerable: !1,
                      configurable: !0
                    }), t;
                  })()
                ), lookupPath: function(t, r) {
                  var a;
                  if (r === void 0 && (r = {}), !t)
                    throw new u.ErrnoError(44);
                  (a = r.follow_mount) !== null && a !== void 0 || (r.follow_mount = !0), ie.isAbs(t) || (t = u.cwd() + "/" + t);
                  e: for (var l = 0; l < 40; l++) {
                    for (var E = t.split("/").filter(function(G) {
                      return !!G;
                    }), w = u.root, S = "/", I = 0; I < E.length; I++) {
                      var D = I === E.length - 1;
                      if (D && r.parent)
                        break;
                      if (E[I] !== ".") {
                        if (E[I] === "..") {
                          S = ie.dirname(S), w = w.parent;
                          continue;
                        }
                        S = ie.join2(S, E[I]);
                        try {
                          w = u.lookupNode(w, E[I]);
                        } catch (G) {
                          if (G?.errno === 44 && D && r.noent_okay)
                            return { path: S };
                          throw G;
                        }
                        if (u.isMountpoint(w) && (!D || r.follow_mount) && (w = w.mounted.root), u.isLink(w.mode) && (!D || r.follow)) {
                          if (!w.node_ops.readlink)
                            throw new u.ErrnoError(52);
                          var U = w.node_ops.readlink(w);
                          ie.isAbs(U) || (U = ie.dirname(S) + "/" + U), t = U + "/" + E.slice(I + 1).join("/");
                          continue e;
                        }
                      }
                    }
                    return { path: S, node: w };
                  }
                  throw new u.ErrnoError(32);
                }, getPath: function(t) {
                  for (var r; ; ) {
                    if (u.isRoot(t)) {
                      var a = t.mount.mountpoint;
                      return r ? a[a.length - 1] !== "/" ? "".concat(a, "/").concat(r) : a + r : a;
                    }
                    r = r ? "".concat(t.name, "/").concat(r) : t.name, t = t.parent;
                  }
                }, hashName: function(t, r) {
                  for (var a = 0, l = 0; l < r.length; l++)
                    a = (a << 5) - a + r.charCodeAt(l) | 0;
                  return (t + a >>> 0) % u.nameTable.length;
                }, hashAddNode: function(t) {
                  var r = u.hashName(t.parent.id, t.name);
                  t.name_next = u.nameTable[r], u.nameTable[r] = t;
                }, hashRemoveNode: function(t) {
                  var r = u.hashName(t.parent.id, t.name);
                  if (u.nameTable[r] === t)
                    u.nameTable[r] = t.name_next;
                  else
                    for (var a = u.nameTable[r]; a; ) {
                      if (a.name_next === t) {
                        a.name_next = t.name_next;
                        break;
                      }
                      a = a.name_next;
                    }
                }, lookupNode: function(t, r) {
                  var a = u.mayLookup(t);
                  if (a)
                    throw new u.ErrnoError(a);
                  for (var l = u.hashName(t.id, r), E = u.nameTable[l]; E; E = E.name_next) {
                    var w = E.name;
                    if (E.parent.id === t.id && w === r)
                      return E;
                  }
                  return u.lookup(t, r);
                }, createNode: function(t, r, a, l) {
                  var E = new u.FSNode(t, r, a, l);
                  return u.hashAddNode(E), E;
                }, destroyNode: function(t) {
                  u.hashRemoveNode(t);
                }, isRoot: function(t) {
                  return t === t.parent;
                }, isMountpoint: function(t) {
                  return !!t.mounted;
                }, isFile: function(t) {
                  return (t & 61440) === 32768;
                }, isDir: function(t) {
                  return (t & 61440) === 16384;
                }, isLink: function(t) {
                  return (t & 61440) === 40960;
                }, isChrdev: function(t) {
                  return (t & 61440) === 8192;
                }, isBlkdev: function(t) {
                  return (t & 61440) === 24576;
                }, isFIFO: function(t) {
                  return (t & 61440) === 4096;
                }, isSocket: function(t) {
                  return (t & 49152) === 49152;
                }, flagsToPermissionString: function(t) {
                  var r = ["r", "w", "rw"][t & 3];
                  return t & 512 && (r += "w"), r;
                }, nodePermissions: function(t, r) {
                  return u.ignorePermissions ? 0 : r.includes("r") && !(t.mode & 292) || r.includes("w") && !(t.mode & 146) || r.includes("x") && !(t.mode & 73) ? 2 : 0;
                }, mayLookup: function(t) {
                  if (!u.isDir(t.mode))
                    return 54;
                  var r = u.nodePermissions(t, "x");
                  return r || (t.node_ops.lookup ? 0 : 2);
                }, mayCreate: function(t, r) {
                  if (!u.isDir(t.mode))
                    return 54;
                  try {
                    var a = u.lookupNode(t, r);
                    return 20;
                  } catch {
                  }
                  return u.nodePermissions(t, "wx");
                }, mayDelete: function(t, r, a) {
                  var l;
                  try {
                    l = u.lookupNode(t, r);
                  } catch (w) {
                    return w.errno;
                  }
                  var E = u.nodePermissions(t, "wx");
                  if (E)
                    return E;
                  if (a) {
                    if (!u.isDir(l.mode))
                      return 54;
                    if (u.isRoot(l) || u.getPath(l) === u.cwd())
                      return 10;
                  } else if (u.isDir(l.mode))
                    return 31;
                  return 0;
                }, mayOpen: function(t, r) {
                  return t ? u.isLink(t.mode) ? 32 : u.isDir(t.mode) && (u.flagsToPermissionString(r) !== "r" || r & 576) ? 31 : u.nodePermissions(t, u.flagsToPermissionString(r)) : 44;
                }, checkOpExists: function(t, r) {
                  if (!t)
                    throw new u.ErrnoError(r);
                  return t;
                }, MAX_OPEN_FDS: 4096, nextfd: function() {
                  for (var t = 0; t <= u.MAX_OPEN_FDS; t++)
                    if (!u.streams[t])
                      return t;
                  throw new u.ErrnoError(33);
                }, getStreamChecked: function(t) {
                  var r = u.getStream(t);
                  if (!r)
                    throw new u.ErrnoError(8);
                  return r;
                }, getStream: function(t) {
                  return u.streams[t];
                }, createStream: function(t, r) {
                  return r === void 0 && (r = -1), t = Object.assign(new u.FSStream(), t), r == -1 && (r = u.nextfd()), t.fd = r, u.streams[r] = t, t;
                }, closeStream: function(t) {
                  u.streams[t] = null;
                }, dupStream: function(t, r) {
                  var a, l;
                  r === void 0 && (r = -1);
                  var E = u.createStream(t, r);
                  return (l = (a = E.stream_ops) === null || a === void 0 ? void 0 : a.dup) === null || l === void 0 || l.call(a, E), E;
                }, doSetAttr: function(t, r, a) {
                  var l = t?.stream_ops.setattr, E = l ? t : r;
                  l ?? (l = r.node_ops.setattr), u.checkOpExists(l, 63), l(E, a);
                }, chrdev_stream_ops: { open: function(t) {
                  var r, a, l = u.getDevice(t.node.rdev);
                  t.stream_ops = l.stream_ops, (a = (r = t.stream_ops).open) === null || a === void 0 || a.call(r, t);
                }, llseek: function() {
                  throw new u.ErrnoError(70);
                } }, major: function(t) {
                  return t >> 8;
                }, minor: function(t) {
                  return t & 255;
                }, makedev: function(t, r) {
                  return t << 8 | r;
                }, registerDevice: function(t, r) {
                  u.devices[t] = { stream_ops: r };
                }, getDevice: function(t) {
                  return u.devices[t];
                }, getMounts: function(t) {
                  for (var r = [], a = [t]; a.length; ) {
                    var l = a.pop();
                    r.push(l), a.push.apply(a, l.mounts);
                  }
                  return r;
                }, syncfs: function(t, r) {
                  typeof t == "function" && (r = t, t = !1), u.syncFSRequests++, u.syncFSRequests > 1 && ce("warning: ".concat(u.syncFSRequests, " FS.syncfs operations in flight at once, probably just doing extra work"));
                  var a = u.getMounts(u.root.mount), l = 0;
                  function E(S) {
                    return u.syncFSRequests--, r(S);
                  }
                  function w(S) {
                    if (S)
                      return w.errored ? void 0 : (w.errored = !0, E(S));
                    ++l >= a.length && E(null);
                  }
                  a.forEach(function(S) {
                    if (!S.type.syncfs)
                      return w(null);
                    S.type.syncfs(S, t, w);
                  });
                }, mount: function(t, r, a) {
                  var l = a === "/", E = !a, w;
                  if (l && u.root)
                    throw new u.ErrnoError(10);
                  if (!l && !E) {
                    var S = u.lookupPath(a, { follow_mount: !1 });
                    if (a = S.path, w = S.node, u.isMountpoint(w))
                      throw new u.ErrnoError(10);
                    if (!u.isDir(w.mode))
                      throw new u.ErrnoError(54);
                  }
                  var I = { type: t, opts: r, mountpoint: a, mounts: [] }, D = t.mount(I);
                  return D.mount = I, I.root = D, l ? u.root = D : w && (w.mounted = I, w.mount && w.mount.mounts.push(I)), D;
                }, unmount: function(t) {
                  var r = u.lookupPath(t, { follow_mount: !1 });
                  if (!u.isMountpoint(r.node))
                    throw new u.ErrnoError(28);
                  var a = r.node, l = a.mounted, E = u.getMounts(l);
                  Object.keys(u.nameTable).forEach(function(S) {
                    for (var I = u.nameTable[S]; I; ) {
                      var D = I.name_next;
                      E.includes(I.mount) && u.destroyNode(I), I = D;
                    }
                  }), a.mounted = null;
                  var w = a.mount.mounts.indexOf(l);
                  a.mount.mounts.splice(w, 1);
                }, lookup: function(t, r) {
                  return t.node_ops.lookup(t, r);
                }, mknod: function(t, r, a) {
                  var l = u.lookupPath(t, { parent: !0 }), E = l.node, w = ie.basename(t);
                  if (!w)
                    throw new u.ErrnoError(28);
                  if (w === "." || w === "..")
                    throw new u.ErrnoError(20);
                  var S = u.mayCreate(E, w);
                  if (S)
                    throw new u.ErrnoError(S);
                  if (!E.node_ops.mknod)
                    throw new u.ErrnoError(63);
                  return E.node_ops.mknod(E, w, r, a);
                }, statfs: function(t) {
                  return u.statfsNode(u.lookupPath(t, { follow: !0 }).node);
                }, statfsStream: function(t) {
                  return u.statfsNode(t.node);
                }, statfsNode: function(t) {
                  var r = { bsize: 4096, frsize: 4096, blocks: 1e6, bfree: 5e5, bavail: 5e5, files: u.nextInode, ffree: u.nextInode - 1, fsid: 42, flags: 2, namelen: 255 };
                  return t.node_ops.statfs && Object.assign(r, t.node_ops.statfs(t.mount.opts.root)), r;
                }, create: function(t, r) {
                  return r === void 0 && (r = 438), r &= 4095, r |= 32768, u.mknod(t, r, 0);
                }, mkdir: function(t, r) {
                  return r === void 0 && (r = 511), r &= 1023, r |= 16384, u.mknod(t, r, 0);
                }, mkdirTree: function(t, r) {
                  for (var a = t.split("/"), l = "", E = 0, w = a; E < w.length; E++) {
                    var S = w[E];
                    if (S) {
                      l += "/" + S;
                      try {
                        u.mkdir(l, r);
                      } catch (I) {
                        if (I.errno != 20)
                          throw I;
                      }
                    }
                  }
                }, mkdev: function(t, r, a) {
                  return typeof a > "u" && (a = r, r = 438), r |= 8192, u.mknod(t, r, a);
                }, symlink: function(t, r) {
                  if (!st.resolve(t))
                    throw new u.ErrnoError(44);
                  var a = u.lookupPath(r, { parent: !0 }), l = a.node;
                  if (!l)
                    throw new u.ErrnoError(44);
                  var E = ie.basename(r), w = u.mayCreate(l, E);
                  if (w)
                    throw new u.ErrnoError(w);
                  if (!l.node_ops.symlink)
                    throw new u.ErrnoError(63);
                  return l.node_ops.symlink(l, E, t);
                }, rename: function(t, r) {
                  var a = ie.dirname(t), l = ie.dirname(r), E = ie.basename(t), w = ie.basename(r), S, I, D;
                  if (S = u.lookupPath(t, { parent: !0 }), I = S.node, S = u.lookupPath(r, { parent: !0 }), D = S.node, !I || !D)
                    throw new u.ErrnoError(44);
                  if (I.mount !== D.mount)
                    throw new u.ErrnoError(75);
                  var U = u.lookupNode(I, E), G = st.relative(t, l);
                  if (G.charAt(0) !== ".")
                    throw new u.ErrnoError(28);
                  if (G = st.relative(r, a), G.charAt(0) !== ".")
                    throw new u.ErrnoError(55);
                  var Q;
                  try {
                    Q = u.lookupNode(D, w);
                  } catch {
                  }
                  if (U !== Q) {
                    var q = u.isDir(U.mode), H = u.mayDelete(I, E, q);
                    if (H)
                      throw new u.ErrnoError(H);
                    if (H = Q ? u.mayDelete(D, w, q) : u.mayCreate(D, w), H)
                      throw new u.ErrnoError(H);
                    if (!I.node_ops.rename)
                      throw new u.ErrnoError(63);
                    if (u.isMountpoint(U) || Q && u.isMountpoint(Q))
                      throw new u.ErrnoError(10);
                    if (D !== I && (H = u.nodePermissions(I, "w"), H))
                      throw new u.ErrnoError(H);
                    u.hashRemoveNode(U);
                    try {
                      I.node_ops.rename(U, D, w), U.parent = D;
                    } catch (z) {
                      throw z;
                    } finally {
                      u.hashAddNode(U);
                    }
                  }
                }, rmdir: function(t) {
                  var r = u.lookupPath(t, { parent: !0 }), a = r.node, l = ie.basename(t), E = u.lookupNode(a, l), w = u.mayDelete(a, l, !0);
                  if (w)
                    throw new u.ErrnoError(w);
                  if (!a.node_ops.rmdir)
                    throw new u.ErrnoError(63);
                  if (u.isMountpoint(E))
                    throw new u.ErrnoError(10);
                  a.node_ops.rmdir(a, l), u.destroyNode(E);
                }, readdir: function(t) {
                  var r = u.lookupPath(t, { follow: !0 }), a = r.node, l = u.checkOpExists(a.node_ops.readdir, 54);
                  return l(a);
                }, unlink: function(t) {
                  var r = u.lookupPath(t, { parent: !0 }), a = r.node;
                  if (!a)
                    throw new u.ErrnoError(44);
                  var l = ie.basename(t), E = u.lookupNode(a, l), w = u.mayDelete(a, l, !1);
                  if (w)
                    throw new u.ErrnoError(w);
                  if (!a.node_ops.unlink)
                    throw new u.ErrnoError(63);
                  if (u.isMountpoint(E))
                    throw new u.ErrnoError(10);
                  a.node_ops.unlink(a, l), u.destroyNode(E);
                }, readlink: function(t) {
                  var r = u.lookupPath(t), a = r.node;
                  if (!a)
                    throw new u.ErrnoError(44);
                  if (!a.node_ops.readlink)
                    throw new u.ErrnoError(28);
                  return a.node_ops.readlink(a);
                }, stat: function(t, r) {
                  var a = u.lookupPath(t, { follow: !r }), l = a.node, E = u.checkOpExists(l.node_ops.getattr, 63);
                  return E(l);
                }, fstat: function(t) {
                  var r = u.getStreamChecked(t), a = r.node, l = r.stream_ops.getattr, E = l ? r : a;
                  return l ?? (l = a.node_ops.getattr), u.checkOpExists(l, 63), l(E);
                }, lstat: function(t) {
                  return u.stat(t, !0);
                }, doChmod: function(t, r, a, l) {
                  u.doSetAttr(t, r, { mode: a & 4095 | r.mode & -4096, ctime: Date.now(), dontFollow: l });
                }, chmod: function(t, r, a) {
                  var l;
                  if (typeof t == "string") {
                    var E = u.lookupPath(t, { follow: !a });
                    l = E.node;
                  } else
                    l = t;
                  u.doChmod(null, l, r, a);
                }, lchmod: function(t, r) {
                  u.chmod(t, r, !0);
                }, fchmod: function(t, r) {
                  var a = u.getStreamChecked(t);
                  u.doChmod(a, a.node, r, !1);
                }, doChown: function(t, r, a) {
                  u.doSetAttr(t, r, { timestamp: Date.now(), dontFollow: a });
                }, chown: function(t, r, a, l) {
                  var E;
                  if (typeof t == "string") {
                    var w = u.lookupPath(t, { follow: !l });
                    E = w.node;
                  } else
                    E = t;
                  u.doChown(null, E, l);
                }, lchown: function(t, r, a) {
                  u.chown(t, r, a, !0);
                }, fchown: function(t, r, a) {
                  var l = u.getStreamChecked(t);
                  u.doChown(l, l.node, !1);
                }, doTruncate: function(t, r, a) {
                  if (u.isDir(r.mode))
                    throw new u.ErrnoError(31);
                  if (!u.isFile(r.mode))
                    throw new u.ErrnoError(28);
                  var l = u.nodePermissions(r, "w");
                  if (l)
                    throw new u.ErrnoError(l);
                  u.doSetAttr(t, r, { size: a, timestamp: Date.now() });
                }, truncate: function(t, r) {
                  if (r < 0)
                    throw new u.ErrnoError(28);
                  var a;
                  if (typeof t == "string") {
                    var l = u.lookupPath(t, { follow: !0 });
                    a = l.node;
                  } else
                    a = t;
                  u.doTruncate(null, a, r);
                }, ftruncate: function(t, r) {
                  var a = u.getStreamChecked(t);
                  if (r < 0 || (a.flags & 2097155) === 0)
                    throw new u.ErrnoError(28);
                  u.doTruncate(a, a.node, r);
                }, utime: function(t, r, a) {
                  var l = u.lookupPath(t, { follow: !0 }), E = l.node, w = u.checkOpExists(E.node_ops.setattr, 63);
                  w(E, { atime: r, mtime: a });
                }, open: function(t, r, a) {
                  if (a === void 0 && (a = 438), t === "")
                    throw new u.ErrnoError(44);
                  r = typeof r == "string" ? Kr(r) : r, r & 64 ? a = a & 4095 | 32768 : a = 0;
                  var l, E;
                  if (typeof t == "object")
                    l = t;
                  else {
                    E = t.endsWith("/");
                    var w = u.lookupPath(t, { follow: !(r & 131072), noent_okay: !0 });
                    l = w.node, t = w.path;
                  }
                  var S = !1;
                  if (r & 64)
                    if (l) {
                      if (r & 128)
                        throw new u.ErrnoError(20);
                    } else {
                      if (E)
                        throw new u.ErrnoError(31);
                      l = u.mknod(t, a | 511, 0), S = !0;
                    }
                  if (!l)
                    throw new u.ErrnoError(44);
                  if (u.isChrdev(l.mode) && (r &= -513), r & 65536 && !u.isDir(l.mode))
                    throw new u.ErrnoError(54);
                  if (!S) {
                    var I = u.mayOpen(l, r);
                    if (I)
                      throw new u.ErrnoError(I);
                  }
                  r & 512 && !S && u.truncate(l, 0), r &= -131713;
                  var D = u.createStream({ node: l, path: u.getPath(l), flags: r, seekable: !0, position: 0, stream_ops: l.stream_ops, ungotten: [], error: !1 });
                  return D.stream_ops.open && D.stream_ops.open(D), S && u.chmod(l, a & 511), O.logReadFiles && !(r & 1) && (t in u.readFiles || (u.readFiles[t] = 1)), D;
                }, close: function(t) {
                  if (u.isClosed(t))
                    throw new u.ErrnoError(8);
                  t.getdents && (t.getdents = null);
                  try {
                    t.stream_ops.close && t.stream_ops.close(t);
                  } catch (r) {
                    throw r;
                  } finally {
                    u.closeStream(t.fd);
                  }
                  t.fd = null;
                }, isClosed: function(t) {
                  return t.fd === null;
                }, llseek: function(t, r, a) {
                  if (u.isClosed(t))
                    throw new u.ErrnoError(8);
                  if (!t.seekable || !t.stream_ops.llseek)
                    throw new u.ErrnoError(70);
                  if (a != 0 && a != 1 && a != 2)
                    throw new u.ErrnoError(28);
                  return t.position = t.stream_ops.llseek(t, r, a), t.ungotten = [], t.position;
                }, read: function(t, r, a, l, E) {
                  if (l < 0 || E < 0)
                    throw new u.ErrnoError(28);
                  if (u.isClosed(t))
                    throw new u.ErrnoError(8);
                  if ((t.flags & 2097155) === 1)
                    throw new u.ErrnoError(8);
                  if (u.isDir(t.node.mode))
                    throw new u.ErrnoError(31);
                  if (!t.stream_ops.read)
                    throw new u.ErrnoError(28);
                  var w = typeof E < "u";
                  if (!w)
                    E = t.position;
                  else if (!t.seekable)
                    throw new u.ErrnoError(70);
                  var S = t.stream_ops.read(t, r, a, l, E);
                  return w || (t.position += S), S;
                }, write: function(t, r, a, l, E, w) {
                  if (l < 0 || E < 0)
                    throw new u.ErrnoError(28);
                  if (u.isClosed(t))
                    throw new u.ErrnoError(8);
                  if ((t.flags & 2097155) === 0)
                    throw new u.ErrnoError(8);
                  if (u.isDir(t.node.mode))
                    throw new u.ErrnoError(31);
                  if (!t.stream_ops.write)
                    throw new u.ErrnoError(28);
                  t.seekable && t.flags & 1024 && u.llseek(t, 0, 2);
                  var S = typeof E < "u";
                  if (!S)
                    E = t.position;
                  else if (!t.seekable)
                    throw new u.ErrnoError(70);
                  var I = t.stream_ops.write(t, r, a, l, E, w);
                  return S || (t.position += I), I;
                }, mmap: function(t, r, a, l, E) {
                  if ((l & 2) !== 0 && (E & 2) === 0 && (t.flags & 2097155) !== 2)
                    throw new u.ErrnoError(2);
                  if ((t.flags & 2097155) === 1)
                    throw new u.ErrnoError(2);
                  if (!t.stream_ops.mmap)
                    throw new u.ErrnoError(43);
                  if (!r)
                    throw new u.ErrnoError(28);
                  return t.stream_ops.mmap(t, r, a, l, E);
                }, msync: function(t, r, a, l, E) {
                  return t.stream_ops.msync ? t.stream_ops.msync(t, r, a, l, E) : 0;
                }, ioctl: function(t, r, a) {
                  if (!t.stream_ops.ioctl)
                    throw new u.ErrnoError(59);
                  return t.stream_ops.ioctl(t, r, a);
                }, readFile: function(t, r) {
                  if (r === void 0 && (r = {}), r.flags = r.flags || 0, r.encoding = r.encoding || "binary", r.encoding !== "utf8" && r.encoding !== "binary")
                    throw new Error('Invalid encoding type "'.concat(r.encoding, '"'));
                  var a, l = u.open(t, r.flags), E = u.stat(t), w = E.size, S = new Uint8Array(w);
                  return u.read(l, S, 0, w, 0), r.encoding === "utf8" ? a = mt(S) : r.encoding === "binary" && (a = S), u.close(l), a;
                }, writeFile: function(t, r, a) {
                  a === void 0 && (a = {}), a.flags = a.flags || 577;
                  var l = u.open(t, a.flags, a.mode);
                  if (typeof r == "string") {
                    var E = new Uint8Array(Ht(r) + 1), w = $e(r, E, 0, E.length);
                    u.write(l, E, 0, w, void 0, a.canOwn);
                  } else if (ArrayBuffer.isView(r))
                    u.write(l, r, 0, r.byteLength, void 0, a.canOwn);
                  else
                    throw new Error("Unsupported data type");
                  u.close(l);
                }, cwd: function() {
                  return u.currentPath;
                }, chdir: function(t) {
                  var r = u.lookupPath(t, { follow: !0 });
                  if (r.node === null)
                    throw new u.ErrnoError(44);
                  if (!u.isDir(r.node.mode))
                    throw new u.ErrnoError(54);
                  var a = u.nodePermissions(r.node, "x");
                  if (a)
                    throw new u.ErrnoError(a);
                  u.currentPath = r.path;
                }, createDefaultDirectories: function() {
                  u.mkdir("/tmp"), u.mkdir("/home"), u.mkdir("/home/web_user");
                }, createDefaultDevices: function() {
                  u.mkdir("/dev"), u.registerDevice(u.makedev(1, 3), { read: function() {
                    return 0;
                  }, write: function(l, E, w, S, I) {
                    return S;
                  }, llseek: function() {
                    return 0;
                  } }), u.mkdev("/dev/null", u.makedev(1, 3)), ze.register(u.makedev(5, 0), ze.default_tty_ops), ze.register(u.makedev(6, 0), ze.default_tty1_ops), u.mkdev("/dev/tty", u.makedev(5, 0)), u.mkdev("/dev/tty1", u.makedev(6, 0));
                  var t = new Uint8Array(1024), r = 0, a = function() {
                    return r === 0 && (Tn(t), r = t.byteLength), t[--r];
                  };
                  u.createDevice("/dev", "random", a), u.createDevice("/dev", "urandom", a), u.mkdir("/dev/shm"), u.mkdir("/dev/shm/tmp");
                }, createSpecialDirectories: function() {
                  u.mkdir("/proc");
                  var t = u.mkdir("/proc/self");
                  u.mkdir("/proc/self/fd"), u.mount({ mount: function() {
                    var r = u.createNode(t, "fd", 16895, 73);
                    return r.stream_ops = { llseek: K.stream_ops.llseek }, r.node_ops = { lookup: function(a, l) {
                      var E = +l, w = u.getStreamChecked(E), S = { parent: null, mount: { mountpoint: "fake" }, node_ops: { readlink: function() {
                        return w.path;
                      } }, id: E + 1 };
                      return S.parent = S, S;
                    }, readdir: function() {
                      return Array.from(u.streams.entries()).filter(function(a) {
                        a[0];
                        var l = a[1];
                        return l;
                      }).map(function(a) {
                        var l = a[0];
                        return a[1], l.toString();
                      });
                    } }, r;
                  } }, {}, "/proc/self/fd");
                }, createStandardStreams: function(t, r, a) {
                  t ? u.createDevice("/dev", "stdin", t) : u.symlink("/dev/tty", "/dev/stdin"), r ? u.createDevice("/dev", "stdout", null, r) : u.symlink("/dev/tty", "/dev/stdout"), a ? u.createDevice("/dev", "stderr", null, a) : u.symlink("/dev/tty1", "/dev/stderr"), u.open("/dev/stdin", 0), u.open("/dev/stdout", 1), u.open("/dev/stderr", 1);
                }, staticInit: function() {
                  u.nameTable = new Array(4096), u.mount(K, {}, "/"), u.createDefaultDirectories(), u.createDefaultDevices(), u.createSpecialDirectories(), u.filesystems = { MEMFS: K };
                }, init: function(t, r, a) {
                  u.initialized = !0, t ?? (t = O.stdin), r ?? (r = O.stdout), a ?? (a = O.stderr), u.createStandardStreams(t, r, a);
                }, quit: function() {
                  u.initialized = !1;
                  for (var t = 0, r = u.streams; t < r.length; t++) {
                    var a = r[t];
                    a && u.close(a);
                  }
                }, findObject: function(t, r) {
                  var a = u.analyzePath(t, r);
                  return a.exists ? a.object : null;
                }, analyzePath: function(t, r) {
                  try {
                    var a = u.lookupPath(t, { follow: !r });
                    t = a.path;
                  } catch {
                  }
                  var l = { isRoot: !1, exists: !1, error: 0, name: null, path: null, object: null, parentExists: !1, parentPath: null, parentObject: null };
                  try {
                    var a = u.lookupPath(t, { parent: !0 });
                    l.parentExists = !0, l.parentPath = a.path, l.parentObject = a.node, l.name = ie.basename(t), a = u.lookupPath(t, { follow: !r }), l.exists = !0, l.path = a.path, l.object = a.node, l.name = a.node.name, l.isRoot = a.path === "/";
                  } catch (E) {
                    l.error = E.errno;
                  }
                  return l;
                }, createPath: function(t, r, a, l) {
                  t = typeof t == "string" ? t : u.getPath(t);
                  for (var E = r.split("/").reverse(); E.length; ) {
                    var w = E.pop();
                    if (w) {
                      var S = ie.join2(t, w);
                      try {
                        u.mkdir(S);
                      } catch (I) {
                        if (I.errno != 20)
                          throw I;
                      }
                      t = S;
                    }
                  }
                  return S;
                }, createFile: function(t, r, a, l, E) {
                  var w = ie.join2(typeof t == "string" ? t : u.getPath(t), r), S = vn(l, E);
                  return u.create(w, S);
                }, createDataFile: function(t, r, a, l, E, w) {
                  var S = r;
                  t && (t = typeof t == "string" ? t : u.getPath(t), S = r ? ie.join2(t, r) : t);
                  var I = vn(l, E), D = u.create(S, I);
                  if (a) {
                    if (typeof a == "string") {
                      for (var U = new Array(a.length), G = 0, Q = a.length; G < Q; ++G)
                        U[G] = a.charCodeAt(G);
                      a = U;
                    }
                    u.chmod(D, I | 146);
                    var q = u.open(D, 577);
                    u.write(q, a, 0, a.length, 0, w), u.close(q), u.chmod(D, I);
                  }
                }, createDevice: function(t, r, a, l) {
                  var E, w, S = ie.join2(typeof t == "string" ? t : u.getPath(t), r), I = vn(!!a, !!l);
                  (E = (w = u.createDevice).major) !== null && E !== void 0 || (w.major = 64);
                  var D = u.makedev(u.createDevice.major++, 0);
                  return u.registerDevice(D, { open: function(U) {
                    U.seekable = !1;
                  }, close: function(U) {
                    var G;
                    !((G = l?.buffer) === null || G === void 0) && G.length && l(10);
                  }, read: function(U, G, Q, q, H) {
                    for (var z = 0, ne = 0; ne < q; ne++) {
                      var be;
                      try {
                        be = a();
                      } catch {
                        throw new u.ErrnoError(29);
                      }
                      if (be === void 0 && z === 0)
                        throw new u.ErrnoError(6);
                      if (be == null)
                        break;
                      z++, G[Q + ne] = be;
                    }
                    return z && (U.node.atime = Date.now()), z;
                  }, write: function(U, G, Q, q, H) {
                    for (var z = 0; z < q; z++)
                      try {
                        l(G[Q + z]);
                      } catch {
                        throw new u.ErrnoError(29);
                      }
                    return q && (U.node.mtime = U.node.ctime = Date.now()), z;
                  } }), u.mkdev(S, I, D);
                }, forceLoadFile: function(t) {
                  if (t.isDevice || t.isFolder || t.link || t.contents)
                    return !0;
                  if (typeof XMLHttpRequest < "u")
                    throw new Error("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");
                  try {
                    t.contents = k(t.url), t.usedBytes = t.contents.length;
                  } catch {
                    throw new u.ErrnoError(29);
                  }
                }, createLazyFile: function(t, r, a, l, E) {
                  var w = (
                    /** @class */
                    (function() {
                      function q() {
                        this.lengthKnown = !1, this.chunks = [];
                      }
                      return q.prototype.get = function(H) {
                        if (!(H > this.length - 1 || H < 0)) {
                          var z = H % this.chunkSize, ne = H / this.chunkSize | 0;
                          return this.getter(ne)[z];
                        }
                      }, q.prototype.setDataGetter = function(H) {
                        this.getter = H;
                      }, q.prototype.cacheLength = function() {
                        var H = new XMLHttpRequest();
                        if (H.open("HEAD", a, !1), H.send(null), !(H.status >= 200 && H.status < 300 || H.status === 304))
                          throw new Error("Couldn't load " + a + ". Status: " + H.status);
                        var z = Number(H.getResponseHeader("Content-length")), ne, be = (ne = H.getResponseHeader("Accept-Ranges")) && ne === "bytes", Re = (ne = H.getResponseHeader("Content-Encoding")) && ne === "gzip", et = 1024 * 1024;
                        be || (et = z);
                        var tt = function(ct, Yt) {
                          if (ct > Yt)
                            throw new Error("invalid range (" + ct + ", " + Yt + ") or no bytes requested!");
                          if (Yt > z - 1)
                            throw new Error("only " + z + " bytes available! programmer error!");
                          var Le = new XMLHttpRequest();
                          if (Le.open("GET", a, !1), z !== et && Le.setRequestHeader("Range", "bytes=" + ct + "-" + Yt), Le.responseType = "arraybuffer", Le.overrideMimeType && Le.overrideMimeType("text/plain; charset=x-user-defined"), Le.send(null), !(Le.status >= 200 && Le.status < 300 || Le.status === 304))
                            throw new Error("Couldn't load " + a + ". Status: " + Le.status);
                          return Le.response !== void 0 ? new Uint8Array(Le.response || []) : zt(Le.responseText || "", !0);
                        }, sn = this;
                        sn.setDataGetter(function(ct) {
                          var Yt = ct * et, Le = (ct + 1) * et - 1;
                          if (Le = Math.min(Le, z - 1), typeof sn.chunks[ct] > "u" && (sn.chunks[ct] = tt(Yt, Le)), typeof sn.chunks[ct] > "u")
                            throw new Error("doXHR failed!");
                          return sn.chunks[ct];
                        }), (Re || !z) && (et = z = 1, z = this.getter(0).length, et = z, oe("LazyFiles on gzip forces download of the whole file when length is accessed")), this._length = z, this._chunkSize = et, this.lengthKnown = !0;
                      }, Object.defineProperty(q.prototype, "length", {
                        get: function() {
                          return this.lengthKnown || this.cacheLength(), this._length;
                        },
                        enumerable: !1,
                        configurable: !0
                      }), Object.defineProperty(q.prototype, "chunkSize", {
                        get: function() {
                          return this.lengthKnown || this.cacheLength(), this._chunkSize;
                        },
                        enumerable: !1,
                        configurable: !0
                      }), q;
                    })()
                  );
                  if (typeof XMLHttpRequest < "u") {
                    if (!ke)
                      throw "Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc";
                    var S = new w(), I = { isDevice: !1, contents: S };
                  } else
                    var I = { isDevice: !1, url: a };
                  var D = u.createFile(t, r, I, l, E);
                  I.contents ? D.contents = I.contents : I.url && (D.contents = null, D.url = I.url), Object.defineProperties(D, { usedBytes: { get: function() {
                    return this.contents.length;
                  } } });
                  var U = {}, G = Object.keys(D.stream_ops);
                  G.forEach(function(q) {
                    var H = D.stream_ops[q];
                    U[q] = function() {
                      for (var z = [], ne = 0; ne < arguments.length; ne++)
                        z[ne] = arguments[ne];
                      return u.forceLoadFile(D), H.apply(void 0, z);
                    };
                  });
                  function Q(q, H, z, ne, be) {
                    var Re = q.node.contents;
                    if (be >= Re.length)
                      return 0;
                    var et = Math.min(Re.length - be, ne);
                    if (Re.slice)
                      for (var tt = 0; tt < et; tt++)
                        H[z + tt] = Re[be + tt];
                    else
                      for (var tt = 0; tt < et; tt++)
                        H[z + tt] = Re.get(be + tt);
                    return et;
                  }
                  return U.read = function(q, H, z, ne, be) {
                    return u.forceLoadFile(D), Q(q, H, z, ne, be);
                  }, U.mmap = function(q, H, z, ne, be) {
                    u.forceLoadFile(D);
                    var Re = on(H);
                    if (!Re)
                      throw new u.ErrnoError(48);
                    return Q(q, He, Re, H, z), { ptr: Re, allocated: !0 };
                  }, D.stream_ops = U, D;
                } }, Qn = function(t, r) {
                  return t ? mt(at, t, r) : "";
                }, me = { DEFAULT_POLLMASK: 5, calculateAt: function(t, r, a) {
                  if (ie.isAbs(r))
                    return r;
                  var l;
                  if (t === -100)
                    l = u.cwd();
                  else {
                    var E = me.getStreamFromFD(t);
                    l = E.path;
                  }
                  if (r.length == 0) {
                    if (!a)
                      throw new u.ErrnoError(44);
                    return l;
                  }
                  return l + "/" + r;
                }, writeStat: function(t, r) {
                  F[t >> 2] = r.dev, F[t + 4 >> 2] = r.mode, _e[t + 8 >> 2] = r.nlink, F[t + 12 >> 2] = r.uid, F[t + 16 >> 2] = r.gid, F[t + 20 >> 2] = r.rdev, Te = [r.size >>> 0, (W = r.size, +Math.abs(W) >= 1 ? W > 0 ? +Math.floor(W / 4294967296) >>> 0 : ~~+Math.ceil((W - +(~~W >>> 0)) / 4294967296) >>> 0 : 0)], F[t + 24 >> 2] = Te[0], F[t + 28 >> 2] = Te[1], F[t + 32 >> 2] = 4096, F[t + 36 >> 2] = r.blocks;
                  var a = r.atime.getTime(), l = r.mtime.getTime(), E = r.ctime.getTime();
                  return Te = [Math.floor(a / 1e3) >>> 0, (W = Math.floor(a / 1e3), +Math.abs(W) >= 1 ? W > 0 ? +Math.floor(W / 4294967296) >>> 0 : ~~+Math.ceil((W - +(~~W >>> 0)) / 4294967296) >>> 0 : 0)], F[t + 40 >> 2] = Te[0], F[t + 44 >> 2] = Te[1], _e[t + 48 >> 2] = a % 1e3 * 1e3 * 1e3, Te = [Math.floor(l / 1e3) >>> 0, (W = Math.floor(l / 1e3), +Math.abs(W) >= 1 ? W > 0 ? +Math.floor(W / 4294967296) >>> 0 : ~~+Math.ceil((W - +(~~W >>> 0)) / 4294967296) >>> 0 : 0)], F[t + 56 >> 2] = Te[0], F[t + 60 >> 2] = Te[1], _e[t + 64 >> 2] = l % 1e3 * 1e3 * 1e3, Te = [Math.floor(E / 1e3) >>> 0, (W = Math.floor(E / 1e3), +Math.abs(W) >= 1 ? W > 0 ? +Math.floor(W / 4294967296) >>> 0 : ~~+Math.ceil((W - +(~~W >>> 0)) / 4294967296) >>> 0 : 0)], F[t + 72 >> 2] = Te[0], F[t + 76 >> 2] = Te[1], _e[t + 80 >> 2] = E % 1e3 * 1e3 * 1e3, Te = [r.ino >>> 0, (W = r.ino, +Math.abs(W) >= 1 ? W > 0 ? +Math.floor(W / 4294967296) >>> 0 : ~~+Math.ceil((W - +(~~W >>> 0)) / 4294967296) >>> 0 : 0)], F[t + 88 >> 2] = Te[0], F[t + 92 >> 2] = Te[1], 0;
                }, writeStatFs: function(t, r) {
                  F[t + 4 >> 2] = r.bsize, F[t + 40 >> 2] = r.bsize, F[t + 8 >> 2] = r.blocks, F[t + 12 >> 2] = r.bfree, F[t + 16 >> 2] = r.bavail, F[t + 20 >> 2] = r.files, F[t + 24 >> 2] = r.ffree, F[t + 28 >> 2] = r.fsid, F[t + 44 >> 2] = r.flags, F[t + 36 >> 2] = r.namelen;
                }, doMsync: function(t, r, a, l, E) {
                  if (!u.isFile(r.node.mode))
                    throw new u.ErrnoError(43);
                  if (l & 2)
                    return 0;
                  var w = at.slice(t, t + a);
                  u.msync(r, w, E, a, l);
                }, getStreamFromFD: function(t) {
                  var r = u.getStreamChecked(t);
                  return r;
                }, varargs: void 0, getStr: function(t) {
                  var r = Qn(t);
                  return r;
                } }, an = function() {
                  var t = F[+me.varargs >> 2];
                  return me.varargs += 4, t;
                }, qr = an, he = { BUCKET_BUFFER_SIZE: 8192, mount: function(t) {
                  return u.createNode(null, "/", 16895, 0);
                }, createPipe: function() {
                  var t = { buckets: [], refcnt: 2, timestamp: /* @__PURE__ */ new Date() };
                  t.buckets.push({ buffer: new Uint8Array(he.BUCKET_BUFFER_SIZE), offset: 0, roffset: 0 });
                  var r = he.nextname(), a = he.nextname(), l = u.createNode(he.root, r, 4096, 0), E = u.createNode(he.root, a, 4096, 0);
                  l.pipe = t, E.pipe = t;
                  var w = u.createStream({ path: r, node: l, flags: 0, seekable: !1, stream_ops: he.stream_ops });
                  l.stream = w;
                  var S = u.createStream({ path: a, node: E, flags: 1, seekable: !1, stream_ops: he.stream_ops });
                  return E.stream = S, { readable_fd: w.fd, writable_fd: S.fd };
                }, stream_ops: { getattr: function(t) {
                  var r = t.node, a = r.pipe.timestamp;
                  return { dev: 14, ino: r.id, mode: 4480, nlink: 1, uid: 0, gid: 0, rdev: 0, size: 0, atime: a, mtime: a, ctime: a, blksize: 4096, blocks: 0 };
                }, poll: function(t) {
                  var r = t.node.pipe;
                  if ((t.flags & 2097155) === 1)
                    return 260;
                  for (var a = 0, l = r.buckets; a < l.length; a++) {
                    var E = l[a];
                    if (E.offset - E.roffset > 0)
                      return 65;
                  }
                  return 0;
                }, dup: function(t) {
                  t.node.pipe.refcnt++;
                }, ioctl: function(t, r, a) {
                  return 28;
                }, fsync: function(t) {
                  return 28;
                }, read: function(t, r, a, l, E) {
                  for (var w = t.node.pipe, S = 0, I = 0, D = w.buckets; I < D.length; I++) {
                    var U = D[I];
                    S += U.offset - U.roffset;
                  }
                  var G = r.subarray(a, a + l);
                  if (l <= 0)
                    return 0;
                  if (S == 0)
                    throw new u.ErrnoError(6);
                  for (var Q = Math.min(S, l), q = Q, H = 0, z = 0, ne = w.buckets; z < ne.length; z++) {
                    var U = ne[z], be = U.offset - U.roffset;
                    if (Q <= be) {
                      var Re = U.buffer.subarray(U.roffset, U.offset);
                      Q < be ? (Re = Re.subarray(0, Q), U.roffset += Q) : H++, G.set(Re);
                      break;
                    } else {
                      var Re = U.buffer.subarray(U.roffset, U.offset);
                      G.set(Re), G = G.subarray(Re.byteLength), Q -= Re.byteLength, H++;
                    }
                  }
                  return H && H == w.buckets.length && (H--, w.buckets[H].offset = 0, w.buckets[H].roffset = 0), w.buckets.splice(0, H), q;
                }, write: function(t, r, a, l, E) {
                  var w = t.node.pipe, S = r.subarray(a, a + l), I = S.byteLength;
                  if (I <= 0)
                    return 0;
                  var D = null;
                  w.buckets.length == 0 ? (D = { buffer: new Uint8Array(he.BUCKET_BUFFER_SIZE), offset: 0, roffset: 0 }, w.buckets.push(D)) : D = w.buckets[w.buckets.length - 1], A(D.offset <= he.BUCKET_BUFFER_SIZE);
                  var U = he.BUCKET_BUFFER_SIZE - D.offset;
                  if (U >= I)
                    return D.buffer.set(S, D.offset), D.offset += I, I;
                  U > 0 && (D.buffer.set(S.subarray(0, U), D.offset), D.offset += U, S = S.subarray(U, S.byteLength));
                  for (var G = S.byteLength / he.BUCKET_BUFFER_SIZE | 0, Q = S.byteLength % he.BUCKET_BUFFER_SIZE, q = 0; q < G; q++) {
                    var H = { buffer: new Uint8Array(he.BUCKET_BUFFER_SIZE), offset: he.BUCKET_BUFFER_SIZE, roffset: 0 };
                    w.buckets.push(H), H.buffer.set(S.subarray(0, he.BUCKET_BUFFER_SIZE)), S = S.subarray(he.BUCKET_BUFFER_SIZE, S.byteLength);
                  }
                  if (Q > 0) {
                    var H = { buffer: new Uint8Array(he.BUCKET_BUFFER_SIZE), offset: S.byteLength, roffset: 0 };
                    w.buckets.push(H), H.buffer.set(S);
                  }
                  return I;
                }, close: function(t) {
                  var r = t.node.pipe;
                  r.refcnt--, r.refcnt === 0 && (r.buckets = null);
                } }, nextname: function() {
                  return he.nextname.current || (he.nextname.current = 0), "pipe[" + he.nextname.current++ + "]";
                } }, Jr = function() {
                  return b("");
                }, Qr = function(t) {
                  return t % 4 === 0 && (t % 100 !== 0 || t % 400 === 0);
                }, $r = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335], eo = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334], $n = function(t) {
                  var r = Qr(t.getFullYear()), a = r ? $r : eo, l = a[t.getMonth()] + t.getDate() - 1;
                  return l;
                }, er = function(t, r) {
                  return r + 2097152 >>> 0 < 4194305 - !!t ? (t >>> 0) + r * 4294967296 : NaN;
                }, tr = function(t) {
                  return vo(t);
                }, to = function(t) {
                  var r = (function() {
                    var a = new Date(F[t + 20 >> 2] + 1900, F[t + 16 >> 2], F[t + 12 >> 2], F[t + 8 >> 2], F[t + 4 >> 2], F[t >> 2], 0), l = F[t + 32 >> 2], E = a.getTimezoneOffset(), w = new Date(a.getFullYear(), 0, 1), S = new Date(a.getFullYear(), 6, 1).getTimezoneOffset(), I = w.getTimezoneOffset(), D = Math.min(I, S);
                    if (l < 0)
                      F[t + 32 >> 2] = +(S != I && D == E);
                    else if (l > 0 != (D == E)) {
                      var U = Math.max(I, S), G = l > 0 ? D : U;
                      a.setTime(a.getTime() + (G - E) * 6e4);
                    }
                    F[t + 24 >> 2] = a.getDay();
                    var Q = $n(a) | 0;
                    F[t + 28 >> 2] = Q, F[t >> 2] = a.getSeconds(), F[t + 4 >> 2] = a.getMinutes(), F[t + 8 >> 2] = a.getHours(), F[t + 12 >> 2] = a.getDate(), F[t + 16 >> 2] = a.getMonth(), F[t + 20 >> 2] = a.getYear();
                    var q = a.getTime();
                    return isNaN(q) ? -1 : q / 1e3;
                  })();
                  return tr((W = r, +Math.abs(W) >= 1 ? W > 0 ? +Math.floor(W / 4294967296) >>> 0 : ~~+Math.ceil((W - +(~~W >>> 0)) / 4294967296) >>> 0 : 0)), r >>> 0;
                }, no = function(t) {
                  var r = (function() {
                    var a = Date.UTC(F[t + 20 >> 2] + 1900, F[t + 16 >> 2], F[t + 12 >> 2], F[t + 8 >> 2], F[t + 4 >> 2], F[t >> 2], 0), l = new Date(a);
                    F[t + 24 >> 2] = l.getUTCDay();
                    var E = Date.UTC(l.getUTCFullYear(), 0, 1, 0, 0, 0, 0), w = (l.getTime() - E) / (1e3 * 60 * 60 * 24) | 0;
                    return F[t + 28 >> 2] = w, l.getTime() / 1e3;
                  })();
                  return tr((W = r, +Math.abs(W) >= 1 ? W > 0 ? +Math.floor(W / 4294967296) >>> 0 : ~~+Math.ceil((W - +(~~W >>> 0)) / 4294967296) >>> 0 : 0)), r >>> 0;
                }, Wt = function(t, r, a) {
                  return $e(t, at, r, a);
                }, ro = function(t, r, a, l) {
                  var E = (/* @__PURE__ */ new Date()).getFullYear(), w = new Date(E, 0, 1), S = new Date(E, 6, 1), I = w.getTimezoneOffset(), D = S.getTimezoneOffset(), U = Math.max(I, D);
                  _e[t >> 2] = U * 60, F[r >> 2] = +(I != D);
                  var G = function(H) {
                    var z = H >= 0 ? "-" : "+", ne = Math.abs(H), be = String(Math.floor(ne / 60)).padStart(2, "0"), Re = String(ne % 60).padStart(2, "0");
                    return "UTC".concat(z).concat(be).concat(Re);
                  }, Q = G(I), q = G(D);
                  D < I ? (Wt(Q, a, 17), Wt(q, l, 17)) : (Wt(Q, l, 17), Wt(q, a, 17));
                }, oo = function() {
                  return 2147483648;
                }, io = function(t) {
                  var r = Oe.buffer, a = (t - r.byteLength + 65535) / 65536 | 0;
                  try {
                    return Oe.grow(a), h(), 1;
                  } catch {
                  }
                }, ao = function(t) {
                  var r = at.length;
                  t >>>= 0;
                  var a = oo();
                  if (t > a)
                    return !1;
                  for (var l = 1; l <= 4; l *= 2) {
                    var E = r * (1 + 0.2 / l);
                    E = Math.min(E, t + 100663296);
                    var w = Math.min(a, rn(Math.max(t, E), 65536)), S = io(w);
                    if (S)
                      return !0;
                  }
                  return !1;
                }, bn = {}, so = function() {
                  return ot || "./this.program";
                }, Gt = function() {
                  if (!Gt.strings) {
                    var t = (typeof navigator == "object" && navigator.languages && navigator.languages[0] || "C").replace("-", "_") + ".UTF-8", r = { USER: "web_user", LOGNAME: "web_user", PATH: "/", PWD: "/", HOME: "/home/web_user", LANG: t, _: so() };
                    for (var a in bn)
                      bn[a] === void 0 ? delete r[a] : r[a] = bn[a];
                    var l = [];
                    for (var a in r)
                      l.push("".concat(a, "=").concat(r[a]));
                    Gt.strings = l;
                  }
                  return Gt.strings;
                }, co = function(t, r) {
                  for (var a = 0; a < t.length; ++a)
                    He[r++] = t.charCodeAt(a);
                  He[r] = 0;
                }, uo = function(t, r) {
                  var a = 0;
                  return Gt().forEach(function(l, E) {
                    var w = r + a;
                    _e[t + E * 4 >> 2] = w, co(l, w), a += l.length + 1;
                  }), 0;
                }, fo = function(t, r) {
                  var a = Gt();
                  _e[t >> 2] = a.length;
                  var l = 0;
                  return a.forEach(function(E) {
                    return l += E.length + 1;
                  }), _e[r >> 2] = l, 0;
                }, lo = 0, Eo = function() {
                  return tn || lo > 0;
                }, ho = function(t) {
                  var r;
                  Eo() || ((r = O.onExit) === null || r === void 0 || r.call(O, t), it = !0), Et(t, new yn(t));
                }, po = function(t, r) {
                  ho(t);
                }, _o = po, mo = function(t, r, a, l) {
                  for (var E = 0, w = 0; w < a; w++) {
                    var S = _e[r >> 2], I = _e[r + 4 >> 2];
                    r += 8;
                    var D = u.read(t, He, S, I, l);
                    if (D < 0)
                      return -1;
                    if (E += D, D < I)
                      break;
                    typeof l < "u" && (l += D);
                  }
                  return E;
                }, wo = function(t, r, a, l) {
                  for (var E = 0, w = 0; w < a; w++) {
                    var S = _e[r >> 2], I = _e[r + 4 >> 2];
                    r += 8;
                    var D = u.write(t, He, S, I, l);
                    if (D < 0)
                      return -1;
                    if (E += D, D < I)
                      break;
                    typeof l < "u" && (l += D);
                  }
                  return E;
                }, nr = function(t) {
                  var r = O["_" + t];
                  return r;
                }, go = function(t, r) {
                  He.set(t, r);
                }, rr = function(t) {
                  return So(t);
                }, yo = function(t) {
                  var r = Ht(t) + 1, a = rr(r);
                  return Wt(t, a, r), a;
                }, Ao = function(t, r, a, l, E) {
                  var w = { string: function(z) {
                    var ne = 0;
                    return z != null && z !== 0 && (ne = yo(z)), ne;
                  }, array: function(z) {
                    var ne = rr(z.length);
                    return go(z, ne), ne;
                  } };
                  function S(z) {
                    return r === "string" ? Qn(z) : r === "boolean" ? !!z : z;
                  }
                  var I = nr(t), D = [], U = 0;
                  if (l)
                    for (var G = 0; G < l.length; G++) {
                      var Q = w[a[G]];
                      Q ? (U === 0 && (U = An()), D[G] = Q(l[G])) : D[G] = l[G];
                    }
                  var q = I.apply(void 0, D);
                  function H(z) {
                    return U !== 0 && _t(U), S(z);
                  }
                  return q = H(q), q;
                }, Ro = function(t, r, a, l) {
                  var E = !a || a.every(function(S) {
                    return S === "number" || S === "boolean";
                  }), w = r !== "string";
                  return w && E && !l ? nr(t) : function() {
                    for (var S = [], I = 0; I < arguments.length; I++)
                      S[I] = arguments[I];
                    return Ao(t, r, a, S, l);
                  };
                }, u.createPreloadedFile = Vr, u.staticInit(), K.doesNotExistError = new u.ErrnoError(44), K.doesNotExistError.stack = "<generic error, no stack>", To = { h: Ee, a: Se, v: Ne, s: De, t: Ue, e: Ge, q: Ye, p: xe, u: re, i: Jr, k: ue, l: to, m: no, r: ro, o: ao, f: uo, g: fo, d: _o, c: le, j: Tt, n: Ot, b: qe }, [4, se()];
              case 1:
                if (ee = M.sent(), ee.x, O._archive_read_new_memory = ee.y, O._archive_read_new = ee.z, O._archive_read_support_filter_all = ee.A, O._archive_read_support_format_all = ee.B, O._archive_read_add_passphrase = ee.C, O._archive_read_open_memory = ee.D, O._archive_read_next_entry = ee.E, O._archive_entry_atime = ee.G, O._archive_entry_birthtime = ee.H, O._archive_entry_ctime = ee.I, O._archive_entry_filetype = ee.J, O._archive_entry_hardlink_utf8 = ee.K, O._archive_entry_mtime = ee.L, O._archive_entry_pathname_utf8 = ee.M, O._archive_entry_size = ee.N, O._archive_entry_symlink_utf8 = ee.O, O._archive_entry_is_encrypted = ee.P, O._free = ee.Q, O._malloc = ee.R, O._archive_read_has_encrypted_entries = ee.S, O._archive_read_data = ee.T, O._archive_read_data_skip = ee.U, O._archive_version_number = ee.V, O._archive_version_string = ee.W, O._archive_error_string = ee.X, O._archive_version_details = ee.Y, O._archive_read_free = ee.Z, vo = ee._, bo = ee.$, So = ee.aa, Io = ee.ba, O.cwrap = Ro, O.preInit)
                  for (typeof O.preInit == "function" && (O.preInit = [O.preInit]); O.preInit.length > 0; )
                    O.preInit.pop()();
                return rt(), lt = bt, [2, lt];
            }
          });
        });
      });
    })();
    n.exports = c, n.exports.default = c;
  })(Un)), Un.exports;
}
var ut = {}, On = {}, vi;
function us() {
  if (vi) return On;
  vi = 1, Object.defineProperty(On, "__esModule", { value: !0 }), On.wrapLibarchiveWasm = n;
  function n(e) {
    var o = function(s, f) {
      return function() {
        for (var d = [], p = 0; p < arguments.length; p++)
          d[p] = arguments[p];
        var _ = s.apply(void 0, d);
        if (f(_))
          throw new Error(this.error_string(d[0]));
        return _;
      };
    }, i = function(s) {
      return s !== 0;
    };
    return {
      module: e,
      version_number: e.cwrap("archive_version_number", "number", []),
      version_string: e.cwrap("archive_version_string", "string", []),
      version_details: e.cwrap("archive_version_details", "string", []),
      read_new_memory: o(e.cwrap("archive_read_new_memory", "number", [
        "number",
        "number",
        "string"
      ]), function(s) {
        return s === 0;
      }),
      read_new: e.cwrap("archive_read_new", "number", []),
      read_support_filter_all: o(e.cwrap("archive_read_support_filter_all", "number", ["number"]), i),
      read_support_format_all: o(e.cwrap("archive_read_support_format_all", "number", ["number"]), i),
      read_open_memory: o(e.cwrap("archive_read_open_memory", "number", ["number", "number", "number"]), i),
      read_next_entry: e.cwrap("archive_read_next_entry", "number", ["number"]),
      read_has_encrypted_entries: e.cwrap("archive_read_has_encrypted_entries", "number", [
        "number"
      ]),
      read_data: o(e.cwrap("archive_read_data", "number", ["number", "number", "number"]), function(s) {
        return s < 0;
      }),
      read_data_skip: o(e.cwrap("archive_read_data_skip", "number", ["number"]), i),
      read_add_passphrase: o(e.cwrap("archive_read_add_passphrase", "number", ["number", "string"]), i),
      read_free: o(e.cwrap("archive_read_free", "number", ["number"]), i),
      error_string: e.cwrap("archive_error_string", "string", ["number"]),
      entry_filetype: e.cwrap("archive_entry_filetype", "number", ["number"]),
      entry_pathname: e.cwrap("archive_entry_pathname_utf8", "string", ["number"]),
      entry_symlink: e.cwrap("archive_entry_symlink_utf8", "string", ["number"]),
      entry_hardlink: e.cwrap("archive_entry_hardlink_utf8", "string", ["number"]),
      entry_size: e.cwrap("archive_entry_size", "number", ["number"]),
      entry_atime: e.cwrap("archive_entry_atime", "number", ["number"]),
      entry_birthtime: e.cwrap("archive_entry_birthtime", "number", ["number"]),
      entry_ctime: e.cwrap("archive_entry_ctime", "number", ["number"]),
      entry_mtime: e.cwrap("archive_entry_mtime", "number", ["number"]),
      entry_is_encrypted: e.cwrap("archive_entry_is_encrypted", "number", ["number"])
    };
  }
  return On;
}
var bi;
function ld() {
  if (bi) return ut;
  bi = 1;
  var n = ut && ut.__awaiter || function(c, d, p, _) {
    function T(A) {
      return A instanceof p ? A : new p(function(h) {
        h(A);
      });
    }
    return new (p || (p = Promise))(function(A, h) {
      function y(v) {
        try {
          m(_.next(v));
        } catch (g) {
          h(g);
        }
      }
      function R(v) {
        try {
          m(_.throw(v));
        } catch (g) {
          h(g);
        }
      }
      function m(v) {
        v.done ? A(v.value) : T(v.value).then(y, R);
      }
      m((_ = _.apply(c, d || [])).next());
    });
  }, e = ut && ut.__generator || function(c, d) {
    var p = { label: 0, sent: function() {
      if (A[0] & 1) throw A[1];
      return A[1];
    }, trys: [], ops: [] }, _, T, A, h = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
    return h.next = y(0), h.throw = y(1), h.return = y(2), typeof Symbol == "function" && (h[Symbol.iterator] = function() {
      return this;
    }), h;
    function y(m) {
      return function(v) {
        return R([m, v]);
      };
    }
    function R(m) {
      if (_) throw new TypeError("Generator is already executing.");
      for (; h && (h = 0, m[0] && (p = 0)), p; ) try {
        if (_ = 1, T && (A = m[0] & 2 ? T.return : m[0] ? T.throw || ((A = T.return) && A.call(T), 0) : T.next) && !(A = A.call(T, m[1])).done) return A;
        switch (T = 0, A && (m = [m[0] & 2, A.value]), m[0]) {
          case 0:
          case 1:
            A = m;
            break;
          case 4:
            return p.label++, { value: m[1], done: !1 };
          case 5:
            p.label++, T = m[1], m = [0];
            continue;
          case 7:
            m = p.ops.pop(), p.trys.pop();
            continue;
          default:
            if (A = p.trys, !(A = A.length > 0 && A[A.length - 1]) && (m[0] === 6 || m[0] === 2)) {
              p = 0;
              continue;
            }
            if (m[0] === 3 && (!A || m[1] > A[0] && m[1] < A[3])) {
              p.label = m[1];
              break;
            }
            if (m[0] === 6 && p.label < A[1]) {
              p.label = A[1], A = m;
              break;
            }
            if (A && p.label < A[2]) {
              p.label = A[2], p.ops.push(m);
              break;
            }
            A[2] && p.ops.pop(), p.trys.pop();
            continue;
        }
        m = d.call(c, p);
      } catch (v) {
        m = [6, v], T = 0;
      } finally {
        _ = A = 0;
      }
      if (m[0] & 5) throw m[1];
      return { value: m[0] ? m[1] : void 0, done: !0 };
    }
  }, o = ut && ut.__importDefault || function(c) {
    return c && c.__esModule ? c : { default: c };
  };
  Object.defineProperty(ut, "__esModule", { value: !0 }), ut.libarchiveWasm = f;
  var i = o(cs()), s = us();
  function f() {
    for (var c = [], d = 0; d < arguments.length; d++)
      c[d] = arguments[d];
    return n(this, void 0, void 0, function() {
      return e(this, function(p) {
        return [2, i.default.apply(void 0, c).then(function(_) {
          return (0, s.wrapLibarchiveWasm)(_);
        })];
      });
    });
  }
  return ut;
}
var Si;
function dd() {
  return Si || (Si = 1, (function(n) {
    var e = gt && gt.__createBinding || (Object.create ? (function(f, c, d, p) {
      p === void 0 && (p = d);
      var _ = Object.getOwnPropertyDescriptor(c, d);
      (!_ || ("get" in _ ? !c.__esModule : _.writable || _.configurable)) && (_ = { enumerable: !0, get: function() {
        return c[d];
      } }), Object.defineProperty(f, p, _);
    }) : (function(f, c, d, p) {
      p === void 0 && (p = d), f[p] = c[d];
    })), o = gt && gt.__exportStar || function(f, c) {
      for (var d in f) d !== "default" && !Object.prototype.hasOwnProperty.call(c, d) && e(c, f, d);
    }, i = gt && gt.__importDefault || function(f) {
      return f && f.__esModule ? f : { default: f };
    };
    Object.defineProperty(n, "__esModule", { value: !0 }), n.libarchive = void 0, o(cd(), n);
    var s = cs();
    Object.defineProperty(n, "libarchive", { enumerable: !0, get: function() {
      return i(s).default;
    } }), o(ld(), n), o(us(), n);
  })(gt)), gt;
}
var Ii = dd();
const Ed = ["https://kemono.cr", "https://pawchive.pw"];
Ed.map((n) => `img.${new URL(n).hostname}`);
function Ni(n, e = "unnamed") {
  let o = (n || e).normalize("NFKC").replace(/[<>:"/\\|?*\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "_").replace(/^[. ]+|[. ]+$/g, "").slice(0, 40).trim().replace(/[. ]+$/g, "");
  return (!o || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(o)) && (o = "_" + (o || e)), o;
}
function hd(n) {
  const e = n.replaceAll("\\", "/");
  if (!e || e.startsWith("/") || /^[a-z]:/i.test(e) || /[\x00-\x1f]/.test(e)) throw new Error("Archive contains an unsafe file path.");
  const o = e.split("/");
  for (; o[0] === "."; ) o.shift();
  if (!o.length || o.some((i) => !i || i === "." || i === ".." || i.includes(":"))) throw new Error("Archive contains an unsafe file path.");
  return o.map((i, s) => {
    const f = s === o.length - 1 ? /\.[a-z0-9_-]{1,64}$/i.exec(i)?.[0] : void 0;
    return f ? Ni(i.slice(0, -f.length), "file") + f : Ni(i, "file");
  }).join("/");
}
async function pd(n, e, o, i, s) {
  let f = 0, c = 0;
  const d = /* @__PURE__ */ new Set(), p = (_, T) => {
    const A = hd(_);
    if (!Number.isSafeInteger(T) || T < 0 || ++f > 1e4 || (c += T) > 8 * 1024 ** 3) throw new Error("Archive extraction exceeds supported file count or size.");
    if (d.has(A.toLowerCase())) throw new Error("Archive contains duplicate file paths.");
    return d.add(A.toLowerCase()), A;
  };
  if (/\.zipx?$/i.test(e)) {
    const _ = new hl(new Hr(n), { useWebWorkers: !1 });
    try {
      for await (const T of _.getEntriesGenerator()) {
        if (T.directory) continue;
        if (T.encrypted) throw new Error("Archive is password protected. The original was kept.");
        if (((T.unixMode || 0) & 61440) === 40960) throw new Error("Archive contains a symbolic link.");
        const A = p(T.filename, T.uncompressedSize);
        await i({ path: A, size: T.uncompressedSize, write: async (h) => {
          await T.getData(h, { checkSignature: !0, preventClose: !0, onprogress: s });
        } }), s();
      }
    } finally {
      await _.close();
    }
  } else {
    if (n.size > 512 * 1024 ** 2) throw new Error("This archive exceeds the 512 MiB in-browser decoder input limit. The original was kept.");
    const _ = await Ii.libarchiveWasm({ locateFile: () => o }), T = new Ii.ArchiveReader(_, new Int8Array(await n.arrayBuffer()));
    try {
      for (const h of T.entries()) {
        if (h.getFiletype() === "Directory") continue;
        if (h.getFiletype() !== "File" || h.getHardlinkTarget() || h.getSymlinkTarget()) throw new Error("Archive contains a link or unsupported special file.");
        if (h.isEncrypted()) throw new Error("Archive is password protected. The original was kept.");
        const y = h.getSize(), R = p(h.getPathname(), y);
        await i({ path: R, size: y, write: async (m) => {
          const v = m.getWriter();
          let g = 0;
          try {
            for (; ; ) {
              const b = T.readData(1048576);
              if (!b.length) break;
              if (g += b.length, g > y) throw new Error("Archive entry exceeds its declared size.");
              await v.write(new Uint8Array(b.buffer, b.byteOffset, b.byteLength)), s();
            }
            if (g !== y) throw new Error("Archive entry is truncated.");
          } finally {
            v.releaseLock();
          }
        } }), s();
      }
      if (_.error_string(T.archive)) throw new Error("Archive decoder reported incomplete or unsupported data.");
    } finally {
      T.free();
    }
  }
  if (!f) throw new Error("Archive contains no regular files. The original was kept.");
}
async function _d(n) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", await n.arrayBuffer()))].map((e) => e.toString(16).padStart(2, "0")).join("");
}
Promise.resolve();
const dr = /* @__PURE__ */ new Map(), md = ".last-used";
async function wd(n, e = !1) {
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(n)) throw new Error("Invalid ZIP cache ID");
  const s = await (await (await navigator.storage.getDirectory()).getDirectoryHandle("kemono-zip-jobs", { create: e })).getDirectoryHandle(n, { create: e }), f = Date.now();
  if (!dr.has(n) || f - dr.get(n) >= 15 * 1e3) {
    const c = await (await s.getFileHandle(md, { create: !0 })).createWritable();
    try {
      await c.write(String(f)), await c.close(), dr.set(n, f);
    } catch (d) {
      throw await c.abort().catch(() => {
      }), d;
    }
  }
  return s;
}
async function gd(n) {
  return _d(new Blob([n]));
}
async function yd(n, e, o) {
  const i = await wd(n, !0), s = await i.getFileHandle(await gd(e), { create: !0 }), f = await s.createWritable();
  try {
    return await o(f), await f.close(), await s.getFile();
  } catch (c) {
    throw await f.abort().catch(() => {
    }), c;
  }
}
self.onmessage = async (n) => {
  const { jobId: e, id: o, file: i, name: s, prefix: f, wasmUrl: c } = n.data, d = [];
  try {
    await pd(i, s, c, async (p) => {
      const _ = `${o}:extract:${d.length + 1}`, T = await yd(e, _, p.write);
      if (T.size !== p.size) throw new Error("Extracted file is incomplete.");
      const A = { id: _, path: f + p.path, bytes: T.size };
      d.push(A), self.postMessage({ type: "file", file: A });
    }, () => self.postMessage({ type: "progress" })), self.postMessage({ type: "done", files: d });
  } catch (p) {
    self.postMessage({ type: "done", files: d, error: p instanceof Error ? p.message : "Archive extraction failed. The original was kept." });
  }
};
