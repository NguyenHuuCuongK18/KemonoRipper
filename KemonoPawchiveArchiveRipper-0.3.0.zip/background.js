const z = ["https://kemono.cr", "https://pawchive.pw"], Te = z.map((t) => `img.${new URL(t).hostname}`);
function Pt(t) {
  try {
    const e = new URL(t), n = /^\/discord\/server\/(\d+)(?:\/(\d+))?\/?$/.exec(e.pathname);
    return !z.includes(e.origin) || e.username || e.password || !n ? null : { serverId: n[1], channelId: n[2] || null, serverName: null, channelName: null };
  } catch {
    return null;
  }
}
function fe(t) {
  const e = Pt(t);
  return e?.channelId ? { ...e, channelId: e.channelId } : null;
}
function W(t) {
  if (typeof t != "string" || !/^\d+$/.test(t)) throw new Error("Expected a Discord ID encoded as a string");
  return t;
}
const Xn = /^\/([0-9a-f]{2})\/([0-9a-f]{2})\/([0-9a-f]{64})\.(png|jpe?g|webp|gif|avif)$/i;
function Dt(t) {
  if (typeof t != "string") return null;
  const e = Xn.exec(t);
  return e ? { path: t, hash: e[3].toLowerCase() } : null;
}
function Vn(t, e = z[0]) {
  const n = Dt(t);
  return n && z.includes(e) ? `https://img.${new URL(e).hostname}/thumbnail/data${n.path}` : null;
}
function j(t) {
  if (typeof t != "string") return null;
  try {
    const e = new URL(t);
    if (e.protocol !== "https:" || e.username || e.password || e.port) return null;
    const n = e.hostname;
    return Te.includes(n) && e.pathname.startsWith("/thumbnail/data/") && Dt(e.pathname.slice(15)) || (z.includes(e.origin) || n === "file.pawchive.pw" || /^n[1-4]\.(?:kemono\.cr|pawchive\.pw)$/.test(n)) && e.pathname.startsWith("/data/") && Dt(e.pathname.slice(5)) || (n === "cdn.discordapp.com" || n === "media.discordapp.net") && /^\/attachments\/\d+\/\d+\/[^/]+\.(png|jpe?g|webp|gif|avif)$/i.test(e.pathname) ? (e.hash = "", e.href) : null;
  } catch {
    return null;
  }
}
class T extends Error {
  constructor(e, n, r = 0) {
    super(e), this.status = n, this.retryAfterMs = r, this.name = "RequestError";
  }
  status;
  retryAfterMs;
  get retryable() {
    return this.status === 0 || this.status === 429 || this.status >= 500;
  }
}
function Gn(t, e = Date.now()) {
  if (!t) return 0;
  const n = Number(t);
  return Math.max(0, Number.isFinite(n) ? n * 1e3 : Date.parse(t) - e || 0);
}
class Le {
  constructor(e = (n, r) => fetch(n, r)) {
    this.transport = e;
  }
  transport;
  async json(e, n = z[0]) {
    if (!z.includes(n)) throw new Error("Unsupported archive origin");
    let r;
    try {
      r = await this.transport(`${n}/api/v1${e}`, {
        headers: { Accept: "text/css" },
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(2e4)
      });
    } catch {
      throw new T("API network request failed or timed out. Open the channel to check site access.", 0);
    }
    if (!r.ok) {
      const a = r.status === 403 ? " Access denied; the required Accept: text/css header was sent. Check access in the site tab." : "";
      throw new T(`API HTTP ${r.status}.${a}`, r.status, Gn(r.headers.get("retry-after")));
    }
    try {
      return JSON.parse(await r.text());
    } catch {
      throw new T("API returned invalid JSON; this page is incomplete.", 422);
    }
  }
  async channel(e, n, r = z[0]) {
    if (W(e), !Number.isSafeInteger(n) || n < 0) throw new Error("Invalid page offset");
    const a = await this.json(`/discord/channel/${e}?o=${n}`, r);
    if (!Array.isArray(a)) throw new T("Channel response is not an array", 422);
    for (const s of a) {
      if (!s || typeof s != "object") throw new T("Invalid message object", 422);
      if (W(s.id), s.channel !== void 0 && W(s.channel) !== e) throw new T("Channel response contains a different channel", 422);
      if (s.server !== void 0 && W(s.server), s.attachments != null && (!Array.isArray(s.attachments) || s.attachments.some((i) => !i || typeof i != "object" || Array.isArray(i)))) throw new T("Invalid attachment list", 422);
    }
    return a;
  }
  async server(e, n = z[0]) {
    W(e);
    const r = await this.json(`/discord/server/${e}`, n);
    if (!r || W(r.id) !== e || !Array.isArray(r.channels)) throw new T("Invalid server metadata", 422);
    return {
      id: e,
      name: typeof r.name == "string" ? r.name : e,
      channels: r.channels.map((a) => ({
        id: W(a.id),
        name: typeof a.name == "string" ? a.name : a.id,
        parentId: typeof a.parent_channel_id == "string" ? W(a.parent_channel_id) : null,
        type: typeof a.type == "number" ? a.type : null,
        postCount: Number.isSafeInteger(a.post_count) && a.post_count >= 0 ? a.post_count : null
      }))
    };
  }
}
function Kn(t, e, n) {
  const r = /* @__PURE__ */ new Map();
  for (const s of e?.channels || []) r.set(s.id, { ...s, sources: ["api"] });
  let a = e?.name || null;
  for (const s of n)
    if (s.serverId === t) {
      a ||= typeof s.serverName == "string" ? s.serverName : null;
      for (const i of s.channels) {
        try {
          W(i.id);
        } catch {
          continue;
        }
        const o = r.get(i.id);
        o ? o.sources = [.../* @__PURE__ */ new Set([...o.sources || [], "dom"])] : r.set(i.id, { id: i.id, name: typeof i.name == "string" ? i.name : i.id, parentId: null, type: null, postCount: null, sources: ["dom"] });
      }
    }
  return e || r.size ? { id: t, name: a || t, channels: [...r.values()] } : null;
}
function se(t) {
  let e = 0xcbf29ce484222325n;
  for (const n of t) e = BigInt.asUintN(64, (e ^ BigInt(n.codePointAt(0))) * 0x100000001b3n);
  return e.toString(16).padStart(16, "0");
}
function Jn(t) {
  if (typeof t != "string") return null;
  const e = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$/.exec(t);
  if (!e) return null;
  const [, n, r, a, s, i, o, f, h] = e, m = Number(n), y = Number(r), l = Number(a);
  if (y < 1 || y > 12 || l < 1 || l > new Date(Date.UTC(m, y, 0)).getUTCDate() || Number(s) > 23 || Number(i) > 59 || Number(o) > 59) return null;
  const d = `${n}-${r}-${a}T${s}:${i}:${o}.${(f || "").padEnd(3, "0").slice(0, 3)}${h || "Z"}`, g = Date.parse(d);
  return Number.isFinite(g) ? new Date(g).toISOString() : null;
}
function pe(t, e, n, r, a) {
  return {
    ...t,
    jobId: e,
    id: `${t.serverId}:${t.channelId}:${n || "dom"}:${r}:${se(a)}`,
    messageId: n,
    attachmentIndex: r,
    attachmentId: null,
    publishedRaw: null,
    publishedAtUtc: null,
    originalFilename: null,
    kemonoPath: null,
    kemonoFileHash: null,
    originalUrl: null,
    discordCdnUrl: null,
    thumbnailUrl: null,
    resolvedUrl: null,
    mediaType: "unknown",
    sourceType: "api",
    provenance: [],
    warnings: [],
    status: "discovered",
    savedPath: null,
    errorMessage: null,
    attempts: 0,
    nextAttemptAt: 0,
    downloadId: null,
    blobUrl: null,
    quality: null,
    bytes: null,
    sha256: null,
    mime: null,
    width: null,
    height: null,
    candidateFailures: []
  };
}
function Qn(t, e, n, r = z[0]) {
  const a = [];
  for (const s of t) {
    if (s.server && s.server !== e.serverId) throw new Error("Message belongs to a different server");
    const i = (m) => (m.publishedRaw = typeof s.published == "string" ? s.published : null, m.publishedAtUtc = Jn(m.publishedRaw), m.provenance = ["api"], m.publishedAtUtc ? /(Z|[+-]\d\d:\d\d)$/.test(m.publishedRaw) || m.warnings.push("Archive timestamp has no timezone; interpreted as UTC") : m.warnings.push("Missing or invalid publication timestamp"), m), o = s.attachments || [];
    o.forEach((m, y) => {
      const l = typeof m.path == "string" ? m.path : null, d = i(pe(e, n, s.id, y + 1, l || m.name || `attachment-${y}`));
      d.originalFilename = typeof m.name == "string" ? m.name : null;
      const g = Dt(l);
      g ? (d.kemonoPath = g.path, d.kemonoFileHash = g.hash, d.thumbnailUrl = Vn(g.path, r), d.mediaType = "image") : (d.discordCdnUrl = j(l), d.discordCdnUrl?.includes("discordapp.") ? d.mediaType = "image" : (d.discordCdnUrl = null, d.warnings.push("Unsupported attachment path; needs an observed image URL"))), a.push(d);
    });
    const f = typeof s.content == "string" ? s.content.match(/https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\/[^\s<>"')]+/g) || [] : [];
    [...new Set(f.map(j).filter((m) => !!m))].forEach((m, y) => {
      const l = i(pe(e, n, s.id, o.length + y + 1, m));
      l.discordCdnUrl = m, l.mediaType = "image", l.originalFilename = new URL(m).pathname.split("/").at(-1);
      try {
        l.originalFilename = decodeURIComponent(l.originalFilename);
      } catch {
      }
      l.provenance.push("inline-content"), a.push(l);
    });
  }
  return a;
}
function ze(t, e) {
  const n = new Map(t.map((r) => [r.id, r]));
  for (const r of e) {
    let a = n.get(r.id);
    if (!a && r.messageId) {
      const o = [...n.values()].filter((f) => (f.sourceType === "dom" || r.sourceType === "dom") && f.sourceType !== r.sourceType && f.serverId === r.serverId && f.channelId === r.channelId && f.messageId === r.messageId && (f.kemonoPath && f.kemonoPath === r.kemonoPath || f.discordCdnUrl && f.discordCdnUrl === r.discordCdnUrl));
      a = o.find((f) => f.attachmentIndex === r.attachmentIndex) || (o.length === 1 ? o[0] : void 0);
    }
    if (!a) {
      n.set(r.id, r);
      continue;
    }
    const s = r.sourceType === "api" && a.sourceType === "dom" ? r : a, i = {
      ...a,
      id: s.id,
      attachmentIndex: s.attachmentIndex,
      publishedRaw: s.publishedRaw || a.publishedRaw || r.publishedRaw,
      publishedAtUtc: s.publishedAtUtc || a.publishedAtUtc || r.publishedAtUtc,
      originalFilename: s.originalFilename || a.originalFilename || r.originalFilename,
      kemonoPath: a.kemonoPath || r.kemonoPath,
      kemonoFileHash: a.kemonoFileHash || r.kemonoFileHash,
      thumbnailUrl: a.thumbnailUrl || r.thumbnailUrl,
      originalUrl: a.originalUrl || r.originalUrl,
      discordCdnUrl: a.discordCdnUrl || r.discordCdnUrl,
      mediaType: a.mediaType === "unknown" ? r.mediaType : a.mediaType,
      sourceType: a.sourceType === r.sourceType ? a.sourceType : "merged",
      provenance: [.../* @__PURE__ */ new Set([...a.provenance, ...r.provenance])],
      warnings: [.../* @__PURE__ */ new Set([...a.warnings, ...r.warnings])]
    };
    n.delete(a.id), n.set(i.id, i);
  }
  return [...n.values()];
}
const jn = 150;
function _n(t, e) {
  const n = structuredClone(t);
  if (n.attempts = 0, n.nextAttemptAt = 0, n.error = null, !e.length)
    return n.pages++, n.coverage = "complete", n.terminal = "empty-page", n;
  const r = se(e.map((a) => a.id).join(","));
  if (n.pageFingerprints.includes(r)) throw new Error("API repeated an earlier page; pagination stopped with incomplete coverage");
  if (n.pages >= 1e4) throw new Error("Safety page limit reached; coverage is incomplete");
  return n.pageFingerprints.push(r), n.pages++, n.messageIds = [.../* @__PURE__ */ new Set([...n.messageIds, ...e.map((a) => a.id)])], n.offset += jn, n.coverage = "scanning", n;
}
function $(t, e = "unnamed") {
  let n = (t || e).normalize("NFKC").replace(/[<>:"/\\|?*\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "_").replace(/^[. ]+|[. ]+$/g, "").slice(0, 40).trim().replace(/[. ]+$/g, "");
  return (!n || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(n)) && (n = "_" + (n || e)), n;
}
function Nt(t) {
  return `ArchiveRoot/${t.service === "discord" ? "discord/" : ""}${t.serverId}_${$(t.serverName, "server")}`;
}
function Qt(t) {
  return `${Nt(t)}/${t.channelId}_${$(t.channelName, "channel")}`;
}
function $n(t, e) {
  if (!/^(png|jpg|webp|gif|avif)$/.test(e)) throw new Error("Unvalidated image format");
  const n = t.publishedAtUtc ? t.publishedAtUtc.slice(0, 19).replace("T", "_").replace(/:(\d{2})/g, "$1") + "Z" : "unknown-date";
  return `${Qt(t)}/${n}_${t.messageId || "unknown-message"}_${String(t.attachmentIndex).padStart(3, "0")}_${se(t.id).slice(0, 8)}.${e}`;
}
let xt;
function K() {
  return xt || (xt = new Promise((t, e) => {
    const n = indexedDB.open("kemono-archive", 2);
    n.onupgradeneeded = () => {
      n.result.objectStoreNames.contains("jobs") || (n.result.createObjectStore("jobs", { keyPath: "id" }), n.result.createObjectStore("media", { keyPath: ["jobId", "id"] }).createIndex("jobId", "jobId")), n.result.objectStoreNames.contains("postJobs") || n.result.createObjectStore("postJobs", { keyPath: "id" });
    }, n.onsuccess = () => t(n.result), n.onerror = () => {
      xt = void 0, e(n.error);
    };
  })), xt;
}
function It(t) {
  return new Promise((e, n) => {
    t.onsuccess = () => e(t.result), t.onerror = () => n(t.error);
  });
}
function Ft(t) {
  return new Promise((e, n) => {
    t.oncomplete = () => e(), t.onerror = t.onabort = () => n(t.error || new Error("Database transaction aborted"));
  });
}
async function G() {
  return It((await K()).transaction("jobs").objectStore("jobs").getAll());
}
async function Me(t) {
  return It((await K()).transaction("jobs").objectStore("jobs").get(t));
}
async function k(t) {
  return It((await K()).transaction("media").objectStore("media").index("jobId").getAll(t));
}
async function R(t) {
  const e = (await K()).transaction("jobs", "readwrite"), n = Ft(e);
  e.objectStore("jobs").put(t), await n;
}
async function M(t) {
  const e = (await K()).transaction("media", "readwrite"), n = Ft(e);
  e.objectStore("media").put(t), await n;
}
async function Ht() {
  return It((await K()).transaction("postJobs").objectStore("postJobs").getAll());
}
async function tr(t) {
  return It((await K()).transaction("postJobs").objectStore("postJobs").get(t));
}
async function O(t) {
  t.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const e = (await K()).transaction("postJobs", "readwrite"), n = Ft(e);
  e.objectStore("postJobs").put(t), await n;
}
async function lt(t, e) {
  const n = (await K()).transaction(["jobs", "media"], "readwrite"), r = Ft(n);
  n.objectStore("jobs").put(t);
  const a = n.objectStore("media"), s = a.index("jobId").openKeyCursor(IDBKeyRange.only(t.id));
  s.onsuccess = () => {
    const i = s.result;
    if (i)
      a.delete(i.primaryKey), i.continue();
    else for (const o of e) a.put(o);
  }, await r;
}
function jt(t, e) {
  return {
    discovered: e.length,
    downloaded: e.filter((n) => n.status === "downloaded").length,
    staged: e.filter((n) => n.status === "staged").length,
    failed: e.filter((n) => n.status === "failed").length,
    skipped: e.filter((n) => n.status === "skipped").length,
    queued: e.filter((n) => n.status === "queued" || n.status === "transferring").length,
    pages: t.channels.reduce((n, r) => n + r.pages, 0),
    messages: t.channels.reduce((n, r) => n + r.messageIds.length, 0),
    incomplete: t.scope === "server" && t.channelDiscovery === "dom" || t.channels.some((n) => n.coverage !== "complete") || e.some((n) => ["failed", "skipped", "queued", "transferring", "staged"].includes(n.status) || n.mediaType === "unknown" || !n.messageId || !(n.thumbnailUrl || n.originalUrl || n.discordCdnUrl)) || t.status === "cancelled"
  };
}
function ot(t, e, n) {
  const r = n ? e.filter((s) => s.channelId === n) : e, a = n ? { ...t, channels: t.channels.filter((s) => s.channelId === n) } : t;
  return JSON.stringify({
    schemaVersion: 1,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    job: { ...a, archive: a.archive ? { ...a.archive, blobUrl: void 0 } : void 0, manifestDownloads: a.manifestDownloads.map(({ blobUrl: s, ...i }) => i) },
    totals: jt(a, r),
    coverageNote: "Complete means every requested API page reached a validated empty array. DOM coverage is limited to observed messages. Indexed links are not a claim that every image is available.",
    timestampPolicy: "Timezone-less archive publication times are interpreted as UTC; raw values are retained.",
    media: r.map(({ blobUrl: s, ...i }) => i)
  }, null, 2);
}
const he = ["serverId", "serverName", "channelId", "channelName", "messageId", "publishedRaw", "publishedAtUtc", "attachmentIndex", "originalFilename", "kemonoPath", "kemonoFileHash", "originalUrl", "discordCdnUrl", "thumbnailUrl", "resolvedUrl", "quality", "sourceType", "status", "savedPath", "sha256", "errorMessage"];
function er(t) {
  const e = (n) => {
    let r = n == null ? "" : String(n);
    return /^[\s]*[=+\-@\t\r]/.test(r) && (r = "'" + r), '"' + r.replaceAll('"', '""') + '"';
  };
  return "\uFEFF" + [he.join(","), ...t.map((n) => he.map((r) => e(n[r])).join(","))].join(`\r
`);
}
function nr(t, e) {
  const n = [t.originalUrl, t.discordCdnUrl].map(j).filter((i) => !!i).map((i) => ({ url: i, quality: "original" })), r = j(t.thumbnailUrl), a = r ? [{ url: r, quality: "thumbnail" }] : [], s = e.mode === "original" ? n : e.mode === "best" && e.tryOriginal ? [...n, ...a] : a;
  return s.filter((i, o) => s.findIndex((f) => f.url === i.url) === o);
}
function Q(t) {
  return t.destination?.kind === "folder" && t.destination.directoryId || t.id;
}
let we;
async function rr() {
  return we ||= new Promise((t, e) => {
    const n = indexedDB.open("kemono-archive-destinations", 1);
    n.onupgradeneeded = () => n.result.createObjectStore("folders"), n.onsuccess = () => t(n.result), n.onerror = () => {
      we = void 0, e(n.error);
    };
  });
}
async function ar(t) {
  const e = await rr();
  return new Promise((n, r) => {
    const a = e.transaction("folders").objectStore("folders").get(t);
    a.onsuccess = () => n(a.result), a.onerror = () => r(a.error);
  });
}
class Y extends Error {
  constructor() {
    super("Folder access is required. Choose folder, click Allow folder access, then Resume.");
  }
}
async function dt(t) {
  const e = await ar(t);
  try {
    if (!e || await e.queryPermission({ mode: "readwrite" }) !== "granted") throw new Y();
  } catch {
    throw new Y();
  }
  return e;
}
function kt(t) {
  const e = t.split("/");
  if (!t || e.some((n) => !n || n === "." || n === ".." || /[\\:\x00-\x1f<>"|?*]/.test(n))) throw new Error("Unsafe archive path");
  return e;
}
function sr(t) {
  const e = kt(t);
  if (e[0] !== "ArchiveRoot" || e.length < 2) throw new Error("Unsafe archive path");
  return e;
}
async function ir(t, e, n, r = !1) {
  const a = r ? kt(e) : sr(e);
  let s = await dt(t);
  for (const i of a.slice(0, -1)) s = await s.getDirectoryHandle(i, { create: n });
  return { directory: s, name: a.at(-1) };
}
async function or(t) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", await t.arrayBuffer()))].map((e) => e.toString(16).padStart(2, "0")).join("");
}
async function Be(t, e, n, r) {
  try {
    const { directory: a, name: s } = await ir(t, e, !1), i = await (await a.getFileHandle(s)).getFile();
    return i.size === r && await or(i) === n;
  } catch (a) {
    if (a instanceof DOMException && a.name === "NotFoundError") return !1;
    throw a instanceof DOMException && ["NotAllowedError", "SecurityError"].includes(a.name) ? new Y() : a;
  }
}
Promise.resolve();
const B = void 0, _ = "undefined", wt = "function", _t = "string", qe = new Uint8Array(), cr = "Invalid option (must be a function)";
function lr(t) {
  if (t && typeof t != wt)
    throw new Error(cr);
  return t;
}
function dr(t) {
  return typeof t == _t && t.trim() ? Number(t) : t;
}
const ur = 256 * 1024, fr = 1, pr = "Invalid maxWorkers (must be an integer greater than 0)", hr = "Invalid baseURI (must be a string)", wr = "Invalid URI (must be a string or a function returning a string)";
let Fe = 2;
try {
  typeof navigator != _ && navigator.hardwareConcurrency && (Fe = navigator.hardwareConcurrency);
} catch {
}
const He = {
  workerURI: "./core/web-worker-wasm.js",
  wasmURI: "./core/streams/zlib-wasm/zlib-streams.wasm",
  chunkSize: ur,
  maxWorkers: Fe,
  terminateWorkerTimeout: 5e3,
  workerStarvationTimeout: 5e3,
  workerStartupTimeout: 5e3,
  useWebWorkers: !0,
  useCompressionStream: !0,
  CompressionStream: typeof CompressionStream != _ && CompressionStream,
  DecompressionStream: typeof DecompressionStream != _ && DecompressionStream
}, Ze = "maxWorkers", We = "baseURI", Ye = [
  "wasmURI",
  "workerURI"
], mr = [
  "useCompressionStream",
  "useWebWorkers"
], Xe = [
  "chunkSize",
  Ze,
  "terminateWorkerTimeout",
  "workerStarvationTimeout",
  "workerStartupTimeout"
], Ve = [
  "createWorker",
  "CompressionStream",
  "DecompressionStream",
  "CompressionStreamFallback",
  "DecompressionStreamFallback"
], gr = [
  We,
  ...Ye,
  ...mr,
  ...Xe,
  ...Ve
], yr = { ...He };
function br(t) {
  const e = {};
  for (const n of gr) {
    const r = t[n];
    r !== B && (e[n] = vr(n, r));
  }
  return e;
}
function vr(t, e) {
  if (Xe.includes(t)) {
    if (e = dr(e), t == Ze && (!Number.isInteger(e) || e < fr))
      throw new Error(pr);
  } else if (Ve.includes(t))
    lr(e);
  else if (t == We) {
    if (e && typeof e != _t)
      throw new Error(hr);
  } else if (Ye.includes(t) && e && typeof e != _t && typeof e != wt)
    throw new Error(wr);
  return e;
}
function Ir(t) {
  t = t || {};
  const { CompressionStreamZlib: e, DecompressionStreamZlib: n } = t;
  if (e === B && n === B)
    return t;
  const r = Object.assign({}, t);
  return r.CompressionStreamFallback === B && (r.CompressionStreamFallback = e), r.DecompressionStreamFallback === B && (r.DecompressionStreamFallback = n), r;
}
function Zt(t) {
  const e = br(Ir(t));
  Object.assign(He, e), Object.assign(yr, e);
}
const Ut = new Uint8Array(288);
Ut.fill(8, 0, 144), Ut.fill(9, 144, 256), Ut.fill(7, 256, 280), Ut.fill(8, 280, 288), new Uint8Array(30).fill(5);
const X = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Sr = (t) => t({ workerURI: (e) => {
  const n = "text/javascript";
  let r = `!function(t){"function"==typeof define&&define.amd?define(t):t()}(function(){"use strict";const{Array:t,Object:n,Number:e,Math:o,Error:r,Uint8Array:c,Uint16Array:s,Uint32Array:a,Int32Array:i,Map:f,DataView:u,Promise:w,TextEncoder:l,crypto:d,postMessage:p,TransformStream:h,ReadableStream:y,WritableStream:m,CompressionStream:S,DecompressionStream:g}=self,v=void 0,b="undefined",k="function",z=new c,C=[[],[],[],[],[],[],[],[]];for(let t=0;t<256;t++){let n=t;for(let t=0;t<8;t++)n=1&n?n>>>1^3988292384:n>>>1;C[0][t]=n}for(let t=0;t<256;t++)for(let n=1;n<8;n++){const e=C[n-1][t];C[n][t]=e>>>8^C[0][255&e]}const[I,M,A,E,R,x,P,D]=C;class F{constructor(t){this.o=t||-1}append(t){let n=0|this.o;const e=0|t.length;let o=0;if(e>=8&&t.buffer){const r=new u(t.buffer,t.byteOffset,e),c=e-8;for(;o<=c;o+=8){const t=n^r.getInt32(o,!0),e=r.getInt32(o+4,!0);n=D[255&t]^P[t>>>8&255]^x[t>>>16&255]^R[t>>>24&255]^E[255&e]^A[e>>>8&255]^M[e>>>16&255]^I[e>>>24&255]}}for(;o<e;o++)n=n>>>8^I[255&(n^t[o])];this.o=n}get(){return~this.o}}class U extends h{constructor(){let t;const n=new F;super({transform(t,e){n.append(t),e.enqueue(t)},flush(){const e=new c(4);new u(e.buffer).setUint32(0,n.get()),t.value=e}}),t=this}}function B(t,n){const e=new c(t.length+n.length);return e.set(t),e.set(n,t.length),e}function W(t){return new u(t.buffer,t.byteOffset,t.byteLength)}const O=64,V=20,K=new c([128]),T=new c(1),_=new i([1732584193,4023233417,2562383102,271733878,3285377520]),j=new c(256),H=new i(256),L=new i(256),Z=new i(256),N=new i(256);let q=!1;function G(t,n){!function(){if(!q){let t=1,n=1;do{t=255&(t^t<<1^(128&t?27:0)),n=255&(n^n<<1),n=255&(n^n<<2),n=255&(n^n<<4),128&n&&(n^=9),j[t]=255&(n^(n<<1|n>>7)^(n<<2|n>>6)^(n<<3|n>>5)^(n<<4|n>>4)^99)}while(1!=t);j[0]=99;for(let t=0;t<256;t++){const n=j[t],e=Y(n),o=e<<24|n<<16|n<<8|e^n;H[t]=o,L[t]=o>>>8|o<<24,Z[t]=o>>>16|o<<16,N[t]=o>>>24|o<<8}q=!0}}();const e=new i(60),o=function(t,n){const e=t.length>>2,o=e+6,r=4*(o+1);let c=1;for(let o=0;o<e;o++)n[o]=t[4*o]<<24|t[4*o+1]<<16|t[4*o+2]<<8|t[4*o+3];for(let t=e;t<r;t++){let o=n[t-1];t%e==0?(o=Q(o<<8|o>>>24)^c<<24,c=Y(c)):e>6&&t%e==4&&(o=Q(o)),n[t]=n[t-e]^o}return o}(t,e),r=new i(4),c=J(n);let s=0,a=0,f=0,w=0;return{process(t,n){n&&c.update(t,0,t.length),function(t){const n=new u(t.buffer,t.byteOffset,t.byteLength),e=t.length;let o=0;for(;o+16<=e;o+=16)l(),n.setInt32(o,n.getInt32(o)^r[0]),n.setInt32(o+4,n.getInt32(o+4)^r[1]),n.setInt32(o+8,n.getInt32(o+8)^r[2]),n.setInt32(o+12,n.getInt32(o+12)^r[3]);if(o<e){l();for(let n=0;o<e;o++,n++)t[o]^=r[n>>2]>>>24-8*(3&n)}}(t),n||c.update(t,0,t.length)},digest:()=>c.digest()};function l(){s=s+1|0,s||(a=a+1|0,a||(f=f+1|0,f||(w=w+1|0)));let t=X(s)^e[0],n=X(a)^e[1],c=X(f)^e[2],i=X(w)^e[3],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[4],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[5],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[6],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[7];t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[8],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[9],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[10],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[11],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[12],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[13],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[14],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[15],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[16],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[17],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[18],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[19],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[20],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[21],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[22],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[23],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[24],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[25],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[26],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[27],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[28],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[29],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[30],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[31],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[32],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[33],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[34],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[35],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[36],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[37],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[38],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[39];let h=40;o>10&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[40],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[41],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[42],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[43],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[44],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[45],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[46],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[47],h=48),o>12&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[48],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[49],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[50],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[51],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[52],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[53],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[54],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[55],h=56),r[0]=(j[u>>>24]<<24|j[l>>>16&255]<<16|j[d>>>8&255]<<8|j[255&p])^e[h],r[1]=(j[l>>>24]<<24|j[d>>>16&255]<<16|j[p>>>8&255]<<8|j[255&u])^e[h+1],r[2]=(j[d>>>24]<<24|j[p>>>16&255]<<16|j[u>>>8&255]<<8|j[255&l])^e[h+2],r[3]=(j[p>>>24]<<24|j[u>>>16&255]<<16|j[l>>>8&255]<<8|j[255&d])^e[h+3]}}function J(t){const n=function(){const t=new i(_),n=new i(16),e=new c(O),r=new u(e.buffer),s=new c(8);let a=0,f=0;return{update:w,digest:function(){const n=8*f,e=o.floor(n/4294967296),r=n>>>0;for(w(K,0,1);56!=a;)w(T,0,1);s[0]=e>>>24,s[1]=e>>>16,s[2]=e>>>8,s[3]=e,s[4]=r>>>24,s[5]=r>>>16,s[6]=r>>>8,s[7]=r,w(s,0,8);const i=new c(V),l=new u(i.buffer);for(let n=0;n<t.length;n++)l.setInt32(4*n,t[n]);return t.set(_),a=0,f=0,i}};function w(t,n,o){const c=n+o;if(f+=o,a){for(;n<c&&a<O;)e[a++]=t[n++];a==O&&(l(r,0),a=0)}if(n+O<=c){const e=new u(t.buffer,t.byteOffset,t.byteLength);for(;n+O<=c;n+=O)l(e,n)}for(;n<c;)e[a++]=t[n++]}function l(e,o){for(let t=0;t<16;t++)n[t]=e.getInt32(o+4*t);let r,c=t[0],s=t[1],a=t[2],i=t[3],f=t[4];for(let t=0;t<15;t+=5)f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[t]|0,s=s<<30|s>>>2,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+n[t+1]|0,c=c<<30|c>>>2,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+n[t+2]|0,f=f<<30|f>>>2,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+n[t+3]|0,i=i<<30|i>>>2,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+n[t+4]|0,a=a<<30|a>>>2;f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[15]|0,s=s<<30|s>>>2,r=n[13]^n[8]^n[2]^n[0],r=r<<1|r>>>31,n[0]=r,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+r|0,c=c<<30|c>>>2,r=n[14]^n[9]^n[3]^n[1],r=r<<1|r>>>31,n[1]=r,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+r|0,f=f<<30|f>>>2,r=n[15]^n[10]^n[4]^n[2],r=r<<1|r>>>31,n[2]=r,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+r|0,i=i<<30|i>>>2,r=n[0]^n[11]^n[5]^n[3],r=r<<1|r>>>31,n[3]=r,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+r|0,a=a<<30|a>>>2;for(let t=20;t<40;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+1859775393+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+1859775393+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+1859775393+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+1859775393+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+1859775393+r|0,a=a<<30|a>>>2;for(let t=40;t<60;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s&a|(s|a)&i)+f+2400959708+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c&s|(c|s)&a)+i+2400959708+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f&c|(f|c)&s)+a+2400959708+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i&f|(i|f)&c)+s+2400959708+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a&i|(a|i)&f)+c+2400959708+r|0,a=a<<30|a>>>2;for(let t=60;t<80;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+3395469782+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+3395469782+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+3395469782+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+3395469782+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+3395469782+r|0,a=a<<30|a>>>2;t[0]=t[0]+c|0,t[1]=t[1]+s|0,t[2]=t[2]+a|0,t[3]=t[3]+i|0,t[4]=t[4]+f|0}}(),e=new c(O),r=new c(O);t.length>O&&(n.update(t,0,t.length),t=n.digest());for(let n=0;n<O;n++){const o=n<t.length?t[n]:0;e[n]=54^o,r[n]=92^o}return n.update(e,0,O),{update(t,e,o){n.update(t,e,o)},digest(){const t=n.digest();n.update(r,0,O),n.update(t,0,V);const o=n.digest();return n.update(e,0,O),o}}}function Q(t){return j[t>>>24]<<24|j[t>>>16&255]<<16|j[t>>>8&255]<<8|j[255&t]}function X(t){return t<<24|(65280&t)<<8|t>>>8&65280|t>>>24}function Y(t){return 255&(t<<1^27*(t>>7))}const $=typeof d!=b&&typeof d.getRandomValues==k,tt="Invalid password",nt="zipjs-abort-check-password";function et(t){if($)return d.getRandomValues(t);throw new r("Crypto API not supported")}const ot={name:"PBKDF2"},rt=n.assign({hash:{name:"HMAC"}},ot),ct=n.assign({iterations:1e3,hash:{name:"SHA-1"}},ot),st=["deriveBits"],at=[8,12,16],it=[16,24,32],ft=10,ut=typeof d!=b,wt=ut&&d.subtle;let lt=ut&&typeof wt!=b&&typeof wt.importKey==k&&typeof wt.deriveBits==k,dt=G;class pt extends h{constructor({password:t,rawPassword:n,encryptionStrength:e,checkPasswordOnly:o,checkAuthenticationCode:s=!0}){const a={};super({start(){yt(a,t,n,e)},async transform(t,n){const{password:e,strength:s,l:i,ready:f}=a;if(e?(await async function(t,n,e,o){const c=await vt(t,n,e,kt(o,0,at[n])),s=kt(o,at[n]);if(c[0]!=s[0]||c[1]!=s[1])throw gt(t),new r(tt)}(a,s,e,kt(t,0,at[s]+2)),t=kt(t,at[s]+2),o?(gt(a),n.error(new r(nt))):i()):await f,a.h)return;const u=new c(t.length-ft-(t.length-ft)%16);n.enqueue(St(a,t,u,0,ft,!0))},async flush(t){const{m:n,S:e,ready:o}=a;if(n){if(await o,a.h)return;const i=kt(e,e.length-ft),f=new c(kt(e,0,e.length-ft));n.process(f,!0);const u=n.digest();let w=e.length<ft?1:0;for(let t=0;t<ft;t++)w|=u[t]^i[t];if(w&&s)return void t.error(new r("Invalid authentication code"));t.enqueue(f)}}}),mt(this,a)}}class ht extends h{constructor({password:t,rawPassword:n,encryptionStrength:e}){const o={};super({start(){yt(o,t,n,e)},async transform(t,n){const{password:e,strength:r,l:s,ready:a}=o;let i=z;if(e?(i=await async function(t,n,e){const o=et(new c(at[n]));return B(o,await vt(t,n,e,o))}(o,r,e),s()):await a,o.h)return;const f=new c(i.length+t.length-t.length%16);f.set(i,0),n.enqueue(St(o,t,f,i.length,0,!1))},async flush(t){const{m:n,S:e,ready:r}=o;if(n){if(await r,o.h)return;const s=new c(e);n.process(s,!1);const a=kt(n.digest(),0,ft);t.enqueue(B(s,a))}}}),mt(this,o)}}function yt(t,e,o,r){n.assign(t,{ready:new w(n=>t.l=n),password:bt(e,o),strength:r-1,S:z,h:!1})}function mt(t,e){const o=t.readable.getReader(),r=new y({async pull(t){try{const{value:n,done:e}=await o.read();e?t.close():t.enqueue(n)}catch(t){throw gt(e),o.cancel(t).catch(()=>{}),t}},cancel:t=>(gt(e),o.cancel(t))});n.defineProperty(t,"readable",{get:()=>r})}function St(t,n,e,o,r,s){const{m:a,S:i}=t;i.length&&(n=B(i,n));const f=n.length-r,u=f-f%16;if(e=function(t,n){if(n&&n>t.length){const e=t;(t=new c(n)).set(e,0)}return t}(e,o+u),u){const t=kt(e,o,o+u);t.set(kt(n,0,u)),a.process(t,s)}return t.S=kt(n,u),e}function gt(t){const{m:n}=t;t.h=!0,n&&n.dispose&&n.dispose()}async function vt(t,e,r,s){t.password=null;const a=it[e],i=await async function(t,e,r){if(lt)try{const o=await wt.importKey("raw",t,rt,!1,st);return new c(await wt.deriveBits(n.assign({salt:e},ct),o,8*r))}catch{lt=!1}return function(t,n,e,r){const s=J(t),a=new c(r),i=new c(n.length+4),f=new u(i.buffer);i.set(n);for(let t=1,e=0;e<r;t++,e+=V){f.setUint32(n.length,t),s.update(i,0,i.length);let c=s.digest();const u=c.slice();for(let t=1;t<1e3;t++){s.update(c,0,V),c=s.digest();for(let t=0;t<V;t++)u[t]^=c[t]}a.set(u.subarray(0,o.min(V,r-e)),e)}return a}(t,e,0,r)}(r,s,2*a+2);return t.m=dt(kt(i,0,a),kt(i,a,2*a)),t.h&&gt(t),kt(i,2*a)}function bt(t,n){return n===v?function(t){if(typeof l==b){t=unescape(encodeURIComponent(t));const n=new c(t.length);for(let e=0;e<n.length;e++)n[e]=t.charCodeAt(e);return n}return(new l).encode(t)}(t):n}function kt(t,n,e){return t.subarray(n,e)}class zt extends h{constructor({password:t,rawPassword:n,passwordVerification:e,checkPasswordOnly:o}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;if(e.password||e.rawPassword){const n=Mt(e,t.subarray(0,12));if(e.password=e.rawPassword=null,0!=(n[11]^e.passwordVerification))throw new r(tt);t=t.subarray(12)}o?n.error(new r(nt)):n.enqueue(Mt(e,t))}})}}class Ct extends h{constructor({password:t,rawPassword:n,passwordVerification:e}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;let o,r;if(e.password||e.rawPassword){e.password=e.rawPassword=null;const n=et(new c(12));n[11]=e.passwordVerification,o=new c(t.length+n.length),o.set(At(e,n),0),r=12}else o=new c(t.length),r=0;o.set(At(e,t),r),n.enqueue(o)}})}}function It(t,e,o,r){n.assign(t,{password:e,rawPassword:o,passwordVerification:r}),function(t,e,o){const r=[305419896,591751049,878082192];if(n.assign(t,{v:r,C:new F(r[0]),I:new F(r[2])}),o)for(let n=0;n<o.length;n++)Et(t,o[n]);else for(let n=0;n<e.length;n++)Et(t,e.charCodeAt(n))}(t,e,o)}function Mt(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,e[o]);return e}function At(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,n[o]);return e}function Et(t,n){let[,e]=t.v;t.C.append([n]);const r=~t.C.get();e=Pt(o.imul(Pt(e+xt(r)),134775813)+1),t.I.append([e>>>24]);const c=~t.I.get();t.v=[r,e,c]}function Rt(t){const n=2|t.v[2];return xt(o.imul(n,1^n)>>>8)}function xt(t){return 255&t}function Pt(t){return 4294967295&t}function Dt(t){return Boolean(t)&&"object"==typeof t}const Ft=new f;function Ut(t){return Ft.get(t)}const Bt="Invalid uncompressed size",Wt="Codec out of memory",Ot="Invalid CRC32",Vt="deflate-raw",Kt="gzip",Tt=[31,139,8];class _t extends h{constructor(t,{chunkSize:n,CompressionStreamFallback:e,CompressionStream:o}){super({});const{compressed:r,encrypted:c,useCompressionStream:s,zipCrypto:a,computeCrc32:i,level:f,deflate64:w,format:l,compressionMethod:d,inputSize:p}=t,h=this;let y,m,S,g=super.readable;const v=l&&Ut(l),b=qt(s,o,e),k=i&&r&&!w&&!v&&(!c||a)&&Boolean(b);if(c&&!a||!i||k||(y=new U,g=Jt(g,y)),r)if(v)g=Qt(g,Nt(v.CompressionStream,l,{level:f,chunkSize:n,compressionMethod:d,uncompressedSize:p}));else if(k)S=new jt,g=Qt(g,new b(Kt,{level:f,chunkSize:n})),g=Jt(g,S);else try{g=Gt(g,s,{level:f,chunkSize:n},o,e)}catch(t){if(!s&&e)throw nn(t);let n;try{n=new o(Kt)}catch{throw nn(t)}g=Qt(g,n),g=Jt(g,new jt)}c&&(a?g=Jt(g,new Ct(t)):(m=new ht(t),g=Jt(g,m))),Zt(h,g,()=>{c&&!a||!i||(h.crc32=k?S.crc32:new u(y.value.buffer).getUint32(0))})}}class jt extends h{constructor(){let t,n=10,e=new c(0);super({transform(t,r){if(n){const e=o.min(n,t.length);if(n-=e,!(t=t.subarray(e)).length)return}const c=e.length+t.length;if(c<=8)return void(e=B(e,t));const s=c-8,a=o.min(s,e.length);r.enqueue(B(e.subarray(0,a),t.subarray(0,s-a))),e=B(e.subarray(a),t.subarray(s-a))},flush(){const n=W(e);t.crc32=n.getUint32(0,!0),t.uncompressedSize=n.getUint32(4,!0)}}),t=this}}class Ht extends h{constructor(t,{chunkSize:n,DecompressionStreamFallback:e,DecompressionStream:o}){super({});const{zipCrypto:s,encrypted:a,checkCrc32:i,crc32:f,compressed:l,useCompressionStream:d,deflate64:p,format:h,compressionMethod:m,rawBitFlag:S,outputSize:g}=t;let b,k,z,C=super.readable;if(a&&(s?C=Jt(C,new zt(t)):(k=new pt(t),C=Jt(C,k))),l){const t=new Set,s=h&&Ut(h);let a;if(s)C=Qt(C,Nt(s.DecompressionStream,h,{chunkSize:n,compressionMethod:m,rawBitFlag:S,uncompressedSize:g}),t);else{const r=qt(d,o,e);if(i&&!p&&f!==v&&g!==v&&r)try{a=new r(Kt,{chunkSize:n})}catch{a=v}if(!a)try{C=Gt(C,d,{chunkSize:n,deflate64:p},o,e,t)}catch(t){if(p||g===v||!d&&e)throw nn(t);try{a=new o(Kt)}catch{throw nn(t)}}}a?(z=!0,C=function(t,n,e,o,s){const a=n.writable.getWriter(),i=n.readable.getReader(),f=o===v?new F:v;let u,l,d=0,p=!1,h=!1;const m=new y({start(t){l=t},pull(){b()},cancel:t=>(h=!0,b(),i.cancel(t))});return async function(){const n=t.getReader();try{const t=new c(10);for(t.set(Tt),await a.write(t);;){await g(),await a.ready;const{value:t,done:e}=await $t(n,s);if(e)break;await a.write(t)}f&&await a.write(new c(0));const r=new c(8),i=W(r);i.setUint32(0,f?f.get():o,!0),i.setUint32(4,e,!0),p=!0,await a.write(r),await a.close()}catch(t){await Xt(a,t),await Yt(n,t)}}(),async function(){try{for(;;){const{value:t,done:n}=await S();if(n)break;if(d+=t.length,d>e)throw new r(Bt);f&&f.append(t),l.enqueue(t)}h||(h=!0,l.close())}catch(t){!function(t){h||(h=!0,l.error(t),b())}(t),await Yt(i,t)}}(),m;function S(){return i.read().catch(t=>{if(p){if(!f)throw on(t,Ot);if(d!=e)throw on(t,Bt);return{done:!0}}throw tn(t,s)})}function g(){if(!h&&l.desiredSize<=0)return new w(t=>u=t)}function b(){if(u){const t=u;u=v,t()}}}(C,a,g,f,t)):C=function(t,n){const e=t.getReader();return new y({async pull(t){try{const{value:n,done:o}=await e.read();o?t.close():t.enqueue(n)}catch(t){throw await Yt(e,t),tn(t,n)}},cancel:t=>e.cancel(t)})}(C,t)}i&&!z&&(b=new U,C=Jt(C,b)),Zt(this,C,()=>{if(b){const t=new u(b.value.buffer).getUint32(0,!1);if(f!=t)throw new r(Ot)}})}}const Lt=new f;function Zt(t,e,o){e=Jt(e,new h({flush:o})),n.defineProperty(t,"readable",{get:()=>e})}function Nt(t,n,e){if(!t)throw new r("Compression method not supported");return new t(n,e)}function qt(t,n,e){return t&&n?n:e&&e.requiresModule?e:void 0}function Gt(t,n,e,o,r,c){const s=n&&o?o:r||o,a=e.deflate64?"deflate64-raw":Vt;let i;try{i=new s(a,e)}catch(t){if(!n||!r||s==r)throw t;i=new r(a,e)}return Qt(t,i,c)}function Jt(t,n){return function(t){if(t instanceof y)return t;const n=t.getReader();return new y({async pull(t){try{const{value:e,done:o}=await n.read();o?t.close():t.enqueue(e)}catch(t){throw n.cancel(t).catch(()=>{}),t}},cancel:t=>n.cancel(t)})}(t).pipeThrough(n)}function Qt(t,n,e){const o=n.writable.getWriter(),r=t.getReader();return async function(){try{for(;;){await o.ready;const t=await $t(r,e);if(t.done){await o.close();break}await o.write(t.value)}}catch(t){await Xt(o,t),await Yt(r,t)}}(),n.readable}async function Xt(t,n){try{await t.abort(n)}catch{}}async function Yt(t,n){try{await t.cancel(n)}catch{}}function $t(t,n){const e=t.read();return n?e.catch(t=>{throw n.add(t),t}):e}function tn(t,n){return n.has(t)?t:on(t,en(t)?Wt:"Invalid compressed data")}function nn(t){return en(t)?on(t,Wt):t}function en(t){return Dt(t)&&"Z_MEM_ERROR"==t.code}function on(t,n){const e=new r(n);return e.cause=t,e}const rn="data",cn="deflate";class sn extends h{constructor(t,e){super({});const o=this,{codecType:c}=t;let s;c.startsWith(cn)?s=_t:c.startsWith("inflate")&&(s=Ht),o.outputSize=0;let a=0;const i=new s(t,e),f=super.readable,u=new h({transform(t,n){t&&t.length&&(a+=t.length,n.enqueue(t))},flush(){n.assign(o,{inputSize:a})}}),w=new h({transform(n,e){if(n&&n.length&&(e.enqueue(n),o.outputSize+=n.length,t.outputSize!==v&&o.outputSize>t.outputSize))throw new r(Bt)},flush(){const{crc32:t}=i;n.assign(o,{crc32:t,inputSize:a})}});n.defineProperty(o,"readable",{get:()=>f.pipeThrough(u).pipeThrough(i).pipeThrough(w)})}}class an extends h{constructor(t){const o=[];let r=0,s=0;function a(){const n=new c(t);let e=0;for(;e<t;){const r=o[0],c=t-e;r.length<=c?(n.set(r,e),e+=r.length,o.shift()):(n.set(r.subarray(0,c),e),o[0]=r.subarray(c),e+=c)}return r-=t,n}(!e.isFinite(t)||t<1)&&(t=262144),super({transform(n,e){for(o.push(n),r+=n.length;r>t;)s+=t,e.enqueue(a())},flush(t){r&&(s+=r,t.enqueue(function(t,n){const e=new c(n);let o=0;for(const n of t)e.set(n,o),o+=n.length;return e}(o,r)))}}),n.defineProperty(this,"outputSize",{get:()=>s})}}let fn=2;try{typeof navigator!=b&&navigator.hardwareConcurrency&&(fn=navigator.hardwareConcurrency)}catch{}const un=new f,wn=new f,ln=function(){try{return structuredClone(new r)instanceof r}catch{return!1}}();let dn=0;async function pn(t){let n,c,s;try{const{options:a,config:i}=t;if(a.format)try{await async function(t,n){!Ft.has(t)&&n&&function(t,n){const{CompressionStream:e,DecompressionStream:o}=n;if(typeof e!=k&&typeof o!=k)throw new r("Invalid codec module");Ft.set(t,{CompressionStream:e,DecompressionStream:o})}(t,await(import(n)))}(a.format,a.codecURI)}catch(t){if(Dt(t))try{t.codecImportFailed=!0}catch{}throw t}if(i.CompressionStream=self.CompressionStream,i.DecompressionStream=self.DecompressionStream,a.compressed&&!a.format)if(a.useCompressionStream){if(!function(t,n){if(!t)return!1;let e=Lt.get(t);e||(e=new f,Lt.set(t,e));let o=e.get(n);if(o===v){try{new t(n),o=!0}catch{o=!1}e.set(n,o)}return o}(a.codecType.startsWith(cn)?i.CompressionStream:i.DecompressionStream,Vt))try{await self.initModule(t.config)}catch{}}else try{await self.initModule(t.config)}catch{a.useCompressionStream=!0}if(a.encrypted&&!a.zipCrypto)try{await self.initModule(t.config)}catch{}!i.CompressionStreamFallback&&i.CompressionStreamZlib&&(i.CompressionStreamFallback=i.CompressionStreamZlib),!i.DecompressionStreamFallback&&i.DecompressionStreamZlib&&(i.DecompressionStreamFallback=i.DecompressionStreamZlib);const u={highWaterMark:1},l=new y({async pull(t){const n=new w(t=>un.set(dn,t));hn({type:"pull",messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER;const{value:o,done:r}=await n;t.enqueue(o),r&&t.close()}},u);s=new m({async write(t){let n;const o=new w(t=>n=t);wn.set(dn,n),hn({type:rn,value:t,messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER,await o}},u),n=new sn(a,i),c=new an(function(t){return r="string"==typeof(n=r=t.chunkSize)&&n.trim()?e(n):n,e.isInteger(r)&&r>=1?o.max(r,64):262144;var n,r}(i)),await l.pipeThrough(n).pipeThrough(c).pipeTo(s,{preventClose:!0,preventAbort:!0}),await s.getWriter().close();const{crc32:d,inputSize:p,outputSize:h}=n;hn({type:"close",result:{crc32:d,inputSize:p,outputSize:h}})}catch(t){const n=c?c.outputSize:0;if(Dt(t))try{t.outputSize=n}catch{}if(s&&!s.locked)try{await s.getWriter().close()}catch{}yn(t,n)}}function hn(t){const{value:n}=t;if(n)if(n.length)try{t.value=(e=n,e.byteOffset||e.byteLength!=e.buffer.byteLength?new c(e):e).buffer,p(t,[t.value])}catch{p(t)}else p(t);else p(t);var e}function yn(t,n){const{message:e,stack:o,code:c,name:s,outputSize:a,cause:i,codecImportFailed:f}=function(t=new r("Unknown error")){return Dt(t)?t:new r(String(t))}(t),u={message:e,stack:o,code:c,name:s,outputSize:a===v?n:a};if(Dt(i)&&(u.cause={name:i.name,message:i.message,code:i.code}),f&&(u.codecImportFailed=!0),ln)try{return void p({error:u,errorValue:{value:t}})}catch{}p({error:u})}addEventListener("message",({data:t})=>{const{type:n,messageId:e,value:o,done:r}=t;try{if("start"==n&&pn(t),n==rn){const t=un.get(e);un.delete(e),t({value:o||new c,done:r})}if("ack"==n){const t=wn.get(e);wn.delete(e),t()}}catch(t){yn(t)}}),p({type:"ready"});const mn="deflate",Sn="deflate-raw",gn="deflate64-raw",vn="gzip",bn=[mn,Sn,vn],kn=[mn,Sn,vn,gn];let zn,Cn,In,Mn,An;function En(t,n){return-4===n&&(t.code="Z_MEM_ERROR"),t}function Rn(t,n,e={}){if(!(t?bn:kn).includes(n))throw new TypeError("Unsupported format: "+n);if(!zn){const t=new r("WASM module not loaded");throw t.cause=An,t}const s="number"==typeof e.level?e.level:-1,a="number"==typeof e.outBuffer?e.outBuffer:65536,i="number"==typeof e.inBufferSize?e.inBufferSize:65536,f={M:0,in:0,inBufferSize:0,A:0,R:!1};let u,l,d,p,h=!0,S=!1;return function(){try{let e;if(f.M=Cn(a),f.in=Cn(i),f.inBufferSize=i,!f.M||!f.in)throw En(new r("allocation failed"),-4);if(t?(f.P=zn.deflate_process,f.D=zn.deflate_last_consumed,f.F=zn.deflate_end,f.A=zn.deflate_new(),e=n===vn?zn.deflate_init_gzip(f.A,s):n===Sn?zn.deflate_init_raw(f.A,s):zn.deflate_init(f.A,s)):n===gn?(f.P=zn.inflate9_process,f.D=zn.inflate9_last_consumed,f.F=zn.inflate9_end,f.A=zn.inflate9_new(),e=zn.inflate9_init_raw(f.A)):(f.P=zn.inflate_process,f.D=zn.inflate_last_consumed,f.F=zn.inflate_end,f.A=zn.inflate_new(),e=n===Sn?zn.inflate_init_raw(f.A):n===vn?zn.inflate_init_gzip(f.A):zn.inflate_init(f.A)),0!==e)throw En(new r("init failed:"+e),e)}catch(t){throw b(f),t}}(),{readable:new y({start(t){u=t},pull(){h=!1,v()},cancel(t){S=!0,p=t,b(f),l.error(t),v()}},{highWaterMark:0}),writable:new m({start(t){l=t},async write(t){if(h&&await new w(t=>d=t),S)throw p;try{!function(t){const n=new c(Mn.buffer),e=f.P,s=f.D,i=f.M;let u=0;for(;u<t.length;){if(f.R)throw new r("trailing data after the end of the stream");const c=o.min(t.length-u,32768);if((!f.in||f.inBufferSize<c)&&(f.in&&In&&(In(f.in),f.in=0),f.in=Cn(c),f.inBufferSize=c,!f.in))throw En(new r("allocation failed"),-4);n.set(t.subarray(u,u+c),f.in);const w=e(f.A,f.in,c,i,a,0),l=w>>24&255,d=128&l?l-256:l;if(d<0)throw En(new r("process error:"+d),d);const p=16777215&w;p&&g(n.slice(i,i+p));const h=s(f.A);if(1===l)f.R=!0;else if(0===h&&0===p)break;u+=h}}(t)}catch(t){throw b(f),u.error(t),t}},close(){if(S)return;try{!function(){const t=new c(Mn.buffer),n=f.P,e=f.M;for(;;){const o=n(f.A,0,0,e,a,4),c=o>>24&255,s=128&c?c-256:c;if(s<0)throw En(new r("process error:"+s),s);const i=16777215&o;if(i&&g(t.slice(e,e+i)),1===c||0===i)break}}()}catch(t){throw b(f),u.error(t),t}const t=b(f);if(0!==t){const n=En(new r("end error:"+t),t);throw u.error(n),n}u.close()},abort(t){b(f),u.error(t)}},{highWaterMark:1})};function g(t){h=!0,u.enqueue(t)}function v(){if(d){const t=d;d=null,t()}}function b(t){let n=0;return t.A&&t.F&&(n=t.F(t.A)),t.A=0,t.in&&In&&In(t.in),t.in=0,t.M&&In&&In(t.M),t.M=0,n}}class xn{constructor(t=mn,n){return Rn(!0,t,n)}}class Pn{constructor(t=mn,n){return Rn(!1,t,n)}}xn.requiresModule=!0,Pn.requiresModule=!0,xn.supportedFormats=bn,Pn.supportedFormats=kn;const Dn=65536;let Fn,Un;function Bn(t){return new c(t.memory.buffer)}let Wn=!1;!function(t={}){const{init:n,U:e}=t,o=t.CompressionStreamFallback||t.CompressionStreamZlib,r=t.DecompressionStreamFallback||t.DecompressionStreamZlib;e&&(dt=e||G),self.initModule=async t=>{n&&await n(t),o&&(t.CompressionStreamFallback=o),r&&(t.DecompressionStreamFallback=r)}}({CompressionStreamFallback:xn,DecompressionStreamFallback:Pn,U:function(t,n){const e=Fn;let o=e?function(t,n,e){Un||(Un=t.malloc(Dn));const o=Un?t.aes_hmac_new():0;if(o){const r=Bn(t);if(r.set(n,Un),r.set(e,Un+n.length),t.aes_hmac_init(o,Un,n.length,Un+n.length,e.length))return t.aes_hmac_end(o,0),0}return o}(e,t,n):0;if(!o)return G(t,n);const r=Un;return{process(t,n){for(let c=0;c<t.length;c+=Dn){const s=t.subarray(c,c+Dn),a=Bn(e);a.set(s,r),e.aes_hmac_process(o,r,s.length,n?1:0),s.set(a.subarray(r,r+s.length))}},digest:()=>(e.aes_hmac_end(o,r),o=0,Bn(e).slice(r,r+20)),dispose(){o&&(e.aes_hmac_end(o,0),o=0)}}},init:t=>async function(t,{baseURI:n}){if(!Wn)try{await async function(t,n){let e,o;try{try{o=new URL(t,n)}catch{}const r=await fetch(o);e=await r.arrayBuffer()}catch(n){if(!t.startsWith("data:application/wasm;base64,"))throw n;e=function(t){const n=t.split(",")[1],e=atob(n),o=e.length,r=new c(o);for(let t=0;t<o;++t)r[t]=e.charCodeAt(t);return r.buffer}(t)}const s=await WebAssembly.instantiate(e);var a;(function(t){if(zn=t,({malloc:Cn,free:In,memory:Mn}=zn),"function"!=typeof Cn||"function"!=typeof In||!Mn)throw zn=Cn=In=Mn=null,new r("Invalid WASM module")})(s.instance.exports),typeof(a=s.instance.exports).aes_hmac_new==k&&(Fn=a,Un=0)}(t,n),Wn=!0}catch(t){throw function(t){An=t}(t),t}}(t.wasmURI,t)})});
`;
  if (typeof r == "string" && (r = new TextEncoder().encode(r)), e) {
    const a = new Blob([r], { type: n });
    return URL.createObjectURL(a);
  }
  return "data:" + n + ";base64," + (function(a) {
    let s = "";
    const i = a.length;
    let o = 0;
    for (; o + 2 < i; o += 3) {
      const h = a[o] << 16 | a[o + 1] << 8 | a[o + 2];
      s += X[h >> 18 & 63] + X[h >> 12 & 63] + X[h >> 6 & 63] + X[63 & h];
    }
    const f = i - o;
    if (f === 1) {
      const h = a[o] << 16;
      s += X[h >> 18 & 63] + X[h >> 12 & 63] + "==";
    } else if (f === 2) {
      const h = a[o] << 16 | a[o + 1] << 8;
      s += X[h >> 18 & 63] + X[h >> 12 & 63] + X[h >> 6 & 63] + "=";
    }
    return s;
  })(r);
} });
function nt(t, e) {
  const n = new Uint8Array(t.length + e.length);
  return n.set(t), n.set(e, t.length), n;
}
function Ge(t) {
  return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
function Ar(t) {
  return !!t && typeof t == "object";
}
const ut = [[], [], [], [], [], [], [], []];
for (let t = 0; t < 256; t++) {
  let e = t;
  for (let n = 0; n < 8; n++)
    e = e & 1 ? e >>> 1 ^ 3988292384 : e >>> 1;
  ut[0][t] = e;
}
for (let t = 0; t < 256; t++)
  for (let e = 1; e < 8; e++) {
    const n = ut[e - 1][t];
    ut[e][t] = n >>> 8 ^ ut[0][n & 255];
  }
const [me, xr, Ur, Er, Rr, Cr, Pr, Dr] = ut;
class Ot {
  constructor(e) {
    this.crc = e || -1;
  }
  append(e) {
    let n = this.crc | 0;
    const r = e.length | 0;
    let a = 0;
    if (r >= 8 && e.buffer) {
      const s = new DataView(e.buffer, e.byteOffset, r), i = r - 8;
      for (; a <= i; a += 8) {
        const o = n ^ s.getInt32(a, !0), f = s.getInt32(a + 4, !0);
        n = Dr[o & 255] ^ Pr[o >>> 8 & 255] ^ Cr[o >>> 16 & 255] ^ Rr[o >>> 24 & 255] ^ Er[f & 255] ^ Ur[f >>> 8 & 255] ^ xr[f >>> 16 & 255] ^ me[f >>> 24 & 255];
      }
    }
    for (; a < r; a++)
      n = n >>> 8 ^ me[(n ^ e[a]) & 255];
    this.crc = n;
  }
  get() {
    return ~this.crc;
  }
}
class Ke extends TransformStream {
  constructor() {
    let e;
    const n = new Ot();
    super({
      transform(r, a) {
        n.append(r), a.enqueue(r);
      },
      flush() {
        const r = new Uint8Array(4);
        new DataView(r.buffer).setUint32(0, n.get()), e.value = r;
      }
    }), e = this;
  }
}
function Nr(t) {
  if (typeof TextEncoder == _) {
    t = unescape(encodeURIComponent(t));
    const e = new Uint8Array(t.length);
    for (let n = 0; n < e.length; n++)
      e[n] = t.charCodeAt(n);
    return e;
  } else
    return new TextEncoder().encode(t);
}
const Xt = 16, kr = 60, H = 64, tt = 20, Or = 16, Tr = 56, Lr = new Uint8Array([128]), zr = new Uint8Array(1), ge = new Int32Array([1732584193, 4023233417, 2562383102, 271733878, 3285377520]), Mr = 54, Br = 92, N = new Uint8Array(256), v = new Int32Array(256), I = new Int32Array(256), S = new Int32Array(256), A = new Int32Array(256);
let ye = !1;
function ie(t, e) {
  Hr();
  const n = new Int32Array(kr), r = Zr(t, n), a = new Int32Array(Xt / 4), s = Je(e);
  let i = 0, o = 0, f = 0, h = 0;
  return {
    process(l, d) {
      d && s.update(l, 0, l.length), m(l), d || s.update(l, 0, l.length);
    },
    digest() {
      return s.digest();
    }
  };
  function m(l) {
    const d = new DataView(l.buffer, l.byteOffset, l.byteLength), g = l.length;
    let p = 0;
    for (; p + Xt <= g; p += Xt)
      y(), d.setInt32(p, d.getInt32(p) ^ a[0]), d.setInt32(p + 4, d.getInt32(p + 4) ^ a[1]), d.setInt32(p + 8, d.getInt32(p + 8) ^ a[2]), d.setInt32(p + 12, d.getInt32(p + 12) ^ a[3]);
    if (p < g) {
      y();
      for (let w = 0; p < g; p++, w++)
        l[p] ^= a[w >> 2] >>> 24 - 8 * (w & 3);
    }
  }
  function y() {
    i = i + 1 | 0, i || (o = o + 1 | 0, o || (f = f + 1 | 0, f || (h = h + 1 | 0)));
    let l = Et(i) ^ n[0], d = Et(o) ^ n[1], g = Et(f) ^ n[2], p = Et(h) ^ n[3], w = v[l >>> 24] ^ I[d >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[p & 255] ^ n[4], c = v[d >>> 24] ^ I[g >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[l & 255] ^ n[5], u = v[g >>> 24] ^ I[p >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[d & 255] ^ n[6], b = v[p >>> 24] ^ I[l >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[g & 255] ^ n[7];
    l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[b & 255] ^ n[8], d = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ n[9], g = v[u >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ n[10], p = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[11], w = v[l >>> 24] ^ I[d >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[p & 255] ^ n[12], c = v[d >>> 24] ^ I[g >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[l & 255] ^ n[13], u = v[g >>> 24] ^ I[p >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[d & 255] ^ n[14], b = v[p >>> 24] ^ I[l >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[g & 255] ^ n[15], l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[b & 255] ^ n[16], d = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ n[17], g = v[u >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ n[18], p = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[19], w = v[l >>> 24] ^ I[d >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[p & 255] ^ n[20], c = v[d >>> 24] ^ I[g >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[l & 255] ^ n[21], u = v[g >>> 24] ^ I[p >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[d & 255] ^ n[22], b = v[p >>> 24] ^ I[l >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[g & 255] ^ n[23], l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[b & 255] ^ n[24], d = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ n[25], g = v[u >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ n[26], p = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[27], w = v[l >>> 24] ^ I[d >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[p & 255] ^ n[28], c = v[d >>> 24] ^ I[g >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[l & 255] ^ n[29], u = v[g >>> 24] ^ I[p >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[d & 255] ^ n[30], b = v[p >>> 24] ^ I[l >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[g & 255] ^ n[31], l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[b & 255] ^ n[32], d = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ n[33], g = v[u >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ n[34], p = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[35], w = v[l >>> 24] ^ I[d >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[p & 255] ^ n[36], c = v[d >>> 24] ^ I[g >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[l & 255] ^ n[37], u = v[g >>> 24] ^ I[p >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[d & 255] ^ n[38], b = v[p >>> 24] ^ I[l >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[g & 255] ^ n[39];
    let x = 40;
    r > 10 && (l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[b & 255] ^ n[40], d = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ n[41], g = v[u >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ n[42], p = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[43], w = v[l >>> 24] ^ I[d >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[p & 255] ^ n[44], c = v[d >>> 24] ^ I[g >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[l & 255] ^ n[45], u = v[g >>> 24] ^ I[p >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[d & 255] ^ n[46], b = v[p >>> 24] ^ I[l >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[g & 255] ^ n[47], x = 48), r > 12 && (l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[b & 255] ^ n[48], d = v[c >>> 24] ^ I[u >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ n[49], g = v[u >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ n[50], p = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[u & 255] ^ n[51], w = v[l >>> 24] ^ I[d >>> 16 & 255] ^ S[g >>> 8 & 255] ^ A[p & 255] ^ n[52], c = v[d >>> 24] ^ I[g >>> 16 & 255] ^ S[p >>> 8 & 255] ^ A[l & 255] ^ n[53], u = v[g >>> 24] ^ I[p >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[d & 255] ^ n[54], b = v[p >>> 24] ^ I[l >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[g & 255] ^ n[55], x = 56), a[0] = (N[w >>> 24] << 24 | N[c >>> 16 & 255] << 16 | N[u >>> 8 & 255] << 8 | N[b & 255]) ^ n[x], a[1] = (N[c >>> 24] << 24 | N[u >>> 16 & 255] << 16 | N[b >>> 8 & 255] << 8 | N[w & 255]) ^ n[x + 1], a[2] = (N[u >>> 24] << 24 | N[b >>> 16 & 255] << 16 | N[w >>> 8 & 255] << 8 | N[c & 255]) ^ n[x + 2], a[3] = (N[b >>> 24] << 24 | N[w >>> 16 & 255] << 16 | N[c >>> 8 & 255] << 8 | N[u & 255]) ^ n[x + 3];
  }
}
function qr(t, e, n, r) {
  const a = Je(t), s = new Uint8Array(r), i = new Uint8Array(e.length + 4), o = new DataView(i.buffer);
  i.set(e);
  for (let f = 1, h = 0; h < r; f++, h += tt) {
    o.setUint32(e.length, f), a.update(i, 0, i.length);
    let m = a.digest();
    const y = m.slice();
    for (let l = 1; l < n; l++) {
      a.update(m, 0, tt), m = a.digest();
      for (let d = 0; d < tt; d++)
        y[d] ^= m[d];
    }
    s.set(y.subarray(0, Math.min(tt, r - h)), h);
  }
  return s;
}
function Je(t) {
  const e = Fr(), n = new Uint8Array(H), r = new Uint8Array(H);
  t.length > H && (e.update(t, 0, t.length), t = e.digest());
  for (let a = 0; a < H; a++) {
    const s = a < t.length ? t[a] : 0;
    n[a] = s ^ Mr, r[a] = s ^ Br;
  }
  return e.update(n, 0, H), {
    update(a, s, i) {
      e.update(a, s, i);
    },
    digest() {
      const a = e.digest();
      e.update(r, 0, H), e.update(a, 0, tt);
      const s = e.digest();
      return e.update(n, 0, H), s;
    }
  };
}
function Fr() {
  const t = new Int32Array(ge), e = new Int32Array(Or), n = new Uint8Array(H), r = new DataView(n.buffer), a = new Uint8Array(8);
  let s = 0, i = 0;
  return {
    update: o,
    digest: f
  };
  function o(m, y, l) {
    const d = y + l;
    if (i += l, s) {
      for (; y < d && s < H; )
        n[s++] = m[y++];
      s == H && (h(r, 0), s = 0);
    }
    if (y + H <= d) {
      const g = new DataView(m.buffer, m.byteOffset, m.byteLength);
      for (; y + H <= d; y += H)
        h(g, y);
    }
    for (; y < d; )
      n[s++] = m[y++];
  }
  function f() {
    const m = i * 8, y = Math.floor(m / 4294967296), l = m >>> 0;
    for (o(Lr, 0, 1); s != Tr; )
      o(zr, 0, 1);
    a[0] = y >>> 24, a[1] = y >>> 16, a[2] = y >>> 8, a[3] = y, a[4] = l >>> 24, a[5] = l >>> 16, a[6] = l >>> 8, a[7] = l, o(a, 0, 8);
    const d = new Uint8Array(tt), g = new DataView(d.buffer);
    for (let p = 0; p < t.length; p++)
      g.setInt32(4 * p, t[p]);
    return t.set(ge), s = 0, i = 0, d;
  }
  function h(m, y) {
    for (let u = 0; u < 16; u++)
      e[u] = m.getInt32(y + 4 * u);
    let l = t[0], d = t[1], g = t[2], p = t[3], w = t[4], c;
    for (let u = 0; u < 15; u += 5)
      w = (l << 5 | l >>> 27) + ((g ^ p) & d ^ p) + w + 1518500249 + e[u] | 0, d = d << 30 | d >>> 2, p = (w << 5 | w >>> 27) + ((d ^ g) & l ^ g) + p + 1518500249 + e[u + 1] | 0, l = l << 30 | l >>> 2, g = (p << 5 | p >>> 27) + ((l ^ d) & w ^ d) + g + 1518500249 + e[u + 2] | 0, w = w << 30 | w >>> 2, d = (g << 5 | g >>> 27) + ((w ^ l) & p ^ l) + d + 1518500249 + e[u + 3] | 0, p = p << 30 | p >>> 2, l = (d << 5 | d >>> 27) + ((p ^ w) & g ^ w) + l + 1518500249 + e[u + 4] | 0, g = g << 30 | g >>> 2;
    w = (l << 5 | l >>> 27) + ((g ^ p) & d ^ p) + w + 1518500249 + e[15] | 0, d = d << 30 | d >>> 2, c = e[13] ^ e[8] ^ e[2] ^ e[0], c = c << 1 | c >>> 31, e[0] = c, p = (w << 5 | w >>> 27) + ((d ^ g) & l ^ g) + p + 1518500249 + c | 0, l = l << 30 | l >>> 2, c = e[14] ^ e[9] ^ e[3] ^ e[1], c = c << 1 | c >>> 31, e[1] = c, g = (p << 5 | p >>> 27) + ((l ^ d) & w ^ d) + g + 1518500249 + c | 0, w = w << 30 | w >>> 2, c = e[15] ^ e[10] ^ e[4] ^ e[2], c = c << 1 | c >>> 31, e[2] = c, d = (g << 5 | g >>> 27) + ((w ^ l) & p ^ l) + d + 1518500249 + c | 0, p = p << 30 | p >>> 2, c = e[0] ^ e[11] ^ e[5] ^ e[3], c = c << 1 | c >>> 31, e[3] = c, l = (d << 5 | d >>> 27) + ((p ^ w) & g ^ w) + l + 1518500249 + c | 0, g = g << 30 | g >>> 2;
    for (let u = 20; u < 40; u += 5)
      c = e[u - 3 & 15] ^ e[u - 8 & 15] ^ e[u - 14 & 15] ^ e[u & 15], c = c << 1 | c >>> 31, e[u & 15] = c, w = (l << 5 | l >>> 27) + (d ^ g ^ p) + w + 1859775393 + c | 0, d = d << 30 | d >>> 2, c = e[u - 2 & 15] ^ e[u - 7 & 15] ^ e[u - 13 & 15] ^ e[u + 1 & 15], c = c << 1 | c >>> 31, e[u + 1 & 15] = c, p = (w << 5 | w >>> 27) + (l ^ d ^ g) + p + 1859775393 + c | 0, l = l << 30 | l >>> 2, c = e[u - 1 & 15] ^ e[u - 6 & 15] ^ e[u - 12 & 15] ^ e[u + 2 & 15], c = c << 1 | c >>> 31, e[u + 2 & 15] = c, g = (p << 5 | p >>> 27) + (w ^ l ^ d) + g + 1859775393 + c | 0, w = w << 30 | w >>> 2, c = e[u & 15] ^ e[u - 5 & 15] ^ e[u - 11 & 15] ^ e[u + 3 & 15], c = c << 1 | c >>> 31, e[u + 3 & 15] = c, d = (g << 5 | g >>> 27) + (p ^ w ^ l) + d + 1859775393 + c | 0, p = p << 30 | p >>> 2, c = e[u + 1 & 15] ^ e[u - 4 & 15] ^ e[u - 10 & 15] ^ e[u + 4 & 15], c = c << 1 | c >>> 31, e[u + 4 & 15] = c, l = (d << 5 | d >>> 27) + (g ^ p ^ w) + l + 1859775393 + c | 0, g = g << 30 | g >>> 2;
    for (let u = 40; u < 60; u += 5)
      c = e[u - 3 & 15] ^ e[u - 8 & 15] ^ e[u - 14 & 15] ^ e[u & 15], c = c << 1 | c >>> 31, e[u & 15] = c, w = (l << 5 | l >>> 27) + (d & g | (d | g) & p) + w + 2400959708 + c | 0, d = d << 30 | d >>> 2, c = e[u - 2 & 15] ^ e[u - 7 & 15] ^ e[u - 13 & 15] ^ e[u + 1 & 15], c = c << 1 | c >>> 31, e[u + 1 & 15] = c, p = (w << 5 | w >>> 27) + (l & d | (l | d) & g) + p + 2400959708 + c | 0, l = l << 30 | l >>> 2, c = e[u - 1 & 15] ^ e[u - 6 & 15] ^ e[u - 12 & 15] ^ e[u + 2 & 15], c = c << 1 | c >>> 31, e[u + 2 & 15] = c, g = (p << 5 | p >>> 27) + (w & l | (w | l) & d) + g + 2400959708 + c | 0, w = w << 30 | w >>> 2, c = e[u & 15] ^ e[u - 5 & 15] ^ e[u - 11 & 15] ^ e[u + 3 & 15], c = c << 1 | c >>> 31, e[u + 3 & 15] = c, d = (g << 5 | g >>> 27) + (p & w | (p | w) & l) + d + 2400959708 + c | 0, p = p << 30 | p >>> 2, c = e[u + 1 & 15] ^ e[u - 4 & 15] ^ e[u - 10 & 15] ^ e[u + 4 & 15], c = c << 1 | c >>> 31, e[u + 4 & 15] = c, l = (d << 5 | d >>> 27) + (g & p | (g | p) & w) + l + 2400959708 + c | 0, g = g << 30 | g >>> 2;
    for (let u = 60; u < 80; u += 5)
      c = e[u - 3 & 15] ^ e[u - 8 & 15] ^ e[u - 14 & 15] ^ e[u & 15], c = c << 1 | c >>> 31, e[u & 15] = c, w = (l << 5 | l >>> 27) + (d ^ g ^ p) + w + 3395469782 + c | 0, d = d << 30 | d >>> 2, c = e[u - 2 & 15] ^ e[u - 7 & 15] ^ e[u - 13 & 15] ^ e[u + 1 & 15], c = c << 1 | c >>> 31, e[u + 1 & 15] = c, p = (w << 5 | w >>> 27) + (l ^ d ^ g) + p + 3395469782 + c | 0, l = l << 30 | l >>> 2, c = e[u - 1 & 15] ^ e[u - 6 & 15] ^ e[u - 12 & 15] ^ e[u + 2 & 15], c = c << 1 | c >>> 31, e[u + 2 & 15] = c, g = (p << 5 | p >>> 27) + (w ^ l ^ d) + g + 3395469782 + c | 0, w = w << 30 | w >>> 2, c = e[u & 15] ^ e[u - 5 & 15] ^ e[u - 11 & 15] ^ e[u + 3 & 15], c = c << 1 | c >>> 31, e[u + 3 & 15] = c, d = (g << 5 | g >>> 27) + (p ^ w ^ l) + d + 3395469782 + c | 0, p = p << 30 | p >>> 2, c = e[u + 1 & 15] ^ e[u - 4 & 15] ^ e[u - 10 & 15] ^ e[u + 4 & 15], c = c << 1 | c >>> 31, e[u + 4 & 15] = c, l = (d << 5 | d >>> 27) + (g ^ p ^ w) + l + 3395469782 + c | 0, g = g << 30 | g >>> 2;
    t[0] = t[0] + l | 0, t[1] = t[1] + d | 0, t[2] = t[2] + g | 0, t[3] = t[3] + p | 0, t[4] = t[4] + w | 0;
  }
}
function Hr() {
  if (!ye) {
    let t = 1, e = 1;
    do
      t = (t ^ t << 1 ^ (t & 128 ? 27 : 0)) & 255, e = (e ^ e << 1) & 255, e = (e ^ e << 2) & 255, e = (e ^ e << 4) & 255, e & 128 && (e ^= 9), N[t] = (e ^ (e << 1 | e >> 7) ^ (e << 2 | e >> 6) ^ (e << 3 | e >> 5) ^ (e << 4 | e >> 4) ^ 99) & 255;
    while (t != 1);
    N[0] = 99;
    for (let n = 0; n < 256; n++) {
      const r = N[n], a = Qe(r), s = a << 24 | r << 16 | r << 8 | a ^ r;
      v[n] = s, I[n] = s >>> 8 | s << 24, S[n] = s >>> 16 | s << 16, A[n] = s >>> 24 | s << 8;
    }
    ye = !0;
  }
}
function Zr(t, e) {
  const n = t.length >> 2, r = n + 6, a = 4 * (r + 1);
  let s = 1;
  for (let i = 0; i < n; i++)
    e[i] = t[4 * i] << 24 | t[4 * i + 1] << 16 | t[4 * i + 2] << 8 | t[4 * i + 3];
  for (let i = n; i < a; i++) {
    let o = e[i - 1];
    i % n == 0 ? (o = be(o << 8 | o >>> 24) ^ s << 24, s = Qe(s)) : n > 6 && i % n == 4 && (o = be(o)), e[i] = e[i - n] ^ o;
  }
  return r;
}
function be(t) {
  return N[t >>> 24] << 24 | N[t >>> 16 & 255] << 16 | N[t >>> 8 & 255] << 8 | N[t & 255];
}
function Et(t) {
  return t << 24 | (t & 65280) << 8 | t >>> 8 & 65280 | t >>> 24;
}
function Qe(t) {
  return (t << 1 ^ (t >> 7) * 27) & 255;
}
const Wr = typeof crypto != _ && typeof crypto.getRandomValues == wt, je = "Invalid password", Yr = "Invalid authentication code", _e = "zipjs-abort-check-password", Xr = "Crypto API not supported";
function $e(t) {
  if (Wr)
    return crypto.getRandomValues(t);
  throw new Error(Xr);
}
const oe = 16, Vr = "raw", tn = { name: "PBKDF2" }, Gr = { name: "HMAC" }, Kr = "SHA-1", en = 1e3, Jr = Object.assign({ hash: Gr }, tn), Qr = Object.assign({ iterations: en, hash: { name: Kr } }, tn), jr = ["deriveBits"], mt = [8, 12, 16], _r = [16, 24, 32], J = 10, $t = 2, nn = typeof crypto != _, gt = nn && crypto.subtle, $r = nn && typeof gt != _;
let ve = $r && typeof gt.importKey == wt && typeof gt.deriveBits == wt, rn = ie;
class ta extends TransformStream {
  constructor({ password: e, rawPassword: n, encryptionStrength: r, checkPasswordOnly: a, checkAuthenticationCode: s = !0 }) {
    const i = {};
    super({
      start() {
        an(i, e, n, r);
      },
      async transform(o, f) {
        const {
          password: h,
          strength: m,
          resolveReady: y,
          ready: l
        } = i;
        if (h ? (await ra(i, m, h, Z(o, 0, mt[m] + $t)), o = Z(o, mt[m] + $t), a ? (yt(i), f.error(new Error(_e))) : y()) : await l, i.discarded)
          return;
        const d = new Uint8Array(o.length - J - (o.length - J) % oe);
        f.enqueue(on(i, o, d, 0, J, !0));
      },
      async flush(o) {
        const {
          engine: f,
          pendingInput: h,
          ready: m
        } = i;
        if (f) {
          if (await m, i.discarded)
            return;
          const y = Z(h, h.length - J), l = new Uint8Array(Z(h, 0, h.length - J));
          f.process(l, !0);
          const d = f.digest();
          let g = h.length < J ? 1 : 0;
          for (let p = 0; p < J; p++)
            g |= d[p] ^ y[p];
          if (g && s) {
            o.error(new Error(Yr));
            return;
          }
          o.enqueue(l);
        }
      }
    }), sn(this, i);
  }
}
class ea extends TransformStream {
  constructor({ password: e, rawPassword: n, encryptionStrength: r }) {
    const a = {};
    super({
      start() {
        an(a, e, n, r);
      },
      async transform(s, i) {
        const {
          password: o,
          strength: f,
          resolveReady: h,
          ready: m
        } = a;
        let y = qe;
        if (o ? (y = await aa(a, f, o), h()) : await m, a.discarded)
          return;
        const l = new Uint8Array(y.length + s.length - s.length % oe);
        l.set(y, 0), i.enqueue(on(a, s, l, y.length, 0, !1));
      },
      async flush(s) {
        const {
          engine: i,
          pendingInput: o,
          ready: f
        } = a;
        if (i) {
          if (await f, a.discarded)
            return;
          const h = new Uint8Array(o);
          i.process(h, !1);
          const m = Z(i.digest(), 0, J);
          s.enqueue(nt(h, m));
        }
      }
    }), sn(this, a);
  }
}
function na(t) {
  rn = t || ie;
}
function an(t, e, n, r) {
  Object.assign(t, {
    ready: new Promise((a) => t.resolveReady = a),
    password: ia(e, n),
    strength: r - 1,
    pendingInput: qe,
    discarded: !1
  });
}
function sn(t, e) {
  const n = t.readable.getReader(), r = new ReadableStream({
    async pull(a) {
      try {
        const { value: s, done: i } = await n.read();
        i ? a.close() : a.enqueue(s);
      } catch (s) {
        throw yt(e), n.cancel(s).catch(() => {
        }), s;
      }
    },
    cancel(a) {
      return yt(e), n.cancel(a);
    }
  });
  Object.defineProperty(t, "readable", {
    get() {
      return r;
    }
  });
}
function on(t, e, n, r, a, s) {
  const {
    engine: i,
    pendingInput: o
  } = t;
  o.length && (e = nt(o, e));
  const f = e.length - a, h = f - f % oe;
  if (n = oa(n, r + h), h) {
    const m = Z(n, r, r + h);
    m.set(Z(e, 0, h)), i.process(m, s);
  }
  return t.pendingInput = Z(e, h), n;
}
async function ra(t, e, n, r) {
  const a = await cn(t, e, n, Z(r, 0, mt[e])), s = Z(r, mt[e]);
  if (a[0] != s[0] || a[1] != s[1])
    throw yt(t), new Error(je);
}
function yt(t) {
  const { engine: e } = t;
  t.discarded = !0, e && e.dispose && e.dispose();
}
async function aa(t, e, n) {
  const r = $e(new Uint8Array(mt[e])), a = await cn(t, e, n, r);
  return nt(r, a);
}
async function cn(t, e, n, r) {
  t.password = null;
  const a = _r[e], s = await sa(n, r, a * 2 + $t);
  return t.engine = rn(Z(s, 0, a), Z(s, a, a * 2)), t.discarded && yt(t), Z(s, a * 2);
}
async function sa(t, e, n) {
  if (ve)
    try {
      const r = await gt.importKey(Vr, t, Jr, !1, jr);
      return new Uint8Array(await gt.deriveBits(Object.assign({ salt: e }, Qr), r, n * 8));
    } catch {
      ve = !1;
    }
  return qr(t, e, en, n);
}
function ia(t, e) {
  return e === B ? Nr(t) : e;
}
function oa(t, e) {
  if (e && e > t.length) {
    const n = t;
    t = new Uint8Array(e), t.set(n, 0);
  }
  return t;
}
function Z(t, e, n) {
  return t.subarray(e, n);
}
const rt = 12;
class ca extends TransformStream {
  constructor({ password: e, rawPassword: n, passwordVerification: r, checkPasswordOnly: a }) {
    super({
      start() {
        ln(this, e, n, r);
      },
      transform(s, i) {
        const o = this;
        if (o.password || o.rawPassword) {
          const f = Ie(o, s.subarray(0, rt));
          if (o.password = o.rawPassword = null, (f[rt - 1] ^ o.passwordVerification) != 0)
            throw new Error(je);
          s = s.subarray(rt);
        }
        a ? i.error(new Error(_e)) : i.enqueue(Ie(o, s));
      }
    });
  }
}
class la extends TransformStream {
  constructor({ password: e, rawPassword: n, passwordVerification: r }) {
    super({
      start() {
        ln(this, e, n, r);
      },
      transform(a, s) {
        const i = this;
        let o, f;
        if (i.password || i.rawPassword) {
          i.password = i.rawPassword = null;
          const h = $e(new Uint8Array(rt));
          h[rt - 1] = i.passwordVerification, o = new Uint8Array(a.length + h.length), o.set(Se(i, h), 0), f = rt;
        } else
          o = new Uint8Array(a.length), f = 0;
        o.set(Se(i, a), f), s.enqueue(o);
      }
    });
  }
}
function ln(t, e, n, r) {
  Object.assign(t, {
    password: e,
    rawPassword: n,
    passwordVerification: r
  }), da(t, e, n);
}
function Ie(t, e) {
  const n = new Uint8Array(e.length);
  for (let r = 0; r < e.length; r++)
    n[r] = dn(t) ^ e[r], Tt(t, n[r]);
  return n;
}
function Se(t, e) {
  const n = new Uint8Array(e.length);
  for (let r = 0; r < e.length; r++)
    n[r] = dn(t) ^ e[r], Tt(t, e[r]);
  return n;
}
function da(t, e, n) {
  const r = [305419896, 591751049, 878082192];
  if (Object.assign(t, {
    cryptoKeys: r,
    crcKey0: new Ot(r[0]),
    crcKey2: new Ot(r[2])
  }), n)
    for (let a = 0; a < n.length; a++)
      Tt(t, n[a]);
  else
    for (let a = 0; a < e.length; a++)
      Tt(t, e.charCodeAt(a));
}
function Tt(t, e) {
  let [, n] = t.cryptoKeys;
  t.crcKey0.append([e]);
  const r = ~t.crcKey0.get();
  n = Ae(Math.imul(Ae(n + un(r)), 134775813) + 1), t.crcKey2.append([n >>> 24]);
  const a = ~t.crcKey2.get();
  t.cryptoKeys = [r, n, a];
}
function dn(t) {
  const e = t.cryptoKeys[2] | 2;
  return un(Math.imul(e, e ^ 1) >>> 8);
}
function un(t) {
  return t & 255;
}
function Ae(t) {
  return t & 4294967295;
}
function ua(t) {
  if (t instanceof ReadableStream)
    return t;
  const e = t.getReader();
  return new ReadableStream({
    async pull(n) {
      try {
        const { value: r, done: a } = await e.read();
        a ? n.close() : n.enqueue(r);
      } catch (r) {
        throw e.cancel(r).catch(() => {
        }), r;
      }
    },
    cancel(n) {
      return e.cancel(n);
    }
  });
}
const fa = "Compression method not supported", pa = /* @__PURE__ */ new Map();
function fn(t) {
  return pa.get(t);
}
const te = "Invalid uncompressed size", ha = "Invalid compressed data", pn = "Codec out of memory", hn = "Invalid CRC32", wa = "Z_MEM_ERROR", ma = "deflate-raw", ga = "deflate64-raw", Lt = "gzip", wn = 10, ee = 8, ya = [31, 139, 8];
class ba extends TransformStream {
  constructor(e, { chunkSize: n, CompressionStreamFallback: r, CompressionStream: a }) {
    super({});
    const { compressed: s, encrypted: i, useCompressionStream: o, zipCrypto: f, computeCrc32: h, level: m, deflate64: y, format: l, compressionMethod: d, inputSize: g } = e, p = this;
    let w, c, u, b = super.readable;
    const x = l && fn(l), C = yn(o, a, r), P = h && s && !y && !x && (!i || f) && !!C;
    if ((!i || f) && h && !P && (w = new Ke(), b = V(b, w)), s)
      if (x)
        b = ft(b, gn(x.CompressionStream, l, { level: m, chunkSize: n, compressionMethod: d, uncompressedSize: g }));
      else if (P)
        u = new xe(), b = ft(b, new C(Lt, { level: m, chunkSize: n })), b = V(b, u);
      else
        try {
          b = bn(b, o, { level: m, chunkSize: n }, a, r);
        } catch (D) {
          if (!o && r)
            throw Mt(D);
          let q;
          try {
            q = new a(Lt);
          } catch {
            throw Mt(D);
          }
          b = ft(b, q), b = V(b, new xe());
        }
    i && (f ? b = V(b, new la(e)) : (c = new ea(e), b = V(b, c))), mn(p, b, () => {
      (!i || f) && h && (p.crc32 = P ? u.crc32 : new DataView(w.value.buffer).getUint32(0));
    });
  }
}
class xe extends TransformStream {
  constructor() {
    let e, n = wn, r = new Uint8Array(0);
    super({
      transform(a, s) {
        if (n) {
          const h = Math.min(n, a.length);
          if (n -= h, a = a.subarray(h), !a.length)
            return;
        }
        const i = r.length + a.length;
        if (i <= ee) {
          r = nt(r, a);
          return;
        }
        const o = i - ee, f = Math.min(o, r.length);
        s.enqueue(nt(
          r.subarray(0, f),
          a.subarray(0, o - f)
        )), r = nt(
          r.subarray(f),
          a.subarray(o - f)
        );
      },
      flush() {
        const a = Ge(r);
        e.crc32 = a.getUint32(0, !0), e.uncompressedSize = a.getUint32(4, !0);
      }
    }), e = this;
  }
}
function va(t, e, n, r, a) {
  const s = e.writable.getWriter(), i = e.readable.getReader(), o = r === B ? new Ot() : B;
  let f = 0, h = !1, m = !1, y, l;
  const d = new ReadableStream({
    start(x) {
      l = x;
    },
    pull() {
      u();
    },
    cancel(x) {
      return m = !0, u(), i.cancel(x);
    }
  });
  return g(), p(), d;
  async function g() {
    const x = t.getReader();
    try {
      const C = new Uint8Array(wn);
      for (C.set(ya), await s.write(C); ; ) {
        await c(), await s.ready;
        const { value: q, done: Yt } = await In(x, a);
        if (Yt)
          break;
        await s.write(q);
      }
      o && await s.write(new Uint8Array(0));
      const P = new Uint8Array(ee), D = Ge(P);
      D.setUint32(0, o ? o.get() : r, !0), D.setUint32(4, n, !0), h = !0, await s.write(P), await s.close();
    } catch (C) {
      await vn(s, C), await zt(x, C);
    }
  }
  async function p() {
    try {
      for (; ; ) {
        const { value: x, done: C } = await w();
        if (C)
          break;
        if (f += x.length, f > n)
          throw new Error(te);
        o && o.append(x), l.enqueue(x);
      }
      m || (m = !0, l.close());
    } catch (x) {
      b(x), await zt(i, x);
    }
  }
  function w() {
    return i.read().catch((x) => {
      if (h) {
        if (!o)
          throw Bt(x, hn);
        if (f != n)
          throw Bt(x, te);
        return { done: !0 };
      }
      throw Sn(x, a);
    });
  }
  function c() {
    if (!m && l.desiredSize <= 0)
      return new Promise((x) => y = x);
  }
  function u() {
    if (y) {
      const x = y;
      y = B, x();
    }
  }
  function b(x) {
    m || (m = !0, l.error(x), u());
  }
}
class Ia extends TransformStream {
  constructor(e, { chunkSize: n, DecompressionStreamFallback: r, DecompressionStream: a }) {
    super({});
    const { zipCrypto: s, encrypted: i, checkCrc32: o, crc32: f, compressed: h, useCompressionStream: m, deflate64: y, format: l, compressionMethod: d, rawBitFlag: g, outputSize: p } = e;
    let w, c, u, b = super.readable;
    if (i && (s ? b = V(b, new ca(e)) : (c = new ta(e), b = V(b, c))), h) {
      const x = /* @__PURE__ */ new Set(), C = l && fn(l);
      let P;
      if (C)
        b = ft(b, gn(C.DecompressionStream, l, { chunkSize: n, compressionMethod: d, rawBitFlag: g, uncompressedSize: p }), x);
      else {
        const D = yn(m, a, r);
        if (o && !y && f !== B && p !== B && D)
          try {
            P = new D(Lt, { chunkSize: n });
          } catch {
            P = B;
          }
        if (!P)
          try {
            b = bn(b, m, { chunkSize: n, deflate64: y }, a, r, x);
          } catch (q) {
            if (y || p === B || !m && r)
              throw Mt(q);
            try {
              P = new a(Lt);
            } catch {
              throw Mt(q);
            }
          }
      }
      P ? (u = !0, b = va(b, P, p, f, x)) : b = Sa(b, x);
    }
    o && !u && (w = new Ke(), b = V(b, w)), mn(this, b, () => {
      if (w) {
        const x = new DataView(w.value.buffer).getUint32(0, !1);
        if (f != x)
          throw new Error(hn);
      }
    });
  }
}
function mn(t, e, n) {
  e = V(e, new TransformStream({ flush: n })), Object.defineProperty(t, "readable", {
    get() {
      return e;
    }
  });
}
function gn(t, e, n) {
  if (!t)
    throw new Error(fa);
  return new t(e, n);
}
function yn(t, e, n) {
  if (t && e)
    return e;
  if (n && n.requiresModule)
    return n;
}
function bn(t, e, n, r, a, s) {
  const i = e && r ? r : a || r, o = n.deflate64 ? ga : ma;
  let f;
  try {
    f = new i(o, n);
  } catch (h) {
    if (e && a && i != a)
      f = new a(o, n);
    else
      throw h;
  }
  return ft(t, f, s);
}
function V(t, e) {
  return ua(t).pipeThrough(e);
}
function ft(t, e, n) {
  const r = e.writable.getWriter(), a = t.getReader();
  return s(), e.readable;
  async function s() {
    try {
      for (; ; ) {
        await r.ready;
        const i = await In(a, n);
        if (i.done) {
          await r.close();
          break;
        }
        await r.write(i.value);
      }
    } catch (i) {
      await vn(r, i), await zt(a, i);
    }
  }
}
async function vn(t, e) {
  try {
    await t.abort(e);
  } catch {
  }
}
async function zt(t, e) {
  try {
    await t.cancel(e);
  } catch {
  }
}
function In(t, e) {
  const n = t.read();
  return e ? n.catch((r) => {
    throw e.add(r), r;
  }) : n;
}
function Sn(t, e) {
  return e.has(t) ? t : Bt(t, An(t) ? pn : ha);
}
function Mt(t) {
  return An(t) ? Bt(t, pn) : t;
}
function An(t) {
  return Ar(t) && t.code == wa;
}
function Bt(t, e) {
  const n = new Error(e);
  return n.cause = t, n;
}
function Sa(t, e) {
  const n = t.getReader();
  return new ReadableStream({
    async pull(r) {
      try {
        const { value: a, done: s } = await n.read();
        s ? r.close() : r.enqueue(a);
      } catch (a) {
        throw await zt(n, a), Sn(a, e);
      }
    },
    cancel(r) {
      return n.cancel(r);
    }
  });
}
const Aa = 256 * 1024, xa = "deflate", Ua = "inflate";
class es extends TransformStream {
  constructor(e, n) {
    super({});
    const r = this, { codecType: a } = e;
    let s;
    a.startsWith(xa) ? s = ba : a.startsWith(Ua) && (s = Ia), r.outputSize = 0;
    let i = 0;
    const o = new s(e, n), f = super.readable, h = new TransformStream({
      transform(y, l) {
        y && y.length && (i += y.length, l.enqueue(y));
      },
      flush() {
        Object.assign(r, {
          inputSize: i
        });
      }
    }), m = new TransformStream({
      transform(y, l) {
        if (y && y.length && (l.enqueue(y), r.outputSize += y.length, e.outputSize !== B && r.outputSize > e.outputSize))
          throw new Error(te);
      },
      flush() {
        const { crc32: y } = o;
        Object.assign(r, {
          crc32: y,
          inputSize: i
        });
      }
    });
    Object.defineProperty(r, "readable", {
      get() {
        return f.pipeThrough(h).pipeThrough(o).pipeThrough(m);
      }
    });
  }
}
class ns extends TransformStream {
  constructor(e) {
    const n = [];
    let r = 0, a = 0;
    (!Number.isFinite(e) || e < 1) && (e = Aa), super({
      transform(o, f) {
        for (n.push(o), r += o.length; r > e; )
          a += e, f.enqueue(s());
      },
      flush(o) {
        r && (a += r, o.enqueue(i(n, r)));
      }
    }), Object.defineProperty(this, "outputSize", {
      get: () => a
    });
    function s() {
      const o = new Uint8Array(e);
      let f = 0;
      for (; f < e; ) {
        const h = n[0], m = e - f;
        h.length <= m ? (o.set(h, f), f += h.length, n.shift()) : (o.set(h.subarray(0, m), f), n[0] = h.subarray(m), f += m);
      }
      return r -= e, o;
    }
    function i(o, f) {
      const h = new Uint8Array(f);
      let m = 0;
      for (const y of o)
        h.set(y, m), m += y.length;
      return h;
    }
  }
}
class rs extends TransformStream {
  constructor({ onstart: e, onprogress: n, size: r, onend: a }) {
    let s = 0;
    super({
      async start() {
        e && await Vt(e, r);
      },
      async transform(i, o) {
        s += i.length, n && await Vt(n, s, r), o.enqueue(i);
      },
      async flush() {
        a && await Vt(a, s);
      }
    });
  }
}
async function Vt(t, ...e) {
  try {
    await t(...e);
  } catch {
  }
}
BigInt(Number.MAX_SAFE_INTEGER);
BigInt(0);
BigInt("0x7fffffffffffffff");
try {
  Zt({ baseURI: import.meta.url });
} catch {
}
const Ea = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258], Ra = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], Ca = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577], Pa = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], Da = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], ct = new Uint8Array(288);
ct.fill(8, 0, 144), ct.fill(9, 144, 256), ct.fill(7, 256, 280), ct.fill(8, 280, 288);
const Na = new Uint8Array(30).fill(5);
function it(t) {
  const e = new Uint16Array(16);
  for (const a of t) e[a]++;
  e[0] = 0;
  const n = new Uint16Array(17);
  for (let a = 1; a <= 15; a++) n[a + 1] = n[a] + e[a];
  const r = new Uint16Array(t.length);
  for (let a = 0; a < t.length; a++) t[a] && (r[n[t[a]]++] = a);
  return { lengthCounts: e, symbols: r };
}
const F = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function ka(t) {
  let e;
  t({ wasmURI: () => (e || (e = "data:application/wasm;base64," + (function(n) {
    let r = "";
    const a = n.length;
    let s = 0;
    for (; s + 2 < a; s += 3) {
      const o = n[s] << 16 | n[s + 1] << 8 | n[s + 2];
      r += F[o >> 18 & 63] + F[o >> 12 & 63] + F[o >> 6 & 63] + F[63 & o];
    }
    const i = a - s;
    if (i === 1) {
      const o = n[s] << 16;
      r += F[o >> 18 & 63] + F[o >> 12 & 63] + "==";
    } else if (i === 2) {
      const o = n[s] << 16 | n[s + 1] << 8;
      r += F[o >> 18 & 63] + F[o >> 12 & 63] + F[o >> 6 & 63] + "=";
    }
    return r;
  })((function(n) {
    let r = 0, a = 0, s = 0, i = new Uint8Array(1024), o = 0, f = 0;
    for (; !f; ) {
      f = m(1);
      const w = m(2);
      if (w == 0) y();
      else if (w == 1) l(it(ct), it(Na));
      else {
        if (w != 2) throw new Error("invalid deflate block type");
        l(...d());
      }
    }
    return i.subarray(0, o);
    function h() {
      if (r >= n.length) throw new Error("unexpected end of deflate data");
      return n[r++];
    }
    function m(w) {
      for (; s < w; ) a |= h() << s, s += 8;
      const c = a & (1 << w) - 1;
      return a >>>= w, s -= w, c;
    }
    function y() {
      a = 0, s = 0;
      const w = h() | h() << 8;
      r += 2, p(o + w);
      for (let c = 0; c < w; c++) i[o++] = h();
    }
    function l(w, c) {
      let u = g(w);
      for (; u != 256; ) {
        if (u < 256) p(o + 1), i[o++] = u;
        else {
          const b = u - 257, x = Ea[b] + m(Ra[b]), C = g(c), P = Ca[C] + m(Pa[C]);
          p(o + x);
          const D = o - P;
          for (let q = 0; q < x; q++) i[o++] = i[D + q];
        }
        u = g(w);
      }
    }
    function d() {
      const w = m(5) + 257, c = m(5) + 1, u = m(4) + 4, b = new Uint8Array(19);
      for (let D = 0; D < u; D++) b[Da[D]] = m(3);
      const x = it(b), C = new Uint8Array(w + c);
      let P = 0;
      for (; P < C.length; ) {
        const D = g(x);
        if (D < 16) C[P++] = D;
        else if (D == 16) {
          const q = C[P - 1];
          let Yt = m(2) + 3;
          for (; Yt--; ) C[P++] = q;
        } else P += D == 17 ? m(3) + 3 : m(7) + 11;
      }
      return [it(C.subarray(0, w)), it(C.subarray(w))];
    }
    function g(w) {
      const { lengthCounts: c, symbols: u } = w;
      let b = 0, x = 0, C = 0;
      for (let P = 1; P <= 15; P++) {
        b |= m(1);
        const D = c[P];
        if (b - x < D) return u[C + (b - x)];
        C += D, x = x + D << 1, b <<= 1;
      }
      throw new Error("invalid huffman code");
    }
    function p(w) {
      if (i.length < w) {
        let c = 2 * i.length;
        for (; c < w; ) c *= 2;
        const u = new Uint8Array(c);
        u.set(i.subarray(0, o)), i = u;
      }
    }
  })((function(n) {
    const r = (n = String(n).replace(/[^A-Za-z0-9+/=]/g, "")).length, a = [];
    for (let s = 0; s < r; s += 4) {
      const i = F.indexOf(n[s]) << 18 | F.indexOf(n[s + 1]) << 12 | (63 & F.indexOf(n[s + 2])) << 6 | 63 & F.indexOf(n[s + 3]);
      a.push(i >> 16 & 255), n[s + 2] !== "=" && a.push(i >> 8 & 255), n[s + 3] !== "=" && a.push(255 & i);
    }
    return new Uint8Array(a);
  })("zb19kF3HdSfW3bfvx3v3vXl3gAEwwIDAuRcQNZQ4AClRA4qkpWmIg+EQhKh19Ier4ioSAkcS7gMBvvdGIOWlOUPxw5BNaRGHUdEOa43YSqRykRUmy93IDncFr+m1dq3d0BttLROpUqpYZWsTpYrKslysFEOGv3P6vo/5AEAStsMp8N17++v06dOnT58+57Q63rtfK6X0fzp2r1lZUffqFb2CJ71yb7DCP3pF8aO6V+mVe+2KPKp7oxX+T6/cG6/0H63/1Y/olXtD/zX49LFEW6W1jSJtdM3UNf4zxtSM1irQQVAP0yAIlDKN0NjY2liFYRhqYwNjjTEqaupQaaViZZPAhvoBXa+HkdZfMV8xUaJXtHvhO2Ea/5ml6P6l+890v2xU4+Tpz586vrz08XtOLz2okvH+68nTJ5fv6R5/UNWaI99UmvXfH+ieObHU66nGoJal0/ep1vb+66njveV7Tpw53fvS/Uv3qSz1CdJYVUrqHc+GX7npLeMjn77wKycfUFtb1bd+6/1aufFt1dvatu9bGm67euO2J7LhV2572/jIJ257e6v6VrW9o18r2t5pP99dWlJmW/VxDQjR/cdPnTpzQunG8aXePV+8//gJBmau2X9laFzWf6/auWNQAg0tppzz5PFTJ39lSamd99xz8vR9J7tLJ5bv+fyXTp9YPnnm9D3Lxz93akmrnfcs3d870T35wPLS6Xt6y8dPtO/pLvWWz3SXVLR7XdIXlpbvOfGlbnfp9LKKi3vuOfHQ8XtOnj7RXbp/6fTyPUsPnVh6gCvvLn3+xJkvnV5Wd9ZaWjmd1tTU7ubk0UO3fKL+0rPBMaPS735Qpyv7lMvaRX2/MnPr/0i51/UxO+ce3zZtVBG4jJRLS/dG0MHD4lQRueBsoc4W2gUdixLarfSc7pAqC+OC5UK757aVhSI9bV7cVuhpkxThEa6RAvcImQc7s0Y1dEohqVnTIEXhrElS0i4pc0WauBbjgu6ssXgtC43KrNP40khTitxTDF5yrKlJAwpnSKGQItPukia13PkiQFwuFINjSDE4ai04+sFOEfQBMgDIeIAURR4IRVFZWOL6NEXtIhRYSJEukVtRYucocQ910Fqu3TOALzdmhQKnKXHB2eUi7sz7dinuooxGo0BQmgfo6KxJKKhg0PITCCiMG/fMNrKzRrmntnGjjTR15xgR6XxTU/pFZ5anzYs7CgNsPdShqJ1bMrkOeJymTVaoectPE4Wab+oUWPE5C03Atl0s9FSOnhnSU7khlQPMlMy0mcxrZPDQKNSCncNTUuhqFPWsSRp1zjhRaLtCxk2UIV6zQs83AzIuK9M8DOYozGPShXITZR4ChIlCNxUpl/n3DO8pxU6hl7XUreQRKffdlaOcLS0L7R7q5JHvfTzfVG5vnjglPVbu9bffjo/ZOYrctaCrs18oVPssE6nTy233iTJPUk/wSYU0jdFROSgBPxS5nZQ4fbbtFCVu78LUcm4qRFY4C8je3VSk85CCwjaVU7klnatGAPJhPAfEY+uuOetsp+S+HZkiRcFUrsg4vZwbQm9RIOwKDKEzlIB0Fal2l+IORisgVQ1wrlLi8QvmhkfQkF3MNRkMpIxhiIcKpXaFtKA7LRS3GM43FVmZTBS10ZUQw5xQiAc/zOH6YU5SfJVhDnmYw/4whzzMJpgjA7KWYTZrhtkMDXMgwxwP5nUIDiRTSJk5Cpk8XXa3nZOpaEj3J2BYAiQ1mK2YVIrC/tQNR/mHU7lxKtcpZhFKYlYZroEnWaMGOM4zHGbRzrnz28gwAMj77Db3LCcJHCg2DEyfYVRVeUo6WBbWrLgfTU4bZefcT/ALOvvp5OGVQ0a5H08eXr2wurq6avH2o0mqu0bpHui4V3//3/1+2EPLr00ymtxF/7tKaaHLInCKdLuIO2BMx5qJe2mSMWjn3Iv8lJAuixolxyik2mK3WUvNnLs4OaOUs2BIFef3/ULBlydzJZSF4hgMCilhSisXmwFzjURIyKksLIxbOdIMSOeB+zG3qZxuFyGZDpgNmTZYasnE3CnzIKUAoAYeVNUHNaSgLGIKj5GieLHbtCkFWVgoMgtN3QhRzrQxG/CVKUgJUEeamgxPCkCiKXI3lBQAbpWbhk0F4ZgfFLRLXiQ6hclCyW0oKPOAswYpGbey0DQp8HwRpZwFr05J+45yj9FOFzzyWLcZ4hesIHLT5bFmmLoXJ6VD6A6P1Xf4TYGavjOJiaTSPsLtAOHSJUy1aWOLsDzSNANUoxtPC+kBk2SOTYFZPC3Ey4TmvjeJ9UK5lyf5o/vmNreC329vE9LD8ytCPxhfWc5kvQ5nzYvbSGNd+c42sMmyUI4WmirFBAjcdLtQ7iEybQdSayM/ZoNfn3k1o8GqaEo3jbl2YZv7mW+4YVNwpmNYY452pWcNl3TwRAGFJfI/u42se4gst6KkYnd+m0xHoNOQajNOscb75gzZDZoLGCWNSH4q5JE5OoQ0GfqQ8W/msDD5EQDb85jXDQPePKMA7HwzSP1omblqtCwIDWsn02IRLvqFNeG1ZBP8xRvgL74U/shS6D5IISoo3cF2ASKwLisXpwrtplhWct+fvM6oQyYj7V6Wx8R9f5JFK7S3lj48LZB2k6VMeRdX7IuUs5DHwkXwaE32CBY6YaSPdJCLxYV2YTzULMAog3X/bYiQZCpxSJkVL09qx+Ld2eXCVMKQJsPCEEtgioUhjZ5BGNL4abhGblwCdrmXl8y3/eJu3LVkNlzcVUoW02w32cOMDuXMsntxR5lrZnUiNoQOcmIRMCTnIJaFIpaxkAVwjNuJSlkEUCIC8KquRIopKknA8Ex115zFWoslXWaD7ZRFgGUu5GUO1WaATM+aSZfkhmyhc+UalRhYcLcbAkAiXUh4Yk/mxjVSsn6tA8ULG/ELlQJDxUzBGvSeliqbutVt7gYUVJX8IqsikzUFJU+1ioTLIunXoN1DpOVjQBElZWHbeVwxOAogbT/rJdf+XI6FNaKTXq7XqSz5UmAg6nrxZF0BEIlgAfgLwDKVCzpOH8HkhXxYw9dGbnhbIzQZiCxjZAcgVOkeASs8K/sSkwohexE88XVP5pEBgw4WqkpUlUtJLsPfJwplIfNDJApE4G5qClgk0sEcS4qqgGScaxGJVFOxZAzBjQuAVkLn+wVpJaVovqmk/t0FSBmE9+IORhRp0LUMlWlqd26bUDc6VfUIRSmaNhnyR8iboVv8NJGS4Z2AoWjWTHqg7Zx0LBMqmEx93yAvcsJEPyGmWpnHFFCNid3mTOqqzyMqpmYpLglcj2I/FvHG/CF+t/xBJkpDJpbnEwateD4Ru2sp3pBPGMxGM8QnTMUn1BCfYKa1XIQVn9CeT6g+n4jdTojyzCeM3yrw6iBjXlQyegw+ga0ABltEfzBf8ImwLw6HfT6hMCC26qP11KiEhK2I48IpnM86hIeUEpnZPP6JUFAICtKgIMMUhJ0wGaYgnlyKKYhivzGO+/QTUuLpJ2G6ACD8NOF3IqQoAQzSDxbUNeiH9w2T1XYB9MMJE1WCmSPrWiJiWjAqNSy4C/PpMwjsBHxyiLwB+TQw15KHg6ynLrsxddkroq5AqCsAOgPBajBEXdyKpy7rriW72SoUyCoUbLQKYWaw0qKiK1OpBXiRlgYnAZfddBkS8qq2+7a/DOlqGTKevOLBphq1Z6JnwLyuOhl48jLC3IKB+kE2aJOVaoL7hA2gkBdzvpqQl+mTV8jkBTZL4TrySoW8+sRlqOaJq9Ynrtoa4qoBArMJcZnLEpdZS1xmPXGZPnEZ5A37xGWxybTrtDzKb1G1WRnoeChYq+UZIq3A759lbBvkN9VatDxY80Kv3rEinjKKU6q7rNyvSKX/W6qTFSxn3FeXYNuhnG0LdT8EmTkPWSenOxDXnOnw+gP2rSB2BiIGLzY1665yrwSsVl6/ujWgk6ikOFnu7ELTDK+Yur9ihtUCObI8ji6i1i8genRxZH2BLI42mCPLaiFeHK0f02pxtH7sh9RCATMVy4pIFyw0A+CNySwk7ZefoC8ssLJRtTzDB2DMT80GKywTsB2ssHbTFVa/5xVWM2Y9EQ+tsFpWWE/E1RQNvWYGndUdBtVrr3iEbSVqhV7UCkZELeUlpwEyAhnvhSYULqJOeEZ+W14Iw77fi2HBiBi2vjLsyyrkggZJ8bZhlIpYh2TXyV0jVDQ6MjYVXRTIKhxSQw2TVbCpGsp4NdS7JyuTbkg//V7KxnJAMuEakgmvnGTCKyWZcBOSCTcnmXVwU0DJQlNVk6SV9mVi1Vdb91dKi6WJGZqq2Jkiu1Zp7ZeqhFS1iOjBAtESMUz1F0rlrgXLOvuFQstCqYfEsEDEsGCNGGbNipkzK6OCWDwQxITDWqHRSb9NJLWROGbBqpkc+ts21RfHbF8TS3awXtrBeonKSefWcbeDoo+FwkrfBRNuMlfY2TmV5jFrF2Td8JjhwYi9ZuabTBEaeoEVUlNg+OlTqY5XhDOHxqsYLHbYHaZY4eZKdFnayxHIBQWUX4686qKRB/2NeCAy41oWboYnn5K55tcAzm+qUTV+PvJ+xdoVUjzXWINrWTE9pPKNyRaBqHyZo9mmYhYv7xVSR1m4GWbhWli48VNQ9fesIScxC/eADVh40J+PCvPRDOajGsxHEatG56MZmo9qaD4G/fkY8HwMeD4GMh+554Yxi3krctKkR5DBfOSEiSqhz659bzfi2WqEZ2uvFBr0Xr0bnq1GePYGleHcymMTahomJuHZA7LxPDtYw7PNKM8eHooBzw6GePYoHVU8247ybDvg2e+ejphnryeYfi+FZwejPNtsyLMvRyPhldJIuAmNhJvQyEZwY1PlebauFlgZG13xbNPn2Tho1Myz9WB3EzCDNJVgn/LxkJLdjT/QMYNzHebZARrxPFv3z8+M8GxT8WxWEAXg2Up4dlDxbDO0dcY6EgxxbOs5tvH7AV6umJW6nTgpZZYdCMsOALESasA4McvWYNkBWDZ+NHKBd/dZthGW7VUX1iPW91SWJawE/fMs0bGRkh2OqnbVvIFOb9Cahe1CZ7rwIrdt4+QkgBBGvBPB+cubKZ/fpYtYQX824ZX4Li4hkhuWssmw1l6z1p7UJ5XLlo819UDrttJK3c8mBC86jRSp/Sq1ap9Kc61X3Msqs6xbUs7Mmv1YnWcNkQqdStNxRTjYdY/wqv5AVk//y0BHK+5XsIq4byQA+UYQ0iNQP0lHlGdkVAT8Ydrs97/TTrsfHaJgPFCFQbUPt7w2cDd6MWtursbPOC0fX3xLzRoLXGXXiHRK2qk7RGJxDxwpolnz6iE5qtIucy2Kpo7msehYFdKwTz3rwjLHAR1IsNWBZMOkkWC7ovOAYpGJglkzLWJiQxqUSm4iA1K8fvgbSU8TodIJsrx5tE53Zs0NqRS4TbLuf+cNR3APsARy+MW31CFsBQ8/Kt++fwhn3+7FOgvAD7xTZnXVutVVQ9EU702Bks/Kz2ccy1fTDCYwO648ynenFPLgZrV0CxME+sO6fZuNpX9wh8lXzCP7lKN2MbYfAzZZYZVX9aLmB0kV0bws1NYfN+xmPUARuO++pUStc5FHBT+YrtqF7XwvGfcjVeZExr0elvk2Mu5VVeZTZNxrqsx3SRfz7UhXZT6OSTgHWWba3CYnybbYnSeyBDbzLcPGIzgUcb+a240MS/4m/igA4bXH9oZRnNQOHLzhxnraaI61svHATGzThdo/tct+/JZbb2Pmd1eeNor+0xQ/ncobjUyeihZ+7uXz+tbiVJ42xjihkdvGjDwVwfwQXhsHcPwei34hmW9+BNYC7TyhaEYpipcphDVD5HSZR9A/lkzvOO42nXkK3e98wyx058WMYloqbs2aaaxUWMwU/rI9BfPYMeS+VWNDMuZs6Uy2hxfqf8yQyJTY7VQeNw4wqPtxrEgWp383sKZm2a2+FXTwdLZ0ex+YB/PsdJiC3O/VmX7dn1fdotC1Oi5hQdD9PF2fas8WASZoHb2yVHfxMe5FkdoVSkOZm9NkU7J3d5pbKXY4EYAIM1IZBXnYmBnF4o1XiEU20pmg0L2tNwN1BqCuXoSZEin3vyZrExlPAa/QwAvzBMVrvFu1zOANTv3kccwltyhLY5z1FhWKIczu/nDw1Dbun8iUgwmHymPp2l7ftRuutGtDcM0ayxqyGbWNpf9RmDh9BBLbh+R/2ACSCskH3wMkLjkrUhyjHOvjpeACrW6Moe+MwiUb8sCtJhimkHdoFaCsbBuB04LcRuE0qCchm4eNG3kZZuK7XWCv2zmq431CplUgI7tvAO0+GiO7MbSNfRUGkI2VoFlj3+iYzlw5ubrJZVDWW0HHJctdITk/KSfPdrsy0VmmuoGM+2fr0ZTxdKWmyDY1kVQSf5onUlU8y+rUcNbc5kw+2bgx7XOSvWsa+C43kNJeZxabHxLxsJkA5m5epygPKPGDYVjNPd+EIlrDvioY7muAvgZUH+ook4f7o7dUngwx69Dps3w+1x4LlDZBKgrjVw8VdUjikXttoizSacMmapF7c7KE+IdjxtflMZLzsCiYc+c1J5zng/px4Hu5dMmtWnnUA5Rgzq2aPKLErRrJlnC2GrIlyJb4bM8Yru0ZM1xbvLY2StyFkYqS0YpojOpudfyUO7+zhLyzm9AvAC+jM+ZqQIumcXfB0JjbXYKplLSN6hntAhFzGzTcRLimCa7xzcmSxrDeJ1ItrBWdeadaWlcrpbxB8oqkz5A5/NXV1dVX1CHzS2RAO58l4/5UmLF20UIzwPEbeHXoApxmB3lENk8aM6l7GeMp6pXnwGjBSfMklXpsuknBD6R8zpdj+x67uHOWj86tn0BrZrgdnT+Wl5fBDI8bH+YZHrq33w46BVjRSs9lZ4X7/2ltZG1B9g+A/P/50Bp5ezWhpLeqMY0cf+yngpk2t3t2BxV9sjhVBNSkgJp4mm9+kGrY62W5MIvbKWiD0+DoM68hYztH7giwJ3hLmIX4qdYohHU0Peu49l2wjr2dd7Z3j5py1tzH7+FZfLJOl7Pmi/ylfhZrti2LdNbcS7Ebk7EYO8vnAYG75pj1042s27PYZaHR/d4Izlg8cn9ScZ6WyMWnUjZ2SakFRcBWSil1W49NiS6NUtahUQqDoWDWnKJxPC8f1OcbTMEKFBzkaUOlvF/flLskV8ZdWmgokoZaQw1R6OIO2holwyhv9UlRKtguUvp2keHjWZ4J21lmzxtO0bjbSrtoirYJtjIqdjB5/dGo/JADVf/Ckxajyal8B9PQfUWGny+WeSuYowa1YPe1gk+/tOxWevlWPH4mn6Aor1OCbQ2jYoJC2tpxZrksds4oXaRkj4IWgZoAqAmoPjxJ6kBNvZokOgU/3XlQmyKpjrwaQ7gSJDHLspQyhigVDMH+xKywplUMYrP2mFHaYKBNCX6Lw7NFgYWuDJaRRiw1RNL86ugUrUNR5NfuD4I4DIpYZwCXZZ1gmScMOo2XzrQPatYZpvg+CtbedwGWJxBKz7IxO0+6GG2BuaUuXlv3nndTdzxUdyx1v606Li1T2CeneUQtSqhRLl4CISJkJLwOyLhFGDcMZ97wXMNTcwPzs1+Ovx3Ur1tB91ujs5tAsrUBwftZgBWJsg1p/r9O1lcQzZpfFv73wKz5LNYdpnkGE1RPu4jWVfQfN6joTys+s8MzYxhPN65F0vcGDPnVQ8VWSlxrsUtN97hZ7DajK5eBqEbNssjcY6ad78QLbWmXec5GSuCQ10DzjpW0MZibjWlzE28CG9Pm+mIPfm4oCtqzOAWTbf78y3kLP5/N6/j5TN7EzxzI/GPmtnwf3m7m1dy6m7sgAbY6aJs5alJ0HWjo+Sdp3+PFvm9VEz6eUUrEXzn7jmeUuUVBDR6DFbBVe5P2UfT8ufWlaqCL2nBBTTXM3Br0bZuXz2Mhdp71DbNCyqww4XOZEGX2Ufj8uXwfvqginOcT+go23yx0vi6D8B4f1CaXzWMRs0lkzHV8y61QDOx2KC3zlN6pDpWm1Mpjqos8QOFwPu5dCCikBilAIaCIuTGzgl1Cp5jw1pd5TJGYStzcxfMAy/m+Cv8uLjH/xig8qI00N8HNsfXrboppQlqb4NZqlLdhjbzIXi4hxXgrjjUVxvf7h+Bz8Jf1RiRnv/HdbBoTUNwu81CsY/bg7Khd8BeKKb2bt0YpKkqhkqqhUsqyAoZqeUxJHkJ3mS4ymn2aL4H8feEu25fXIAEmecyCYB5SRrW2O3gXvAcobDNO4/lmneuplTNKDUYMdiftPJYFmdvJ9uc1mPTjJRWAYI3Pr5wWpe6H4M8XVacZ7KI6Y5BJKJRqQiSBPJpMBUgSBIf98ZQVHLIQhY46Tb3LfTet5MjUm2BEdA2wVKOdMKJNB1PcD2ERidp4J7r7mCkLzwiuoajtxsqCOUGDLIxsA/CBhoARMBjgCKPqLLac+e5baqF5DQy/Z80rhxrXgAP9G2HIfZlVhNi4sTtl5pFHjT3VE8Ww/eAOXpOybMnywAQ0hIbqy8L5Nt6E/dO3lMfI6kXVmfI7vsZOvzdqFFYcQoCckX3nnisUHhVtoSZbiUybiVKOG8y0IbbnJD7sLOrzYIxHujK9g3bOjHd33hIgJuwctQim+HtEJ98oUCyvY8AkYS/0i4aG+oYO1FktgE11eNndLzc0dYQ1038+oo+iZr6lsSvtC+7NfAsG6H+SlWRHSs35Zo1qLJCDyKvVg5pAULNiUzu8pvmVQ8OiWCaiWGuNKNaikDLhQo1RUcxeoSzQAC/MQIDgWQ2n26yoGkM1ad5yKk8FfRnPjQm3Qik1SgaqwQwR4mCjQ+lZBiMDGC1Ky8V3BweLYbaS9bIZpfIGZQwcRixjTQlk+xKoIUstkV9ayN4AzKJnNu5fC8LH4B1DHf703Ur8lYnDSReVqNu+O6qLgy7V/csq/17Xoq1TFHXACO+qxJeUUhwCDg0F2+Rb4YjBPJ/8XEmnmcRfOUSpdMpv1kLg2PP7Fvo9KgdXMpTdYF5PbvBtxwbftsseMudT1X9V7Ttbs+YHh1Ihu1+WEcbjZzcku0ZnMN7vegcgI9swczzSRSYuU4wMOWxpUYPpbSvTWyb0ljGStzLNV/TWWENvyXuit2oY8pjnQZ7JvGhQK+dhiqshGh2KrE9FP0w3lI/Hgd8/q/CbQRBgQmJ5+I4BPQ2hl1I7SkzR+yCmO4aJCS2Owo89TT2PAOT3vSTbbLLuqtkY96z9jsJ61nyU5Qt4JhVsjnTDMWGbLGIQhIyRmdRKDVMShFS7KMN7M/53va+jXfrT3ptxsNQuUzkjhW6jTpbqi1MFhEELrUZep6Zr3QUtqWMFbI2C65Q6xMJCAmEhwE8AzZP16dNKzXK6lXTr041PP6jUrZxuJN34dBiuGWQYkUZwdl+jgOrZB0SGFSVMpXZhAL1cY3m0RO/gq1on24gOQYQS61pH0eG7eWWrgwe3OqxPGNJKosBYorQ11trAApia0+0blTr86FceP3f+wsVV/Uix75CCvLYPiKljibRe6yOwRJLWz2Jdhiw1mCvUBBjIbQU+mfZBpbJraey6IGEpc+y6IBsq67VJAdWPNGF6OijhG0b+fJ+U3x/MDZreL8OWCR6yNptIgJ/127btaaWyD15R2wENl3hvbQeCzqR9nVIjOBxuyFSV+4z5vuGK921YMRONhaRSz4MAArg9xuPNQ51yLVTDQzLSKpOQlcYtzAdkjte4NgoqGvTvTJOeA4Am66zua1Jd9Hz1hWajL240GhusB2MbfGtu8K0x2MInKSs766yziuHhLep/9weDPfFEUffnJQyYJfgKsbaSWQmfWaRgHikOaRv+aRL8fBpn4O3CgsdYapQEfQS6Lhb0raNT0G5Om4m8ziLcBidh/qAEilB/plMpQws+eBHNp9eDpmSbQKH7wyFV2e39oyN0gn2mk/lmIkoXTGjMUH+Agxbr2KK3vDR5e5HiA93NoKSsAr2dJRgKblHiToyxBcUni1NNtfk5Vb8n1amZrXS3lnsw39TwBq7OgJScAfEp1v+4YXeyoe7El+rO/rXdmf5b6k6yrjv70Z2XhonLYtB5tRycGMZXtt8Q2CqAQiijdotQ//ioPBikI0db/pQR5iQ3gBJdTY5jr0/XnoSvOb/iPf98k0WNiflmOLJJCq9wk2QZXk1cC8ElWLk/HFl1GUibB7yF9YCL4WGS0g6cUQDQVySv0zmMJa9USeUXIqzgTcU7sSa7gtkiQo1HYfvi7EITp1H/mt+9uUcwbW4W6TzwZjuwjJtedlnp2EqUYMETwV4nmm8atjC/vki4AOxebuDYFFwEG+frMXosktQpuZsN3GqUtCnJcqGUm8SP4PpZc4O3eoMUEpdUo3qbEug1IqpTRPXFIpkqoixnHSbARBY4JkZtwmc2kVtTHb/cBMcLxHFIBNj6whRnhA4uofrdbDUH9sl2DbBByZtsk5JzvA6YrdJuStqlWCVzb6J1e9+I974VoQ42vzCwQQSJQPa/dTIiak3wKXJAUbYHkMrj3lQO+XhIb2ADqWl41sMgDGepU6Vb1fIMx0QY5eATlALsxvPP8QHHVpwwC/HN/X2yU+LXy0BNga3T7iNTIIAjU/mkkNm/9WT2cD6JtZ3gGjKZ/nZNN1bEDAwGS2J/dHM+hp/bCJEMzAqN8V4u02J4NXc3Mlden3wK4GB8nZbs1IpwLzlLD+2ihl60oANpmjlqOfZyodStGthmpc6WxOdaNezQoQdnj3unl4/Bl17Jgt0seW+SSlZkKxKXoYIaOJ7Tna4zbAFZoxSRABLvj9OAyq3yxokpyTARvf1s4wjHaMBjsyyalB5j0XCD+hJp0jskwlm2csJOvLPlM4Man6pqTChdbMKFNJHCvKXasP5m39cxgTNkIt6OCTznvMu0yBYoSElVlPPGFA8HqIixVWB/oKb3B4q9pyHwUCTOdJqaHZEA4TgghBI/bedbkKOR1/kcR0xFGzB3jKm+xow3GXZ5jakOLlVHO4lvZ5L1F3VqLAxVMpLL8PeJIrYr1GBT3gYEjhi8tMGmvM1gjpp5QnFRhylvE92cKGIsghDpmlj6MrzDW3Hg8lpPKRNL3Qafc8M+IGZLXYwNxWypWwd266OWusmQpW6DMm+pmyEvW+ry00QK1RRP5AxMXoDmOR6DZXM3J1PfN16xkTDRT9giy6IfyfEBEYyPjqQM94aUuMVT9roylNCWDHIzVsY4ZbiwVDFiMHXZAnCXe9g9BFsV9vyKXdCZYg0l6sJxbHx0ikvWaIziN+uQI8YyQ7W0GPMM4t7KpvM2UjQ2a25OCcbKYzBIlAJsDJtVvh2c1wqPvVmUsCFF43B/41hBYMLtWd7Igi232YQYPh6Ty930Po3TBbviHkHu7BrPbHfDE+NmNpJeaysJ/qu9CaVeY0LJ0VsYjsyQygzp0D2Sppk3gvWml3NrrGJbWX3Nl866L3uzeloXO/lWdlf12Bk87s3uWmu2GWZj6X/4gG6Ko8ojpLJZmFoe7TbVrsqFo+GNNneLW7BFlBU24vQGrvaILBPW/Xa44I/mf47DO4ELpj8iE0xjbYJ18nR/A+vXJ5XdzBllU2ArkWRl1kxXLk32SJd9btyDjr2Oj06VbEPN74Gzd06Vd3abMOu/hMmldR9aYNPC3w4XxBcFlkGNLRIgSlSFP2fJTEJBrWrXWHarr+k2S03WG/1op+8UAfgHugicuaOp3EVIzoGLFpsKS+dF+M1HR6ZyCRxCYbcIHHWJV+eX9FQRuL0PUNB1e3vZJ+WbuK0f1B/BBzzckH0SuPTKdxEcGTrGF1DnZS00Yt3HwSO9uOntz724WZmpaZYjOCkp3V5WOG+c9hv6EonJLarvLytGpRvnU5eo428qzRlxi+OBqS28s2pYZ0WQ4WGbgk7nDj8sG9VC9hItBKKjHx0Epm6h1RaLqftz9hDdnbOQCbU/xMGcpcKM5wBXXpPKGeKabzx2asFBxEqmugx3MNV1HBpsqusyHI9NdRmGabObZfqqstBDGvqKgivLxeagkvGgjq6guhkVXz7X+0U+g924Amg4QAm8crHnvxJcTFwZLkIK0mlzPVssqmlMIcjmKIbN6Q1saDTYQhNHXpJ5yEzmT1R7LDS1Wi1gRd4PFSuk3F+phSar6IVamNcPejFHwUE9wTJ+G36jAFbOEMR6mzfEd8uMT6DukB7xIRCVrB4q+tZdjYINjCXL9fNgQKJIHO6PLRG2oF11afhorU/b4irUziN/jtdny410E0CiCoYJDnIwAgY0XRuBEQyBwRjlA5f+3nX3tNktS8NEHgtCdnsUidaZBavI9zRe30Rc8nm+b6LPPUNfkxdacXgCHYRgwhMIUShaELBxTzJ9sEEvgddq+D7KuoDIefGxploLRTCAYtDRH6rKUJrr2F/V8Tff1/3voa/vpad/NTyU18tQNip9jRFzogpQK9Chss0B6adecipXa2cFxlq+HVTEHPfJOuo/hf0ngYY9Vcy0eRn+1+ykzefvvx0eaepK5lipuJ+sijo71KjSPBM0lXWacT+Bn2zQT+R6TXbrcBuRUMnjB0SJoqXDz4G9qk9bbu2cpqCEH5UIERS0nc78mv+SnjXPMcNQ2c0ucPwRctaU9E7Nmhe0r4Sz90ffTJvXZryJ5mszcgLz05nh5fc9JMvQhexsh/AnwUFEei1hHWak1063Z83LuoKeFYez6BXXiP+/PnM5NOAcyakNUVB1n+PxpVIpq9+uBKuXrnK+GQhOX90KMzcZXbY9FdNE6V8RuccMn2oOcP+SFrspDL2eH8q32GnGFK3PTJEzR5t+3FiTN0wlRyp57GpQSdxHUu3qICn2KmkATkPmIRxgqcApF45+Ez7WhNKQn3T/ySzw5vsrpsybzgwfhYkHF841xPaKEgn3E3IhI09w0pYnu9C08hQuQNOKp2ihGclTvACVMVRlOHsKy6LG4OAY+f/RixTmASujYTnEp4ARnnBgCBIIYd/pLctwyMg+w/AN5NPC0EXe3C2E+Rof0NSo2UafOABZQBHOQqoBf20GgSVdsNjUu8Q9QeYUzyjEpdTDU66fHG44I9clo+Z2Iawd5hIz6sJ5RIOgtHSPJ2vmaMNd+E0NZ8z1s3favKDZpcsTqlAxW5i/LJtNYS8ym5liAZAc7sbMdTALg9HeBWvA7ycHG/ZuXTKFSOaxeZf8Jh1lOOp9Mxw59UOEhsA1Trk3tsInZNyotAjcIx1nxOXxt9ljigL3qx0+cec9cTPaNSwwBk4v9Bcc7IjbY6FCWHfN1rPnDsj8fepAESx3Oe5b4MY+zUwhulWfO7CZ5B1tvu2BsvmrB7xsjIpds51bZ1xGQfsse5iAkEq/1501Tx1wv/uUPqhlLYncBX5BTKLlbuGhYG1t0CZ7x2ADWS31dgOY1qYNYIIFp4csbJ/l2hGR02Vt0czbMgVIZLKD3mWXhYIZ+JsviBDzLGsWOA7qO409rYuwsv3nEFCKAjhJC30/e2CwWnu2y78YdPyCeip9BudhGUI0JbATZtqYBCXdBXNElmRAFqa/sK0fAN2XeTbPUsk8B/VH8stUNKM+ml+2reT9ZRmAU788OOmls/BhVYvnj8vOjqpHZJJNIq7sndY7qrf7cbXmU1aN/YTVUX8/3a31ypDKLNs1pIhL/5nWwQo0YFD1hX0VH7bPHCvlEpo+zURz6QznL5fhnH73ysRfZeXXz9WRqRSO2TozaY31e6cync5zbC/EWfFu89OG1njL75ZgDqwrUn4yWPeDt1Tb3bvIcKXP1ky8Ej9C2qsnzZx7+jHEb0PIzsd4QTj/mOZ1yGkcIUuqBBmdB+eD9ScfLIdwlYQXGluXs98rwiYUNXfhyf/9/3qkB6MYpzswVMd09xtOsG8oss7fKuttyOeYHG86D9yFx7Q846xBi32NoyPcRno4+UU7d/hVQ+nh4Mlfzeuc86E8cBJMp/4Ztq05rB/jB+v2djhG+YXHNAXZNCx/BA7kOcc2oyml33L15YJjXJ7/1Du85/wfI2xZv2lx14MHCMyILSxHg2xaYvv1u5Qe1g+zDWUKbOHgWEkJHCRm01j+AcOgBAeH7slRvDu42OSAy/OkXdyZFzdsnBUbwnBQ0GNzTfTk/K28GepxUAKESRk6AwZvmj5d1AC4tyVix2t9XUAUPf9E0fzWoJ5P5RESJkk9/0QxNpKgkJBR/PwTRWskIUbCOwLV808U2UhCiARFwfNPFOlIQnBY53UMzOHk78G0BqhmBPPxV/1w8GTROFeVKDnue49tBMZozXfVyyEzttZ+j3uwVads7fewl0MMTNd+D4C6OoarLqZQDDn6lY9xv/MW4yXPGG852Pw0wtHU3C+dIsMBX55/IrvueVjuP/8EP7WAK37KgE5+SoHxJ7Lr8oCDuHId3GCAkMTJooVzA9jDZUfYk4L31l/phZsWKRDQCqma1HDqIMFslhBslmA3Swg3S4g2S4jXJHAPE+lh4nuY/tOQmTb7VOYcy8nHwzrClgXoOgIn/vztoA0NhXvt7eAoTqktbmHIcOnG6uptJa8snESqi0A1fAEEzsk81v30qioMxJd7MKXIookHXLYMdozGEBqQa+y2wP5+aDguwgsfxu5Pc7jqACufr0xe4IXoH83gMRg82sFjOHiMBo/x4DEZPNYGj/XBYzp4bAwem4PHscFjC498OUXG8fE4RH5TVf3mow9+wBi98GEZpBc+XNGhsStMx9mAjq8Qo/2aw8FocuRkptuyUP7RDB6DwaMdPIaDx2jwGA8ek8FjbfBYHzymg8fG4LE5eBwbPFb40j42MkwqGRXQLMMUcLkbOp2m/7Kmt+NOmzk2LvCb2Njh4FdUv8SrZMNRSVrcqnkTs8znroP9zJCXNYeKi10Lx+hgpVXxui8Mvgrcy2oWwZRYAmwiZLrcJHHRzEL23fCz0/kYNrcxzpVhj5vHTrMpaY1P6akuG11us1a1qSuDWbC0UBLjgYttjEQxZ4rhpEW1o1P5mNNct3iWZwvibr2cp763XAFJS2gE9g3q003dsKgGXquI2jGP3i50m2LvRA00aFCzWIitQfQAx3wC3RAgPa5hfMHYDuUzO6SmQ7h3E/k4hcXWfKIKbTdmjEKYpJZbbVI0lU+4i2PuYgOPW92jJh/Hyfhq5lbHfGrLXWxKqsrHYYyFwCP6iPufI/eDiKKpYtJpGlsuWoudJqajOeL+3LpXLJJ2knxtYXh3ydnTFhpjna9xK1BHOU3Rcr49wGmvonEKaVvV36bT5dGm2kVNGl9kxUzT/ZjNNrbiU9vp5SJCzrxJEU1g057msVuhGmXtYsdyPkVbYM/OJvj5btrOA7ebEpoq2QiiLCJq3qoNRbQDXn4RxRD/E9zSwPTRXpZRKSKnz3IEwqgDHjMgpT7Rt4sqwkGbTIeiko/IcoPuIC5QzAuC+ASxObAe6qr/EeXLrg6MZI7A2OBYt8lOZXA8qx+doozGKJsqMhzHbKHt3K8tABUdjpdhH8I2JjFlZZEeZasghjX1LbSL1Kk7m5riPBoaS4wBtcqiRZNHOzyG1KKdRzvdZixTLiXBV0xjQFQsG+GYtsA2yZwFDpOcNQpoKW9W8weTC9MrlmnC1FsWQquDecK+Oge1Ail77gzTOfZ7wzYK1SsZIhxrix0nA0Yt5OGQDBZmF0pMIONW6lbSDytUFMwJA1Sif9d8KdZALuEQZ2n6n2tctRCQaov9vhH7fQhWYr/vF3rlQwgbsd9H3Gix39dQrWl/y0PKwSUl3dvva6jjkG44nYN9wUpy1xro2I5Ek8k+kKb3m2BFPyI3H6kCRt2BhGlqHZV4d9NGwYbPwkAbfrzWG2grig5VigpfOmxLLGwtdmR8SRcHBZdbNUil37Em6AfLCnCfGew2jgIYOanjqJu7fahrRp53ABiKUCX6n2EHAO7WWgeAaARK2+bI7UAg7yKaEWniLNpn4dXKr10i9YoiFPj05vwBJGCOuOmN8H31Ui9agQMADDeqEr5h5MfBOMpjtvebjmXc++slkwrHXq7arsz5r6TtQIxGfIn31nYg6BQHgGiThkxVufYOANFwxdGGFRsOPwiH2MBNltk+tpqExUCbg1FnH2ARiNhUpw3izFnDxraSOv2ywTWPPFUkJnefDAMZPezjnD3rA8Iy0RQyXQC3qjYSm5T30HpJb2gzodJCaxbfIMdx3NaS9K3cJDY6LI9vlGWWs9gqy906WPEbcbmSTFV3LfFmCy2S6njjIn22sJV2gMXDzpSwkrPVFie9UZrUPpBWtX37GPY56nBy7ok+C5JufCt9Tmu7IjPP7mfw27yDNwL5EY54oTkI4BRrHJyP5ChxQZXnlRHiVWi5PodXJ1ExswqLVyfM4ezDLCQY1GO8YIuBDEnC9hYRRGxcCACWzLyCFdT9/OlNOliR+5VgiVcEPtav00c5rr70rp3728jeZtO19Pc1W63xMZRh7PxDI1eL4ICK7xDjr3vk4/e3DX/cuuBjH5pKQBvGn9O36p/URAO1ekBiE74xI++vzYSbFdw0If1vDcMKnR7rbhXrcqErDlmbi7XCihJb+TC+fWWwYiUhK/o3SVOVopgjsPrKg0pR7Jpt8bwPvJZYZQeqmgaqSKnJDLWyLq3Sd26W/PbbQU9OWjaBs29/4iMYi+E3L065Nw+fIATRmUi/pX1sT+6LdrUh1GhfrR50/9yBoWY3SGf0iIZa3dVUl6uJbdJkYNA+8woluGNKRDgSlDx/IP1vKkDNSh9YNmp9n8BWEDgPdnIHXwlw2TpRfAC5S9o85mn6Vl3HUJXGg5tEcY4vKmWOV1mfNtdDRR/4OVVzb6++/TsrrPSLJOyVZfUnoiyByrHrYbM8fbYf9Y33CBpL10F9zjRZi/2U/33GNI2jvhIRCwsrBL0CsoYK56tzJA41Km4oESyBI3Y2AVp+ur3MbuSn1/tPP9ElOvGz7dlH+P3Vrfz+RvW+uoNzun+zDaxuC1Ywg14F2AYYOd8J4YbyytaqZyJ6S48E8W/MoMSpsgjdeDnLDGHavDnj6iWuXIWt6RQ/hcdE8/wqzqo5bEqMyCEwf8HpN2zx7VFv1MJHh9kMr4XgDXLr0FMHcov9HWcInOn6gyWzCbNYSxDmigiMT5U8zXpmodczC3fhce0ufE1nH2VChCGqB4cvbuoD4mF7PwD56dNkD2WXkW7LEsjgiM+OFaAw1EUNAQr8jaRvbMfWgxHT8PDQCM7eB1wSzmwYV7w4pW25lMTjgqwLyxSBvJ+SIdIDSGLSVwWS+NKQcDP8ZQBJ5P7ftwVJDFJzgJyrA9JG6CkST0yNtgh5VXPVd1umhfXgsT93NTNFtoyoLkJIsmZS4obIfjWXnwbJlXXAbAj70EQYhrXPD8BzCkO17KaK4xSaYn6DWdRHcfh2PZ+uquxAmv6rmh5fkUuBEn/YxjETJYRt8I6MAXnxlT9Vh8yF69ipMHDqTr4l1n37Oh5A99wOcOWVvN4X1qycAqlpc+E6XENwl5fdNF8od+E6WN3yKU2dJWQH0xJzRxFPyX1zCacWjRICj/K3gPaR9sYMGw+8AfOmOsXw9Y7mq1XozRmKeJNt2rPmzRkWf9gJRwRH6DCqgblwHRqve3jqDI+/7q5qz0i0kpi35iOipIZPh/XiMAuv6i7re8wfRIDnytW0eWEHb5t8t/lmxhd2EGsPs48JON+8jrcPs+abVQnYp8hhVtS/UW84V5XqccbGXf2eWugbElkRudssGON4nkVeGPvwFSn8hK1UtAiJG722FEATEcsPm7IPAetD6/XH9s6mSodhMx42GWDuiSgxn9oB/0k+120IxcV9isvkGrsk9+a8mQRxbyKoNxT2ooTk2Av94IAMhz9Vs6y9FBgEwZW8a9xLVhLQS/eSvWsqH+dl1khHDI3D1TTmI1ApW+Dgs9hSFnBriWnMhybCpgOFsDreVZipogX8GNGfBzm4SQM6p4gjDI7avXB08pDST7NfUcjqJG5LIuLLMj4mthoBtcpTspI3hwkb0Q22AIqSQqQLeRsOJYA9D2+FoGsk2VBFZAo+LzAMThO1j0GSoSaNOd2WnVLIiQYmLFDa3MpqqlR0fRz2z5k78b92Dhd6VD7PfdSVMs/Itpb10IiNUQzQCHxwYH0xBEL4J9yHvlBNwTdmEBKKr85s+x6HpKu5Vm1/ZZMl6hDYhkXZh0Lmwib72FC+9J8YXVshjVAhfK0ok8Dbbwe36shZF5CFxjx2v67xlPi9lzCuFQ7S7jedqedjlo+rQ7nhlS8USo/wrVjas7KKKOwRLAn4FB6F3tSsQFEt8bgCr3+N0M9QJiFbx7CiiReUKlPIyBB6SWVX9tR2fn1qOxdi2bB2TLB3UJ+XxPPbvcrioH5avjy9PUXMwLqLHG5YtEeKYKrqtgucpWDKo4Px9oNE1/ym5rUZlv9Y5Au9yBc0qgvDfzoDLzQ7owxHB+WV7qDyIeV1Ze0l+O9vKkF1UbX5q3aWLuPoAXcMFsm1+7bwEnu6oUUyGt5Y+l0rTrRgg2TEBknkw5At7IoaZnbCUD6ZjIL5eFLUfV3xchfKAFnNBdZ4CNbYwxNXG8grg7XehzVun/X1wwjP20vhsVrTa25325262/obFC98HX5QHphk2qyOF4k34GKezuKHHRaa1oJhr2SfvkZksu2zbCaYDCy6RKiUjxWsirgrchGebhcJJS4+61ZN+c77o2ZxakZd+E2P+ViYgOgQmdwRXGZY3+Ayivpdez8qh/pwP3z9cOToYzsqU2iHGdsWnrAJ/Ckv/ANEgnEZnle3wPPcUynURsGALqT9gf37u6IEuw7R6wEctFhRdR9gCWVapDJjcdFyCrb3lYTVyyGeV3FVSTCgCnHRvvSUs1eGWN2HW/ntGV88nXlp3+/Q0n+U6vqKsFuw5CKeyi2z4XiKzQU88x1lvCscplthC8e3+YRUF6arRVSsVyw3ofiI6PHKwgjT5TsHhenGfGIUeEZmPSODXVRQUZ8VztSgcA2SojaFQ0haO8LDSFqbNoSkRh9JYfusrz8cDG7IgxmKdWR1OoPDqsGOO6h23IhZyQFaIorZWlUCRfpesi40l8vQI+G1tqJSMyeDfqnZdEUUayoeW0qEosgboAYy5HZ4F8y3yGHlEkhgOQVcHNRf314MYBmZRVcBJrMBTMa7Kj91gMJqu2lc69N9rmnWbjUj31i0wVbTVN4wl91qGj8tDGLFGor9qYM06FPYPinm2AkUypoeyJq+Fm2/+XeKtrcqtI39LaKt2d4IZRJoORA5Zy2WvvF3iqW/rrBU/1vEUs0vE6NYQrBaIxGjPXwpi4ExJUcKw2JgAk4MMdBADEymOKq6iIJva52uyNYeQhu29kXY37QWNShFOErwsvexkZOUajto75TrUMl+usl32WND0C1sVT6uFCaJT/TfG9X3psTDbS7wFoP9E3g/P6MkgI3Fdilli5DRGmy/5kXezLETioTok90uLs0i3xV/uaLfXlQfazhef0yL6a65pOku352pK9NdKFAlWssPFe6p2n7MwdhcL7tHL6yazpTcLyi+qdoYw9K9+9ARUvBh63Kco48vNKtb2036Zo1HYdo0XNgumCYehoE8BYtTOW9zOXYNn7MuiLWRKLf5+JzvM/N69g+x5jfmWCmgI3x+SYvk8JwuGpDWcPs6wkQZROLh/SyiQIhS7+6pwhyFerhO8XwHaQvdbocjHSmJBnCE1T2dIspmhg5PnG17+h58CtqDs5rBV4OvK9UBzeC7bg+cCcWjI5WQItL7Bn7PaekHaz1gSHR0ih1xGQ8W9lgN9qrla9DhJwu3mExeJjhlQibgc5rfnmO1d5sHoTp+YPuLBpns47tGP5T+/mv2v23L3djB4KSI7wxM5Tb3gE8L5J5gWxi5N5BHgkmQw0QbhHHkgWY3Nb6ubfWA7yWbgABT6JzPxf4PPMVf0lIJhlz7EYZ/x1E+UQpQdcC+fFwZ5jO0QB5RqwfAfI71FXRoNa0qwe/jB+6WetBgWgFU+nFAeEWyFVgvaZh3GmlMOO7DUkcRtKGdpxDx0EtfFYB/jhnqO2P+9IGjAsSsefoAb3Wt+O/psVArpbTHJvxBYQsXSLHncLXfoPfGBy1GtrubfnCLUHBm7+CewGygDyT8sHnkK+Twrd3mMsh5mAKvBHtJy2Sr0GSkb4EnQo7aARYtYfYEJ3D6xACApDzaggHagmG02XZVnKxH2wbYqlBRRO0irOZ5Y5gHAC2Bn9G2YigBprpYnAWY5H46Rwvd+W7T9LEtN6UKqOc0Rey8DjwdnSoMm7OJg80u8ZuSEdrFnu9pocEX/BwzZYVpzGfokZwJXcAXnLuEzy0pSH9DvEHYRSI76EOVFFqujoPyJVic8re2e1/mjHRFgQ3Spdz0LN9LiUXDR7h6MOFxiCO3a3Llil+Rpvs+Z+/Ak6Xp1zQ7rvANecxjYMRs/CKPac/I3I2wR4Eo8eFKnLP1kjkycBDHYfIeH7LMF3Dc1lD6Xh8QTCop+zrfhF8Qgi/9rYQv+mVTgtgfiEZyg151ePqydk/w5SgKbq3ypTDuSTFuEm8eccCGa6NXHL2ks9vEIQWk4Z40bU+Xpr0oQJLJfgEk+oL2XXhB5yYVB1sX3F31dNQbUIk3oFSlps1F3R46iR/1VFaVX+TQcf6GOQw8J43EAxn2nIzEc9JrMsUQJGaNpNz7g42m10sgmtriFLwqy8qtcqSYErRJNwvTxk5NXl+fkWn/2gwfBgaLMvVe0dXJqWj9X9DBXDW3/akHz222Ruhkt/mJ/4L2GnO4bvb16MNFArILzZANoryLZ8UxTL/WafPMgUpNzKyl4BsPklnzjP/6TdZ/QcOhps239TJi2j/jK+eIP/3F1Huim81Hc+gk5j0ki1QQ+UOKjZBeeYauxx47hipxDA28h+HCCHd6TuMwCX6i0iHrnaTJip+or3OYC6m+Y7phExvTZ+rGmbunhp27qyb0cBO6akKLY/f6Jtix2zcz1fJKG890L1vlpaGGqRaWQrDNP450fUU4e4wJLILiy3IU4BdH3zdbQpvI6Q+XchOGrH4cA6yEvr5dMdSLmq+RuDggvLjtQwNUbD2WBdTKkiXWZ7YvLTzNQD+r5RRCZs/DbO4UiN+n1xBDcwhbYkrunvJ2WF4touDC5083An+2ccVl4eL1LHQvcZmHXk5QfOXpvBcG+lOdCaakMPu4fGPCkyQIMPAp0lLBMwf4kmPWGvr1uy1dQnQKxTchD03zxw/wsYinJTbJ9WwZntaQU1KxpgkWqxXhnBdauOpCs9adg3IOpnSRkJ1ha26e1EW03OtgZJ7R4hMfCjyarTX4nA97oeUeJVU2QSwA1KQ7bKwsA2b5TKh+UPNJW520zM9gXTe4A+YoayCNe8IcbQ5EADmbYsoTmezpA4VhGxSxSXq5YjiFJnPUzrmvsFMK70HcVwy2HvNY7ftBNnlqIKgRuwSD0QnW4MCvyRxjNaFpQ/EpcqAXFeyKXLnsuWN187KAFBK8vqCzfPpAmt7Dq71nmVWT7I017RHG3BOEcSn8yYGbYtMAQZ0cZKc/NKa1Yh5Btu97HnMWL9/zKPqRhluHn6Yitbbdk2D1js+lj/n934+91ImAFXJ2m9c92aQU8tGUBMPQ7aJJQXlQKbl893EtoT3Pa9zThs+ZD4SCLXlaCklqWA6zJHRQKcr4iUmKj1oDf99Po4R57jhLzHja8ot89dSWJ37lWy44i0MYU2Jxse4Nvehj48Pl4CsmLcynmdI1cxZDrDcx4oJnqOnhNTlHAm+RprFO5S2hIWfH7IjAd730Qzek/64+EI6SgXDkxaOV9cLR/JB0tNhBOJL5JiNaoj4MyUZpbqsVG2P/PV0xx1nzokY8DNmwvaBxUzRrolkouHu9QGX7ApXNfsFHmwhceLRvm6XFOTdYaGoXVHsMLzy5Rwky23CDqZAP71lFHAkWB5GJhpdgmXKjQlnBtPaidiu9clQyG4pYsYlktj7Hu5HMkvchmX2PY/+1h0fiZYmsUjLDjqFsELX/6zMynV6bGRXIgv5myx7DwiubI2HZaABswctm36tkMz/CLIh9Z0RAkfUwXgD1VLLTIGaF2jBmxSVkEcPy3rT5zoBtCaeUKC1/N9LZQPoaloXMcBeNdLHaOWzSzWEpdyBHDAl+fSzYUNbvEWRvUKRh+H7P/79hTOhkWKjEHvxdCJXBexEqzeWrvCKhEgylBTuCT/bXxPV6aj1qfL0uGUbLsXLfDjKb/vtIx7D9/7FqF/X9Ck6ClZKVHTRClx1lzU7kNC4Ae/QrHA6ew6Zd+AZ8h7B/rbwSJ5fd3i+5qQ7HK+6AGS33KOwV8lrj23gp6rEpD76HzvpfKVnryI3URdgrOG/o4rNdtpdCqKCz3R6sapf50lR+RnFn+bnn/kL1blEvfIOd5xawpqk8ci98Q7u/ALmwZbKEI0B9RUrR9chd8ME4w6yXe0UNIQoq8DO53Wq5i8jO7H3dxa7zhWc0x9GZfHDWvHBBnjM8f1ueEzy/oIfNnC98Q2JCiPOVvb9A5KNZ85rmeCohm+8lwYooyVf4ki2z7HZDhtIU3jGVY/Q1heISSOkChxI2y4RgABI6mKPbxBSeKWpy63LyYHaYg/YiKIC+6LsJkb0nHjU1ZxfIuN13QN0dZYdhPQ3HF2w1BhEFoPIY8kiFg0PwhpbfVZiy/pES5ehrf/xn//DhWfOMIXX4rT/4P//kP3z9v/it7FBwHu+P/oun//AbP/8//vLMoeCckbIX5HzUZp+CYUB2u5tAZAk2vXI/hVgPImO31ItqgWdRBHMMvkXJR0mCtTf7zsKqYbYHotfy8iPVEyPYAdzvCT5U7y6q7FMOLvuM8qIGY7Namc2PYga+f3X3YwW3pDj9JHgNr7egSDji99/gFq/c5Fl5mVzuQtE2lJwsd7vp7+jK/05dF1wwkCifPxw8+TDDFUGWc5/s8P7HXfT4/zYLgxcV394hF70DUutDQLtzHFMrzI7A+Zys+2R5zK6gXxDKbZkdIevm2hJhQy6Bg0pW1GolaudsPqR0+m915bGXsceewMk2ueHh5O9B4nKrycDsMvuU++kEGCGyHX4jeOzwxeAXRb0ClzaXgA4AY24rk1U3IVYGpmSrgoc7TJE4mXDBsniHiPGn+HmG3+KaSooO30whQpycuw0GNAhXEXpfo4lsQTCFQV3oD3TgsnK/SqfBMhWcvCcxRP0b7lT/hjvFN9yl/0uuP70iDpg3FQFHNRnkDvq5A38bPPJRYZDPDPKZfj4j+WrIl1w+31Z2/Lx8voler+f0g4VB/usLjr5iB/ltP7+V/C3km7h8vjryNS6fr+Hbt8h/c3G5ewOLEPn2FxHyRYN8UT9fJPmaBFtVZS+fc9JDECGYjp5Wk0WMIvGgSNwvEkuRbVixyHIx3H/QwtrCb2M9VDFdJLJE9KtI+lUkUkVKtR4Zzn3b5XPDxFtlRYZ82SBf1s+XSb7ttLVHqYCSoczuYhxlxgdlxvtlxqXMEar3KJAy4/z/nbBkRf/4jYPo9SiWtyn+/27UfUMBzkR6ULfu162lbkfbaHuPV179YKGpSUd6lEhN10Dt0+tRSK5Hukdj/HUP/39vD0y6R3t6tJs/EI3RNT3aK0XzHqUolfXoGv5Q4Pr2Ho1L8j441fdop7ztJ0vjPdolbx+gmHb2aErerqUx2oU2+O2DNIUWSd6m+f/XkUZdBdrG+4doHIDskzwfpr14pD3I8KEe5fz1ev7/TI8I367v0XX84QDl9OEezUjRgz3aiVL7e/Rh/nAD7aJ9PfqAJN9IU0i6Vt4+QrvpAz36oLx9lIiu7dG0vN1EOX0QbfDbx2gaLR6Qt1n+/yHaD0BuQNt4v5k+AEBulDwfpxk80vXIcHOPDvLXW/j/t/boAL7d0qND/OEwHaSP9+hWKbrQo2tR6iM9+jh/uI0+SDf26KOS/As0jaSb5O0TdB19tEcfk7dP0gG6qUez8nYHHaSPoQ1+W6RZtHhY3o7x/z9NHwEgt6FtvM/RLXRbr0cL/HYnfRRg/UKP5vj9U/QJ+hgdoBm6gT5AU3zNAUIV1eUw6m6aEHXi7S58sCzlmOgoH0MVrFtIioleh+Z7pfut//jVH4RlscPtebDYUlKDjuKpXtIkzZdUp4ke3d6hiV5JO1BXlX+SttDtyNnodajRK2krTZS0A9dr9DpU75U0OZx9pOxdxK3VaRI/W3sd2tpDy9tRwRbChy29ku4aLtMYftnuga3RXXhK0fo21FCn1Le+fTj/VtpCDeSs9TpU66FbR0rajrsrcIczoN+0rW1SMqWtDLOvHne/cHtbPLDbhss0h1+2cMPw6N2GpwStt0pqYrx861uG87dQOXIGvQ4FPYRpcCVtYQbQoaRXUmvTtlIpmVALP61eh1q9UmSgJvRVvvvpcJnaaG1ouOQriVAEr7gOZ8+DRdjrUNhDXKRWyVcpV+CMQGCGXyIBxgjqcR9nKQEvex3SPYiowyV7XraC1qzm+z5SneaX/+rf/9VfI7wRKrU4EuDdHgCUhkyPS+IiElhe9LilYLjo+noiqSHukaFrIGiFGxXr4Xx5J8fSljbWVDT0Yjx0Ee1CLQwdN6GxKALqAr2NekO93LSeSGqIsWbs8dCtKybQ7fPQmSuEbv8m0O19b9DtvjR0H3pX0F3rYQI8tBk8bIos7YOg6MOlLKxoIhytdRgcIZUA8teeB4uxDoiy00VLOWAc2wBGqeCbT/5nv4ZzJkZaSTf2YfS4GKMPshtOlyAkkEGldrikobALe6UQKQFdj+aiLukOfvFtpB09/BJIY7brCb2DnSOKRDTtGw37jQabVsNdjkq6WRAX+OmD4DofQTVBl2wfIeFINRR1kcJwWroOYxpzT0OK8W0U3NFuBx52QRibbAnGP+objfqNmk2rqWA/6FHgyRc2dx/HdBfYzeVhv8nDbt4f7Le9B9gt/YInF8OGgoC/OwCDbrlMR0YbGExeC+41yxOlS3G/r6OEwLP7Vr5egaH2FLRB53//zdefg9bcQx3S3ADZQ7zC0iE0OTLpfdH19fi5Cu5KnwTdxhsUExgPszvg8DzctFbG6cKG0IV0B68q7xq6myCJfaJHn5Jdz6VhXXyXsB7bBNaPQcD7ZLVTSN4L5Leiik/16M5qi3RpyGfRxzuwZeHd0bvoB93tLZjmKaRP0Bygpkx2jJ6jbAy9cNxS7uCaoEPo8CK2Nk4/yGEPmSmRHubhQy37mxCP0hwdRjfp01xQg6SjnkgoI/0s5Zqv2+mTwEuCjZ7TD5bEUs7Y+s7C2JYj4rDG3q2JWtX2AUp+N9dbV0Tvk3KkJlYXB1WMguxTUDb9WJd5hohZuszHERlAl/kW3B1qynwrdCumzCdIuTc5QJlyb+gy304mH2NfZb5UMJBje9QYih7sDX1YP8zax+3ZPG3L5vOYJrJ58YpTvcK6sbPuzbgzzWpZtjzbms1Dl7y9+v6M7omLmO0VsYuqz9/WPe8xAm10FWbzhRd0jy3DoBdeU/UkjHEH+cgOV0bRSPZwpP1eDxrxEYjY+i0aqS8cqS8eqc+uq68+2hU2rbMj9UUj9YUj9cXr6rPrcDANNK7BwX6qj7RRG2kjuQzM8TocXC+a901wWh+pr7auvnAdDggG1kP1JSP1jVJL/QpwcNMGdHADhZfA8+XGbT0d3HxJuhodt+gK6OC2NXQVXwIH4RXgYG4DOrjrKtPB7VeZDu64ynTwyxvQwS9dZTr4zFWmg89eZTr44gZ0cN9VpoNTV5kO7r3KdLC8AR08cJXp4KGrTAcPX2U6WNXA9BokPKXfFyU01mHhcf2+SKG1Dg3n9Puihdo6PDyre2Ld8oym1iVW8salQRWPoaf1GipqjNQxSnStdXXE3gqucYkxaF16pPOQ4Aa5hY0YdNFw6R3wH+gbPjEtb95Lexm6HMW9t4a+Ynkq3mDeDOeG45u+pPwTX4bO62sp+jl9yXkTXoai1+PXimnMGrKuX6LWTWjlxbVzLbwErSQb08oLa7F/qfla34BWxqnhmoueQn6kxV7r6lLIy1eZQi5eZQr5/t8Ihbx6FSjkB1eBQl55vxSSpbh4XvVxPqNknKTcjPrvX2DDiAoNM+offVuMI6phmVH/3TNiHNG77KEqLDNSwkX3failvWhte/G69ux7as9Ke0mf5qU9u7a9aF174XtqL5H2Gn2ak/bCte3Zde3FG7R3uaN8aCw0NUu5+JRtaZttl8HuJIXpkcWPzWP8JHlIER4aFE2rRm9WNRDRCC9Jb1YlUMrgxfZmlSXY9ETTSvVmOegm2zCPwewDLsLweBUT+RT2PmzS42+B4cBDY3AEH6Mm3z8vF8OkYsnxiNY+pK2BaYr1Kg0y2e3v0RKIjZLYFIjtWSb4V2e3Q9nx7QC2JBmb+yKabZpwmypNA6XSp5o6HNyzNIilmwcCYbRfuUcYq8q70MFIcZI3sIXyXs3wc3Z8OYFbOTKVB7hc06k7YMBDph36EMNOwxwcF0TJBRtZG47nfM1XcqSIO3x5CgWudrTbbSr3MGIyTZtpp92FA6TGAyXtIdC4U+6ZA2+mUMDgbiVSDpceSjS4VXbSZBjdh0THpCWemCazjBwPkzr89tuPrr6iDrHV/uHV1a+svqYPmWd13x/rcS3RxacBVdfBSsXQeKBm2VJUUthQeyjlvO5/f1YPEmBXBKQ97b1v4d/iVlf1rPnZjK8Kr85WBQBjIhaSP5txZnnWNCpfPXh5eKe785VH49P8YOQ2d76XDi4OCTCgs127+q6+D8Px3risZAMs669Ls5VngyRzLGfTb6LvPME9eFWLW+8PONz7LWp/BWTh7TdnEfGJzeFPOWjsXp8B8ZDOZpsc6H3WXA/yQvc0YhFPoMu7YfYsQRUC8aLk0NoFk9AchxAU0+1JBE3+uPsQbGePFGqKewoz/cFl6rijwV/CnuI+9cA9wrfx5cY98/XKIlT50K27JRSsWS54XC58XTteLFfHlxFcH32+cwpOPErsxDjUsrtwXleXXw8HiubQr0pe3e/8pna7/RXn/gonE8y5jO9jQVRdvghnzxExcYPVOg7MXLw8i3BCDK6mEPGEXNzmG6y8GWY4CG1t3YWnES12AMnwtVWiGWVrOR8qW+LhmUE8vAH4bAQcHdSZRBx353Eljzuv5esWRhfs7Pk6Y7LuNcQG3OJWjWQY8xme6WeYLG/VY+4Z49u+4FFnll1yq/7dx/Uw6hA14hkYQGccofV3DMK19a3s9lQlC+XCW/Xvfk2maIhY3Re+NlwRBpjNWCU8g4vXtuS/1zb5nqz/Hg5o4x9UtLHlkrTxm9qHmxrqoNyEVtFGSgEo/6kD4hnjwzMH7qfZrDm3gwL3g2zWvLmdAncxmzWvbWeu+v1t8CTfwc+vbi1nzevy/SfQov90OwXZ9TKTVDWTZ71nf/+6RC2sojBVUG9/A58eTO9nD8gvwgRwFE86xOb1gPc7evDtOe/SUHmW/UC7xqlCu9e3wt9m1vyYOaR7zb/+SF7/b//6irz+tX/9vk4RlRmGqTZN/xLG36tJ+o/tqjp5uvelz3/+5ImTS6eX6f6l+890v6xuPPDRAzceuHHm/jPLp5a+rE6ePnv81Mn76NTJ5aXu8VMHTy2d/sLyF3vUW1rup504c98SDSd86XT79JkHT9MXl47ft9Slz586/oXREved7C0fP31iafTr504u+2qou/TA0vFltXzmDN1//PSXq89nuv2i1Pvy/Z87c6rXL91bPtNduo8+d+rMiXYFjfrclz7/+aUuLXW7Z7qqt9xdOn6/fxkBfmaG7j/Z6508/QVaOn3fzJnPz3A16uTpE2e63aUTy1VXTnxxaeSzh2vt5/uOLx/vfxztMqFPnz/epc8dP9FWVbXdEwDg/uPLJ77YL/HgydP3nXmQeid/ZWmAIu7d8pcfWNpkZLg/6xvlr9WwnDhz/wPdpV7v5JnTdP/S8hfP3KfwX6bG1RalVKJiVVORqqtQpcqqhgpUUxk1prRqKXexkf6BDZRVoYpUrBJVU3WVqqZqqXG1Ve1QU2qv2qc+rD6qblWfUv+JOqF66jH1e+qP1V8oo5Vva/Rv3P9t8X9b/d+E/9vm/zK1qL7HkSeMEhgAa1ONq50qVzcqp46rR9UfKa0fxS2wgbY60olu6ExPatI36Dl973D7VZtVW2hju9qudqgdalJNqp1qp9qldqkpNaV2q93qGnWNmlNz6r32P5Duq9U1f4/6v6/4v8f83+P+7wn/d/4q9F+v6ovD7VbtVe08qZ5Uv6Z+TZ1T59RX1VfVr6tfV7+hfkM9pZ5SX1NfU19XX1d0WKnVRCmtldqjlWoppS4cUUrVpH97lHzjvvpvW5VSsXIXxtNjEjxk8M+s+Res+WfX/AtH/rnzW9KltVWtLVplj/y/2P9L/L+a/1f3/1L/r+H/Nfmfu7g13VdVH/sOZuNbVBLXonqY2kbQNGO6pdwbW9P7Y27bqoT/KR6vTCX+OWIfncTnATXWGJaMv1fPGCV5pneelcYznoxWVp6NNlplNeV+NpHWbvhlLVj9/wA=")))), e) });
}
const Wt = "deflate", xn = "deflate-raw", Oa = "deflate64-raw", Un = "gzip", En = [Wt, xn, Un], Rn = [Wt, xn, Un, Oa];
let Ta;
function Cn(t, e, n = {}) {
  if (!(t ? En : Rn).includes(e))
    throw new TypeError("Unsupported format: " + e);
  {
    const r = new Error("WASM module not loaded");
    throw r.cause = Ta, r;
  }
}
class ce {
  constructor(e = Wt, n) {
    return Cn(!0, e, n);
  }
}
class le {
  constructor(e = Wt, n) {
    return Cn(!1, e, n);
  }
}
ce.requiresModule = !0;
le.requiresModule = !0;
ce.supportedFormats = En;
le.supportedFormats = Rn;
function La(t, e) {
  return ie(t, e);
}
na(La);
Zt({
  CompressionStreamFallback: ce,
  DecompressionStreamFallback: le
});
ka(Zt);
Sr(Zt);
class bt extends Error {
  constructor() {
    super("ZIP cache could not be written. Free some disk space, then Resume.");
  }
}
let Gt;
async function U(t, e = {}) {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length || (Gt ||= chrome.offscreen.createDocument({ url: "offscreen/index.html", reasons: [chrome.offscreen.Reason.BLOBS], justification: "Validate archived image bytes, decode dimensions, and create local blob URLs for browser downloads and exports." }).finally(() => {
    Gt = void 0;
  }), await Gt);
  const n = await chrome.runtime.sendMessage({ target: "offscreen", action: t, ...e });
  if (!n?.ok)
    throw n?.error === new Y().message ? new Y() : n?.error === new bt().message ? new bt() : new Error(n?.error || "Image validator did not respond");
  return n.data;
}
async function E(t) {
  t && await U("release", { url: t }).catch(() => {
  });
}
async function ne(t, e, n = "application/json", r = !1) {
  const { blobUrl: a } = await U("export", { text: t, mime: n });
  try {
    return { id: await chrome.downloads.download({ url: a, filename: e, conflictAction: r ? "overwrite" : "uniquify", saveAs: !1 }), blobUrl: a };
  } catch (s) {
    throw await E(a), s;
  }
}
const pt = 3;
function st(t, e = 0) {
  return Math.max(2e3 * 2 ** Math.max(0, t - 1), e);
}
async function za(t, e) {
  const n = nr(t, e);
  if (!n.length)
    return t.status = "skipped", t.errorMessage = e.mode === "original" ? "No original URL was exposed by the archive. No URL was invented." : "No observed or supported thumbnail URL is available.", await M(t), 0;
  t.status = "transferring", t.attempts++, await M(t);
  let r = 0, a = !1;
  for (const s of n)
    if (!t.candidateFailures.some((i) => i.url === s.url && /Image HTTP (400|401|403|404|410|422)\b/.test(i.reason)))
      try {
        const i = new URL(s.url).hostname;
        if (!z.includes(new URL(s.url).origin) && !Te.includes(i) && !await chrome.permissions.contains({ origins: [`https://${i}/*`] })) {
          t.candidateFailures.push({ url: s.url, reason: "Optional permission for this original host was not granted" });
          continue;
        }
        const o = await U("image", { url: s.url });
        if (o.failure) {
          if (t.candidateFailures.push({ url: s.url, reason: o.failure }), o.status === 429) {
            r = st(t.attempts, o.retryAfterMs), a = !0;
            break;
          }
          (!o.status || o.status >= 500) && (a = !0);
          continue;
        }
        if (t.resolvedUrl = s.url, t.quality = s.quality, t.bytes = o.bytes, t.sha256 = o.sha256, t.mime = o.mime, t.width = o.width, t.height = o.height, t.blobUrl = o.blobUrl, t.savedPath = $n(t, o.ext), await M(t), e.destination?.kind === "zip")
          return await U("stage-image", { jobId: e.id, recordId: t.id, url: o.blobUrl }), t.status = "staged", t.downloadId = null, await E(t.blobUrl), t.blobUrl = null, t.errorMessage = null, await M(t), 0;
        if (e.destination?.kind === "folder") {
          const f = await U("save-image", { jobId: Q(e), path: t.savedPath, url: o.blobUrl });
          return t.savedPath = f.path, t.status = "downloaded", t.downloadId = null, await E(t.blobUrl), t.blobUrl = null, t.errorMessage = null, await M(t), 0;
        }
        return t.downloadId = await chrome.downloads.download({ url: o.blobUrl, filename: t.savedPath, conflictAction: "uniquify", saveAs: !1 }), t.errorMessage = null, await M(t), 0;
      } catch (i) {
        if (i instanceof Y || i instanceof bt)
          throw t.status = "queued", t.attempts--, t.errorMessage = i.message, await E(t.blobUrl), t.blobUrl = null, await M(t), i;
        a = !0, t.candidateFailures.push({ url: s.url, reason: "Image fetch, decoding, or browser download failed" }), await E(t.blobUrl), t.blobUrl = null, t.downloadId = null;
      }
  return t.errorMessage = t.candidateFailures.at(-1)?.reason || "All allowed image candidates failed", a && t.attempts < pt ? (t.status = "queued", t.nextAttemptAt = Date.now() + (r || st(t.attempts))) : t.status = "failed", await M(t), r;
}
async function de(t, e = !1, n) {
  if (n?.destination?.kind === "zip") {
    const { ids: a } = await U("zip-matches", { jobId: n.id, records: [t] });
    t.status = a.includes(t.id) ? "staged" : t.attempts < pt ? "queued" : "failed", t.errorMessage = t.status === "staged" ? null : "ZIP image collection was interrupted", await E(t.blobUrl), t.blobUrl = null, t.downloadId = null, await M(t);
    return;
  }
  if (n?.destination?.kind === "folder") {
    t.savedPath && t.sha256 && t.bytes !== null && await Be(Q(n), t.savedPath, t.sha256, t.bytes) ? (t.status = "downloaded", t.errorMessage = null) : (t.status = t.attempts < pt ? "queued" : "failed", t.errorMessage = "Folder write was interrupted before completion", t.nextAttemptAt = Date.now() + st(t.attempts)), await E(t.blobUrl), t.blobUrl = null, t.downloadId = null, await M(t);
    return;
  }
  let r;
  if (t.downloadId !== null ? [r] = await chrome.downloads.search({ id: t.downloadId }) : t.savedPath && t.blobUrl && (r = (await chrome.downloads.search({ query: [t.savedPath.split("/").at(-1)], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === t.blobUrl), r && (t.downloadId = r.id)), r?.state === "complete") {
    if (r.exists === !1 ? (t.status = "failed", t.errorMessage = "The completed file was removed outside the extension") : (t.status = "downloaded", t.errorMessage = null), r.filename) {
      const a = r.filename.replaceAll("\\", "/"), s = a.lastIndexOf("/ArchiveRoot/");
      s >= 0 && (t.savedPath = a.slice(s + 1));
    }
    await E(t.blobUrl), t.blobUrl = null;
  } else (r?.state === "interrupted" || !r && e) && (t.errorMessage = r?.error || "Worker/browser interrupted an uncommitted transfer", t.status = t.attempts < pt ? "queued" : "failed", t.nextAttemptAt = Date.now() + st(t.attempts), await E(t.blobUrl), t.blobUrl = null, t.downloadId = null);
  await M(t);
}
function Rt(t) {
  return { state: "pending", filename: `kemono-discord_${t.serverId}_${$(t.serverName, "server")}_${t.id.slice(0, 8)}.zip`, blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null };
}
async function Pn(t) {
  const e = t.archive;
  if (!e || !["ready", "saved", "saving"].includes(e.state)) throw new Error("The ZIP is still being prepared");
  if (e.state === "saving") return;
  await E(e.blobUrl);
  const n = await U("zip-open", { jobId: t.id });
  e.blobUrl = n.blobUrl, e.bytes = n.bytes, e.downloadId = null, e.state = "saving", e.error = null, t.manifestState = "saving", await R(t);
  try {
    e.downloadId = await chrome.downloads.download({ url: n.blobUrl, filename: e.filename, conflictAction: "uniquify", saveAs: !0 });
  } catch {
    e.state = "ready", e.error = "ZIP saving was cancelled or blocked. Click Save ZIP to try again; images remain cached.", t.manifestState = "pending", await E(e.blobUrl), e.blobUrl = null;
  }
  await R(t);
}
async function Ma(t, e) {
  t.archive ||= Rt(t);
  const n = t.archive;
  if (n.state === "pending") {
    n.state = "building", n.error = null, t.manifestState = "pending", await R(t), await U("zip-build-start", { job: t, records: e });
    return;
  }
  if (n.state !== "building") return;
  const r = await U("zip-build-status", { jobId: t.id });
  if (!r) {
    n.state = "pending", await R(t);
    return;
  }
  Object.assign(n, r), r.state === "ready" ? (t.status = "finished", await R(t), await Pn(t)) : r.state === "failed" ? (t.status = "finished", t.manifestState = "failed", await R(t)) : await R(t);
}
async function Dn(t, e = !1) {
  const n = t.archive;
  if (!n || n.state !== "saving") return;
  let r;
  if (n.downloadId !== null ? [r] = await chrome.downloads.search({ id: n.downloadId }) : n.blobUrl && (r = (await chrome.downloads.search({ query: [n.filename], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === n.blobUrl), r && (n.downloadId = r.id)), r?.state === "complete" && r.exists !== !1) {
    n.state = "saved", n.error = null, t.manifestState = "saved", await E(n.blobUrl), n.blobUrl = null;
    const a = await k(t.id);
    for (const s of a) s.status === "staged" && (s.status = "downloaded");
    await lt(t, a);
  } else (r?.state === "interrupted" || r?.exists === !1 || !r && e) && (n.state = "ready", n.error = "ZIP download was interrupted. Click Save ZIP to retry without fetching images again.", t.manifestState = "pending", await E(n.blobUrl), n.blobUrl = null, n.downloadId = null, await R(t));
}
const Nn = new Le();
function L(t) {
  return t.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), t;
}
async function Ue(t) {
  const e = await Me(t);
  if (!e) throw new Error("Archive job was not found");
  return e;
}
async function Ee(t) {
  const e = Pt(t);
  if (!e) throw new Error("Open or paste a Kemono or Pawchive Discord server or channel URL");
  const n = new URL(t).origin, a = (await chrome.tabs.query({ url: `${n}/discord/server/*` })).filter((y) => y.id !== void 0 && Pt(y.url || "")?.serverId === e.serverId && new URL(y.url).origin === n).map(async (y) => {
    try {
      const l = await chrome.tabs.sendMessage(y.id, { type: "DISCOVER_CHANNELS" });
      return l?.serverId === e.serverId && Array.isArray(l.channels) ? l : null;
    } catch {
      return null;
    }
  }), [s, ...i] = await Promise.allSettled([Nn.server(e.serverId, n), ...a]), o = s.status === "fulfilled" ? s.value : null, f = i.flatMap((y) => y.status === "fulfilled" && y.value ? [y.value] : []), h = Kn(e.serverId, o, f);
  e.serverName = h?.name || null, e.channelName = h?.channels.find((y) => y.id === e.channelId)?.name || null;
  let m = null;
  return o || (m = `${s.status === "rejected" && s.reason instanceof Error ? s.reason.message : "Server metadata is unavailable."} ${h?.channels.length ? "Using channel links from the open page; hidden or unloaded channels may be missing." : e.channelId ? "Current-channel scanning is still available." : "Open the server page, reload it, and discover its channel links again."}`), { scope: e, server: h, warning: m, apiChannelCount: o?.channels.length || 0, domChannelCount: h?.channels.filter((y) => y.sources?.includes("dom")).length || 0 };
}
async function Re(t, e) {
  if (t.type === "DISCOVER") return Ee(t.url);
  if (t.type === "LIST") {
    const r = (await G()).sort((a, s) => s.createdAt.localeCompare(a.createdAt));
    return Promise.all(r.map(async (a) => ({ job: a, totals: jt(a, await k(a.id)) })));
  }
  if (t.type === "DETAIL") {
    const r = await Ue(t.jobId), a = await k(r.id);
    return { job: r, media: a, totals: jt(r, a) };
  }
  if (t.type === "DASHBOARD")
    return await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") }), null;
  if (t.type === "START") {
    if (!["thumbnail", "best", "original"].includes(t.mode)) throw new Error("Invalid quality mode");
    const { scope: r, server: a, warning: s, apiChannelCount: i, domChannelCount: o } = await Ee(t.url), f = new URL(t.url).origin, h = !!t.allChannels || !r.channelId && !t.channelIds.length, m = [...new Set(h ? a?.channels.map((d) => d.id) || [] : t.channelIds.length ? t.channelIds.map(W) : r.channelId ? [r.channelId] : [])];
    if (!m.length) throw new Error(s || "No channels were discovered in this server. Open the server page and try Discover channels again.");
    if (m.some((d) => d !== r.channelId && !a?.channels.some((g) => g.id === d))) throw new Error("Selected channel was not discovered in this server");
    for (const d of await G()) ["scanning", "downloading"].includes(d.status) && (d.resumeStatus = d.status, d.status = "paused", await R(L(d)));
    const y = {
      service: "discord",
      id: crypto.randomUUID(),
      serverId: r.serverId,
      serverName: r.serverName,
      mode: t.mode,
      tryOriginal: !!t.tryOriginal,
      channels: m.map((d) => {
        const g = a?.channels.find((p) => p.id === d);
        return { channelId: d, channelName: g?.name || null, postCount: g?.postCount ?? null, offset: 0, pages: 0, messageIds: [], pageFingerprints: [], coverage: "pending", terminal: null, failures: [], attempts: 0, nextAttemptAt: 0, error: null, domMessages: 0 };
      }),
      status: "scanning",
      resumeStatus: "scanning",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      warnings: s ? [s] : [],
      autoManifest: !1,
      manifestState: "pending",
      manifestDownloads: [],
      apiNextAt: 0,
      mediaNextAt: 0,
      scope: h ? "server" : m.length === 1 ? "channel" : "selected",
      sourceUrl: `${f}/discord/server/${r.serverId}${r.channelId ? "/" + r.channelId : ""}`,
      discoveredChannelCount: a?.channels.length || m.length,
      channelDiscovery: i ? o ? "api+dom" : "api" : o ? "dom" : "current-channel",
      destination: { kind: "zip" }
    };
    await R(y);
    const l = await chrome.tabs.query({ url: `${f}/discord/server/*` });
    for (const d of l) d.id && Pt(d.url || "")?.serverId === y.serverId && new URL(d.url).origin === f && chrome.tabs.sendMessage(d.id, { type: "SCAN_DOM" }).catch(() => {
    });
    return { jobId: y.id };
  }
  if (t.type === "DOM") {
    const r = fe(t.url), a = fe(e.tab?.url || "");
    if (!r || !a || a.channelId !== r.channelId || a.serverId !== r.serverId || new URL(t.url).origin !== new URL(e.tab.url).origin) return null;
    const s = new URL(t.url).origin;
    for (const i of await G()) {
      if (i.serverId !== r.serverId || new URL(i.sourceUrl || z[0]).origin !== s || !["scanning", "indexed", "paused"].includes(i.status)) continue;
      const o = i.channels.find((h) => h.channelId === r.channelId);
      if (!o) continue;
      const f = t.records.slice(0, 1e4).filter((h) => h.serverId === r.serverId && h.channelId === r.channelId).map((h) => ({
        ...h,
        jobId: i.id,
        service: i.service,
        serverName: i.serverName,
        channelName: o.channelName,
        originalUrl: j(h.originalUrl),
        discordCdnUrl: j(h.discordCdnUrl),
        thumbnailUrl: j(h.thumbnailUrl)
      }));
      o.domMessages = Math.max(o.domMessages, t.messageCount), await lt(L(i), ze(await k(i.id), f));
    }
    return null;
  }
  const n = await Ue(t.jobId);
  if (n.archive?.state === "saving" && (t.type === "DESTINATION" || t.type === "ACTION" && ["download", "retry"].includes(t.action))) throw new Error("Finish or cancel the current ZIP save before starting another");
  if (t.type === "DESTINATION") {
    if (n.status === "downloading") throw new Error("Pause the job before choosing its save destination");
    const r = await k(n.id);
    if (t.kind === "folder") {
      const a = t.directoryId || n.id, s = await dt(a);
      for (const i of r)
        ["downloaded", "staged"].includes(i.status) && (!i.savedPath || !i.sha256 || i.bytes === null || !await Be(a, i.savedPath, i.sha256, i.bytes)) || i.status === "transferring" ? (i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await E(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = n.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null) : i.status === "staged" && (i.status = "downloaded");
      for (const i of n.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await E(i.blobUrl);
      n.destination = { kind: "folder", name: s.name, ...t.directoryId ? { directoryId: a } : {} }, n.manifestState = "pending", n.manifestPaths = [], n.manifestDownloads = [], n.archive = void 0;
    } else if (t.kind === "zip") {
      const a = r.filter((i) => ["downloaded", "staged", "transferring"].includes(i.status)), s = new Set((await U("zip-matches", { jobId: n.id, records: a })).ids);
      for (const i of a)
        i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await E(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = s.has(i.id) ? "staged" : n.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null;
      for (const i of n.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await E(i.blobUrl);
      n.destination = { kind: "zip" }, n.archive = Rt(n), n.manifestState = "pending", n.manifestDownloads = [], n.manifestPaths = [];
    } else if (t.kind === "browser") {
      if (r.some((a) => ["downloaded", "staged"].includes(a.status)) && n.destination?.kind !== "browser" && n.destination) throw new Error("Create a new job to switch collected files to individual Browser downloads.");
      n.destination = { kind: "browser" }, n.archive = void 0;
    } else throw new Error("Unsupported save destination");
    return n.destinationError = null, await lt(L(n), r), null;
  }
  if (t.type === "EXPORT") {
    const r = await k(n.id), a = Nt(n), s = n.id.slice(0, 8), i = `${a}/${t.format === "csv" ? "links" : t.format === "failures" ? "failures" : "manifest"}-${s}.${t.format === "csv" ? "csv" : "json"}`, o = t.format === "csv" ? er(r) : ot(n, t.format === "failures" ? r.filter((h) => h.status === "failed" || h.status === "skipped") : r), f = t.format === "csv" ? "text/csv;charset=utf-8" : "application/json";
    return n.destination?.kind === "folder" ? await U("save-text", { jobId: Q(n), path: i, text: o, mime: f }) : await ne(o, i, f), null;
  }
  if (t.action === "pause") {
    ["scanning", "downloading"].includes(n.status) && (n.resumeStatus = n.status, n.status = "paused");
    for (const r of await k(n.id)) r.status === "transferring" && r.downloadId !== null && await chrome.downloads.pause(r.downloadId).catch(() => {
    });
    n.destination?.kind === "zip" && n.archive?.state === "building" && (await U("zip-stop", { jobId: n.id }), n.archive.state = "pending");
  } else if (t.action === "cancel") {
    n.status = "cancelled", n.destination?.kind === "zip" && (await U("zip-stop", { jobId: n.id }), n.archive?.state === "saving" && n.archive.downloadId !== null && await chrome.downloads.cancel(n.archive.downloadId).catch(() => {
    }), n.archive?.state === "building" && (n.archive.state = "pending"));
    for (const r of await k(n.id))
      r.status === "transferring" && r.downloadId !== null && await chrome.downloads.cancel(r.downloadId).catch(() => {
      }), ["queued", "transferring"].includes(r.status) && (r.status = "skipped", r.errorMessage = "Cancelled by user", await E(r.blobUrl), r.blobUrl = null, await M(r));
  } else if (t.action === "resume") {
    if (n.status !== "paused") throw new Error("Only paused jobs can be resumed");
    n.destination?.kind === "folder" && n.resumeStatus === "downloading" && await dt(Q(n)), n.destinationError = null, n.status = n.resumeStatus;
    for (const r of await k(n.id)) r.status === "transferring" && r.downloadId !== null && await chrome.downloads.resume(r.downloadId).catch(() => {
    });
  } else if (t.action === "retry") {
    for (const r of n.channels) r.coverage === "incomplete" && (r.coverage = "pending", r.attempts = 0, r.error = null, r.nextAttemptAt = 0);
    for (const r of await k(n.id)) (r.status === "failed" || r.status === "skipped") && (r.status = n.autoManifest ? "queued" : "discovered", r.attempts = 0, r.nextAttemptAt = 0, r.errorMessage = null, r.candidateFailures = [], await M(r));
    n.status = n.channels.some((r) => r.coverage !== "complete") ? "scanning" : n.autoManifest ? "downloading" : "indexed", n.manifestState = "pending", n.destination?.kind === "zip" && (n.archive = Rt(n));
  } else if (t.action === "save-zip") {
    if (n.destination?.kind !== "zip") throw new Error("Select ZIP output first");
    return await Pn(n), null;
  } else if (t.action === "clear-cache") {
    if (n.destination?.kind !== "zip" || ["scanning", "downloading"].includes(n.status) || n.archive?.state === "saving") throw new Error("Finish or cancel ZIP saving before clearing its cache");
    await E(n.archive?.blobUrl || null), await U("zip-clear", { jobId: n.id });
    const r = await k(n.id);
    for (const a of r) ["downloaded", "staged"].includes(a.status) && (a.status = "discovered", a.attempts = 0, a.nextAttemptAt = 0);
    return n.archive = void 0, n.status = "indexed", n.autoManifest = !1, n.manifestState = "pending", await lt(L(n), r), null;
  } else if (t.action === "download") {
    if (n.status === "scanning" || n.channels.some((s) => ["pending", "scanning"].includes(s.coverage))) throw new Error("Pause or finish the scan before downloading the indexed results");
    if (!n.destination) throw new Error("Choose a save folder or explicitly select Browser downloads before starting the batch");
    n.destination.kind === "folder" && await dt(Q(n));
    const r = await k(n.id);
    let a;
    n.destination.kind === "zip" && (a = new Set((await U("zip-matches", { jobId: n.id, records: r.filter((s) => ["downloaded", "staged"].includes(s.status)) })).ids), n.archive = Rt(n));
    for (const s of r) (s.status === "discovered" || a && ["staged", "downloaded"].includes(s.status) && !a.has(s.id)) && (s.status = "queued", s.attempts = 0, s.nextAttemptAt = 0, await M(s));
    n.status = "downloading", n.autoManifest = !0, n.manifestState = "pending";
  }
  return await R(L(n)), null;
}
async function Ba(t) {
  if (!t.channels.some((n) => ["pending", "scanning"].includes(n.coverage))) {
    t.status = t.autoManifest ? "downloading" : "indexed", await R(L(t));
    return;
  }
  if (Date.now() < t.apiNextAt) return;
  const e = t.channels.find((n) => ["pending", "scanning"].includes(n.coverage) && n.nextAttemptAt <= Date.now());
  if (!e) {
    t.channels.some((n) => ["pending", "scanning"].includes(n.coverage)) || (t.status = t.autoManifest ? "downloading" : "indexed", await R(L(t)));
    return;
  }
  try {
    const n = new URL(t.sourceUrl || z[0]).origin, r = await Nn.channel(e.channelId, e.offset, n), a = _n(e, r), s = Qn(r, { serverId: t.serverId, serverName: t.serverName, channelId: e.channelId, channelName: e.channelName, service: t.service }, t.id, n);
    if (t.autoManifest) for (const i of s) i.status = "queued";
    t.channels[t.channels.indexOf(e)] = a, a.coverage === "complete" && a.postCount !== null && a.postCount !== a.messageIds.length && t.warnings.push(`Channel ${a.channelId}: metadata post_count=${a.postCount}; API unique messages=${a.messageIds.length}.`), t.apiNextAt = Date.now() + 1100, await lt(L(t), ze(await k(t.id), s));
  } catch (n) {
    e.attempts++, e.error = n instanceof Error ? n.message : "Page scan failed", e.failures.push({ offset: e.offset, reason: e.error, at: (/* @__PURE__ */ new Date()).toISOString() });
    const r = n instanceof T && n.retryable;
    if (n instanceof T && n.status === 429 && (t.apiNextAt = Date.now() + st(e.attempts, n.retryAfterMs)), r && e.attempts < pt) {
      const a = st(e.attempts, n.retryAfterMs);
      e.nextAttemptAt = Date.now() + a, t.apiNextAt = e.nextAttemptAt;
    } else e.coverage = "incomplete";
    await R(L(t));
  }
}
async function qa(t, e) {
  t.manifestState = "saving", t.manifestDownloads = [], await R(L(t));
  try {
    if (t.destination?.kind === "folder") {
      t.manifestPaths = [];
      for (const s of t.channels) {
        const i = `${Qt({ ...t, channelId: s.channelId, channelName: s.channelName })}/channel-manifest.json`;
        await U("save-text", { jobId: Q(t), path: i, text: ot(t, e, s.channelId), overwrite: !0 }), t.manifestPaths.push(i), await R(t);
      }
      const a = `${Nt(t)}/manifest.json`;
      await U("save-text", { jobId: Q(t), path: a, text: ot(t, e), overwrite: !0 }), t.manifestPaths.push(a), t.manifestState = "saved", await R(L(t));
      return;
    }
    for (const a of t.channels) {
      const s = `${Qt({ ...t, channelId: a.channelId, channelName: a.channelName })}/channel-manifest.json`, i = await ne(ot(t, e, a.channelId), s, "application/json", !0);
      t.manifestDownloads.push({ ...i, path: s, state: "in_progress" }), await R(t);
    }
    const n = `${Nt(t)}/manifest.json`, r = await ne(ot(t, e), n, "application/json", !0);
    t.manifestDownloads.push({ ...r, path: n, state: "in_progress" }), await R(t);
  } catch (n) {
    n instanceof Y ? (t.manifestState = "pending", await qt(t, n)) : (t.manifestState = "failed", t.warnings.push("One or more manifest saves failed. Use Export JSON to save the current state."), await R(L(t)));
  }
}
async function qt(t, e) {
  t.resumeStatus = "downloading", t.status = "paused", t.destinationError = e.message, await R(L(t));
}
async function Fa() {
  const t = await G(), e = Math.max(0, ...t.map((r) => r.apiNextAt)), n = Math.max(0, ...t.map((r) => r.mediaNextAt));
  for (const r of t) {
    if (r.status === "scanning") {
      (Date.now() >= e || r.channels.every((o) => !["pending", "scanning"].includes(o.coverage))) && await Ba(r);
      return;
    }
    if (r.status !== "downloading") continue;
    if (r.destination?.kind === "folder")
      try {
        await dt(Q(r));
      } catch (o) {
        await qt(r, o instanceof Error ? o : new Y());
        return;
      }
    let a = await k(r.id);
    for (const o of a) o.status === "transferring" && (o.downloadId !== null || ["folder", "zip"].includes(r.destination?.kind || "")) && await de(o, !0, r);
    a = await k(r.id);
    const s = a.filter((o) => o.status === "transferring").length, i = a.filter((o) => o.status === "queued" && o.nextAttemptAt <= Date.now()).slice(0, Math.max(0, 2 - s));
    if (i.length && Date.now() >= n) {
      const o = await Promise.allSettled(i.map((m) => za(m, r))), f = o.find((m) => m.status === "rejected");
      if (f?.status === "rejected") {
        if (f.reason instanceof Y || f.reason instanceof bt) {
          await qt(r, f.reason);
          return;
        }
        throw f.reason;
      }
      const h = o.flatMap((m) => m.status === "fulfilled" ? [m.value] : []);
      r.mediaNextAt = Date.now() + Math.max(r.destination?.kind === "zip" ? 250 : 1100, ...h), await R(r);
    }
    if (a = await k(r.id), !a.some((o) => o.status === "queued" || o.status === "transferring")) {
      if (r.destination?.kind === "zip") {
        await Ma(r, a);
        return;
      }
      r.status = "finished", await R(L(r)), r.autoManifest && r.manifestState === "pending" && await qa(r, a);
    }
    if (r.destination?.kind === "zip") {
      const o = a.filter((f) => f.status === "queued");
      if (o.length) {
        const f = Math.max(n, r.mediaNextAt, Math.min(...o.map((h) => h.nextAttemptAt)));
        return Math.max(100, Math.min(1200, f - Date.now()));
      }
    }
    return;
  }
}
async function Ha() {
  for (const t of await G()) {
    t.destination?.kind === "zip" && await Dn(t, !0);
    try {
      for (const e of await k(t.id)) e.status === "transferring" && await de(e, !0, t);
    } catch (e) {
      if (!(e instanceof Y || e instanceof bt)) throw e;
      t.status === "downloading" && await qt(t, e);
    }
    if (t.manifestState === "saving") {
      if (t.destination?.kind === "zip") continue;
      if (t.destination?.kind === "folder") {
        t.manifestState = "pending", t.status === "finished" && (t.status = "downloading"), await R(t);
        continue;
      }
      for (const e of t.manifestDownloads) {
        const [n] = await chrome.downloads.search({ id: e.id });
        e.state = n?.state === "complete" ? "complete" : n?.state === "in_progress" ? "in_progress" : "interrupted";
      }
      t.manifestDownloads.length !== t.channels.length + 1 ? (t.manifestState = "pending", t.status === "finished" && (t.status = "downloading")) : t.manifestDownloads.every((e) => e.state === "complete") ? t.manifestState = "saved" : t.manifestDownloads.some((e) => e.state === "interrupted") && (t.manifestState = "failed"), await R(t);
    }
  }
}
async function Za(t) {
  if (!t.state || !["complete", "interrupted"].includes(t.state.current || "")) return;
  for (const n of await G()) {
    n.destination?.kind === "zip" && n.archive?.downloadId === t.id && await Dn(n);
    for (const a of await k(n.id)) a.downloadId === t.id && a.status === "transferring" && await de(a);
    const r = n.manifestDownloads.find((a) => a.id === t.id);
    r && (r.state = t.state.current === "complete" ? "complete" : "interrupted", await E(r.blobUrl), n.manifestDownloads.length === n.channels.length + 1 && n.manifestDownloads.every((a) => a.state === "complete") && (n.manifestState = "saved"), r.state === "interrupted" && (n.manifestState = "failed"), await R(L(n)));
  }
  const [e] = await chrome.downloads.search({ id: t.id });
  e?.url.startsWith(`blob:chrome-extension://${chrome.runtime.id}/`) && await E(e.url);
}
function vt(t) {
  try {
    const e = new URL(t);
    return z.includes(e.origin) && !e.username && !e.password;
  } catch {
    return !1;
  }
}
function re(t) {
  if (!vt(t)) return null;
  const e = new URL(t), n = /^\/(fanbox|patreon)\/user\/(\d+)(?:\/post\/(\d+))?\/?$/.exec(e.pathname);
  return n ? { origin: e.origin, platform: n[1], creatorId: n[2], postId: n[3] || null } : null;
}
function Ce(t) {
  return `${t.origin}/${t.platform}/user/${t.creatorId}${t.postId ? `/post/${t.postId}` : ""}`;
}
class Wa extends Le {
  validate(e, n) {
    const r = e;
    if (!r || typeof r != "object" || typeof r.id != "string" || !/^\d+$/.test(r.id) || r.user !== n.creatorId || r.service !== n.platform) throw new T("Post response belongs to a different creator or service.", 422);
    if (r.attachments != null && (!Array.isArray(r.attachments) || r.attachments.some((a) => !a || typeof a != "object"))) throw new T("Invalid post attachment list.", 422);
    if (r.content != null && typeof r.content != "string") throw new T("Invalid post text.", 422);
    return r;
  }
  async profile(e) {
    const n = await this.json(`/${e.platform}/user/${e.creatorId}/profile`, e.origin);
    return n && n.id === e.creatorId && typeof n.name == "string" ? n.name : e.creatorId;
  }
  async total(e) {
    const n = await fetch(`${e.origin}/${e.platform}/user/${e.creatorId}`, { headers: { Accept: "text/html" }, credentials: "omit", redirect: "error", signal: AbortSignal.timeout(1e4) });
    if (!n.ok) return null;
    const r = /Showing\s+[\d,]+\s*[-–]\s*[\d,]+\s+of\s+([\d,]+)/i.exec(await n.text()), a = r ? Number(r[1].replaceAll(",", "")) : NaN;
    return Number.isSafeInteger(a) && a >= 0 ? a : null;
  }
  async posts(e, n) {
    const r = `/${e.platform}/user/${e.creatorId}`;
    let a;
    try {
      a = await this.json(`${r}${e.origin === "https://kemono.cr" ? "/posts" : ""}?o=${n}`, e.origin);
    } catch (i) {
      if (!(i instanceof T) || i.status !== 404) throw i;
      a = await this.json(`${r}${e.origin === "https://kemono.cr" ? "" : "/posts"}?o=${n}`, e.origin);
    }
    const s = Array.isArray(a) ? a : a?.posts;
    if (!Array.isArray(s)) throw new T("Post list is not an array.", 422);
    return s.map((i) => this.validate(i, e));
  }
  async post(e) {
    const n = await this.json(`/${e.platform}/user/${e.creatorId}/post/${e.postId}`, e.origin), r = this.validate(n?.post || n, e);
    if (r.id !== e.postId) throw new T("The API returned a different post.", 422);
    return r;
  }
}
const kn = /^\/[0-9a-f]{2}\/[0-9a-f]{2}\/[0-9a-f]{64}(?:\.[a-z0-9_-]{1,16})?$/i, Pe = /\.(png|jpe?g|webp|gif|avif|bmp|tiff?|svg|heic|heif|jxl)$/i;
function ae(t) {
  if (typeof t != "string") return null;
  try {
    const e = new URL(t);
    if (e.protocol !== "https:" || e.port || e.username || e.password) return null;
    const n = e.hostname, r = /^(?:img\.(?:kemono\.cr|pawchive\.pw))$/.test(n), a = z.includes(e.origin) || /^(?:file|n[1-4])\.(?:kemono\.cr|pawchive\.pw)$/.test(n), s = r ? "/thumbnail/data" : "/data";
    return !(r || a) || !e.pathname.startsWith(s + "/") || !kn.test(e.pathname.slice(s.length)) ? null : (e.hash = "", e.href);
  } catch {
    return null;
  }
}
function De(t, e, n, r) {
  const a = t.path;
  if (typeof a != "string" || !kn.test(a)) return null;
  const s = typeof t.name == "string" && t.name ? t.name : a.split("/").at(-1), i = Pe.test(a) || Pe.test(s) ? "image" : "file", o = new URL(e.origin).hostname, f = Number.isInteger(t.node) && t.node >= 1 && t.node <= 4 ? t.node : null, h = f ? `n${f}.${o}` : o === "pawchive.pw" ? "file.pawchive.pw" : o, m = n === !1 ? null : ae(`https://${h}/data${a}?f=${encodeURIComponent(s)}`);
  return { id: `${r}:${a}`, name: s, path: a, kind: i, thumbnailUrl: i === "image" ? ae(`https://img.${o}/thumbnail/data${a}`) : null, originalUrl: m };
}
function Ne(t, e) {
  const n = typeof t.has_full == "boolean" ? t.has_full : null, r = [];
  for (const a of [t.file, ...t.attachments || []]) {
    if (!a) continue;
    const s = De(a, e, n, r.length + 1);
    s && !r.some((i) => i.path === s.path) && r.push(s);
  }
  for (const a of (t.content || "").matchAll(/(?:src|href)=["']([^"']+)["']/gi)) {
    let s = null;
    try {
      s = ae(new URL(a[1].replaceAll("&amp;", "&"), e.origin).href);
    } catch {
    }
    if (!s) continue;
    const i = new URL(s).pathname.replace(/^\/(?:thumbnail\/)?data/, "");
    if (r.some((f) => f.path === i)) continue;
    const o = De({ path: i }, e, n, r.length + 1);
    o && (new URL(s).pathname.startsWith("/thumbnail/") || (o.originalUrl = n === !1 ? null : s), r.push(o));
  }
  return { id: t.id, title: t.title || `Post ${t.id}`, content: t.content || "", published: t.published || null, hasFull: n, media: r, embed: t.embed || null };
}
function Ya(t) {
  return `${t.source.platform}/${t.source.creatorId}_${$(t.creatorName, "creator")}`;
}
function Xa(t) {
  const e = t.lastIndexOf("."), n = e >= 0 && /^[a-z0-9_-]{1,16}$/i.test(t.slice(e + 1)) ? t.slice(e) : "";
  return $(n ? t.slice(0, e) : t, "attachment") + n;
}
function Va(t, e) {
  const n = [], r = e.quality === "both" ? ["thumbnail", "full res"] : [e.quality];
  for (const a of t.posts) for (const s of r) {
    const i = `${t.destination?.kind === "folder" ? "" : Ya(t) + "/"}${s}/${a.id}_${$(a.title, "post")}`;
    for (const [o, f] of a.media.entries()) {
      if (f.kind === "image" ? !e.images : !e.files || s === "thumbnail") continue;
      const h = s === "thumbnail" ? f.thumbnailUrl : f.originalUrl;
      n.push({ id: `${a.id}:${s}:${f.id}`, postId: a.id, quality: s, kind: f.kind, url: h, path: `${i}/${String(o + 1).padStart(3, "0")}_${Xa(f.name)}`, status: h ? "queued" : "unavailable", bytes: null, attempts: 0, nextAt: 0, error: h ? null : "Full-resolution file was not archived; no thumbnail was substituted." });
    }
    e.text && n.push({ id: `${a.id}:${s}:text`, postId: a.id, quality: s, kind: "text", url: null, path: `${i}/post.txt`, status: "queued", bytes: null, attempts: 0, nextAt: 0, error: null });
  }
  return n;
}
const et = (t) => {
  if (!t || typeof t != "object" || Array.isArray(t)) throw new Error("Invalid post sync JSON.");
  return t;
};
function On(t) {
  return t.replace(/^(\d+:(?:thumbnail|full res):)\d+:(\/)/, "$1$2");
}
function Tn(t) {
  const e = et(t);
  if (!["thumbnail", "full res", "both"].includes(String(e.quality)) || ["images", "files", "text"].some((n) => typeof e[n] != "boolean")) throw new Error("Invalid content selection.");
  return { quality: e.quality, images: e.images, files: e.files, text: e.text };
}
function ue(t, e) {
  if (t.source.origin !== e.origin || t.source.platform !== e.platform || t.source.creatorId !== e.creatorId) throw new Error("This JSON belongs to a different website, service, or creator. Open that creator’s profile to sync it.");
}
function Ga(t, e, n = !1) {
  const r = et(t);
  if (typeof r.id != "string" || r.id.length > 500 || !["thumbnail", "full res"].includes(String(r.quality)) || !["image", "file", "text"].includes(String(r.kind)) || typeof r.path != "string" || r.path.length > 2e3 || !Number.isSafeInteger(r.bytes) || r.bytes <= 0) throw new Error("Invalid downloaded file in sync JSON.");
  const a = On(r.id);
  if (!a.startsWith(`${e}:${r.quality}:`) || (r.kind === "text" ? a !== `${e}:${r.quality}:text` : !/^\/[a-f0-9]{2}\/[a-f0-9]{2}\/[a-f0-9]{64}(?:\.[a-z0-9_-]{1,16})?$/i.test(a.slice(`${e}:${r.quality}:`.length)))) throw new Error("Invalid downloaded file ID in sync JSON.");
  let s = r.path;
  if (n) {
    const o = kt(s), f = o.findIndex((h) => h === r.quality);
    if (f < 0) throw new Error("Invalid legacy archive path.");
    s = o.slice(f).join("/");
  }
  const i = kt(s);
  if (i.length !== 3 || i[0] !== r.quality || !i[1].startsWith(e + "_")) throw new Error("Downloaded paths must stay inside this post’s quality folder.");
  return { id: a, quality: r.quality, kind: r.kind, path: s, bytes: r.bytes };
}
function Ka(t, e) {
  const n = et(t), r = n.schemaVersion === 1 && typeof n.sourceUrl == "string" && Array.isArray(n.files) && Array.isArray(n.posts);
  let a;
  if (r) a = re(n.sourceUrl);
  else {
    if (n.format !== "archive-ripper-post-sync" || n.version !== 1) throw new Error("Choose sync.json or a post archive manifest.json. A failures.json is not a download history.");
    const h = et(n.source);
    if (a = re(`${h.origin}/${h.platform}/user/${h.creatorId}`), !a || h.origin !== a.origin || h.platform !== a.platform || h.creatorId !== a.creatorId) throw new Error("Invalid creator in sync JSON.");
  }
  if (!a) throw new Error("Invalid creator in sync JSON.");
  const s = { format: "archive-ripper-post-sync", version: 1, source: { origin: a.origin, platform: a.platform, creatorId: a.creatorId }, creatorName: String(r ? n.creator || a.creatorId : n.creatorName || a.creatorId).slice(0, 300), updatedAt: (/* @__PURE__ */ new Date()).toISOString(), selection: Tn(n.selection), posts: [] };
  if (ue(s, e), !Array.isArray(n.posts) || n.posts.length > 1e5) throw new Error("Invalid post list in sync JSON.");
  let i = 0;
  const o = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map();
  if (r) for (const h of n.files) {
    const m = et(h);
    if (!["staged", "downloaded"].includes(String(m.status))) continue;
    const y = String(m.postId), l = f.get(y) || [];
    l.push(m), f.set(y, l);
  }
  for (const h of n.posts) {
    const m = et(h);
    if (typeof m.id != "string" || !/^\d{1,40}$/.test(m.id) || o.has(m.id)) throw new Error("Invalid or duplicate post ID in sync JSON.");
    o.add(m.id);
    const y = r ? f.get(m.id) || [] : m.files;
    if (!Array.isArray(y) || (i += y.length) > 2e5) throw new Error("Invalid file list in sync JSON.");
    const l = y.map((d) => Ga(d, m.id, r));
    if (new Set(l.map((d) => d.id)).size !== l.length) throw new Error("Duplicate file ID in sync JSON.");
    l.length && s.posts.push({ id: m.id, title: String(m.title || `Post ${m.id}`).slice(0, 500), files: l });
  }
  return s;
}
function Ln(t) {
  const { origin: e, platform: n, creatorId: r } = t.source;
  return { format: "archive-ripper-post-sync", version: 1, source: { origin: e, platform: n, creatorId: r }, creatorName: t.creatorName, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), selection: t.selection, posts: [] };
}
function ke(t, e) {
  if (!t) return structuredClone(e);
  ue(e, { ...t.source });
  const n = structuredClone(t), r = new Map(n.posts.map((a) => [a.id, a]));
  for (const a of e.posts) {
    const s = r.get(a.id);
    if (s) {
      const i = new Map(s.files.map((o) => [o.id, o]));
      for (const o of a.files) i.set(o.id, { ...o });
      s.files = [...i.values()];
    } else {
      const i = structuredClone(a);
      n.posts.push(i), r.set(i.id, i);
    }
  }
  return n.selection = e.selection, n.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), n;
}
function Ja(t, e, n) {
  if (!["downloaded", "staged"].includes(e.status) || !e.bytes) return;
  let r = t.posts.find((i) => i.id === e.postId);
  r || (r = { id: e.postId, title: n, files: [] }, t.posts.push(r));
  const a = { id: On(e.id), quality: e.quality, kind: e.kind, path: e.path, bytes: e.bytes }, s = r.files.findIndex((i) => i.id === a.id);
  s < 0 ? r.files.push(a) : r.files[s] = a, t.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
}
const ht = new Wa(), zn = (t, e = 0) => Math.max(e, 2e3 * 2 ** Math.max(0, t - 1));
async function Qa(t) {
  const e = await tr(t);
  if (!e) throw new Error("Post archive was not found.");
  return e;
}
function Kt(t) {
  t.posts = [], t.detailQueue = [], t.tasks = [], t.status = "scanning", t.resumeStatus = "scanning", t.scan = { offset: 0, pages: 0, total: t.source.postId ? 1 : null, complete: !1, error: null, attempts: 0, nextAt: 0, fingerprints: [] }, t.nextAt = 0, t.error = null, t.archive = void 0, t.autoDownload = void 0;
}
async function Mn(t) {
  const e = t.autoDownload;
  if (!(!e || !t.scan.complete)) {
    t.autoDownload = void 0, t.status = "ready", await O(t);
    try {
      await qn({ type: "POST_DOWNLOAD", jobId: t.id, selection: e, destination: "folder" });
    } catch (n) {
      t.autoDownload = e, t.status = "paused", t.resumeStatus = "downloading", t.error = n instanceof Error ? n.message : "Could not start sync.", await O(t);
    }
  }
}
async function at() {
  for (const t of await Ht()) if (["scanning", "downloading"].includes(t.status)) {
    t.resumeStatus = t.status, t.status = "paused", await U("post-transfer-stop", { jobId: t.id });
    for (const e of t.tasks) e.status === "transferring" && (e.status = "queued", e.attempts = Math.max(0, e.attempts - 1));
    t.archive?.state === "building" && (await U("zip-stop", { jobId: t.id }), t.archive.state = "pending"), await O(t);
  }
}
function ja(t, e = 100) {
  const { posts: n, tasks: r, sync: a, ...s } = t, i = new Set(a?.posts.map((o) => o.id));
  return { job: s, totals: {
    synced: r.filter((o) => o.synced).length,
    syncPosts: a?.posts.length || 0,
    newPosts: n.filter((o) => !i.has(o.id)).length,
    posts: n.length,
    discovered: n.length - t.detailQueue.length,
    total: t.scan.total,
    images: n.reduce((o, f) => o + f.media.filter((h) => h.kind === "image").length, 0),
    files: n.reduce((o, f) => o + f.media.filter((h) => h.kind === "file").length, 0),
    fullPosts: n.filter((o) => o.hasFull !== !1).length,
    selected: r.length,
    saved: r.filter((o) => o.status === "downloaded" || t.destination?.kind !== "folder" && o.status === "staged").length,
    failed: r.filter((o) => ["failed", "unavailable"].includes(o.status)).length,
    retryable: r.filter((o) => o.status === "failed").length,
    processed: r.filter((o) => ["downloaded", "failed", "unavailable"].includes(o.status) || t.destination?.kind !== "folder" && o.status === "staged").length
  }, posts: n.slice(0, Math.min(1e3, Math.max(1, e))).map((o) => ({ id: o.id, title: o.title, files: o.media.length, hasFull: o.hasFull })) };
}
async function Bn(t) {
  const e = t.archive;
  if (!e || !["ready", "saved"].includes(e.state)) throw new Error("The ZIP is still being prepared.");
  await E(e.blobUrl);
  const n = await U("zip-open", { jobId: t.id });
  Object.assign(e, n, { state: "saving", downloadId: null, error: null }), await O(t);
  try {
    e.downloadId = await chrome.downloads.download({ url: n.blobUrl, filename: e.filename, conflictAction: "uniquify", saveAs: !0 });
  } catch {
    e.state = "ready", e.error = "Save was cancelled. Choose Save ZIP to try again.", await E(e.blobUrl), e.blobUrl = null;
  }
  await O(t);
}
async function qn(t) {
  if (t.type === "POST_START") {
    const n = re(t.url);
    if (!n) throw new Error("Open a Patreon or Fanbox profile or post on Kemono or Pawchive.");
    await at();
    for (const s of await G()) ["scanning", "downloading"].includes(s.status) && (s.resumeStatus = s.status, s.status = "paused", await R(s));
    const r = {
      id: crypto.randomUUID(),
      service: "posts",
      source: n,
      sourceUrl: Ce(n),
      creatorName: n.creatorId,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      status: "scanning",
      resumeStatus: "scanning",
      selection: { quality: "thumbnail", images: !0, files: !0, text: !0 },
      scan: { offset: 0, pages: 0, total: n.postId ? 1 : Number.isSafeInteger(t.expectedPosts) && t.expectedPosts > 0 ? t.expectedPosts : null, complete: !1, error: null, attempts: 0, nextAt: 0, fingerprints: [] },
      posts: [],
      detailQueue: [],
      tasks: [],
      archive: void 0,
      destination: { kind: "folder", directoryId: "", name: "" },
      nextAt: 0,
      error: null
    }, a = await Promise.allSettled([ht.profile(n), r.scan.total === null ? ht.total(n) : Promise.resolve(r.scan.total)]);
    return a[0].status === "fulfilled" && (r.creatorName = a[0].value), a[1].status === "fulfilled" && (r.scan.total = a[1].value), await O(r), { jobId: r.id };
  }
  const e = await Qa(t.jobId);
  if (t.type === "POST_DETAIL") return ja(e, t.limit);
  if (e.archive?.state === "saving" && !(t.type === "POST_ACTION" && t.action === "cancel")) throw new Error("Finish or cancel the current ZIP save first.");
  if (t.type === "POST_FOLDER") {
    if (e.status === "downloading") throw new Error("Pause this download before changing its folder.");
    if (typeof t.directoryId != "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(t.directoryId)) throw new Error("Invalid folder selection.");
    const n = await U("post-folder-read", { directoryId: t.directoryId, postJob: e });
    e.destination = { kind: "folder", directoryId: t.directoryId, name: String(t.name).slice(0, 300) }, await E(e.archive?.blobUrl || null), e.archive = void 0, e.tasks = [], e.autoDownload = void 0, e.scan.complete && (e.status = "ready"), n && (e.sync = ke(e.sync, n), e.tasks.length || (e.selection = n.selection));
  } else if (t.type === "POST_SYNC_IMPORT") {
    if (e.status === "downloading") throw new Error("Pause this download before importing a sync JSON.");
    const n = Ka(t.json, e.source);
    await at(), e.sync = ke(e.sync, n), e.selection = n.selection, e.source.postId = null, e.sourceUrl = Ce(e.source), await E(e.archive?.blobUrl || null), Kt(e), e.destination?.kind !== "folder" && (e.destination = { kind: "folder", directoryId: "", name: "" });
  } else if (t.type === "POST_DOWNLOAD") {
    if (!e.scan.complete || ["scanning", "downloading"].includes(e.status)) throw new Error("Finish scanning before starting another download.");
    const n = Tn(t.selection), r = t.destination || e.destination?.kind || "zip";
    if (!["folder", "zip"].includes(r)) throw new Error("Invalid download destination.");
    if (r === "zip" && e.sync) throw new Error("Sync extends an existing folder. Choose Save to folder.");
    if (r === "folder" && (e.destination?.kind !== "folder" || !e.destination.directoryId)) throw new Error("Choose the creator folder before saving. For an older ZIP, choose its extracted creator folder containing thumbnail or full res.");
    if (r === "folder" && e.status === "finished" && !e.source.postId)
      return Kt(e), e.autoDownload = n, await O(e), null;
    r === "zip" && (e.destination = { kind: "zip" }), e.autoDownload = void 0;
    const a = new Map(e.tasks.map((s) => [s.id, s]));
    if (e.tasks = Va(e, n), !e.tasks.length) throw new Error("Choose at least one available content type. Other files require Full resolution or Both.");
    for (const s of e.tasks) {
      const i = a.get(s.id);
      i && ["staged", "downloaded"].includes(i.status) && await U("post-cached", { jobId: e.id, task: i }) && (Object.assign(s, { status: "staged", bytes: i.bytes }), s.kind === "image" && (s.path = s.path.replace(/\.[^/.]+$/, i.path.slice(i.path.lastIndexOf(".")))));
    }
    if (r === "folder") {
      const s = await U("post-folder-check", { postJob: e });
      e.sync = s.sync || Ln(e);
      const i = new Map(s.files.map((o) => [o.id, o]));
      for (const o of e.tasks) {
        const f = i.get(o.id);
        f && Object.assign(o, f, { status: "downloaded", synced: !0, error: null });
      }
      e.sync.selection = n;
    }
    e.selection = n, e.status = "downloading", e.resumeStatus = "downloading", e.error = null, e.archive && await E(e.archive.blobUrl), e.archive = r === "zip" ? { state: "pending", filename: `${e.source.platform}_${e.source.creatorId}_${$(e.creatorName)}${e.source.postId ? "_post-" + e.source.postId : ""}_${e.id.slice(0, 8)}.zip`, blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null } : void 0;
  } else {
    if (t.action === "pause")
      return await at(), null;
    if (t.action === "rescan") {
      if (["scanning", "downloading"].includes(e.status)) throw new Error("Pause or finish this job before scanning again.");
      await E(e.archive?.blobUrl || null), Kt(e);
    } else if (t.action === "resume" || t.action === "retry") {
      if (t.action === "resume" && e.status !== "paused") throw new Error("Only paused jobs can be resumed.");
      if (e.error = null, e.scan.error = null, e.scan.attempts = 0, e.scan.nextAt = 0, e.scan.complete && e.autoDownload)
        return await Mn(e), null;
      for (const n of e.tasks) n.status === "failed" && (n.status = "queued", n.attempts = 0, n.nextAt = 0, n.error = null);
      e.status = e.scan.complete ? e.tasks.length ? "downloading" : "ready" : "scanning", e.archive && e.archive.state !== "pending" && (await E(e.archive.blobUrl), e.archive.blobUrl = null, e.archive.downloadId = null, e.archive.error = null, await U("zip-stop", { jobId: e.id }), e.archive.state = "pending");
    } else if (t.action === "cancel") {
      await U("post-transfer-stop", { jobId: e.id }), await U("zip-stop", { jobId: e.id });
      for (const n of e.tasks) n.status === "transferring" && (n.status = "queued");
      e.archive?.state === "saving" && e.archive.downloadId !== null && await chrome.downloads.cancel(e.archive.downloadId).catch(() => {
      }), e.archive?.state === "building" && (e.archive.state = "pending"), e.status = "cancelled";
    } else {
      if (t.action === "save-zip")
        return await Bn(e), null;
      if (t.action === "clear-cache") {
        if (["scanning", "downloading"].includes(e.status)) throw new Error("Pause or finish this job before clearing its cache.");
        await E(e.archive?.blobUrl || null), await U("zip-clear", { jobId: e.id }), e.archive = void 0, e.tasks = [], e.status = e.scan.complete ? "ready" : "paused";
      }
    }
  }
  return await O(e), null;
}
async function _a(t) {
  try {
    if (t.detailQueue.length) {
      const e = await ht.post({ ...t.source, postId: t.detailQueue[0] }), n = t.posts.findIndex((r) => r.id === e.id);
      t.posts[n] = Ne(e, t.source), t.detailQueue.shift();
    } else {
      const e = t.source.postId ? [await ht.post(t.source)] : await ht.posts(t.source, t.scan.offset), n = e.map((a) => a.id).join(",");
      if (e.length && t.scan.fingerprints.includes(n)) throw new Error("The API repeated a page. Retry to finish this scan.");
      if (t.scan.pages >= 1e4) throw new Error("The profile exceeded the scan page limit.");
      e.length && t.scan.fingerprints.push(n);
      const r = new Set(t.posts.map((a) => a.id));
      for (const a of e) r.has(a.id) || (t.posts.push(Ne(a, t.source)), r.add(a.id), !t.source.postId && (a.detail_fetched === !1 || a.content === void 0 || a.attachments === void 0) && t.detailQueue.push(a.id));
      t.scan.offset += 50, t.scan.pages++, (!e.length || t.source.postId) && (t.scan.complete = !0, t.scan.total = t.posts.length, t.status = "ready");
    }
    t.scan.attempts = 0, t.scan.error = null, t.scan.nextAt = Date.now() + 1e3;
  } catch (e) {
    t.scan.attempts++, t.scan.error = e instanceof Error ? e.message : "Post discovery failed.", e instanceof T && e.retryable && t.scan.attempts < 3 ? t.scan.nextAt = Date.now() + zn(t.scan.attempts, e.retryAfterMs) : (t.status = "paused", t.resumeStatus = "scanning", t.error = t.scan.error);
  }
  await O(t), t.scan.complete && t.autoDownload && await Mn(t);
}
async function Fn(t) {
  for (const e of t.tasks) if (e.status === "transferring") {
    const n = await U("post-transfer-status", { jobId: t.id, recordId: e.id });
    if (n?.state === "transferring") continue;
    if (n?.bytes !== void 0)
      e.bytes = n.bytes, e.status = "staged", e.error = null, e.kind === "image" && n.ext && (e.path = e.path.replace(/\.[^/.]+$/, "." + n.ext));
    else {
      e.error = n?.failure || "Transfer interrupted; retrying.";
      const r = !n?.status || n.status === 429 || n.status >= 500;
      e.status = r && e.attempts < 3 ? "queued" : "failed", e.nextAt = Date.now() + zn(e.attempts, n?.retryAfterMs), n?.status === 429 && (t.nextAt = Math.max(t.nextAt, e.nextAt));
    }
    await O(t), await U("post-transfer-forget", { jobId: t.id, recordId: e.id });
  }
}
async function $a() {
  const t = await Ht(), e = Math.max(0, ...t.map((n) => Math.max(n.nextAt, n.scan.nextAt)));
  for (const n of t) {
    if (n.status === "scanning")
      return Date.now() >= e && await _a(n), !0;
    if (n.status !== "downloading") continue;
    if (await Fn(n), n.destination?.kind === "folder")
      try {
        for (const i of n.tasks) if (i.status === "staged") {
          const o = await U("post-folder-write", { postJob: n, recordId: i.id });
          Object.assign(i, o, { status: "downloaded" }), n.sync ||= Ln(n), ue(n.sync, n.source), Ja(n.sync, i, n.posts.find((f) => f.id === i.postId)?.title || i.postId), await O(n), await U("post-folder-index", { postJob: n }), await U("post-cache-remove", { jobId: n.id, recordId: i.id }).catch(() => {
          });
        }
      } catch (i) {
        await U("post-transfer-stop", { jobId: n.id });
        for (const o of n.tasks) o.status === "transferring" && (o.status = "queued", o.attempts = Math.max(0, o.attempts - 1));
        return n.status = "paused", n.resumeStatus = "downloading", n.error = i instanceof Error ? i.message : "Could not write to the creator folder. Check folder access and free disk space, then Resume.", await O(n), !0;
      }
    const r = n.tasks.filter((i) => i.status === "transferring").length, a = Date.now() >= e ? n.tasks.filter((i) => i.status === "queued" && i.nextAt <= Date.now()).slice(0, Math.max(0, 2 - r)) : [];
    for (const i of a)
      i.status = "transferring", i.attempts++, await O(n), await U("post-transfer-start", { jobId: n.id, task: i, post: n.posts.find((o) => o.id === i.postId), source: n.source });
    if (a.length && (n.nextAt = Date.now() + 400, await O(n)), n.tasks.some((i) => ["queued", "transferring"].includes(i.status))) return !0;
    if (n.destination?.kind === "folder") {
      try {
        await U("post-folder-index", { postJob: n }), n.status = "finished", await U("zip-clear", { jobId: n.id }).catch(() => {
        });
      } catch (i) {
        n.status = "paused", n.error = i instanceof Error ? i.message : "Could not update sync.json. Check folder access, then Resume.";
      }
      return await O(n), !0;
    }
    const s = n.archive;
    if (s.state === "pending")
      await U("post-zip-build-start", { postJob: n }), s.state = "building";
    else if (s.state === "building") {
      const i = await U("zip-build-status", { jobId: n.id });
      if (!i) s.state = "pending";
      else {
        if (Object.assign(s, i), i.state === "ready")
          return n.status = "finished", await O(n), await Bn(n), !0;
        i.state === "failed" && (n.status = "finished", n.error = i.error);
      }
    }
    return await O(n), !0;
  }
  return !1;
}
async function Hn(t = !1) {
  for (const e of await Ht()) {
    const n = e.archive;
    if (n?.state === "saving") {
      let r;
      if (n.downloadId !== null ? [r] = await chrome.downloads.search({ id: n.downloadId }) : n.blobUrl && (r = (await chrome.downloads.search({ query: [n.filename], limit: 20 })).find((a) => a.url === n.blobUrl)), r?.state === "complete" && r.exists !== !1) {
        n.state = "saved", n.error = null;
        for (const a of e.tasks) a.status === "staged" && (a.status = "downloaded");
      } else if (r?.state === "interrupted" || r?.exists === !1 || !r && t)
        n.state = "ready", n.error = "ZIP saving was interrupted. Choose Save ZIP to retry.";
      else continue;
      await E(n.blobUrl), n.blobUrl = null, await O(e);
    }
    t && e.status === "downloading" && await Fn(e);
  }
}
async function ts(t, e) {
  const n = e.id === chrome.runtime.id && e.tab?.url?.split("#")[0] === chrome.runtime.getURL("folder/index.html");
  if (e.tab?.url && !vt(e.tab.url) && !n) throw new Error("Archive Ripper works only on Kemono and Pawchive.");
  if (t.type === "PAGE_CONTEXT") {
    const r = e.tab?.id !== void 0 ? await chrome.tabs.get(e.tab.id) : (await chrome.tabs.query({ active: !0, lastFocusedWindow: !0 }))[0];
    if (!r?.id || !vt(r.url || "")) return null;
    try {
      const a = await chrome.tabs.sendMessage(r.id, { type: "PAGE_CONTEXT" });
      if (a?.url === r.url) return a;
    } catch {
    }
    return { url: r.url, expectedPosts: null };
  }
  if (t.type === "SERVICE_JOBS") {
    const r = (await G()).map((s) => ({ id: s.id, service: "discord", sourceUrl: s.sourceUrl || `https://kemono.cr/discord/server/${s.serverId}${s.channels.length === 1 ? "/" + s.channels[0].channelId : ""}`, title: s.serverName || s.serverId, status: s.status, createdAt: s.createdAt })), a = (await Ht()).map((s) => ({ id: s.id, service: "posts", sourceUrl: s.sourceUrl, title: s.source.postId && s.posts[0]?.title || s.creatorName, status: s.status, createdAt: s.createdAt }));
    return [...r, ...a].sort((s, i) => i.createdAt.localeCompare(s.createdAt));
  }
  if (t.type.startsWith("POST_")) {
    if (t.type === "POST_DOWNLOAD" || t.type === "POST_SYNC_IMPORT" || t.type === "POST_ACTION" && ["resume", "retry", "rescan"].includes(t.action)) {
      await at();
      for (const r of await G()) ["scanning", "downloading"].includes(r.status) && (r.resumeStatus = r.status, r.status = "paused", await R(r));
    }
    return qn(t);
  }
  if (t.type === "DISCORD_DOWNLOAD") {
    const r = await Me(t.jobId);
    if (!r || !["thumbnail", "full res", "best"].includes(t.quality)) throw new Error("Invalid Discord download.");
    if (!["indexed", "finished"].includes(r.status)) throw new Error("Finish scanning before downloading.");
    return r.mode = t.quality === "full res" ? "original" : t.quality, r.tryOriginal = t.quality === "best", await R(r), await at(), Re({ type: "ACTION", jobId: r.id, action: "download" }, e);
  }
  return (t.type === "START" || t.type === "ACTION" && ["download", "resume", "retry"].includes(t.action)) && await at(), Re(t, e);
}
let Oe = Promise.resolve(), Jt, Ct = !1;
function St(t) {
  const e = Oe.then(t);
  return Oe = e.catch(() => {
  }), e;
}
function Zn() {
  Ct || (Ct = !0, St(async () => await $a() ? 750 : Fa()).then((t) => t || 1200, () => 1200).then((t) => {
    Ct = !1, At(t);
  }));
}
function At(t = 1200) {
  Jt || Ct || (Jt = setTimeout(() => {
    Jt = void 0, Zn();
  }, t));
}
chrome.runtime.onMessage.addListener((t, e, n) => {
  if (!(e.id !== chrome.runtime.id || t.target === "offscreen"))
    return St(() => ts(t, e)).then((r) => n({ ok: !0, data: r }), (r) => n({ ok: !1, error: r instanceof Error ? r.message : "Archive operation failed" })).finally(At), !0;
});
chrome.downloads.onChanged.addListener((t) => {
  St(async () => {
    await Za(t), await Hn();
  }).catch(() => {
  }).finally(At);
});
chrome.alarms.onAlarm.addListener((t) => {
  t.name === "archive-tick" && Zn();
});
async function Wn() {
  await Ha(), await Hn(!0);
}
chrome.runtime.onStartup.addListener(() => {
  St(Wn).finally(At);
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
});
chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
St(Wn).catch(() => {
}).finally(At);
chrome.action.onClicked.addListener((t) => {
  !t.id || !vt(t.url || "") || (async () => {
    try {
      await chrome.tabs.sendMessage(t.id, { type: "TOGGLE_OVERLAY" });
    } catch {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["content.js"] }), await chrome.tabs.sendMessage(t.id, { type: "TOGGLE_OVERLAY" });
    }
  })().catch(() => {
    chrome.action.setTitle({ tabId: t.id, title: "Refresh this page, then open Archive Ripper." });
  });
});
async function Yn(t) {
  t.id !== void 0 && await (vt(t.url || "") ? chrome.action.enable(t.id) : chrome.action.disable(t.id));
}
chrome.tabs.onUpdated.addListener((t, e, n) => {
  Yn(n);
});
chrome.action.disable().then(async () => {
  for (const t of await chrome.tabs.query({ url: ["https://kemono.cr/*", "https://pawchive.pw/*"] })) await Yn(t);
});
