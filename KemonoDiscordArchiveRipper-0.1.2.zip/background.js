function F(e) {
  try {
    const a = new URL(e), t = /^\/discord\/server\/(\d+)(?:\/(\d+))?\/?$/.exec(a.pathname);
    return a.origin !== "https://kemono.cr" || a.username || a.password || !t ? null : { serverId: t[1], channelId: t[2] || null, serverName: null, channelName: null };
  } catch {
    return null;
  }
}
function j(e) {
  const a = F(e);
  return a?.channelId ? { ...a, channelId: a.channelId } : null;
}
function y(e) {
  if (typeof e != "string" || !/^\d+$/.test(e)) throw new Error("Expected a Discord ID encoded as a string");
  return e;
}
const de = /^\/([0-9a-f]{2})\/([0-9a-f]{2})\/([0-9a-f]{64})\.(png|jpe?g|webp|gif|avif)$/i;
function q(e) {
  if (typeof e != "string") return null;
  const a = de.exec(e);
  return a ? { path: e, hash: a[3].toLowerCase() } : null;
}
function ce(e) {
  const a = q(e);
  return a ? `https://img.kemono.cr/thumbnail/data${a.path}` : null;
}
function U(e) {
  if (typeof e != "string") return null;
  try {
    const a = new URL(e);
    if (a.protocol !== "https:" || a.username || a.password || a.port) return null;
    const t = a.hostname;
    return t === "img.kemono.cr" && a.pathname.startsWith("/thumbnail/data/") && q(a.pathname.slice(15)) || (t === "kemono.cr" || /^n[1-4]\.kemono\.cr$/.test(t)) && a.pathname.startsWith("/data/") && q(a.pathname.slice(5)) || (t === "cdn.discordapp.com" || t === "media.discordapp.net") && /^\/attachments\/\d+\/\d+\/[^/]+\.(png|jpe?g|webp|gif|avif)$/i.test(a.pathname) ? (a.hash = "", a.href) : null;
  } catch {
    return null;
  }
}
class b extends Error {
  constructor(a, t, n = 0) {
    super(a), this.status = t, this.retryAfterMs = n, this.name = "RequestError";
  }
  status;
  retryAfterMs;
  get retryable() {
    return this.status === 0 || this.status === 429 || this.status >= 500;
  }
}
function ue(e, a = Date.now()) {
  if (!e) return 0;
  const t = Number(e);
  return Math.max(0, Number.isFinite(t) ? t * 1e3 : Date.parse(e) - a || 0);
}
class fe {
  constructor(a = (t, n) => fetch(t, n)) {
    this.transport = a;
  }
  transport;
  async json(a) {
    let t;
    try {
      t = await this.transport(`https://kemono.cr/api/v1${a}`, {
        headers: { Accept: "text/css" },
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(2e4)
      });
    } catch {
      throw new b("API network request failed or timed out. Open the channel to check site access.", 0);
    }
    if (!t.ok) {
      const n = t.status === 403 ? " Access denied; the required Accept: text/css header was sent. Check access in the site tab." : "";
      throw new b(`API HTTP ${t.status}.${n}`, t.status, ue(t.headers.get("retry-after")));
    }
    try {
      return JSON.parse(await t.text());
    } catch {
      throw new b("API returned invalid JSON; this page is incomplete.", 422);
    }
  }
  async channel(a, t) {
    if (y(a), !Number.isSafeInteger(t) || t < 0) throw new Error("Invalid page offset");
    const n = await this.json(`/discord/channel/${a}?o=${t}`);
    if (!Array.isArray(n)) throw new b("Channel response is not an array", 422);
    for (const s of n) {
      if (!s || typeof s != "object") throw new b("Invalid message object", 422);
      if (y(s.id), s.channel !== void 0 && y(s.channel) !== a) throw new b("Channel response contains a different channel", 422);
      if (s.server !== void 0 && y(s.server), s.attachments != null && (!Array.isArray(s.attachments) || s.attachments.some((r) => !r || typeof r != "object" || Array.isArray(r)))) throw new b("Invalid attachment list", 422);
    }
    return n;
  }
  async server(a) {
    y(a);
    const t = await this.json(`/discord/server/${a}`);
    if (!t || y(t.id) !== a || !Array.isArray(t.channels)) throw new b("Invalid server metadata", 422);
    return {
      id: a,
      name: typeof t.name == "string" ? t.name : a,
      channels: t.channels.map((n) => ({
        id: y(n.id),
        name: typeof n.name == "string" ? n.name : n.id,
        parentId: typeof n.parent_channel_id == "string" ? y(n.parent_channel_id) : null,
        type: typeof n.type == "number" ? n.type : null,
        postCount: Number.isSafeInteger(n.post_count) && n.post_count >= 0 ? n.post_count : null
      }))
    };
  }
}
function he(e, a, t) {
  const n = /* @__PURE__ */ new Map();
  for (const r of a?.channels || []) n.set(r.id, { ...r, sources: ["api"] });
  let s = a?.name || null;
  for (const r of t)
    if (r.serverId === e) {
      s ||= typeof r.serverName == "string" ? r.serverName : null;
      for (const i of r.channels) {
        try {
          y(i.id);
        } catch {
          continue;
        }
        const o = n.get(i.id);
        o ? o.sources = [.../* @__PURE__ */ new Set([...o.sources || [], "dom"])] : n.set(i.id, { id: i.id, name: typeof i.name == "string" ? i.name : i.id, parentId: null, type: null, postCount: null, sources: ["dom"] });
      }
    }
  return a || n.size ? { id: e, name: s || e, channels: [...n.values()] } : null;
}
function Z(e) {
  let a = 0xcbf29ce484222325n;
  for (const t of e) a = BigInt.asUintN(64, (a ^ BigInt(t.codePointAt(0))) * 0x100000001b3n);
  return a.toString(16).padStart(16, "0");
}
function me(e) {
  if (typeof e != "string") return null;
  const a = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$/.exec(e);
  if (!a) return null;
  const [, t, n, s, r, i, o, l, d] = a, u = Number(t), f = Number(n), c = Number(s);
  if (f < 1 || f > 12 || c < 1 || c > new Date(Date.UTC(u, f, 0)).getUTCDate() || Number(r) > 23 || Number(i) > 59 || Number(o) > 59) return null;
  const v = `${t}-${n}-${s}T${r}:${i}:${o}.${(l || "").padEnd(3, "0").slice(0, 3)}${d || "Z"}`, P = Date.parse(v);
  return Number.isFinite(P) ? new Date(P).toISOString() : null;
}
function G(e, a, t, n, s) {
  return {
    ...e,
    jobId: a,
    id: `${e.serverId}:${e.channelId}:${t || "dom"}:${n}:${Z(s)}`,
    messageId: t,
    attachmentIndex: n,
    attachmentId: null,
    publishedRaw: null,
    publishedAtUtc: null,
    originalFilename: null,
    kemonoPath: null,
    kemonoFileHash: null,
    originalUrl: null,
    discordCdnUrl: null,
    thumbnailUrl: null,
    resolvedUrl: null,
    mediaType: "unknown",
    sourceType: "api",
    provenance: [],
    warnings: [],
    status: "discovered",
    savedPath: null,
    errorMessage: null,
    attempts: 0,
    nextAttemptAt: 0,
    downloadId: null,
    blobUrl: null,
    quality: null,
    bytes: null,
    sha256: null,
    mime: null,
    width: null,
    height: null,
    candidateFailures: []
  };
}
function pe(e, a, t) {
  const n = [];
  for (const s of e) {
    if (s.server && s.server !== a.serverId) throw new Error("Message belongs to a different server");
    const r = (d) => (d.publishedRaw = typeof s.published == "string" ? s.published : null, d.publishedAtUtc = me(d.publishedRaw), d.provenance = ["api"], d.publishedAtUtc ? /(Z|[+-]\d\d:\d\d)$/.test(d.publishedRaw) || d.warnings.push("Archive timestamp has no timezone; interpreted as UTC") : d.warnings.push("Missing or invalid publication timestamp"), d), i = s.attachments || [];
    i.forEach((d, u) => {
      const f = typeof d.path == "string" ? d.path : null, c = r(G(a, t, s.id, u + 1, f || d.name || `attachment-${u}`));
      c.originalFilename = typeof d.name == "string" ? d.name : null;
      const v = q(f);
      v ? (c.kemonoPath = v.path, c.kemonoFileHash = v.hash, c.thumbnailUrl = ce(v.path), c.mediaType = "image") : (c.discordCdnUrl = U(f), c.discordCdnUrl?.includes("discordapp.") ? c.mediaType = "image" : (c.discordCdnUrl = null, c.warnings.push("Unsupported attachment path; needs an observed image URL"))), n.push(c);
    });
    const o = typeof s.content == "string" ? s.content.match(/https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\/[^\s<>"')]+/g) || [] : [];
    [...new Set(o.map(U).filter((d) => !!d))].forEach((d, u) => {
      const f = r(G(a, t, s.id, i.length + u + 1, d));
      f.discordCdnUrl = d, f.mediaType = "image", f.originalFilename = new URL(d).pathname.split("/").at(-1);
      try {
        f.originalFilename = decodeURIComponent(f.originalFilename);
      } catch {
      }
      f.provenance.push("inline-content"), n.push(f);
    });
  }
  return n;
}
function ae(e, a) {
  const t = new Map(e.map((n) => [n.id, n]));
  for (const n of a) {
    let s = t.get(n.id);
    if (!s && n.messageId) {
      const o = [...t.values()].filter((l) => (l.sourceType === "dom" || n.sourceType === "dom") && l.sourceType !== n.sourceType && l.serverId === n.serverId && l.channelId === n.channelId && l.messageId === n.messageId && (l.kemonoPath && l.kemonoPath === n.kemonoPath || l.discordCdnUrl && l.discordCdnUrl === n.discordCdnUrl));
      s = o.find((l) => l.attachmentIndex === n.attachmentIndex) || (o.length === 1 ? o[0] : void 0);
    }
    if (!s) {
      t.set(n.id, n);
      continue;
    }
    const r = n.sourceType === "api" && s.sourceType === "dom" ? n : s, i = {
      ...s,
      id: r.id,
      attachmentIndex: r.attachmentIndex,
      publishedRaw: r.publishedRaw || s.publishedRaw || n.publishedRaw,
      publishedAtUtc: r.publishedAtUtc || s.publishedAtUtc || n.publishedAtUtc,
      originalFilename: r.originalFilename || s.originalFilename || n.originalFilename,
      kemonoPath: s.kemonoPath || n.kemonoPath,
      kemonoFileHash: s.kemonoFileHash || n.kemonoFileHash,
      thumbnailUrl: s.thumbnailUrl || n.thumbnailUrl,
      originalUrl: s.originalUrl || n.originalUrl,
      discordCdnUrl: s.discordCdnUrl || n.discordCdnUrl,
      mediaType: s.mediaType === "unknown" ? n.mediaType : s.mediaType,
      sourceType: s.sourceType === n.sourceType ? s.sourceType : "merged",
      provenance: [.../* @__PURE__ */ new Set([...s.provenance, ...n.provenance])],
      warnings: [.../* @__PURE__ */ new Set([...s.warnings, ...n.warnings])]
    };
    t.delete(s.id), t.set(i.id, i);
  }
  return [...t.values()];
}
const we = 150;
function ge(e, a) {
  const t = structuredClone(e);
  if (t.attempts = 0, t.nextAttemptAt = 0, t.error = null, !a.length)
    return t.pages++, t.coverage = "complete", t.terminal = "empty-page", t;
  const n = Z(a.map((s) => s.id).join(","));
  if (t.pageFingerprints.includes(n)) throw new Error("API repeated an earlier page; pagination stopped with incomplete coverage");
  if (t.pages >= 1e4) throw new Error("Safety page limit reached; coverage is incomplete");
  return t.pageFingerprints.push(n), t.pages++, t.messageIds = [.../* @__PURE__ */ new Set([...t.messageIds, ...a.map((s) => s.id)])], t.offset += we, t.coverage = "scanning", t;
}
function se(e, a = "unnamed") {
  let t = (e || a).normalize("NFKC").replace(/[<>:"/\\|?*\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "_").replace(/^[. ]+|[. ]+$/g, "").slice(0, 40).trim().replace(/[. ]+$/g, "");
  return (!t || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(t)) && (t = "_" + (t || a)), t;
}
function O(e) {
  return `ArchiveRoot/${e.serverId}_${se(e.serverName, "server")}`;
}
function H(e) {
  return `${O(e)}/${e.channelId}_${se(e.channelName, "channel")}`;
}
function ve(e, a) {
  if (!/^(png|jpg|webp|gif|avif)$/.test(a)) throw new Error("Unvalidated image format");
  const t = e.publishedAtUtc ? e.publishedAtUtc.slice(0, 19).replace("T", "_").replace(/:(\d{2})/g, "$1") + "Z" : "unknown-date";
  return `${H(e)}/${t}_${e.messageId || "unknown-message"}_${String(e.attachmentIndex).padStart(3, "0")}_${Z(e.id).slice(0, 8)}.${a}`;
}
let E;
function D() {
  return E || (E = new Promise((e, a) => {
    const t = indexedDB.open("kemono-archive", 1);
    t.onupgradeneeded = () => {
      t.result.createObjectStore("jobs", { keyPath: "id" }), t.result.createObjectStore("media", { keyPath: ["jobId", "id"] }).createIndex("jobId", "jobId");
    }, t.onsuccess = () => e(t.result), t.onerror = () => {
      E = void 0, a(t.error);
    };
  })), E;
}
function V(e) {
  return new Promise((a, t) => {
    e.onsuccess = () => a(e.result), e.onerror = () => t(e.error);
  });
}
function W(e) {
  return new Promise((a, t) => {
    e.oncomplete = () => a(), e.onerror = e.onabort = () => t(e.error || new Error("Database transaction aborted"));
  });
}
async function S() {
  return V((await D()).transaction("jobs").objectStore("jobs").getAll());
}
async function ye(e) {
  return V((await D()).transaction("jobs").objectStore("jobs").get(e));
}
async function m(e) {
  return V((await D()).transaction("media").objectStore("media").index("jobId").getAll(e));
}
async function h(e) {
  const a = (await D()).transaction("jobs", "readwrite"), t = W(a);
  a.objectStore("jobs").put(e), await t;
}
async function w(e) {
  const a = (await D()).transaction("media", "readwrite"), t = W(a);
  a.objectStore("media").put(e), await t;
}
async function z(e, a) {
  const t = (await D()).transaction(["jobs", "media"], "readwrite"), n = W(t);
  t.objectStore("jobs").put(e);
  const s = t.objectStore("media"), r = s.index("jobId").openKeyCursor(IDBKeyRange.only(e.id));
  r.onsuccess = () => {
    const i = r.result;
    if (i)
      s.delete(i.primaryKey), i.continue();
    else for (const o of a) s.put(o);
  }, await n;
}
function J(e, a) {
  return {
    discovered: a.length,
    downloaded: a.filter((t) => t.status === "downloaded").length,
    failed: a.filter((t) => t.status === "failed").length,
    skipped: a.filter((t) => t.status === "skipped").length,
    queued: a.filter((t) => t.status === "queued" || t.status === "transferring").length,
    pages: e.channels.reduce((t, n) => t + n.pages, 0),
    messages: e.channels.reduce((t, n) => t + n.messageIds.length, 0),
    incomplete: e.scope === "server" && e.channelDiscovery === "dom" || e.channels.some((t) => t.coverage !== "complete") || a.some((t) => ["failed", "skipped", "queued", "transferring"].includes(t.status) || t.mediaType === "unknown" || !t.messageId || !(t.thumbnailUrl || t.originalUrl || t.discordCdnUrl)) || e.status === "cancelled"
  };
}
function M(e, a, t) {
  const n = t ? a.filter((r) => r.channelId === t) : a, s = t ? { ...e, channels: e.channels.filter((r) => r.channelId === t) } : e;
  return JSON.stringify({
    schemaVersion: 1,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    job: { ...s, manifestDownloads: s.manifestDownloads.map(({ blobUrl: r, ...i }) => i) },
    totals: J(s, n),
    coverageNote: "Complete means every requested API page reached a validated empty array. DOM coverage is limited to observed messages. Indexed links are not a claim that every image is available.",
    timestampPolicy: "Timezone-less archive publication times are interpreted as UTC; raw values are retained.",
    media: n.map(({ blobUrl: r, ...i }) => i)
  }, null, 2);
}
const Q = ["serverId", "serverName", "channelId", "channelName", "messageId", "publishedRaw", "publishedAtUtc", "attachmentIndex", "originalFilename", "kemonoPath", "kemonoFileHash", "originalUrl", "discordCdnUrl", "thumbnailUrl", "resolvedUrl", "quality", "sourceType", "status", "savedPath", "sha256", "errorMessage"];
function be(e) {
  const a = (t) => {
    let n = t == null ? "" : String(t);
    return /^[\s]*[=+\-@\t\r]/.test(n) && (n = "'" + n), '"' + n.replaceAll('"', '""') + '"';
  };
  return "\uFEFF" + [Q.join(","), ...e.map((t) => Q.map((n) => a(t[n])).join(","))].join(`\r
`);
}
function Ie(e, a) {
  const t = [e.originalUrl, e.discordCdnUrl].map(U).filter((i) => !!i).map((i) => ({ url: i, quality: "original" })), n = U(e.thumbnailUrl), s = n ? [{ url: n, quality: "thumbnail" }] : [], r = a.mode === "original" ? t : a.mode === "best" && a.tryOriginal ? [...t, ...s] : s;
  return r.filter((i, o) => r.findIndex((l) => l.url === i.url) === o);
}
function A(e) {
  return e.destination?.kind === "folder" && e.destination.directoryId || e.id;
}
let Y;
async function Ae() {
  return Y ||= new Promise((e, a) => {
    const t = indexedDB.open("kemono-archive-destinations", 1);
    t.onupgradeneeded = () => t.result.createObjectStore("folders"), t.onsuccess = () => e(t.result), t.onerror = () => {
      Y = void 0, a(t.error);
    };
  });
}
async function Ue(e) {
  const a = await Ae();
  return new Promise((t, n) => {
    const s = a.transaction("folders").objectStore("folders").get(e);
    s.onsuccess = () => t(s.result), s.onerror = () => n(s.error);
  });
}
class I extends Error {
  constructor() {
    super("Folder access is required. Open the dashboard, click Allow folder access, then Resume.");
  }
}
async function N(e) {
  const a = await Ue(e);
  try {
    if (!a || await a.queryPermission({ mode: "readwrite" }) !== "granted") throw new I();
  } catch {
    throw new I();
  }
  return a;
}
let L;
async function x(e, a = {}) {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length || (L ||= chrome.offscreen.createDocument({ url: "offscreen/index.html", reasons: [chrome.offscreen.Reason.BLOBS], justification: "Validate archived image bytes, decode dimensions, and create local blob URLs for browser downloads and exports." }).finally(() => {
    L = void 0;
  }), await L);
  const t = await chrome.runtime.sendMessage({ target: "offscreen", action: e, ...a });
  if (!t?.ok)
    throw t?.error === new I().message ? new I() : new Error(t?.error || "Image validator did not respond");
  return t.data;
}
async function g(e) {
  e && await x("release", { url: e }).catch(() => {
  });
}
async function K(e, a, t = "application/json", n = !1) {
  const { blobUrl: s } = await x("export", { text: e, mime: t });
  try {
    return { id: await chrome.downloads.download({ url: s, filename: a, conflictAction: n ? "overwrite" : "uniquify", saveAs: !1 }), blobUrl: s };
  } catch (r) {
    throw await g(s), r;
  }
}
function xe(e) {
  const a = e.split("/");
  if (a[0] !== "ArchiveRoot" || a.length < 2 || a.some((t) => !t || t === "." || t === ".." || /[\\:\x00-\x1f]/.test(t))) throw new Error("Unsafe archive path");
  return a;
}
async function Se(e, a, t) {
  const n = xe(a);
  let s = await N(e);
  for (const r of n.slice(0, -1)) s = await s.getDirectoryHandle(r, { create: t });
  return { directory: s, name: n.at(-1) };
}
async function ke(e) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", await e.arrayBuffer()))].map((a) => a.toString(16).padStart(2, "0")).join("");
}
async function ie(e, a, t, n) {
  try {
    const { directory: s, name: r } = await Se(e, a, !1), i = await (await s.getFileHandle(r)).getFile();
    return i.size === n && await ke(i) === t;
  } catch (s) {
    if (s instanceof DOMException && s.name === "NotFoundError") return !1;
    throw s instanceof DOMException && ["NotAllowedError", "SecurityError"].includes(s.name) ? new I() : s;
  }
}
Promise.resolve();
const R = 3;
function k(e, a = 0) {
  return Math.max(2e3 * 2 ** Math.max(0, e - 1), a);
}
async function De(e, a) {
  const t = Ie(e, a);
  if (!t.length)
    return e.status = "skipped", e.errorMessage = a.mode === "original" ? "No original URL was exposed by the archive. No URL was invented." : "No observed or supported thumbnail URL is available.", await w(e), 0;
  e.status = "transferring", e.attempts++, await w(e);
  let n = 0, s = !1;
  for (const r of t)
    if (!e.candidateFailures.some((i) => i.url === r.url && /Image HTTP (400|401|403|404|410|422)\b/.test(i.reason)))
      try {
        const i = new URL(r.url).hostname;
        if (!["kemono.cr", "img.kemono.cr"].includes(i) && !await chrome.permissions.contains({ origins: [`https://${i}/*`] })) {
          e.candidateFailures.push({ url: r.url, reason: "Optional permission for this original host was not granted" });
          continue;
        }
        const o = await x("image", { url: r.url });
        if (o.failure) {
          if (e.candidateFailures.push({ url: r.url, reason: o.failure }), o.status === 429) {
            n = k(e.attempts, o.retryAfterMs), s = !0;
            break;
          }
          (!o.status || o.status >= 500) && (s = !0);
          continue;
        }
        if (e.resolvedUrl = r.url, e.quality = r.quality, e.bytes = o.bytes, e.sha256 = o.sha256, e.mime = o.mime, e.width = o.width, e.height = o.height, e.blobUrl = o.blobUrl, e.savedPath = ve(e, o.ext), await w(e), a.destination?.kind === "folder") {
          const l = await x("save-image", { jobId: A(a), path: e.savedPath, url: o.blobUrl });
          return e.savedPath = l.path, e.status = "downloaded", e.downloadId = null, await g(e.blobUrl), e.blobUrl = null, e.errorMessage = null, await w(e), 0;
        }
        return e.downloadId = await chrome.downloads.download({ url: o.blobUrl, filename: e.savedPath, conflictAction: "uniquify", saveAs: !1 }), e.errorMessage = null, await w(e), 0;
      } catch (i) {
        if (i instanceof I)
          throw e.status = "queued", e.attempts--, e.errorMessage = i.message, await g(e.blobUrl), e.blobUrl = null, await w(e), i;
        s = !0, e.candidateFailures.push({ url: r.url, reason: "Image fetch, decoding, or browser download failed" }), await g(e.blobUrl), e.blobUrl = null, e.downloadId = null;
      }
  return e.errorMessage = e.candidateFailures.at(-1)?.reason || "All allowed image candidates failed", s && e.attempts < R ? (e.status = "queued", e.nextAttemptAt = Date.now() + (n || k(e.attempts))) : e.status = "failed", await w(e), n;
}
async function X(e, a = !1, t) {
  if (t?.destination?.kind === "folder") {
    e.savedPath && e.sha256 && e.bytes !== null && await ie(A(t), e.savedPath, e.sha256, e.bytes) ? (e.status = "downloaded", e.errorMessage = null) : (e.status = e.attempts < R ? "queued" : "failed", e.errorMessage = "Folder write was interrupted before completion", e.nextAttemptAt = Date.now() + k(e.attempts)), await g(e.blobUrl), e.blobUrl = null, e.downloadId = null, await w(e);
    return;
  }
  let n;
  if (e.downloadId !== null ? [n] = await chrome.downloads.search({ id: e.downloadId }) : e.savedPath && e.blobUrl && (n = (await chrome.downloads.search({ query: [e.savedPath.split("/").at(-1)], limit: 20, orderBy: ["-startTime"] })).find((r) => r.url === e.blobUrl), n && (e.downloadId = n.id)), n?.state === "complete") {
    if (n.exists === !1 ? (e.status = "failed", e.errorMessage = "The completed file was removed outside the extension") : (e.status = "downloaded", e.errorMessage = null), n.filename) {
      const s = n.filename.replaceAll("\\", "/"), r = s.lastIndexOf("/ArchiveRoot/");
      r >= 0 && (e.savedPath = s.slice(r + 1));
    }
    await g(e.blobUrl), e.blobUrl = null;
  } else (n?.state === "interrupted" || !n && a) && (e.errorMessage = n?.error || "Worker/browser interrupted an uncommitted transfer", e.status = e.attempts < R ? "queued" : "failed", e.nextAttemptAt = Date.now() + k(e.attempts), await g(e.blobUrl), e.blobUrl = null, e.downloadId = null);
  await w(e);
}
const re = new fe();
function p(e) {
  return e.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), e;
}
async function ee(e) {
  const a = await ye(e);
  if (!a) throw new Error("Archive job was not found");
  return a;
}
async function te(e) {
  const a = F(e);
  if (!a) throw new Error("Open or paste a Kemono Discord server or channel URL");
  const n = (await chrome.tabs.query({ url: "https://kemono.cr/discord/server/*" })).filter((u) => u.id !== void 0 && F(u.url || "")?.serverId === a.serverId).map(async (u) => {
    try {
      const f = await chrome.tabs.sendMessage(u.id, { type: "DISCOVER_CHANNELS" });
      return f?.serverId === a.serverId && Array.isArray(f.channels) ? f : null;
    } catch {
      return null;
    }
  }), [s, ...r] = await Promise.allSettled([re.server(a.serverId), ...n]), i = s.status === "fulfilled" ? s.value : null, o = r.flatMap((u) => u.status === "fulfilled" && u.value ? [u.value] : []), l = he(a.serverId, i, o);
  a.serverName = l?.name || null, a.channelName = l?.channels.find((u) => u.id === a.channelId)?.name || null;
  let d = null;
  return i || (d = `${s.status === "rejected" && s.reason instanceof Error ? s.reason.message : "Server metadata is unavailable."} ${l?.channels.length ? "Using channel links from the open page; hidden or unloaded channels may be missing." : a.channelId ? "Current-channel scanning is still available." : "Open the server page, reload it, and discover its channel links again."}`), { scope: a, server: l, warning: d, apiChannelCount: i?.channels.length || 0, domChannelCount: l?.channels.filter((u) => u.sources?.includes("dom")).length || 0 };
}
async function Me(e, a) {
  if (e.type === "DISCOVER") return te(e.url);
  if (e.type === "LIST") {
    const n = (await S()).sort((s, r) => r.createdAt.localeCompare(s.createdAt));
    return Promise.all(n.map(async (s) => ({ job: s, totals: J(s, await m(s.id)) })));
  }
  if (e.type === "DETAIL") {
    const n = await ee(e.jobId), s = await m(n.id);
    return { job: n, media: s, totals: J(n, s) };
  }
  if (e.type === "DASHBOARD")
    return await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") }), null;
  if (e.type === "START") {
    if (!["thumbnail", "best", "original"].includes(e.mode)) throw new Error("Invalid quality mode");
    const { scope: n, server: s, warning: r, apiChannelCount: i, domChannelCount: o } = await te(e.url), l = !!e.allChannels || !n.channelId && !e.channelIds.length, d = [...new Set(l ? s?.channels.map((c) => c.id) || [] : e.channelIds.length ? e.channelIds.map(y) : n.channelId ? [n.channelId] : [])];
    if (!d.length) throw new Error(r || "No channels were discovered in this server. Open the server page and try Discover channels again.");
    if (d.some((c) => c !== n.channelId && !s?.channels.some((v) => v.id === c))) throw new Error("Selected channel was not discovered in this server");
    for (const c of await S()) ["scanning", "downloading"].includes(c.status) && (c.resumeStatus = c.status, c.status = "paused", await h(p(c)));
    const u = {
      id: crypto.randomUUID(),
      serverId: n.serverId,
      serverName: n.serverName,
      mode: e.mode,
      tryOriginal: !!e.tryOriginal,
      channels: d.map((c) => {
        const v = s?.channels.find((P) => P.id === c);
        return { channelId: c, channelName: v?.name || null, postCount: v?.postCount ?? null, offset: 0, pages: 0, messageIds: [], pageFingerprints: [], coverage: "pending", terminal: null, failures: [], attempts: 0, nextAttemptAt: 0, error: null, domMessages: 0 };
      }),
      status: "scanning",
      resumeStatus: "scanning",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      warnings: r ? [r] : [],
      autoManifest: !1,
      manifestState: "pending",
      manifestDownloads: [],
      apiNextAt: 0,
      mediaNextAt: 0,
      scope: l ? "server" : d.length === 1 ? "channel" : "selected",
      sourceUrl: `https://kemono.cr/discord/server/${n.serverId}${n.channelId ? "/" + n.channelId : ""}`,
      discoveredChannelCount: s?.channels.length || d.length,
      channelDiscovery: i ? o ? "api+dom" : "api" : o ? "dom" : "current-channel"
    };
    await h(u);
    const f = await chrome.tabs.query({ url: "https://kemono.cr/discord/server/*" });
    for (const c of f) c.id && F(c.url || "")?.serverId === u.serverId && chrome.tabs.sendMessage(c.id, { type: "SCAN_DOM" }).catch(() => {
    });
    return { jobId: u.id };
  }
  if (e.type === "DOM") {
    const n = j(e.url), s = j(a.tab?.url || "");
    if (!n || !s || s.channelId !== n.channelId || s.serverId !== n.serverId) return null;
    for (const r of await S()) {
      if (r.serverId !== n.serverId || !["scanning", "indexed", "paused"].includes(r.status)) continue;
      const i = r.channels.find((l) => l.channelId === n.channelId);
      if (!i) continue;
      const o = e.records.slice(0, 1e4).filter((l) => l.serverId === n.serverId && l.channelId === n.channelId).map((l) => ({
        ...l,
        jobId: r.id,
        serverName: r.serverName,
        channelName: i.channelName,
        originalUrl: U(l.originalUrl),
        discordCdnUrl: U(l.discordCdnUrl),
        thumbnailUrl: U(l.thumbnailUrl)
      }));
      i.domMessages = Math.max(i.domMessages, e.messageCount), await z(p(r), ae(await m(r.id), o));
    }
    return null;
  }
  const t = await ee(e.jobId);
  if (e.type === "DESTINATION") {
    if (t.status === "downloading") throw new Error("Pause the job before choosing its save destination");
    const n = await m(t.id);
    if (e.kind === "folder") {
      const s = e.directoryId || t.id, r = await N(s);
      for (const i of n)
        (i.status === "downloaded" && (!i.savedPath || !i.sha256 || i.bytes === null || !await ie(s, i.savedPath, i.sha256, i.bytes)) || i.status === "transferring") && (i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await g(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = t.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null);
      for (const i of t.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await g(i.blobUrl);
      t.destination = { kind: "folder", name: r.name, ...e.directoryId ? { directoryId: s } : {} }, t.manifestState = "pending", t.manifestPaths = [], t.manifestDownloads = [];
    } else if (e.kind === "browser") {
      if (n.some((s) => s.status === "downloaded") && t.destination?.kind === "folder") throw new Error("Keep this job’s chosen folder, or create a new job to use Browser downloads.");
      t.destination = { kind: "browser" };
    } else throw new Error("Unsupported save destination");
    return t.destinationError = null, await z(p(t), n), null;
  }
  if (e.type === "EXPORT") {
    const n = await m(t.id), s = O(t), r = t.id.slice(0, 8), i = `${s}/${e.format === "csv" ? "links" : e.format === "failures" ? "failures" : "manifest"}-${r}.${e.format === "csv" ? "csv" : "json"}`, o = e.format === "csv" ? be(n) : M(t, e.format === "failures" ? n.filter((d) => d.status === "failed" || d.status === "skipped") : n), l = e.format === "csv" ? "text/csv;charset=utf-8" : "application/json";
    return t.destination?.kind === "folder" ? await x("save-text", { jobId: A(t), path: i, text: o, mime: l }) : await K(o, i, l), null;
  }
  if (e.action === "pause") {
    ["scanning", "downloading"].includes(t.status) && (t.resumeStatus = t.status, t.status = "paused");
    for (const n of await m(t.id)) n.status === "transferring" && n.downloadId !== null && await chrome.downloads.pause(n.downloadId).catch(() => {
    });
  } else if (e.action === "cancel") {
    t.status = "cancelled";
    for (const n of await m(t.id))
      n.status === "transferring" && n.downloadId !== null && await chrome.downloads.cancel(n.downloadId).catch(() => {
      }), ["queued", "transferring"].includes(n.status) && (n.status = "skipped", n.errorMessage = "Cancelled by user", await g(n.blobUrl), n.blobUrl = null, await w(n));
  } else if (e.action === "resume") {
    if (t.status !== "paused") throw new Error("Only paused jobs can be resumed");
    t.destination?.kind === "folder" && t.resumeStatus === "downloading" && await N(A(t)), t.destinationError = null, t.status = t.resumeStatus;
    for (const n of await m(t.id)) n.status === "transferring" && n.downloadId !== null && await chrome.downloads.resume(n.downloadId).catch(() => {
    });
  } else if (e.action === "retry") {
    for (const n of t.channels) n.coverage === "incomplete" && (n.coverage = "pending", n.attempts = 0, n.error = null, n.nextAttemptAt = 0);
    for (const n of await m(t.id)) (n.status === "failed" || n.status === "skipped") && (n.status = t.autoManifest ? "queued" : "discovered", n.attempts = 0, n.nextAttemptAt = 0, n.errorMessage = null, n.candidateFailures = [], await w(n));
    t.status = t.channels.some((n) => n.coverage !== "complete") ? "scanning" : t.autoManifest ? "downloading" : "indexed", t.manifestState = "pending";
  } else if (e.action === "download") {
    if (t.status === "scanning" || t.channels.some((n) => ["pending", "scanning"].includes(n.coverage))) throw new Error("Pause or finish the scan before downloading the indexed results");
    if (!t.destination) throw new Error("Choose a save folder or explicitly select Browser downloads before starting the batch");
    t.destination.kind === "folder" && await N(A(t));
    for (const n of await m(t.id)) n.status === "discovered" && (n.status = "queued", await w(n));
    t.status = "downloading", t.autoManifest = !0, t.manifestState = "pending";
  }
  return await h(p(t)), null;
}
async function Ne(e) {
  if (!e.channels.some((t) => ["pending", "scanning"].includes(t.coverage))) {
    e.status = e.autoManifest ? "downloading" : "indexed", await h(p(e));
    return;
  }
  if (Date.now() < e.apiNextAt) return;
  const a = e.channels.find((t) => ["pending", "scanning"].includes(t.coverage) && t.nextAttemptAt <= Date.now());
  if (!a) {
    e.channels.some((t) => ["pending", "scanning"].includes(t.coverage)) || (e.status = e.autoManifest ? "downloading" : "indexed", await h(p(e)));
    return;
  }
  try {
    const t = await re.channel(a.channelId, a.offset), n = ge(a, t), s = pe(t, { serverId: e.serverId, serverName: e.serverName, channelId: a.channelId, channelName: a.channelName }, e.id);
    if (e.autoManifest) for (const r of s) r.status = "queued";
    e.channels[e.channels.indexOf(a)] = n, n.coverage === "complete" && n.postCount !== null && n.postCount !== n.messageIds.length && e.warnings.push(`Channel ${n.channelId}: metadata post_count=${n.postCount}; API unique messages=${n.messageIds.length}.`), e.apiNextAt = Date.now() + 1100, await z(p(e), ae(await m(e.id), s));
  } catch (t) {
    a.attempts++, a.error = t instanceof Error ? t.message : "Page scan failed", a.failures.push({ offset: a.offset, reason: a.error, at: (/* @__PURE__ */ new Date()).toISOString() });
    const n = t instanceof b && t.retryable;
    if (t instanceof b && t.status === 429 && (e.apiNextAt = Date.now() + k(a.attempts, t.retryAfterMs)), n && a.attempts < R) {
      const s = k(a.attempts, t.retryAfterMs);
      a.nextAttemptAt = Date.now() + s, e.apiNextAt = a.nextAttemptAt;
    } else a.coverage = "incomplete";
    await h(p(e));
  }
}
async function Ce(e, a) {
  e.manifestState = "saving", e.manifestDownloads = [], await h(p(e));
  try {
    if (e.destination?.kind === "folder") {
      e.manifestPaths = [];
      for (const r of e.channels) {
        const i = `${H({ ...e, channelId: r.channelId, channelName: r.channelName })}/channel-manifest.json`;
        await x("save-text", { jobId: A(e), path: i, text: M(e, a, r.channelId), overwrite: !0 }), e.manifestPaths.push(i), await h(e);
      }
      const s = `${O(e)}/manifest.json`;
      await x("save-text", { jobId: A(e), path: s, text: M(e, a), overwrite: !0 }), e.manifestPaths.push(s), e.manifestState = "saved", await h(p(e));
      return;
    }
    for (const s of e.channels) {
      const r = `${H({ ...e, channelId: s.channelId, channelName: s.channelName })}/channel-manifest.json`, i = await K(M(e, a, s.channelId), r, "application/json", !0);
      e.manifestDownloads.push({ ...i, path: r, state: "in_progress" }), await h(e);
    }
    const t = `${O(e)}/manifest.json`, n = await K(M(e, a), t, "application/json", !0);
    e.manifestDownloads.push({ ...n, path: t, state: "in_progress" }), await h(e);
  } catch (t) {
    t instanceof I ? (e.manifestState = "pending", await _(e, t)) : (e.manifestState = "failed", e.warnings.push("One or more manifest saves failed. Use Export JSON to save the current state."), await h(p(e)));
  }
}
async function _(e, a) {
  e.resumeStatus = "downloading", e.status = "paused", e.destinationError = a.message, await h(p(e));
}
async function $e() {
  const e = await S(), a = Math.max(0, ...e.map((n) => n.apiNextAt)), t = Math.max(0, ...e.map((n) => n.mediaNextAt));
  for (const n of e) {
    if (n.status === "scanning") {
      (Date.now() >= a || n.channels.every((o) => !["pending", "scanning"].includes(o.coverage))) && await Ne(n);
      return;
    }
    if (n.status !== "downloading") continue;
    if (n.destination?.kind === "folder")
      try {
        await N(A(n));
      } catch (o) {
        await _(n, o instanceof Error ? o : new I());
        return;
      }
    let s = await m(n.id);
    for (const o of s) o.status === "transferring" && (o.downloadId !== null || n.destination?.kind === "folder") && await X(o, n.destination?.kind === "folder", n);
    s = await m(n.id);
    const r = s.filter((o) => o.status === "transferring").length, i = s.filter((o) => o.status === "queued" && o.nextAttemptAt <= Date.now()).slice(0, Math.max(0, 2 - r));
    if (i.length && Date.now() >= t) {
      const o = await Promise.allSettled(i.map((u) => De(u, n))), l = o.find((u) => u.status === "rejected");
      if (l?.status === "rejected") {
        if (l.reason instanceof I) {
          await _(n, l.reason);
          return;
        }
        throw l.reason;
      }
      const d = o.flatMap((u) => u.status === "fulfilled" ? [u.value] : []);
      n.mediaNextAt = Date.now() + Math.max(1100, ...d), await h(n);
    }
    s = await m(n.id), s.some((o) => o.status === "queued" || o.status === "transferring") || (n.status = "finished", await h(p(n)), n.autoManifest && n.manifestState === "pending" && await Ce(n, s));
    return;
  }
}
async function oe() {
  for (const e of await S()) {
    try {
      for (const a of await m(e.id)) a.status === "transferring" && await X(a, !0, e);
    } catch (a) {
      if (!(a instanceof I)) throw a;
      e.status === "downloading" && await _(e, a);
    }
    if (e.manifestState === "saving") {
      if (e.destination?.kind === "folder") {
        e.manifestState = "pending", e.status === "finished" && (e.status = "downloading"), await h(e);
        continue;
      }
      for (const a of e.manifestDownloads) {
        const [t] = await chrome.downloads.search({ id: a.id });
        a.state = t?.state === "complete" ? "complete" : t?.state === "in_progress" ? "in_progress" : "interrupted";
      }
      e.manifestDownloads.length !== e.channels.length + 1 ? (e.manifestState = "pending", e.status === "finished" && (e.status = "downloading")) : e.manifestDownloads.every((a) => a.state === "complete") ? e.manifestState = "saved" : e.manifestDownloads.some((a) => a.state === "interrupted") && (e.manifestState = "failed"), await h(e);
    }
  }
}
async function Pe(e) {
  if (!e.state || !["complete", "interrupted"].includes(e.state.current || "")) return;
  for (const t of await S()) {
    for (const s of await m(t.id)) s.downloadId === e.id && s.status === "transferring" && await X(s);
    const n = t.manifestDownloads.find((s) => s.id === e.id);
    n && (n.state = e.state.current === "complete" ? "complete" : "interrupted", await g(n.blobUrl), t.manifestDownloads.length === t.channels.length + 1 && t.manifestDownloads.every((s) => s.state === "complete") && (t.manifestState = "saved"), n.state === "interrupted" && (t.manifestState = "failed"), await h(p(t)));
  }
  const [a] = await chrome.downloads.search({ id: e.id });
  a?.url.startsWith(`blob:chrome-extension://${chrome.runtime.id}/`) && await g(a.url);
}
let ne = Promise.resolve(), B, T = !1;
function C(e) {
  const a = ne.then(e);
  return ne = a.catch(() => {
  }), a;
}
function le() {
  T || (T = !0, C($e).catch(() => {
  }).finally(() => {
    T = !1, $();
  }));
}
function $() {
  B || T || (B = setTimeout(() => {
    B = void 0, le();
  }, 1200));
}
chrome.runtime.onMessage.addListener((e, a, t) => {
  if (!(a.id !== chrome.runtime.id || e.target === "offscreen"))
    return C(() => Me(e, a)).then((n) => t({ ok: !0, data: n }), (n) => t({ ok: !1, error: n instanceof Error ? n.message : "Archive operation failed" })).finally($), !0;
});
chrome.downloads.onChanged.addListener((e) => {
  C(() => Pe(e)).catch(() => {
  }).finally($);
});
chrome.alarms.onAlarm.addListener((e) => {
  e.name === "archive-tick" && le();
});
chrome.runtime.onStartup.addListener(() => {
  C(oe).finally($);
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
});
chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
C(oe).catch(() => {
}).finally($);
