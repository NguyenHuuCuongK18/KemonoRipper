const H = ["https://kemono.cr", "https://pawchive.pw"], ge = H.map((t) => `img.${new URL(t).hostname}`);
function St(t) {
  try {
    const n = new URL(t), e = /^\/discord\/server\/(\d+)(?:\/(\d+))?\/?$/.exec(n.pathname);
    return !H.includes(n.origin) || n.username || n.password || !e ? null : { serverId: e[1], channelId: e[2] || null, serverName: null, channelName: null };
  } catch {
    return null;
  }
}
function ee(t) {
  const n = St(t);
  return n?.channelId ? { ...n, channelId: n.channelId } : null;
}
function Z(t) {
  if (typeof t != "string" || !/^\d+$/.test(t)) throw new Error("Expected a Discord ID encoded as a string");
  return t;
}
const pn = /^\/([0-9a-f]{2})\/([0-9a-f]{2})\/([0-9a-f]{64})\.(png|jpe?g|webp|gif|avif)$/i;
function At(t) {
  if (typeof t != "string") return null;
  const n = pn.exec(t);
  return n ? { path: t, hash: n[3].toLowerCase() } : null;
}
function mn(t, n = H[0]) {
  const e = At(t);
  return e && H.includes(n) ? `https://img.${new URL(n).hostname}/thumbnail/data${e.path}` : null;
}
function G(t) {
  if (typeof t != "string") return null;
  try {
    const n = new URL(t);
    if (n.protocol !== "https:" || n.username || n.password || n.port) return null;
    const e = n.hostname;
    return ge.includes(e) && n.pathname.startsWith("/thumbnail/data/") && At(n.pathname.slice(15)) || (H.includes(n.origin) || /^n[1-4]\.(?:kemono\.cr|pawchive\.pw)$/.test(e)) && n.pathname.startsWith("/data/") && At(n.pathname.slice(5)) || (e === "cdn.discordapp.com" || e === "media.discordapp.net") && /^\/attachments\/\d+\/\d+\/[^/]+\.(png|jpe?g|webp|gif|avif)$/i.test(n.pathname) ? (n.hash = "", n.href) : null;
  } catch {
    return null;
  }
}
class q extends Error {
  constructor(n, e, r = 0) {
    super(n), this.status = e, this.retryAfterMs = r, this.name = "RequestError";
  }
  status;
  retryAfterMs;
  get retryable() {
    return this.status === 0 || this.status === 429 || this.status >= 500;
  }
}
function gn(t, n = Date.now()) {
  if (!t) return 0;
  const e = Number(t);
  return Math.max(0, Number.isFinite(e) ? e * 1e3 : Date.parse(t) - n || 0);
}
class yn {
  constructor(n = (e, r) => fetch(e, r)) {
    this.transport = n;
  }
  transport;
  async json(n, e = H[0]) {
    if (!H.includes(e)) throw new Error("Unsupported archive origin");
    let r;
    try {
      r = await this.transport(`${e}/api/v1${n}`, {
        headers: { Accept: "text/css" },
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(2e4)
      });
    } catch {
      throw new q("API network request failed or timed out. Open the channel to check site access.", 0);
    }
    if (!r.ok) {
      const a = r.status === 403 ? " Access denied; the required Accept: text/css header was sent. Check access in the site tab." : "";
      throw new q(`API HTTP ${r.status}.${a}`, r.status, gn(r.headers.get("retry-after")));
    }
    try {
      return JSON.parse(await r.text());
    } catch {
      throw new q("API returned invalid JSON; this page is incomplete.", 422);
    }
  }
  async channel(n, e, r = H[0]) {
    if (Z(n), !Number.isSafeInteger(e) || e < 0) throw new Error("Invalid page offset");
    const a = await this.json(`/discord/channel/${n}?o=${e}`, r);
    if (!Array.isArray(a)) throw new q("Channel response is not an array", 422);
    for (const s of a) {
      if (!s || typeof s != "object") throw new q("Invalid message object", 422);
      if (Z(s.id), s.channel !== void 0 && Z(s.channel) !== n) throw new q("Channel response contains a different channel", 422);
      if (s.server !== void 0 && Z(s.server), s.attachments != null && (!Array.isArray(s.attachments) || s.attachments.some((i) => !i || typeof i != "object" || Array.isArray(i)))) throw new q("Invalid attachment list", 422);
    }
    return a;
  }
  async server(n, e = H[0]) {
    Z(n);
    const r = await this.json(`/discord/server/${n}`, e);
    if (!r || Z(r.id) !== n || !Array.isArray(r.channels)) throw new q("Invalid server metadata", 422);
    return {
      id: n,
      name: typeof r.name == "string" ? r.name : n,
      channels: r.channels.map((a) => ({
        id: Z(a.id),
        name: typeof a.name == "string" ? a.name : a.id,
        parentId: typeof a.parent_channel_id == "string" ? Z(a.parent_channel_id) : null,
        type: typeof a.type == "number" ? a.type : null,
        postCount: Number.isSafeInteger(a.post_count) && a.post_count >= 0 ? a.post_count : null
      }))
    };
  }
}
function bn(t, n, e) {
  const r = /* @__PURE__ */ new Map();
  for (const s of n?.channels || []) r.set(s.id, { ...s, sources: ["api"] });
  let a = n?.name || null;
  for (const s of e)
    if (s.serverId === t) {
      a ||= typeof s.serverName == "string" ? s.serverName : null;
      for (const i of s.channels) {
        try {
          Z(i.id);
        } catch {
          continue;
        }
        const o = r.get(i.id);
        o ? o.sources = [.../* @__PURE__ */ new Set([...o.sources || [], "dom"])] : r.set(i.id, { id: i.id, name: typeof i.name == "string" ? i.name : i.id, parentId: null, type: null, postCount: null, sources: ["dom"] });
      }
    }
  return n || r.size ? { id: t, name: a || t, channels: [...r.values()] } : null;
}
function Vt(t) {
  let n = 0xcbf29ce484222325n;
  for (const e of t) n = BigInt.asUintN(64, (n ^ BigInt(e.codePointAt(0))) * 0x100000001b3n);
  return n.toString(16).padStart(16, "0");
}
function vn(t) {
  if (typeof t != "string") return null;
  const n = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$/.exec(t);
  if (!n) return null;
  const [, e, r, a, s, i, o, p, g] = n, m = Number(e), y = Number(r), l = Number(a);
  if (y < 1 || y > 12 || l < 1 || l > new Date(Date.UTC(m, y, 0)).getUTCDate() || Number(s) > 23 || Number(i) > 59 || Number(o) > 59) return null;
  const u = `${e}-${r}-${a}T${s}:${i}:${o}.${(p || "").padEnd(3, "0").slice(0, 3)}${g || "Z"}`, h = Date.parse(u);
  return Number.isFinite(h) ? new Date(h).toISOString() : null;
}
function ne(t, n, e, r, a) {
  return {
    ...t,
    jobId: n,
    id: `${t.serverId}:${t.channelId}:${e || "dom"}:${r}:${Vt(a)}`,
    messageId: e,
    attachmentIndex: r,
    attachmentId: null,
    publishedRaw: null,
    publishedAtUtc: null,
    originalFilename: null,
    kemonoPath: null,
    kemonoFileHash: null,
    originalUrl: null,
    discordCdnUrl: null,
    thumbnailUrl: null,
    resolvedUrl: null,
    mediaType: "unknown",
    sourceType: "api",
    provenance: [],
    warnings: [],
    status: "discovered",
    savedPath: null,
    errorMessage: null,
    attempts: 0,
    nextAttemptAt: 0,
    downloadId: null,
    blobUrl: null,
    quality: null,
    bytes: null,
    sha256: null,
    mime: null,
    width: null,
    height: null,
    candidateFailures: []
  };
}
function In(t, n, e, r = H[0]) {
  const a = [];
  for (const s of t) {
    if (s.server && s.server !== n.serverId) throw new Error("Message belongs to a different server");
    const i = (m) => (m.publishedRaw = typeof s.published == "string" ? s.published : null, m.publishedAtUtc = vn(m.publishedRaw), m.provenance = ["api"], m.publishedAtUtc ? /(Z|[+-]\d\d:\d\d)$/.test(m.publishedRaw) || m.warnings.push("Archive timestamp has no timezone; interpreted as UTC") : m.warnings.push("Missing or invalid publication timestamp"), m), o = s.attachments || [];
    o.forEach((m, y) => {
      const l = typeof m.path == "string" ? m.path : null, u = i(ne(n, e, s.id, y + 1, l || m.name || `attachment-${y}`));
      u.originalFilename = typeof m.name == "string" ? m.name : null;
      const h = At(l);
      h ? (u.kemonoPath = h.path, u.kemonoFileHash = h.hash, u.thumbnailUrl = mn(h.path, r), u.mediaType = "image") : (u.discordCdnUrl = G(l), u.discordCdnUrl?.includes("discordapp.") ? u.mediaType = "image" : (u.discordCdnUrl = null, u.warnings.push("Unsupported attachment path; needs an observed image URL"))), a.push(u);
    });
    const p = typeof s.content == "string" ? s.content.match(/https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\/[^\s<>"')]+/g) || [] : [];
    [...new Set(p.map(G).filter((m) => !!m))].forEach((m, y) => {
      const l = i(ne(n, e, s.id, o.length + y + 1, m));
      l.discordCdnUrl = m, l.mediaType = "image", l.originalFilename = new URL(m).pathname.split("/").at(-1);
      try {
        l.originalFilename = decodeURIComponent(l.originalFilename);
      } catch {
      }
      l.provenance.push("inline-content"), a.push(l);
    });
  }
  return a;
}
function ye(t, n) {
  const e = new Map(t.map((r) => [r.id, r]));
  for (const r of n) {
    let a = e.get(r.id);
    if (!a && r.messageId) {
      const o = [...e.values()].filter((p) => (p.sourceType === "dom" || r.sourceType === "dom") && p.sourceType !== r.sourceType && p.serverId === r.serverId && p.channelId === r.channelId && p.messageId === r.messageId && (p.kemonoPath && p.kemonoPath === r.kemonoPath || p.discordCdnUrl && p.discordCdnUrl === r.discordCdnUrl));
      a = o.find((p) => p.attachmentIndex === r.attachmentIndex) || (o.length === 1 ? o[0] : void 0);
    }
    if (!a) {
      e.set(r.id, r);
      continue;
    }
    const s = r.sourceType === "api" && a.sourceType === "dom" ? r : a, i = {
      ...a,
      id: s.id,
      attachmentIndex: s.attachmentIndex,
      publishedRaw: s.publishedRaw || a.publishedRaw || r.publishedRaw,
      publishedAtUtc: s.publishedAtUtc || a.publishedAtUtc || r.publishedAtUtc,
      originalFilename: s.originalFilename || a.originalFilename || r.originalFilename,
      kemonoPath: a.kemonoPath || r.kemonoPath,
      kemonoFileHash: a.kemonoFileHash || r.kemonoFileHash,
      thumbnailUrl: a.thumbnailUrl || r.thumbnailUrl,
      originalUrl: a.originalUrl || r.originalUrl,
      discordCdnUrl: a.discordCdnUrl || r.discordCdnUrl,
      mediaType: a.mediaType === "unknown" ? r.mediaType : a.mediaType,
      sourceType: a.sourceType === r.sourceType ? a.sourceType : "merged",
      provenance: [.../* @__PURE__ */ new Set([...a.provenance, ...r.provenance])],
      warnings: [.../* @__PURE__ */ new Set([...a.warnings, ...r.warnings])]
    };
    e.delete(a.id), e.set(i.id, i);
  }
  return [...e.values()];
}
const Sn = 150;
function An(t, n) {
  const e = structuredClone(t);
  if (e.attempts = 0, e.nextAttemptAt = 0, e.error = null, !n.length)
    return e.pages++, e.coverage = "complete", e.terminal = "empty-page", e;
  const r = Vt(n.map((a) => a.id).join(","));
  if (e.pageFingerprints.includes(r)) throw new Error("API repeated an earlier page; pagination stopped with incomplete coverage");
  if (e.pages >= 1e4) throw new Error("Safety page limit reached; coverage is incomplete");
  return e.pageFingerprints.push(r), e.pages++, e.messageIds = [.../* @__PURE__ */ new Set([...e.messageIds, ...n.map((a) => a.id)])], e.offset += Sn, e.coverage = "scanning", e;
}
function Kt(t, n = "unnamed") {
  let e = (t || n).normalize("NFKC").replace(/[<>:"/\\|?*\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "_").replace(/^[. ]+|[. ]+$/g, "").slice(0, 40).trim().replace(/[. ]+$/g, "");
  return (!e || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(e)) && (e = "_" + (e || n)), e;
}
function Ut(t) {
  return `ArchiveRoot/${t.serverId}_${Kt(t.serverName, "server")}`;
}
function Ht(t) {
  return `${Ut(t)}/${t.channelId}_${Kt(t.channelName, "channel")}`;
}
function Un(t, n) {
  if (!/^(png|jpg|webp|gif|avif)$/.test(n)) throw new Error("Unvalidated image format");
  const e = t.publishedAtUtc ? t.publishedAtUtc.slice(0, 19).replace("T", "_").replace(/:(\d{2})/g, "$1") + "Z" : "unknown-date";
  return `${Ht(t)}/${e}_${t.messageId || "unknown-message"}_${String(t.attachmentIndex).padStart(3, "0")}_${Vt(t.id).slice(0, 8)}.${n}`;
}
let gt;
function et() {
  return gt || (gt = new Promise((t, n) => {
    const e = indexedDB.open("kemono-archive", 1);
    e.onupgradeneeded = () => {
      e.result.createObjectStore("jobs", { keyPath: "id" }), e.result.createObjectStore("media", { keyPath: ["jobId", "id"] }).createIndex("jobId", "jobId");
    }, e.onsuccess = () => t(e.result), e.onerror = () => {
      gt = void 0, n(e.error);
    };
  })), gt;
}
function Gt(t) {
  return new Promise((n, e) => {
    t.onsuccess = () => n(t.result), t.onerror = () => e(t.error);
  });
}
function jt(t) {
  return new Promise((n, e) => {
    t.oncomplete = () => n(), t.onerror = t.onabort = () => e(t.error || new Error("Database transaction aborted"));
  });
}
async function Q() {
  return Gt((await et()).transaction("jobs").objectStore("jobs").getAll());
}
async function xn(t) {
  return Gt((await et()).transaction("jobs").objectStore("jobs").get(t));
}
async function D(t) {
  return Gt((await et()).transaction("media").objectStore("media").index("jobId").getAll(t));
}
async function R(t) {
  const n = (await et()).transaction("jobs", "readwrite"), e = jt(n);
  n.objectStore("jobs").put(t), await e;
}
async function O(t) {
  const n = (await et()).transaction("media", "readwrite"), e = jt(n);
  n.objectStore("media").put(t), await e;
}
async function st(t, n) {
  const e = (await et()).transaction(["jobs", "media"], "readwrite"), r = jt(e);
  e.objectStore("jobs").put(t);
  const a = e.objectStore("media"), s = a.index("jobId").openKeyCursor(IDBKeyRange.only(t.id));
  s.onsuccess = () => {
    const i = s.result;
    if (i)
      a.delete(i.primaryKey), i.continue();
    else for (const o of n) a.put(o);
  }, await r;
}
function Ft(t, n) {
  return {
    discovered: n.length,
    downloaded: n.filter((e) => e.status === "downloaded").length,
    staged: n.filter((e) => e.status === "staged").length,
    failed: n.filter((e) => e.status === "failed").length,
    skipped: n.filter((e) => e.status === "skipped").length,
    queued: n.filter((e) => e.status === "queued" || e.status === "transferring").length,
    pages: t.channels.reduce((e, r) => e + r.pages, 0),
    messages: t.channels.reduce((e, r) => e + r.messageIds.length, 0),
    incomplete: t.scope === "server" && t.channelDiscovery === "dom" || t.channels.some((e) => e.coverage !== "complete") || n.some((e) => ["failed", "skipped", "queued", "transferring", "staged"].includes(e.status) || e.mediaType === "unknown" || !e.messageId || !(e.thumbnailUrl || e.originalUrl || e.discordCdnUrl)) || t.status === "cancelled"
  };
}
function rt(t, n, e) {
  const r = e ? n.filter((s) => s.channelId === e) : n, a = e ? { ...t, channels: t.channels.filter((s) => s.channelId === e) } : t;
  return JSON.stringify({
    schemaVersion: 1,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    job: { ...a, archive: a.archive ? { ...a.archive, blobUrl: void 0 } : void 0, manifestDownloads: a.manifestDownloads.map(({ blobUrl: s, ...i }) => i) },
    totals: Ft(a, r),
    coverageNote: "Complete means every requested API page reached a validated empty array. DOM coverage is limited to observed messages. Indexed links are not a claim that every image is available.",
    timestampPolicy: "Timezone-less archive publication times are interpreted as UTC; raw values are retained.",
    media: r.map(({ blobUrl: s, ...i }) => i)
  }, null, 2);
}
const re = ["serverId", "serverName", "channelId", "channelName", "messageId", "publishedRaw", "publishedAtUtc", "attachmentIndex", "originalFilename", "kemonoPath", "kemonoFileHash", "originalUrl", "discordCdnUrl", "thumbnailUrl", "resolvedUrl", "quality", "sourceType", "status", "savedPath", "sha256", "errorMessage"];
function Rn(t) {
  const n = (e) => {
    let r = e == null ? "" : String(e);
    return /^[\s]*[=+\-@\t\r]/.test(r) && (r = "'" + r), '"' + r.replaceAll('"', '""') + '"';
  };
  return "\uFEFF" + [re.join(","), ...t.map((e) => re.map((r) => n(e[r])).join(","))].join(`\r
`);
}
function En(t, n) {
  const e = [t.originalUrl, t.discordCdnUrl].map(G).filter((i) => !!i).map((i) => ({ url: i, quality: "original" })), r = G(t.thumbnailUrl), a = r ? [{ url: r, quality: "thumbnail" }] : [], s = n.mode === "original" ? e : n.mode === "best" && n.tryOriginal ? [...e, ...a] : a;
  return s.filter((i, o) => s.findIndex((p) => p.url === i.url) === o);
}
function K(t) {
  return t.destination?.kind === "folder" && t.destination.directoryId || t.id;
}
let ae;
async function Cn() {
  return ae ||= new Promise((t, n) => {
    const e = indexedDB.open("kemono-archive-destinations", 1);
    e.onupgradeneeded = () => e.result.createObjectStore("folders"), e.onsuccess = () => t(e.result), e.onerror = () => {
      ae = void 0, n(e.error);
    };
  });
}
async function Nn(t) {
  const n = await Cn();
  return new Promise((e, r) => {
    const a = n.transaction("folders").objectStore("folders").get(t);
    a.onsuccess = () => e(a.result), a.onerror = () => r(a.error);
  });
}
class W extends Error {
  constructor() {
    super("Folder access is required. Open the dashboard, click Allow folder access, then Resume.");
  }
}
async function it(t) {
  const n = await Nn(t);
  try {
    if (!n || await n.queryPermission({ mode: "readwrite" }) !== "granted") throw new W();
  } catch {
    throw new W();
  }
  return n;
}
function Pn(t) {
  const n = t.split("/");
  if (n[0] !== "ArchiveRoot" || n.length < 2 || n.some((e) => !e || e === "." || e === ".." || /[\\:\x00-\x1f]/.test(e))) throw new Error("Unsafe archive path");
  return n;
}
async function Dn(t, n, e) {
  const r = Pn(n);
  let a = await it(t);
  for (const s of r.slice(0, -1)) a = await a.getDirectoryHandle(s, { create: e });
  return { directory: a, name: r.at(-1) };
}
async function Tn(t) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", await t.arrayBuffer()))].map((n) => n.toString(16).padStart(2, "0")).join("");
}
async function be(t, n, e, r) {
  try {
    const { directory: a, name: s } = await Dn(t, n, !1), i = await (await a.getFileHandle(s)).getFile();
    return i.size === r && await Tn(i) === e;
  } catch (a) {
    if (a instanceof DOMException && a.name === "NotFoundError") return !1;
    throw a instanceof DOMException && ["NotAllowedError", "SecurityError"].includes(a.name) ? new W() : a;
  }
}
Promise.resolve();
const L = void 0, j = "undefined", ut = "function", Zt = "string", ve = new Uint8Array(), kn = "Invalid option (must be a function)";
function On(t) {
  if (t && typeof t != ut)
    throw new Error(kn);
  return t;
}
function Ln(t) {
  return typeof t == Zt && t.trim() ? Number(t) : t;
}
const zn = 256 * 1024, Bn = 1, Mn = "Invalid maxWorkers (must be an integer greater than 0)", Hn = "Invalid baseURI (must be a string)", Fn = "Invalid URI (must be a string or a function returning a string)";
let Ie = 2;
try {
  typeof navigator != j && navigator.hardwareConcurrency && (Ie = navigator.hardwareConcurrency);
} catch {
}
const Se = {
  workerURI: "./core/web-worker-wasm.js",
  wasmURI: "./core/streams/zlib-wasm/zlib-streams.wasm",
  chunkSize: zn,
  maxWorkers: Ie,
  terminateWorkerTimeout: 5e3,
  workerStarvationTimeout: 5e3,
  workerStartupTimeout: 5e3,
  useWebWorkers: !0,
  useCompressionStream: !0,
  CompressionStream: typeof CompressionStream != j && CompressionStream,
  DecompressionStream: typeof DecompressionStream != j && DecompressionStream
}, Ae = "maxWorkers", Ue = "baseURI", xe = [
  "wasmURI",
  "workerURI"
], Zn = [
  "useCompressionStream",
  "useWebWorkers"
], Re = [
  "chunkSize",
  Ae,
  "terminateWorkerTimeout",
  "workerStarvationTimeout",
  "workerStartupTimeout"
], Ee = [
  "createWorker",
  "CompressionStream",
  "DecompressionStream",
  "CompressionStreamFallback",
  "DecompressionStreamFallback"
], qn = [
  Ue,
  ...xe,
  ...Zn,
  ...Re,
  ...Ee
], Wn = { ...Se };
function Yn(t) {
  const n = {};
  for (const e of qn) {
    const r = t[e];
    r !== L && (n[e] = Xn(e, r));
  }
  return n;
}
function Xn(t, n) {
  if (Re.includes(t)) {
    if (n = Ln(n), t == Ae && (!Number.isInteger(n) || n < Bn))
      throw new Error(Mn);
  } else if (Ee.includes(t))
    On(n);
  else if (t == Ue) {
    if (n && typeof n != Zt)
      throw new Error(Hn);
  } else if (xe.includes(t) && n && typeof n != Zt && typeof n != ut)
    throw new Error(Fn);
  return n;
}
function Vn(t) {
  t = t || {};
  const { CompressionStreamZlib: n, DecompressionStreamZlib: e } = t;
  if (n === L && e === L)
    return t;
  const r = Object.assign({}, t);
  return r.CompressionStreamFallback === L && (r.CompressionStreamFallback = n), r.DecompressionStreamFallback === L && (r.DecompressionStreamFallback = e), r;
}
function Tt(t) {
  const n = Yn(Vn(t));
  Object.assign(Se, n), Object.assign(Wn, n);
}
const yt = new Uint8Array(288);
yt.fill(8, 0, 144), yt.fill(9, 144, 256), yt.fill(7, 256, 280), yt.fill(8, 280, 288), new Uint8Array(30).fill(5);
const Y = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Kn = (t) => t({ workerURI: (n) => {
  const e = "text/javascript";
  let r = `!function(t){"function"==typeof define&&define.amd?define(t):t()}(function(){"use strict";const{Array:t,Object:n,Number:e,Math:o,Error:r,Uint8Array:c,Uint16Array:s,Uint32Array:a,Int32Array:i,Map:f,DataView:u,Promise:w,TextEncoder:l,crypto:d,postMessage:p,TransformStream:h,ReadableStream:y,WritableStream:m,CompressionStream:S,DecompressionStream:g}=self,v=void 0,b="undefined",k="function",z=new c,C=[[],[],[],[],[],[],[],[]];for(let t=0;t<256;t++){let n=t;for(let t=0;t<8;t++)n=1&n?n>>>1^3988292384:n>>>1;C[0][t]=n}for(let t=0;t<256;t++)for(let n=1;n<8;n++){const e=C[n-1][t];C[n][t]=e>>>8^C[0][255&e]}const[I,M,A,E,R,x,P,D]=C;class F{constructor(t){this.o=t||-1}append(t){let n=0|this.o;const e=0|t.length;let o=0;if(e>=8&&t.buffer){const r=new u(t.buffer,t.byteOffset,e),c=e-8;for(;o<=c;o+=8){const t=n^r.getInt32(o,!0),e=r.getInt32(o+4,!0);n=D[255&t]^P[t>>>8&255]^x[t>>>16&255]^R[t>>>24&255]^E[255&e]^A[e>>>8&255]^M[e>>>16&255]^I[e>>>24&255]}}for(;o<e;o++)n=n>>>8^I[255&(n^t[o])];this.o=n}get(){return~this.o}}class U extends h{constructor(){let t;const n=new F;super({transform(t,e){n.append(t),e.enqueue(t)},flush(){const e=new c(4);new u(e.buffer).setUint32(0,n.get()),t.value=e}}),t=this}}function B(t,n){const e=new c(t.length+n.length);return e.set(t),e.set(n,t.length),e}function W(t){return new u(t.buffer,t.byteOffset,t.byteLength)}const O=64,V=20,K=new c([128]),T=new c(1),_=new i([1732584193,4023233417,2562383102,271733878,3285377520]),j=new c(256),H=new i(256),L=new i(256),Z=new i(256),N=new i(256);let q=!1;function G(t,n){!function(){if(!q){let t=1,n=1;do{t=255&(t^t<<1^(128&t?27:0)),n=255&(n^n<<1),n=255&(n^n<<2),n=255&(n^n<<4),128&n&&(n^=9),j[t]=255&(n^(n<<1|n>>7)^(n<<2|n>>6)^(n<<3|n>>5)^(n<<4|n>>4)^99)}while(1!=t);j[0]=99;for(let t=0;t<256;t++){const n=j[t],e=Y(n),o=e<<24|n<<16|n<<8|e^n;H[t]=o,L[t]=o>>>8|o<<24,Z[t]=o>>>16|o<<16,N[t]=o>>>24|o<<8}q=!0}}();const e=new i(60),o=function(t,n){const e=t.length>>2,o=e+6,r=4*(o+1);let c=1;for(let o=0;o<e;o++)n[o]=t[4*o]<<24|t[4*o+1]<<16|t[4*o+2]<<8|t[4*o+3];for(let t=e;t<r;t++){let o=n[t-1];t%e==0?(o=Q(o<<8|o>>>24)^c<<24,c=Y(c)):e>6&&t%e==4&&(o=Q(o)),n[t]=n[t-e]^o}return o}(t,e),r=new i(4),c=J(n);let s=0,a=0,f=0,w=0;return{process(t,n){n&&c.update(t,0,t.length),function(t){const n=new u(t.buffer,t.byteOffset,t.byteLength),e=t.length;let o=0;for(;o+16<=e;o+=16)l(),n.setInt32(o,n.getInt32(o)^r[0]),n.setInt32(o+4,n.getInt32(o+4)^r[1]),n.setInt32(o+8,n.getInt32(o+8)^r[2]),n.setInt32(o+12,n.getInt32(o+12)^r[3]);if(o<e){l();for(let n=0;o<e;o++,n++)t[o]^=r[n>>2]>>>24-8*(3&n)}}(t),n||c.update(t,0,t.length)},digest:()=>c.digest()};function l(){s=s+1|0,s||(a=a+1|0,a||(f=f+1|0,f||(w=w+1|0)));let t=X(s)^e[0],n=X(a)^e[1],c=X(f)^e[2],i=X(w)^e[3],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[4],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[5],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[6],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[7];t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[8],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[9],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[10],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[11],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[12],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[13],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[14],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[15],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[16],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[17],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[18],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[19],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[20],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[21],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[22],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[23],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[24],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[25],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[26],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[27],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[28],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[29],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[30],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[31],t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[32],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[33],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[34],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[35],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[36],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[37],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[38],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[39];let h=40;o>10&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[40],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[41],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[42],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[43],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[44],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[45],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[46],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[47],h=48),o>12&&(t=H[u>>>24]^L[l>>>16&255]^Z[d>>>8&255]^N[255&p]^e[48],n=H[l>>>24]^L[d>>>16&255]^Z[p>>>8&255]^N[255&u]^e[49],c=H[d>>>24]^L[p>>>16&255]^Z[u>>>8&255]^N[255&l]^e[50],i=H[p>>>24]^L[u>>>16&255]^Z[l>>>8&255]^N[255&d]^e[51],u=H[t>>>24]^L[n>>>16&255]^Z[c>>>8&255]^N[255&i]^e[52],l=H[n>>>24]^L[c>>>16&255]^Z[i>>>8&255]^N[255&t]^e[53],d=H[c>>>24]^L[i>>>16&255]^Z[t>>>8&255]^N[255&n]^e[54],p=H[i>>>24]^L[t>>>16&255]^Z[n>>>8&255]^N[255&c]^e[55],h=56),r[0]=(j[u>>>24]<<24|j[l>>>16&255]<<16|j[d>>>8&255]<<8|j[255&p])^e[h],r[1]=(j[l>>>24]<<24|j[d>>>16&255]<<16|j[p>>>8&255]<<8|j[255&u])^e[h+1],r[2]=(j[d>>>24]<<24|j[p>>>16&255]<<16|j[u>>>8&255]<<8|j[255&l])^e[h+2],r[3]=(j[p>>>24]<<24|j[u>>>16&255]<<16|j[l>>>8&255]<<8|j[255&d])^e[h+3]}}function J(t){const n=function(){const t=new i(_),n=new i(16),e=new c(O),r=new u(e.buffer),s=new c(8);let a=0,f=0;return{update:w,digest:function(){const n=8*f,e=o.floor(n/4294967296),r=n>>>0;for(w(K,0,1);56!=a;)w(T,0,1);s[0]=e>>>24,s[1]=e>>>16,s[2]=e>>>8,s[3]=e,s[4]=r>>>24,s[5]=r>>>16,s[6]=r>>>8,s[7]=r,w(s,0,8);const i=new c(V),l=new u(i.buffer);for(let n=0;n<t.length;n++)l.setInt32(4*n,t[n]);return t.set(_),a=0,f=0,i}};function w(t,n,o){const c=n+o;if(f+=o,a){for(;n<c&&a<O;)e[a++]=t[n++];a==O&&(l(r,0),a=0)}if(n+O<=c){const e=new u(t.buffer,t.byteOffset,t.byteLength);for(;n+O<=c;n+=O)l(e,n)}for(;n<c;)e[a++]=t[n++]}function l(e,o){for(let t=0;t<16;t++)n[t]=e.getInt32(o+4*t);let r,c=t[0],s=t[1],a=t[2],i=t[3],f=t[4];for(let t=0;t<15;t+=5)f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[t]|0,s=s<<30|s>>>2,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+n[t+1]|0,c=c<<30|c>>>2,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+n[t+2]|0,f=f<<30|f>>>2,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+n[t+3]|0,i=i<<30|i>>>2,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+n[t+4]|0,a=a<<30|a>>>2;f=(c<<5|c>>>27)+((a^i)&s^i)+f+1518500249+n[15]|0,s=s<<30|s>>>2,r=n[13]^n[8]^n[2]^n[0],r=r<<1|r>>>31,n[0]=r,i=(f<<5|f>>>27)+((s^a)&c^a)+i+1518500249+r|0,c=c<<30|c>>>2,r=n[14]^n[9]^n[3]^n[1],r=r<<1|r>>>31,n[1]=r,a=(i<<5|i>>>27)+((c^s)&f^s)+a+1518500249+r|0,f=f<<30|f>>>2,r=n[15]^n[10]^n[4]^n[2],r=r<<1|r>>>31,n[2]=r,s=(a<<5|a>>>27)+((f^c)&i^c)+s+1518500249+r|0,i=i<<30|i>>>2,r=n[0]^n[11]^n[5]^n[3],r=r<<1|r>>>31,n[3]=r,c=(s<<5|s>>>27)+((i^f)&a^f)+c+1518500249+r|0,a=a<<30|a>>>2;for(let t=20;t<40;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+1859775393+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+1859775393+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+1859775393+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+1859775393+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+1859775393+r|0,a=a<<30|a>>>2;for(let t=40;t<60;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s&a|(s|a)&i)+f+2400959708+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c&s|(c|s)&a)+i+2400959708+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f&c|(f|c)&s)+a+2400959708+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i&f|(i|f)&c)+s+2400959708+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a&i|(a|i)&f)+c+2400959708+r|0,a=a<<30|a>>>2;for(let t=60;t<80;t+=5)r=n[t-3&15]^n[t-8&15]^n[t-14&15]^n[15&t],r=r<<1|r>>>31,n[15&t]=r,f=(c<<5|c>>>27)+(s^a^i)+f+3395469782+r|0,s=s<<30|s>>>2,r=n[t-2&15]^n[t-7&15]^n[t-13&15]^n[t+1&15],r=r<<1|r>>>31,n[t+1&15]=r,i=(f<<5|f>>>27)+(c^s^a)+i+3395469782+r|0,c=c<<30|c>>>2,r=n[t-1&15]^n[t-6&15]^n[t-12&15]^n[t+2&15],r=r<<1|r>>>31,n[t+2&15]=r,a=(i<<5|i>>>27)+(f^c^s)+a+3395469782+r|0,f=f<<30|f>>>2,r=n[15&t]^n[t-5&15]^n[t-11&15]^n[t+3&15],r=r<<1|r>>>31,n[t+3&15]=r,s=(a<<5|a>>>27)+(i^f^c)+s+3395469782+r|0,i=i<<30|i>>>2,r=n[t+1&15]^n[t-4&15]^n[t-10&15]^n[t+4&15],r=r<<1|r>>>31,n[t+4&15]=r,c=(s<<5|s>>>27)+(a^i^f)+c+3395469782+r|0,a=a<<30|a>>>2;t[0]=t[0]+c|0,t[1]=t[1]+s|0,t[2]=t[2]+a|0,t[3]=t[3]+i|0,t[4]=t[4]+f|0}}(),e=new c(O),r=new c(O);t.length>O&&(n.update(t,0,t.length),t=n.digest());for(let n=0;n<O;n++){const o=n<t.length?t[n]:0;e[n]=54^o,r[n]=92^o}return n.update(e,0,O),{update(t,e,o){n.update(t,e,o)},digest(){const t=n.digest();n.update(r,0,O),n.update(t,0,V);const o=n.digest();return n.update(e,0,O),o}}}function Q(t){return j[t>>>24]<<24|j[t>>>16&255]<<16|j[t>>>8&255]<<8|j[255&t]}function X(t){return t<<24|(65280&t)<<8|t>>>8&65280|t>>>24}function Y(t){return 255&(t<<1^27*(t>>7))}const $=typeof d!=b&&typeof d.getRandomValues==k,tt="Invalid password",nt="zipjs-abort-check-password";function et(t){if($)return d.getRandomValues(t);throw new r("Crypto API not supported")}const ot={name:"PBKDF2"},rt=n.assign({hash:{name:"HMAC"}},ot),ct=n.assign({iterations:1e3,hash:{name:"SHA-1"}},ot),st=["deriveBits"],at=[8,12,16],it=[16,24,32],ft=10,ut=typeof d!=b,wt=ut&&d.subtle;let lt=ut&&typeof wt!=b&&typeof wt.importKey==k&&typeof wt.deriveBits==k,dt=G;class pt extends h{constructor({password:t,rawPassword:n,encryptionStrength:e,checkPasswordOnly:o,checkAuthenticationCode:s=!0}){const a={};super({start(){yt(a,t,n,e)},async transform(t,n){const{password:e,strength:s,l:i,ready:f}=a;if(e?(await async function(t,n,e,o){const c=await vt(t,n,e,kt(o,0,at[n])),s=kt(o,at[n]);if(c[0]!=s[0]||c[1]!=s[1])throw gt(t),new r(tt)}(a,s,e,kt(t,0,at[s]+2)),t=kt(t,at[s]+2),o?(gt(a),n.error(new r(nt))):i()):await f,a.h)return;const u=new c(t.length-ft-(t.length-ft)%16);n.enqueue(St(a,t,u,0,ft,!0))},async flush(t){const{m:n,S:e,ready:o}=a;if(n){if(await o,a.h)return;const i=kt(e,e.length-ft),f=new c(kt(e,0,e.length-ft));n.process(f,!0);const u=n.digest();let w=e.length<ft?1:0;for(let t=0;t<ft;t++)w|=u[t]^i[t];if(w&&s)return void t.error(new r("Invalid authentication code"));t.enqueue(f)}}}),mt(this,a)}}class ht extends h{constructor({password:t,rawPassword:n,encryptionStrength:e}){const o={};super({start(){yt(o,t,n,e)},async transform(t,n){const{password:e,strength:r,l:s,ready:a}=o;let i=z;if(e?(i=await async function(t,n,e){const o=et(new c(at[n]));return B(o,await vt(t,n,e,o))}(o,r,e),s()):await a,o.h)return;const f=new c(i.length+t.length-t.length%16);f.set(i,0),n.enqueue(St(o,t,f,i.length,0,!1))},async flush(t){const{m:n,S:e,ready:r}=o;if(n){if(await r,o.h)return;const s=new c(e);n.process(s,!1);const a=kt(n.digest(),0,ft);t.enqueue(B(s,a))}}}),mt(this,o)}}function yt(t,e,o,r){n.assign(t,{ready:new w(n=>t.l=n),password:bt(e,o),strength:r-1,S:z,h:!1})}function mt(t,e){const o=t.readable.getReader(),r=new y({async pull(t){try{const{value:n,done:e}=await o.read();e?t.close():t.enqueue(n)}catch(t){throw gt(e),o.cancel(t).catch(()=>{}),t}},cancel:t=>(gt(e),o.cancel(t))});n.defineProperty(t,"readable",{get:()=>r})}function St(t,n,e,o,r,s){const{m:a,S:i}=t;i.length&&(n=B(i,n));const f=n.length-r,u=f-f%16;if(e=function(t,n){if(n&&n>t.length){const e=t;(t=new c(n)).set(e,0)}return t}(e,o+u),u){const t=kt(e,o,o+u);t.set(kt(n,0,u)),a.process(t,s)}return t.S=kt(n,u),e}function gt(t){const{m:n}=t;t.h=!0,n&&n.dispose&&n.dispose()}async function vt(t,e,r,s){t.password=null;const a=it[e],i=await async function(t,e,r){if(lt)try{const o=await wt.importKey("raw",t,rt,!1,st);return new c(await wt.deriveBits(n.assign({salt:e},ct),o,8*r))}catch{lt=!1}return function(t,n,e,r){const s=J(t),a=new c(r),i=new c(n.length+4),f=new u(i.buffer);i.set(n);for(let t=1,e=0;e<r;t++,e+=V){f.setUint32(n.length,t),s.update(i,0,i.length);let c=s.digest();const u=c.slice();for(let t=1;t<1e3;t++){s.update(c,0,V),c=s.digest();for(let t=0;t<V;t++)u[t]^=c[t]}a.set(u.subarray(0,o.min(V,r-e)),e)}return a}(t,e,0,r)}(r,s,2*a+2);return t.m=dt(kt(i,0,a),kt(i,a,2*a)),t.h&&gt(t),kt(i,2*a)}function bt(t,n){return n===v?function(t){if(typeof l==b){t=unescape(encodeURIComponent(t));const n=new c(t.length);for(let e=0;e<n.length;e++)n[e]=t.charCodeAt(e);return n}return(new l).encode(t)}(t):n}function kt(t,n,e){return t.subarray(n,e)}class zt extends h{constructor({password:t,rawPassword:n,passwordVerification:e,checkPasswordOnly:o}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;if(e.password||e.rawPassword){const n=Mt(e,t.subarray(0,12));if(e.password=e.rawPassword=null,0!=(n[11]^e.passwordVerification))throw new r(tt);t=t.subarray(12)}o?n.error(new r(nt)):n.enqueue(Mt(e,t))}})}}class Ct extends h{constructor({password:t,rawPassword:n,passwordVerification:e}){super({start(){It(this,t,n,e)},transform(t,n){const e=this;let o,r;if(e.password||e.rawPassword){e.password=e.rawPassword=null;const n=et(new c(12));n[11]=e.passwordVerification,o=new c(t.length+n.length),o.set(At(e,n),0),r=12}else o=new c(t.length),r=0;o.set(At(e,t),r),n.enqueue(o)}})}}function It(t,e,o,r){n.assign(t,{password:e,rawPassword:o,passwordVerification:r}),function(t,e,o){const r=[305419896,591751049,878082192];if(n.assign(t,{v:r,C:new F(r[0]),I:new F(r[2])}),o)for(let n=0;n<o.length;n++)Et(t,o[n]);else for(let n=0;n<e.length;n++)Et(t,e.charCodeAt(n))}(t,e,o)}function Mt(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,e[o]);return e}function At(t,n){const e=new c(n.length);for(let o=0;o<n.length;o++)e[o]=Rt(t)^n[o],Et(t,n[o]);return e}function Et(t,n){let[,e]=t.v;t.C.append([n]);const r=~t.C.get();e=Pt(o.imul(Pt(e+xt(r)),134775813)+1),t.I.append([e>>>24]);const c=~t.I.get();t.v=[r,e,c]}function Rt(t){const n=2|t.v[2];return xt(o.imul(n,1^n)>>>8)}function xt(t){return 255&t}function Pt(t){return 4294967295&t}function Dt(t){return Boolean(t)&&"object"==typeof t}const Ft=new f;function Ut(t){return Ft.get(t)}const Bt="Invalid uncompressed size",Wt="Codec out of memory",Ot="Invalid CRC32",Vt="deflate-raw",Kt="gzip",Tt=[31,139,8];class _t extends h{constructor(t,{chunkSize:n,CompressionStreamFallback:e,CompressionStream:o}){super({});const{compressed:r,encrypted:c,useCompressionStream:s,zipCrypto:a,computeCrc32:i,level:f,deflate64:w,format:l,compressionMethod:d,inputSize:p}=t,h=this;let y,m,S,g=super.readable;const v=l&&Ut(l),b=qt(s,o,e),k=i&&r&&!w&&!v&&(!c||a)&&Boolean(b);if(c&&!a||!i||k||(y=new U,g=Jt(g,y)),r)if(v)g=Qt(g,Nt(v.CompressionStream,l,{level:f,chunkSize:n,compressionMethod:d,uncompressedSize:p}));else if(k)S=new jt,g=Qt(g,new b(Kt,{level:f,chunkSize:n})),g=Jt(g,S);else try{g=Gt(g,s,{level:f,chunkSize:n},o,e)}catch(t){if(!s&&e)throw nn(t);let n;try{n=new o(Kt)}catch{throw nn(t)}g=Qt(g,n),g=Jt(g,new jt)}c&&(a?g=Jt(g,new Ct(t)):(m=new ht(t),g=Jt(g,m))),Zt(h,g,()=>{c&&!a||!i||(h.crc32=k?S.crc32:new u(y.value.buffer).getUint32(0))})}}class jt extends h{constructor(){let t,n=10,e=new c(0);super({transform(t,r){if(n){const e=o.min(n,t.length);if(n-=e,!(t=t.subarray(e)).length)return}const c=e.length+t.length;if(c<=8)return void(e=B(e,t));const s=c-8,a=o.min(s,e.length);r.enqueue(B(e.subarray(0,a),t.subarray(0,s-a))),e=B(e.subarray(a),t.subarray(s-a))},flush(){const n=W(e);t.crc32=n.getUint32(0,!0),t.uncompressedSize=n.getUint32(4,!0)}}),t=this}}class Ht extends h{constructor(t,{chunkSize:n,DecompressionStreamFallback:e,DecompressionStream:o}){super({});const{zipCrypto:s,encrypted:a,checkCrc32:i,crc32:f,compressed:l,useCompressionStream:d,deflate64:p,format:h,compressionMethod:m,rawBitFlag:S,outputSize:g}=t;let b,k,z,C=super.readable;if(a&&(s?C=Jt(C,new zt(t)):(k=new pt(t),C=Jt(C,k))),l){const t=new Set,s=h&&Ut(h);let a;if(s)C=Qt(C,Nt(s.DecompressionStream,h,{chunkSize:n,compressionMethod:m,rawBitFlag:S,uncompressedSize:g}),t);else{const r=qt(d,o,e);if(i&&!p&&f!==v&&g!==v&&r)try{a=new r(Kt,{chunkSize:n})}catch{a=v}if(!a)try{C=Gt(C,d,{chunkSize:n,deflate64:p},o,e,t)}catch(t){if(p||g===v||!d&&e)throw nn(t);try{a=new o(Kt)}catch{throw nn(t)}}}a?(z=!0,C=function(t,n,e,o,s){const a=n.writable.getWriter(),i=n.readable.getReader(),f=o===v?new F:v;let u,l,d=0,p=!1,h=!1;const m=new y({start(t){l=t},pull(){b()},cancel:t=>(h=!0,b(),i.cancel(t))});return async function(){const n=t.getReader();try{const t=new c(10);for(t.set(Tt),await a.write(t);;){await g(),await a.ready;const{value:t,done:e}=await $t(n,s);if(e)break;await a.write(t)}f&&await a.write(new c(0));const r=new c(8),i=W(r);i.setUint32(0,f?f.get():o,!0),i.setUint32(4,e,!0),p=!0,await a.write(r),await a.close()}catch(t){await Xt(a,t),await Yt(n,t)}}(),async function(){try{for(;;){const{value:t,done:n}=await S();if(n)break;if(d+=t.length,d>e)throw new r(Bt);f&&f.append(t),l.enqueue(t)}h||(h=!0,l.close())}catch(t){!function(t){h||(h=!0,l.error(t),b())}(t),await Yt(i,t)}}(),m;function S(){return i.read().catch(t=>{if(p){if(!f)throw on(t,Ot);if(d!=e)throw on(t,Bt);return{done:!0}}throw tn(t,s)})}function g(){if(!h&&l.desiredSize<=0)return new w(t=>u=t)}function b(){if(u){const t=u;u=v,t()}}}(C,a,g,f,t)):C=function(t,n){const e=t.getReader();return new y({async pull(t){try{const{value:n,done:o}=await e.read();o?t.close():t.enqueue(n)}catch(t){throw await Yt(e,t),tn(t,n)}},cancel:t=>e.cancel(t)})}(C,t)}i&&!z&&(b=new U,C=Jt(C,b)),Zt(this,C,()=>{if(b){const t=new u(b.value.buffer).getUint32(0,!1);if(f!=t)throw new r(Ot)}})}}const Lt=new f;function Zt(t,e,o){e=Jt(e,new h({flush:o})),n.defineProperty(t,"readable",{get:()=>e})}function Nt(t,n,e){if(!t)throw new r("Compression method not supported");return new t(n,e)}function qt(t,n,e){return t&&n?n:e&&e.requiresModule?e:void 0}function Gt(t,n,e,o,r,c){const s=n&&o?o:r||o,a=e.deflate64?"deflate64-raw":Vt;let i;try{i=new s(a,e)}catch(t){if(!n||!r||s==r)throw t;i=new r(a,e)}return Qt(t,i,c)}function Jt(t,n){return function(t){if(t instanceof y)return t;const n=t.getReader();return new y({async pull(t){try{const{value:e,done:o}=await n.read();o?t.close():t.enqueue(e)}catch(t){throw n.cancel(t).catch(()=>{}),t}},cancel:t=>n.cancel(t)})}(t).pipeThrough(n)}function Qt(t,n,e){const o=n.writable.getWriter(),r=t.getReader();return async function(){try{for(;;){await o.ready;const t=await $t(r,e);if(t.done){await o.close();break}await o.write(t.value)}}catch(t){await Xt(o,t),await Yt(r,t)}}(),n.readable}async function Xt(t,n){try{await t.abort(n)}catch{}}async function Yt(t,n){try{await t.cancel(n)}catch{}}function $t(t,n){const e=t.read();return n?e.catch(t=>{throw n.add(t),t}):e}function tn(t,n){return n.has(t)?t:on(t,en(t)?Wt:"Invalid compressed data")}function nn(t){return en(t)?on(t,Wt):t}function en(t){return Dt(t)&&"Z_MEM_ERROR"==t.code}function on(t,n){const e=new r(n);return e.cause=t,e}const rn="data",cn="deflate";class sn extends h{constructor(t,e){super({});const o=this,{codecType:c}=t;let s;c.startsWith(cn)?s=_t:c.startsWith("inflate")&&(s=Ht),o.outputSize=0;let a=0;const i=new s(t,e),f=super.readable,u=new h({transform(t,n){t&&t.length&&(a+=t.length,n.enqueue(t))},flush(){n.assign(o,{inputSize:a})}}),w=new h({transform(n,e){if(n&&n.length&&(e.enqueue(n),o.outputSize+=n.length,t.outputSize!==v&&o.outputSize>t.outputSize))throw new r(Bt)},flush(){const{crc32:t}=i;n.assign(o,{crc32:t,inputSize:a})}});n.defineProperty(o,"readable",{get:()=>f.pipeThrough(u).pipeThrough(i).pipeThrough(w)})}}class an extends h{constructor(t){const o=[];let r=0,s=0;function a(){const n=new c(t);let e=0;for(;e<t;){const r=o[0],c=t-e;r.length<=c?(n.set(r,e),e+=r.length,o.shift()):(n.set(r.subarray(0,c),e),o[0]=r.subarray(c),e+=c)}return r-=t,n}(!e.isFinite(t)||t<1)&&(t=262144),super({transform(n,e){for(o.push(n),r+=n.length;r>t;)s+=t,e.enqueue(a())},flush(t){r&&(s+=r,t.enqueue(function(t,n){const e=new c(n);let o=0;for(const n of t)e.set(n,o),o+=n.length;return e}(o,r)))}}),n.defineProperty(this,"outputSize",{get:()=>s})}}let fn=2;try{typeof navigator!=b&&navigator.hardwareConcurrency&&(fn=navigator.hardwareConcurrency)}catch{}const un=new f,wn=new f,ln=function(){try{return structuredClone(new r)instanceof r}catch{return!1}}();let dn=0;async function pn(t){let n,c,s;try{const{options:a,config:i}=t;if(a.format)try{await async function(t,n){!Ft.has(t)&&n&&function(t,n){const{CompressionStream:e,DecompressionStream:o}=n;if(typeof e!=k&&typeof o!=k)throw new r("Invalid codec module");Ft.set(t,{CompressionStream:e,DecompressionStream:o})}(t,await(import(n)))}(a.format,a.codecURI)}catch(t){if(Dt(t))try{t.codecImportFailed=!0}catch{}throw t}if(i.CompressionStream=self.CompressionStream,i.DecompressionStream=self.DecompressionStream,a.compressed&&!a.format)if(a.useCompressionStream){if(!function(t,n){if(!t)return!1;let e=Lt.get(t);e||(e=new f,Lt.set(t,e));let o=e.get(n);if(o===v){try{new t(n),o=!0}catch{o=!1}e.set(n,o)}return o}(a.codecType.startsWith(cn)?i.CompressionStream:i.DecompressionStream,Vt))try{await self.initModule(t.config)}catch{}}else try{await self.initModule(t.config)}catch{a.useCompressionStream=!0}if(a.encrypted&&!a.zipCrypto)try{await self.initModule(t.config)}catch{}!i.CompressionStreamFallback&&i.CompressionStreamZlib&&(i.CompressionStreamFallback=i.CompressionStreamZlib),!i.DecompressionStreamFallback&&i.DecompressionStreamZlib&&(i.DecompressionStreamFallback=i.DecompressionStreamZlib);const u={highWaterMark:1},l=new y({async pull(t){const n=new w(t=>un.set(dn,t));hn({type:"pull",messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER;const{value:o,done:r}=await n;t.enqueue(o),r&&t.close()}},u);s=new m({async write(t){let n;const o=new w(t=>n=t);wn.set(dn,n),hn({type:rn,value:t,messageId:dn}),dn=(dn+1)%e.MAX_SAFE_INTEGER,await o}},u),n=new sn(a,i),c=new an(function(t){return r="string"==typeof(n=r=t.chunkSize)&&n.trim()?e(n):n,e.isInteger(r)&&r>=1?o.max(r,64):262144;var n,r}(i)),await l.pipeThrough(n).pipeThrough(c).pipeTo(s,{preventClose:!0,preventAbort:!0}),await s.getWriter().close();const{crc32:d,inputSize:p,outputSize:h}=n;hn({type:"close",result:{crc32:d,inputSize:p,outputSize:h}})}catch(t){const n=c?c.outputSize:0;if(Dt(t))try{t.outputSize=n}catch{}if(s&&!s.locked)try{await s.getWriter().close()}catch{}yn(t,n)}}function hn(t){const{value:n}=t;if(n)if(n.length)try{t.value=(e=n,e.byteOffset||e.byteLength!=e.buffer.byteLength?new c(e):e).buffer,p(t,[t.value])}catch{p(t)}else p(t);else p(t);var e}function yn(t,n){const{message:e,stack:o,code:c,name:s,outputSize:a,cause:i,codecImportFailed:f}=function(t=new r("Unknown error")){return Dt(t)?t:new r(String(t))}(t),u={message:e,stack:o,code:c,name:s,outputSize:a===v?n:a};if(Dt(i)&&(u.cause={name:i.name,message:i.message,code:i.code}),f&&(u.codecImportFailed=!0),ln)try{return void p({error:u,errorValue:{value:t}})}catch{}p({error:u})}addEventListener("message",({data:t})=>{const{type:n,messageId:e,value:o,done:r}=t;try{if("start"==n&&pn(t),n==rn){const t=un.get(e);un.delete(e),t({value:o||new c,done:r})}if("ack"==n){const t=wn.get(e);wn.delete(e),t()}}catch(t){yn(t)}}),p({type:"ready"});const mn="deflate",Sn="deflate-raw",gn="deflate64-raw",vn="gzip",bn=[mn,Sn,vn],kn=[mn,Sn,vn,gn];let zn,Cn,In,Mn,An;function En(t,n){return-4===n&&(t.code="Z_MEM_ERROR"),t}function Rn(t,n,e={}){if(!(t?bn:kn).includes(n))throw new TypeError("Unsupported format: "+n);if(!zn){const t=new r("WASM module not loaded");throw t.cause=An,t}const s="number"==typeof e.level?e.level:-1,a="number"==typeof e.outBuffer?e.outBuffer:65536,i="number"==typeof e.inBufferSize?e.inBufferSize:65536,f={M:0,in:0,inBufferSize:0,A:0,R:!1};let u,l,d,p,h=!0,S=!1;return function(){try{let e;if(f.M=Cn(a),f.in=Cn(i),f.inBufferSize=i,!f.M||!f.in)throw En(new r("allocation failed"),-4);if(t?(f.P=zn.deflate_process,f.D=zn.deflate_last_consumed,f.F=zn.deflate_end,f.A=zn.deflate_new(),e=n===vn?zn.deflate_init_gzip(f.A,s):n===Sn?zn.deflate_init_raw(f.A,s):zn.deflate_init(f.A,s)):n===gn?(f.P=zn.inflate9_process,f.D=zn.inflate9_last_consumed,f.F=zn.inflate9_end,f.A=zn.inflate9_new(),e=zn.inflate9_init_raw(f.A)):(f.P=zn.inflate_process,f.D=zn.inflate_last_consumed,f.F=zn.inflate_end,f.A=zn.inflate_new(),e=n===Sn?zn.inflate_init_raw(f.A):n===vn?zn.inflate_init_gzip(f.A):zn.inflate_init(f.A)),0!==e)throw En(new r("init failed:"+e),e)}catch(t){throw b(f),t}}(),{readable:new y({start(t){u=t},pull(){h=!1,v()},cancel(t){S=!0,p=t,b(f),l.error(t),v()}},{highWaterMark:0}),writable:new m({start(t){l=t},async write(t){if(h&&await new w(t=>d=t),S)throw p;try{!function(t){const n=new c(Mn.buffer),e=f.P,s=f.D,i=f.M;let u=0;for(;u<t.length;){if(f.R)throw new r("trailing data after the end of the stream");const c=o.min(t.length-u,32768);if((!f.in||f.inBufferSize<c)&&(f.in&&In&&(In(f.in),f.in=0),f.in=Cn(c),f.inBufferSize=c,!f.in))throw En(new r("allocation failed"),-4);n.set(t.subarray(u,u+c),f.in);const w=e(f.A,f.in,c,i,a,0),l=w>>24&255,d=128&l?l-256:l;if(d<0)throw En(new r("process error:"+d),d);const p=16777215&w;p&&g(n.slice(i,i+p));const h=s(f.A);if(1===l)f.R=!0;else if(0===h&&0===p)break;u+=h}}(t)}catch(t){throw b(f),u.error(t),t}},close(){if(S)return;try{!function(){const t=new c(Mn.buffer),n=f.P,e=f.M;for(;;){const o=n(f.A,0,0,e,a,4),c=o>>24&255,s=128&c?c-256:c;if(s<0)throw En(new r("process error:"+s),s);const i=16777215&o;if(i&&g(t.slice(e,e+i)),1===c||0===i)break}}()}catch(t){throw b(f),u.error(t),t}const t=b(f);if(0!==t){const n=En(new r("end error:"+t),t);throw u.error(n),n}u.close()},abort(t){b(f),u.error(t)}},{highWaterMark:1})};function g(t){h=!0,u.enqueue(t)}function v(){if(d){const t=d;d=null,t()}}function b(t){let n=0;return t.A&&t.F&&(n=t.F(t.A)),t.A=0,t.in&&In&&In(t.in),t.in=0,t.M&&In&&In(t.M),t.M=0,n}}class xn{constructor(t=mn,n){return Rn(!0,t,n)}}class Pn{constructor(t=mn,n){return Rn(!1,t,n)}}xn.requiresModule=!0,Pn.requiresModule=!0,xn.supportedFormats=bn,Pn.supportedFormats=kn;const Dn=65536;let Fn,Un;function Bn(t){return new c(t.memory.buffer)}let Wn=!1;!function(t={}){const{init:n,U:e}=t,o=t.CompressionStreamFallback||t.CompressionStreamZlib,r=t.DecompressionStreamFallback||t.DecompressionStreamZlib;e&&(dt=e||G),self.initModule=async t=>{n&&await n(t),o&&(t.CompressionStreamFallback=o),r&&(t.DecompressionStreamFallback=r)}}({CompressionStreamFallback:xn,DecompressionStreamFallback:Pn,U:function(t,n){const e=Fn;let o=e?function(t,n,e){Un||(Un=t.malloc(Dn));const o=Un?t.aes_hmac_new():0;if(o){const r=Bn(t);if(r.set(n,Un),r.set(e,Un+n.length),t.aes_hmac_init(o,Un,n.length,Un+n.length,e.length))return t.aes_hmac_end(o,0),0}return o}(e,t,n):0;if(!o)return G(t,n);const r=Un;return{process(t,n){for(let c=0;c<t.length;c+=Dn){const s=t.subarray(c,c+Dn),a=Bn(e);a.set(s,r),e.aes_hmac_process(o,r,s.length,n?1:0),s.set(a.subarray(r,r+s.length))}},digest:()=>(e.aes_hmac_end(o,r),o=0,Bn(e).slice(r,r+20)),dispose(){o&&(e.aes_hmac_end(o,0),o=0)}}},init:t=>async function(t,{baseURI:n}){if(!Wn)try{await async function(t,n){let e,o;try{try{o=new URL(t,n)}catch{}const r=await fetch(o);e=await r.arrayBuffer()}catch(n){if(!t.startsWith("data:application/wasm;base64,"))throw n;e=function(t){const n=t.split(",")[1],e=atob(n),o=e.length,r=new c(o);for(let t=0;t<o;++t)r[t]=e.charCodeAt(t);return r.buffer}(t)}const s=await WebAssembly.instantiate(e);var a;(function(t){if(zn=t,({malloc:Cn,free:In,memory:Mn}=zn),"function"!=typeof Cn||"function"!=typeof In||!Mn)throw zn=Cn=In=Mn=null,new r("Invalid WASM module")})(s.instance.exports),typeof(a=s.instance.exports).aes_hmac_new==k&&(Fn=a,Un=0)}(t,n),Wn=!0}catch(t){throw function(t){An=t}(t),t}}(t.wasmURI,t)})});
`;
  if (typeof r == "string" && (r = new TextEncoder().encode(r)), n) {
    const a = new Blob([r], { type: e });
    return URL.createObjectURL(a);
  }
  return "data:" + e + ";base64," + (function(a) {
    let s = "";
    const i = a.length;
    let o = 0;
    for (; o + 2 < i; o += 3) {
      const g = a[o] << 16 | a[o + 1] << 8 | a[o + 2];
      s += Y[g >> 18 & 63] + Y[g >> 12 & 63] + Y[g >> 6 & 63] + Y[63 & g];
    }
    const p = i - o;
    if (p === 1) {
      const g = a[o] << 16;
      s += Y[g >> 18 & 63] + Y[g >> 12 & 63] + "==";
    } else if (p === 2) {
      const g = a[o] << 16 | a[o + 1] << 8;
      s += Y[g >> 18 & 63] + Y[g >> 12 & 63] + Y[g >> 6 & 63] + "=";
    }
    return s;
  })(r);
} });
function _(t, n) {
  const e = new Uint8Array(t.length + n.length);
  return e.set(t), e.set(n, t.length), e;
}
function Ce(t) {
  return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
function Gn(t) {
  return !!t && typeof t == "object";
}
const ot = [[], [], [], [], [], [], [], []];
for (let t = 0; t < 256; t++) {
  let n = t;
  for (let e = 0; e < 8; e++)
    n = n & 1 ? n >>> 1 ^ 3988292384 : n >>> 1;
  ot[0][t] = n;
}
for (let t = 0; t < 256; t++)
  for (let n = 1; n < 8; n++) {
    const e = ot[n - 1][t];
    ot[n][t] = e >>> 8 ^ ot[0][e & 255];
  }
const [se, jn, Jn, Qn, _n, $n, tr, er] = ot;
class xt {
  constructor(n) {
    this.crc = n || -1;
  }
  append(n) {
    let e = this.crc | 0;
    const r = n.length | 0;
    let a = 0;
    if (r >= 8 && n.buffer) {
      const s = new DataView(n.buffer, n.byteOffset, r), i = r - 8;
      for (; a <= i; a += 8) {
        const o = e ^ s.getInt32(a, !0), p = s.getInt32(a + 4, !0);
        e = er[o & 255] ^ tr[o >>> 8 & 255] ^ $n[o >>> 16 & 255] ^ _n[o >>> 24 & 255] ^ Qn[p & 255] ^ Jn[p >>> 8 & 255] ^ jn[p >>> 16 & 255] ^ se[p >>> 24 & 255];
      }
    }
    for (; a < r; a++)
      e = e >>> 8 ^ se[(e ^ n[a]) & 255];
    this.crc = e;
  }
  get() {
    return ~this.crc;
  }
}
class Ne extends TransformStream {
  constructor() {
    let n;
    const e = new xt();
    super({
      transform(r, a) {
        e.append(r), a.enqueue(r);
      },
      flush() {
        const r = new Uint8Array(4);
        new DataView(r.buffer).setUint32(0, e.get()), n.value = r;
      }
    }), n = this;
  }
}
function nr(t) {
  if (typeof TextEncoder == j) {
    t = unescape(encodeURIComponent(t));
    const n = new Uint8Array(t.length);
    for (let e = 0; e < n.length; e++)
      n[e] = t.charCodeAt(e);
    return n;
  } else
    return new TextEncoder().encode(t);
}
const Lt = 16, rr = 60, M = 64, J = 20, ar = 16, sr = 56, ir = new Uint8Array([128]), or = new Uint8Array(1), ie = new Int32Array([1732584193, 4023233417, 2562383102, 271733878, 3285377520]), cr = 54, lr = 92, N = new Uint8Array(256), v = new Int32Array(256), I = new Int32Array(256), S = new Int32Array(256), A = new Int32Array(256);
let oe = !1;
function Jt(t, n) {
  fr();
  const e = new Int32Array(rr), r = wr(t, e), a = new Int32Array(Lt / 4), s = Pe(n);
  let i = 0, o = 0, p = 0, g = 0;
  return {
    process(l, u) {
      u && s.update(l, 0, l.length), m(l), u || s.update(l, 0, l.length);
    },
    digest() {
      return s.digest();
    }
  };
  function m(l) {
    const u = new DataView(l.buffer, l.byteOffset, l.byteLength), h = l.length;
    let f = 0;
    for (; f + Lt <= h; f += Lt)
      y(), u.setInt32(f, u.getInt32(f) ^ a[0]), u.setInt32(f + 4, u.getInt32(f + 4) ^ a[1]), u.setInt32(f + 8, u.getInt32(f + 8) ^ a[2]), u.setInt32(f + 12, u.getInt32(f + 12) ^ a[3]);
    if (f < h) {
      y();
      for (let w = 0; f < h; f++, w++)
        l[f] ^= a[w >> 2] >>> 24 - 8 * (w & 3);
    }
  }
  function y() {
    i = i + 1 | 0, i || (o = o + 1 | 0, o || (p = p + 1 | 0, p || (g = g + 1 | 0)));
    let l = bt(i) ^ e[0], u = bt(o) ^ e[1], h = bt(p) ^ e[2], f = bt(g) ^ e[3], w = v[l >>> 24] ^ I[u >>> 16 & 255] ^ S[h >>> 8 & 255] ^ A[f & 255] ^ e[4], c = v[u >>> 24] ^ I[h >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[l & 255] ^ e[5], d = v[h >>> 24] ^ I[f >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[u & 255] ^ e[6], b = v[f >>> 24] ^ I[l >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[h & 255] ^ e[7];
    l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[b & 255] ^ e[8], u = v[c >>> 24] ^ I[d >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ e[9], h = v[d >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ e[10], f = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[d & 255] ^ e[11], w = v[l >>> 24] ^ I[u >>> 16 & 255] ^ S[h >>> 8 & 255] ^ A[f & 255] ^ e[12], c = v[u >>> 24] ^ I[h >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[l & 255] ^ e[13], d = v[h >>> 24] ^ I[f >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[u & 255] ^ e[14], b = v[f >>> 24] ^ I[l >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[h & 255] ^ e[15], l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[b & 255] ^ e[16], u = v[c >>> 24] ^ I[d >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ e[17], h = v[d >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ e[18], f = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[d & 255] ^ e[19], w = v[l >>> 24] ^ I[u >>> 16 & 255] ^ S[h >>> 8 & 255] ^ A[f & 255] ^ e[20], c = v[u >>> 24] ^ I[h >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[l & 255] ^ e[21], d = v[h >>> 24] ^ I[f >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[u & 255] ^ e[22], b = v[f >>> 24] ^ I[l >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[h & 255] ^ e[23], l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[b & 255] ^ e[24], u = v[c >>> 24] ^ I[d >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ e[25], h = v[d >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ e[26], f = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[d & 255] ^ e[27], w = v[l >>> 24] ^ I[u >>> 16 & 255] ^ S[h >>> 8 & 255] ^ A[f & 255] ^ e[28], c = v[u >>> 24] ^ I[h >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[l & 255] ^ e[29], d = v[h >>> 24] ^ I[f >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[u & 255] ^ e[30], b = v[f >>> 24] ^ I[l >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[h & 255] ^ e[31], l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[b & 255] ^ e[32], u = v[c >>> 24] ^ I[d >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ e[33], h = v[d >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ e[34], f = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[d & 255] ^ e[35], w = v[l >>> 24] ^ I[u >>> 16 & 255] ^ S[h >>> 8 & 255] ^ A[f & 255] ^ e[36], c = v[u >>> 24] ^ I[h >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[l & 255] ^ e[37], d = v[h >>> 24] ^ I[f >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[u & 255] ^ e[38], b = v[f >>> 24] ^ I[l >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[h & 255] ^ e[39];
    let U = 40;
    r > 10 && (l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[b & 255] ^ e[40], u = v[c >>> 24] ^ I[d >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ e[41], h = v[d >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ e[42], f = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[d & 255] ^ e[43], w = v[l >>> 24] ^ I[u >>> 16 & 255] ^ S[h >>> 8 & 255] ^ A[f & 255] ^ e[44], c = v[u >>> 24] ^ I[h >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[l & 255] ^ e[45], d = v[h >>> 24] ^ I[f >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[u & 255] ^ e[46], b = v[f >>> 24] ^ I[l >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[h & 255] ^ e[47], U = 48), r > 12 && (l = v[w >>> 24] ^ I[c >>> 16 & 255] ^ S[d >>> 8 & 255] ^ A[b & 255] ^ e[48], u = v[c >>> 24] ^ I[d >>> 16 & 255] ^ S[b >>> 8 & 255] ^ A[w & 255] ^ e[49], h = v[d >>> 24] ^ I[b >>> 16 & 255] ^ S[w >>> 8 & 255] ^ A[c & 255] ^ e[50], f = v[b >>> 24] ^ I[w >>> 16 & 255] ^ S[c >>> 8 & 255] ^ A[d & 255] ^ e[51], w = v[l >>> 24] ^ I[u >>> 16 & 255] ^ S[h >>> 8 & 255] ^ A[f & 255] ^ e[52], c = v[u >>> 24] ^ I[h >>> 16 & 255] ^ S[f >>> 8 & 255] ^ A[l & 255] ^ e[53], d = v[h >>> 24] ^ I[f >>> 16 & 255] ^ S[l >>> 8 & 255] ^ A[u & 255] ^ e[54], b = v[f >>> 24] ^ I[l >>> 16 & 255] ^ S[u >>> 8 & 255] ^ A[h & 255] ^ e[55], U = 56), a[0] = (N[w >>> 24] << 24 | N[c >>> 16 & 255] << 16 | N[d >>> 8 & 255] << 8 | N[b & 255]) ^ e[U], a[1] = (N[c >>> 24] << 24 | N[d >>> 16 & 255] << 16 | N[b >>> 8 & 255] << 8 | N[w & 255]) ^ e[U + 1], a[2] = (N[d >>> 24] << 24 | N[b >>> 16 & 255] << 16 | N[w >>> 8 & 255] << 8 | N[c & 255]) ^ e[U + 2], a[3] = (N[b >>> 24] << 24 | N[w >>> 16 & 255] << 16 | N[c >>> 8 & 255] << 8 | N[d & 255]) ^ e[U + 3];
  }
}
function ur(t, n, e, r) {
  const a = Pe(t), s = new Uint8Array(r), i = new Uint8Array(n.length + 4), o = new DataView(i.buffer);
  i.set(n);
  for (let p = 1, g = 0; g < r; p++, g += J) {
    o.setUint32(n.length, p), a.update(i, 0, i.length);
    let m = a.digest();
    const y = m.slice();
    for (let l = 1; l < e; l++) {
      a.update(m, 0, J), m = a.digest();
      for (let u = 0; u < J; u++)
        y[u] ^= m[u];
    }
    s.set(y.subarray(0, Math.min(J, r - g)), g);
  }
  return s;
}
function Pe(t) {
  const n = dr(), e = new Uint8Array(M), r = new Uint8Array(M);
  t.length > M && (n.update(t, 0, t.length), t = n.digest());
  for (let a = 0; a < M; a++) {
    const s = a < t.length ? t[a] : 0;
    e[a] = s ^ cr, r[a] = s ^ lr;
  }
  return n.update(e, 0, M), {
    update(a, s, i) {
      n.update(a, s, i);
    },
    digest() {
      const a = n.digest();
      n.update(r, 0, M), n.update(a, 0, J);
      const s = n.digest();
      return n.update(e, 0, M), s;
    }
  };
}
function dr() {
  const t = new Int32Array(ie), n = new Int32Array(ar), e = new Uint8Array(M), r = new DataView(e.buffer), a = new Uint8Array(8);
  let s = 0, i = 0;
  return {
    update: o,
    digest: p
  };
  function o(m, y, l) {
    const u = y + l;
    if (i += l, s) {
      for (; y < u && s < M; )
        e[s++] = m[y++];
      s == M && (g(r, 0), s = 0);
    }
    if (y + M <= u) {
      const h = new DataView(m.buffer, m.byteOffset, m.byteLength);
      for (; y + M <= u; y += M)
        g(h, y);
    }
    for (; y < u; )
      e[s++] = m[y++];
  }
  function p() {
    const m = i * 8, y = Math.floor(m / 4294967296), l = m >>> 0;
    for (o(ir, 0, 1); s != sr; )
      o(or, 0, 1);
    a[0] = y >>> 24, a[1] = y >>> 16, a[2] = y >>> 8, a[3] = y, a[4] = l >>> 24, a[5] = l >>> 16, a[6] = l >>> 8, a[7] = l, o(a, 0, 8);
    const u = new Uint8Array(J), h = new DataView(u.buffer);
    for (let f = 0; f < t.length; f++)
      h.setInt32(4 * f, t[f]);
    return t.set(ie), s = 0, i = 0, u;
  }
  function g(m, y) {
    for (let d = 0; d < 16; d++)
      n[d] = m.getInt32(y + 4 * d);
    let l = t[0], u = t[1], h = t[2], f = t[3], w = t[4], c;
    for (let d = 0; d < 15; d += 5)
      w = (l << 5 | l >>> 27) + ((h ^ f) & u ^ f) + w + 1518500249 + n[d] | 0, u = u << 30 | u >>> 2, f = (w << 5 | w >>> 27) + ((u ^ h) & l ^ h) + f + 1518500249 + n[d + 1] | 0, l = l << 30 | l >>> 2, h = (f << 5 | f >>> 27) + ((l ^ u) & w ^ u) + h + 1518500249 + n[d + 2] | 0, w = w << 30 | w >>> 2, u = (h << 5 | h >>> 27) + ((w ^ l) & f ^ l) + u + 1518500249 + n[d + 3] | 0, f = f << 30 | f >>> 2, l = (u << 5 | u >>> 27) + ((f ^ w) & h ^ w) + l + 1518500249 + n[d + 4] | 0, h = h << 30 | h >>> 2;
    w = (l << 5 | l >>> 27) + ((h ^ f) & u ^ f) + w + 1518500249 + n[15] | 0, u = u << 30 | u >>> 2, c = n[13] ^ n[8] ^ n[2] ^ n[0], c = c << 1 | c >>> 31, n[0] = c, f = (w << 5 | w >>> 27) + ((u ^ h) & l ^ h) + f + 1518500249 + c | 0, l = l << 30 | l >>> 2, c = n[14] ^ n[9] ^ n[3] ^ n[1], c = c << 1 | c >>> 31, n[1] = c, h = (f << 5 | f >>> 27) + ((l ^ u) & w ^ u) + h + 1518500249 + c | 0, w = w << 30 | w >>> 2, c = n[15] ^ n[10] ^ n[4] ^ n[2], c = c << 1 | c >>> 31, n[2] = c, u = (h << 5 | h >>> 27) + ((w ^ l) & f ^ l) + u + 1518500249 + c | 0, f = f << 30 | f >>> 2, c = n[0] ^ n[11] ^ n[5] ^ n[3], c = c << 1 | c >>> 31, n[3] = c, l = (u << 5 | u >>> 27) + ((f ^ w) & h ^ w) + l + 1518500249 + c | 0, h = h << 30 | h >>> 2;
    for (let d = 20; d < 40; d += 5)
      c = n[d - 3 & 15] ^ n[d - 8 & 15] ^ n[d - 14 & 15] ^ n[d & 15], c = c << 1 | c >>> 31, n[d & 15] = c, w = (l << 5 | l >>> 27) + (u ^ h ^ f) + w + 1859775393 + c | 0, u = u << 30 | u >>> 2, c = n[d - 2 & 15] ^ n[d - 7 & 15] ^ n[d - 13 & 15] ^ n[d + 1 & 15], c = c << 1 | c >>> 31, n[d + 1 & 15] = c, f = (w << 5 | w >>> 27) + (l ^ u ^ h) + f + 1859775393 + c | 0, l = l << 30 | l >>> 2, c = n[d - 1 & 15] ^ n[d - 6 & 15] ^ n[d - 12 & 15] ^ n[d + 2 & 15], c = c << 1 | c >>> 31, n[d + 2 & 15] = c, h = (f << 5 | f >>> 27) + (w ^ l ^ u) + h + 1859775393 + c | 0, w = w << 30 | w >>> 2, c = n[d & 15] ^ n[d - 5 & 15] ^ n[d - 11 & 15] ^ n[d + 3 & 15], c = c << 1 | c >>> 31, n[d + 3 & 15] = c, u = (h << 5 | h >>> 27) + (f ^ w ^ l) + u + 1859775393 + c | 0, f = f << 30 | f >>> 2, c = n[d + 1 & 15] ^ n[d - 4 & 15] ^ n[d - 10 & 15] ^ n[d + 4 & 15], c = c << 1 | c >>> 31, n[d + 4 & 15] = c, l = (u << 5 | u >>> 27) + (h ^ f ^ w) + l + 1859775393 + c | 0, h = h << 30 | h >>> 2;
    for (let d = 40; d < 60; d += 5)
      c = n[d - 3 & 15] ^ n[d - 8 & 15] ^ n[d - 14 & 15] ^ n[d & 15], c = c << 1 | c >>> 31, n[d & 15] = c, w = (l << 5 | l >>> 27) + (u & h | (u | h) & f) + w + 2400959708 + c | 0, u = u << 30 | u >>> 2, c = n[d - 2 & 15] ^ n[d - 7 & 15] ^ n[d - 13 & 15] ^ n[d + 1 & 15], c = c << 1 | c >>> 31, n[d + 1 & 15] = c, f = (w << 5 | w >>> 27) + (l & u | (l | u) & h) + f + 2400959708 + c | 0, l = l << 30 | l >>> 2, c = n[d - 1 & 15] ^ n[d - 6 & 15] ^ n[d - 12 & 15] ^ n[d + 2 & 15], c = c << 1 | c >>> 31, n[d + 2 & 15] = c, h = (f << 5 | f >>> 27) + (w & l | (w | l) & u) + h + 2400959708 + c | 0, w = w << 30 | w >>> 2, c = n[d & 15] ^ n[d - 5 & 15] ^ n[d - 11 & 15] ^ n[d + 3 & 15], c = c << 1 | c >>> 31, n[d + 3 & 15] = c, u = (h << 5 | h >>> 27) + (f & w | (f | w) & l) + u + 2400959708 + c | 0, f = f << 30 | f >>> 2, c = n[d + 1 & 15] ^ n[d - 4 & 15] ^ n[d - 10 & 15] ^ n[d + 4 & 15], c = c << 1 | c >>> 31, n[d + 4 & 15] = c, l = (u << 5 | u >>> 27) + (h & f | (h | f) & w) + l + 2400959708 + c | 0, h = h << 30 | h >>> 2;
    for (let d = 60; d < 80; d += 5)
      c = n[d - 3 & 15] ^ n[d - 8 & 15] ^ n[d - 14 & 15] ^ n[d & 15], c = c << 1 | c >>> 31, n[d & 15] = c, w = (l << 5 | l >>> 27) + (u ^ h ^ f) + w + 3395469782 + c | 0, u = u << 30 | u >>> 2, c = n[d - 2 & 15] ^ n[d - 7 & 15] ^ n[d - 13 & 15] ^ n[d + 1 & 15], c = c << 1 | c >>> 31, n[d + 1 & 15] = c, f = (w << 5 | w >>> 27) + (l ^ u ^ h) + f + 3395469782 + c | 0, l = l << 30 | l >>> 2, c = n[d - 1 & 15] ^ n[d - 6 & 15] ^ n[d - 12 & 15] ^ n[d + 2 & 15], c = c << 1 | c >>> 31, n[d + 2 & 15] = c, h = (f << 5 | f >>> 27) + (w ^ l ^ u) + h + 3395469782 + c | 0, w = w << 30 | w >>> 2, c = n[d & 15] ^ n[d - 5 & 15] ^ n[d - 11 & 15] ^ n[d + 3 & 15], c = c << 1 | c >>> 31, n[d + 3 & 15] = c, u = (h << 5 | h >>> 27) + (f ^ w ^ l) + u + 3395469782 + c | 0, f = f << 30 | f >>> 2, c = n[d + 1 & 15] ^ n[d - 4 & 15] ^ n[d - 10 & 15] ^ n[d + 4 & 15], c = c << 1 | c >>> 31, n[d + 4 & 15] = c, l = (u << 5 | u >>> 27) + (h ^ f ^ w) + l + 3395469782 + c | 0, h = h << 30 | h >>> 2;
    t[0] = t[0] + l | 0, t[1] = t[1] + u | 0, t[2] = t[2] + h | 0, t[3] = t[3] + f | 0, t[4] = t[4] + w | 0;
  }
}
function fr() {
  if (!oe) {
    let t = 1, n = 1;
    do
      t = (t ^ t << 1 ^ (t & 128 ? 27 : 0)) & 255, n = (n ^ n << 1) & 255, n = (n ^ n << 2) & 255, n = (n ^ n << 4) & 255, n & 128 && (n ^= 9), N[t] = (n ^ (n << 1 | n >> 7) ^ (n << 2 | n >> 6) ^ (n << 3 | n >> 5) ^ (n << 4 | n >> 4) ^ 99) & 255;
    while (t != 1);
    N[0] = 99;
    for (let e = 0; e < 256; e++) {
      const r = N[e], a = De(r), s = a << 24 | r << 16 | r << 8 | a ^ r;
      v[e] = s, I[e] = s >>> 8 | s << 24, S[e] = s >>> 16 | s << 16, A[e] = s >>> 24 | s << 8;
    }
    oe = !0;
  }
}
function wr(t, n) {
  const e = t.length >> 2, r = e + 6, a = 4 * (r + 1);
  let s = 1;
  for (let i = 0; i < e; i++)
    n[i] = t[4 * i] << 24 | t[4 * i + 1] << 16 | t[4 * i + 2] << 8 | t[4 * i + 3];
  for (let i = e; i < a; i++) {
    let o = n[i - 1];
    i % e == 0 ? (o = ce(o << 8 | o >>> 24) ^ s << 24, s = De(s)) : e > 6 && i % e == 4 && (o = ce(o)), n[i] = n[i - e] ^ o;
  }
  return r;
}
function ce(t) {
  return N[t >>> 24] << 24 | N[t >>> 16 & 255] << 16 | N[t >>> 8 & 255] << 8 | N[t & 255];
}
function bt(t) {
  return t << 24 | (t & 65280) << 8 | t >>> 8 & 65280 | t >>> 24;
}
function De(t) {
  return (t << 1 ^ (t >> 7) * 27) & 255;
}
const hr = typeof crypto != j && typeof crypto.getRandomValues == ut, Te = "Invalid password", pr = "Invalid authentication code", ke = "zipjs-abort-check-password", mr = "Crypto API not supported";
function Oe(t) {
  if (hr)
    return crypto.getRandomValues(t);
  throw new Error(mr);
}
const Qt = 16, gr = "raw", Le = { name: "PBKDF2" }, yr = { name: "HMAC" }, br = "SHA-1", ze = 1e3, vr = Object.assign({ hash: yr }, Le), Ir = Object.assign({ iterations: ze, hash: { name: br } }, Le), Sr = ["deriveBits"], dt = [8, 12, 16], Ar = [16, 24, 32], V = 10, qt = 2, Be = typeof crypto != j, ft = Be && crypto.subtle, Ur = Be && typeof ft != j;
let le = Ur && typeof ft.importKey == ut && typeof ft.deriveBits == ut, Me = Jt;
class xr extends TransformStream {
  constructor({ password: n, rawPassword: e, encryptionStrength: r, checkPasswordOnly: a, checkAuthenticationCode: s = !0 }) {
    const i = {};
    super({
      start() {
        He(i, n, e, r);
      },
      async transform(o, p) {
        const {
          password: g,
          strength: m,
          resolveReady: y,
          ready: l
        } = i;
        if (g ? (await Cr(i, m, g, F(o, 0, dt[m] + qt)), o = F(o, dt[m] + qt), a ? (wt(i), p.error(new Error(ke))) : y()) : await l, i.discarded)
          return;
        const u = new Uint8Array(o.length - V - (o.length - V) % Qt);
        p.enqueue(Ze(i, o, u, 0, V, !0));
      },
      async flush(o) {
        const {
          engine: p,
          pendingInput: g,
          ready: m
        } = i;
        if (p) {
          if (await m, i.discarded)
            return;
          const y = F(g, g.length - V), l = new Uint8Array(F(g, 0, g.length - V));
          p.process(l, !0);
          const u = p.digest();
          let h = g.length < V ? 1 : 0;
          for (let f = 0; f < V; f++)
            h |= u[f] ^ y[f];
          if (h && s) {
            o.error(new Error(pr));
            return;
          }
          o.enqueue(l);
        }
      }
    }), Fe(this, i);
  }
}
class Rr extends TransformStream {
  constructor({ password: n, rawPassword: e, encryptionStrength: r }) {
    const a = {};
    super({
      start() {
        He(a, n, e, r);
      },
      async transform(s, i) {
        const {
          password: o,
          strength: p,
          resolveReady: g,
          ready: m
        } = a;
        let y = ve;
        if (o ? (y = await Nr(a, p, o), g()) : await m, a.discarded)
          return;
        const l = new Uint8Array(y.length + s.length - s.length % Qt);
        l.set(y, 0), i.enqueue(Ze(a, s, l, y.length, 0, !1));
      },
      async flush(s) {
        const {
          engine: i,
          pendingInput: o,
          ready: p
        } = a;
        if (i) {
          if (await p, a.discarded)
            return;
          const g = new Uint8Array(o);
          i.process(g, !1);
          const m = F(i.digest(), 0, V);
          s.enqueue(_(g, m));
        }
      }
    }), Fe(this, a);
  }
}
function Er(t) {
  Me = t || Jt;
}
function He(t, n, e, r) {
  Object.assign(t, {
    ready: new Promise((a) => t.resolveReady = a),
    password: Dr(n, e),
    strength: r - 1,
    pendingInput: ve,
    discarded: !1
  });
}
function Fe(t, n) {
  const e = t.readable.getReader(), r = new ReadableStream({
    async pull(a) {
      try {
        const { value: s, done: i } = await e.read();
        i ? a.close() : a.enqueue(s);
      } catch (s) {
        throw wt(n), e.cancel(s).catch(() => {
        }), s;
      }
    },
    cancel(a) {
      return wt(n), e.cancel(a);
    }
  });
  Object.defineProperty(t, "readable", {
    get() {
      return r;
    }
  });
}
function Ze(t, n, e, r, a, s) {
  const {
    engine: i,
    pendingInput: o
  } = t;
  o.length && (n = _(o, n));
  const p = n.length - a, g = p - p % Qt;
  if (e = Tr(e, r + g), g) {
    const m = F(e, r, r + g);
    m.set(F(n, 0, g)), i.process(m, s);
  }
  return t.pendingInput = F(n, g), e;
}
async function Cr(t, n, e, r) {
  const a = await qe(t, n, e, F(r, 0, dt[n])), s = F(r, dt[n]);
  if (a[0] != s[0] || a[1] != s[1])
    throw wt(t), new Error(Te);
}
function wt(t) {
  const { engine: n } = t;
  t.discarded = !0, n && n.dispose && n.dispose();
}
async function Nr(t, n, e) {
  const r = Oe(new Uint8Array(dt[n])), a = await qe(t, n, e, r);
  return _(r, a);
}
async function qe(t, n, e, r) {
  t.password = null;
  const a = Ar[n], s = await Pr(e, r, a * 2 + qt);
  return t.engine = Me(F(s, 0, a), F(s, a, a * 2)), t.discarded && wt(t), F(s, a * 2);
}
async function Pr(t, n, e) {
  if (le)
    try {
      const r = await ft.importKey(gr, t, vr, !1, Sr);
      return new Uint8Array(await ft.deriveBits(Object.assign({ salt: n }, Ir), r, e * 8));
    } catch {
      le = !1;
    }
  return ur(t, n, ze, e);
}
function Dr(t, n) {
  return n === L ? nr(t) : n;
}
function Tr(t, n) {
  if (n && n > t.length) {
    const e = t;
    t = new Uint8Array(n), t.set(e, 0);
  }
  return t;
}
function F(t, n, e) {
  return t.subarray(n, e);
}
const $ = 12;
class kr extends TransformStream {
  constructor({ password: n, rawPassword: e, passwordVerification: r, checkPasswordOnly: a }) {
    super({
      start() {
        We(this, n, e, r);
      },
      transform(s, i) {
        const o = this;
        if (o.password || o.rawPassword) {
          const p = ue(o, s.subarray(0, $));
          if (o.password = o.rawPassword = null, (p[$ - 1] ^ o.passwordVerification) != 0)
            throw new Error(Te);
          s = s.subarray($);
        }
        a ? i.error(new Error(ke)) : i.enqueue(ue(o, s));
      }
    });
  }
}
class Or extends TransformStream {
  constructor({ password: n, rawPassword: e, passwordVerification: r }) {
    super({
      start() {
        We(this, n, e, r);
      },
      transform(a, s) {
        const i = this;
        let o, p;
        if (i.password || i.rawPassword) {
          i.password = i.rawPassword = null;
          const g = Oe(new Uint8Array($));
          g[$ - 1] = i.passwordVerification, o = new Uint8Array(a.length + g.length), o.set(de(i, g), 0), p = $;
        } else
          o = new Uint8Array(a.length), p = 0;
        o.set(de(i, a), p), s.enqueue(o);
      }
    });
  }
}
function We(t, n, e, r) {
  Object.assign(t, {
    password: n,
    rawPassword: e,
    passwordVerification: r
  }), Lr(t, n, e);
}
function ue(t, n) {
  const e = new Uint8Array(n.length);
  for (let r = 0; r < n.length; r++)
    e[r] = Ye(t) ^ n[r], Rt(t, e[r]);
  return e;
}
function de(t, n) {
  const e = new Uint8Array(n.length);
  for (let r = 0; r < n.length; r++)
    e[r] = Ye(t) ^ n[r], Rt(t, n[r]);
  return e;
}
function Lr(t, n, e) {
  const r = [305419896, 591751049, 878082192];
  if (Object.assign(t, {
    cryptoKeys: r,
    crcKey0: new xt(r[0]),
    crcKey2: new xt(r[2])
  }), e)
    for (let a = 0; a < e.length; a++)
      Rt(t, e[a]);
  else
    for (let a = 0; a < n.length; a++)
      Rt(t, n.charCodeAt(a));
}
function Rt(t, n) {
  let [, e] = t.cryptoKeys;
  t.crcKey0.append([n]);
  const r = ~t.crcKey0.get();
  e = fe(Math.imul(fe(e + Xe(r)), 134775813) + 1), t.crcKey2.append([e >>> 24]);
  const a = ~t.crcKey2.get();
  t.cryptoKeys = [r, e, a];
}
function Ye(t) {
  const n = t.cryptoKeys[2] | 2;
  return Xe(Math.imul(n, n ^ 1) >>> 8);
}
function Xe(t) {
  return t & 255;
}
function fe(t) {
  return t & 4294967295;
}
function zr(t) {
  if (t instanceof ReadableStream)
    return t;
  const n = t.getReader();
  return new ReadableStream({
    async pull(e) {
      try {
        const { value: r, done: a } = await n.read();
        a ? e.close() : e.enqueue(r);
      } catch (r) {
        throw n.cancel(r).catch(() => {
        }), r;
      }
    },
    cancel(e) {
      return n.cancel(e);
    }
  });
}
const Br = "Compression method not supported", Mr = /* @__PURE__ */ new Map();
function Ve(t) {
  return Mr.get(t);
}
const Wt = "Invalid uncompressed size", Hr = "Invalid compressed data", Ke = "Codec out of memory", Ge = "Invalid CRC32", Fr = "Z_MEM_ERROR", Zr = "deflate-raw", qr = "deflate64-raw", Et = "gzip", je = 10, Yt = 8, Wr = [31, 139, 8];
class Yr extends TransformStream {
  constructor(n, { chunkSize: e, CompressionStreamFallback: r, CompressionStream: a }) {
    super({});
    const { compressed: s, encrypted: i, useCompressionStream: o, zipCrypto: p, computeCrc32: g, level: m, deflate64: y, format: l, compressionMethod: u, inputSize: h } = n, f = this;
    let w, c, d, b = super.readable;
    const U = l && Ve(l), x = _e(o, a, r), E = g && s && !y && !U && (!i || p) && !!x;
    if ((!i || p) && g && !E && (w = new Ne(), b = X(b, w)), s)
      if (U)
        b = ct(b, Qe(U.CompressionStream, l, { level: m, chunkSize: e, compressionMethod: u, uncompressedSize: h }));
      else if (E)
        d = new we(), b = ct(b, new x(Et, { level: m, chunkSize: e })), b = X(b, d);
      else
        try {
          b = $e(b, o, { level: m, chunkSize: e }, a, r);
        } catch (C) {
          if (!o && r)
            throw Nt(C);
          let z;
          try {
            z = new a(Et);
          } catch {
            throw Nt(C);
          }
          b = ct(b, z), b = X(b, new we());
        }
    i && (p ? b = X(b, new Or(n)) : (c = new Rr(n), b = X(b, c))), Je(f, b, () => {
      (!i || p) && g && (f.crc32 = E ? d.crc32 : new DataView(w.value.buffer).getUint32(0));
    });
  }
}
class we extends TransformStream {
  constructor() {
    let n, e = je, r = new Uint8Array(0);
    super({
      transform(a, s) {
        if (e) {
          const g = Math.min(e, a.length);
          if (e -= g, a = a.subarray(g), !a.length)
            return;
        }
        const i = r.length + a.length;
        if (i <= Yt) {
          r = _(r, a);
          return;
        }
        const o = i - Yt, p = Math.min(o, r.length);
        s.enqueue(_(
          r.subarray(0, p),
          a.subarray(0, o - p)
        )), r = _(
          r.subarray(p),
          a.subarray(o - p)
        );
      },
      flush() {
        const a = Ce(r);
        n.crc32 = a.getUint32(0, !0), n.uncompressedSize = a.getUint32(4, !0);
      }
    }), n = this;
  }
}
function Xr(t, n, e, r, a) {
  const s = n.writable.getWriter(), i = n.readable.getReader(), o = r === L ? new xt() : L;
  let p = 0, g = !1, m = !1, y, l;
  const u = new ReadableStream({
    start(U) {
      l = U;
    },
    pull() {
      d();
    },
    cancel(U) {
      return m = !0, d(), i.cancel(U);
    }
  });
  return h(), f(), u;
  async function h() {
    const U = t.getReader();
    try {
      const x = new Uint8Array(je);
      for (x.set(Wr), await s.write(x); ; ) {
        await c(), await s.ready;
        const { value: z, done: Ot } = await en(U, a);
        if (Ot)
          break;
        await s.write(z);
      }
      o && await s.write(new Uint8Array(0));
      const E = new Uint8Array(Yt), C = Ce(E);
      C.setUint32(0, o ? o.get() : r, !0), C.setUint32(4, e, !0), g = !0, await s.write(E), await s.close();
    } catch (x) {
      await tn(s, x), await Ct(U, x);
    }
  }
  async function f() {
    try {
      for (; ; ) {
        const { value: U, done: x } = await w();
        if (x)
          break;
        if (p += U.length, p > e)
          throw new Error(Wt);
        o && o.append(U), l.enqueue(U);
      }
      m || (m = !0, l.close());
    } catch (U) {
      b(U), await Ct(i, U);
    }
  }
  function w() {
    return i.read().catch((U) => {
      if (g) {
        if (!o)
          throw Pt(U, Ge);
        if (p != e)
          throw Pt(U, Wt);
        return { done: !0 };
      }
      throw nn(U, a);
    });
  }
  function c() {
    if (!m && l.desiredSize <= 0)
      return new Promise((U) => y = U);
  }
  function d() {
    if (y) {
      const U = y;
      y = L, U();
    }
  }
  function b(U) {
    m || (m = !0, l.error(U), d());
  }
}
class Vr extends TransformStream {
  constructor(n, { chunkSize: e, DecompressionStreamFallback: r, DecompressionStream: a }) {
    super({});
    const { zipCrypto: s, encrypted: i, checkCrc32: o, crc32: p, compressed: g, useCompressionStream: m, deflate64: y, format: l, compressionMethod: u, rawBitFlag: h, outputSize: f } = n;
    let w, c, d, b = super.readable;
    if (i && (s ? b = X(b, new kr(n)) : (c = new xr(n), b = X(b, c))), g) {
      const U = /* @__PURE__ */ new Set(), x = l && Ve(l);
      let E;
      if (x)
        b = ct(b, Qe(x.DecompressionStream, l, { chunkSize: e, compressionMethod: u, rawBitFlag: h, uncompressedSize: f }), U);
      else {
        const C = _e(m, a, r);
        if (o && !y && p !== L && f !== L && C)
          try {
            E = new C(Et, { chunkSize: e });
          } catch {
            E = L;
          }
        if (!E)
          try {
            b = $e(b, m, { chunkSize: e, deflate64: y }, a, r, U);
          } catch (z) {
            if (y || f === L || !m && r)
              throw Nt(z);
            try {
              E = new a(Et);
            } catch {
              throw Nt(z);
            }
          }
      }
      E ? (d = !0, b = Xr(b, E, f, p, U)) : b = Kr(b, U);
    }
    o && !d && (w = new Ne(), b = X(b, w)), Je(this, b, () => {
      if (w) {
        const U = new DataView(w.value.buffer).getUint32(0, !1);
        if (p != U)
          throw new Error(Ge);
      }
    });
  }
}
function Je(t, n, e) {
  n = X(n, new TransformStream({ flush: e })), Object.defineProperty(t, "readable", {
    get() {
      return n;
    }
  });
}
function Qe(t, n, e) {
  if (!t)
    throw new Error(Br);
  return new t(n, e);
}
function _e(t, n, e) {
  if (t && n)
    return n;
  if (e && e.requiresModule)
    return e;
}
function $e(t, n, e, r, a, s) {
  const i = n && r ? r : a || r, o = e.deflate64 ? qr : Zr;
  let p;
  try {
    p = new i(o, e);
  } catch (g) {
    if (n && a && i != a)
      p = new a(o, e);
    else
      throw g;
  }
  return ct(t, p, s);
}
function X(t, n) {
  return zr(t).pipeThrough(n);
}
function ct(t, n, e) {
  const r = n.writable.getWriter(), a = t.getReader();
  return s(), n.readable;
  async function s() {
    try {
      for (; ; ) {
        await r.ready;
        const i = await en(a, e);
        if (i.done) {
          await r.close();
          break;
        }
        await r.write(i.value);
      }
    } catch (i) {
      await tn(r, i), await Ct(a, i);
    }
  }
}
async function tn(t, n) {
  try {
    await t.abort(n);
  } catch {
  }
}
async function Ct(t, n) {
  try {
    await t.cancel(n);
  } catch {
  }
}
function en(t, n) {
  const e = t.read();
  return n ? e.catch((r) => {
    throw n.add(r), r;
  }) : e;
}
function nn(t, n) {
  return n.has(t) ? t : Pt(t, rn(t) ? Ke : Hr);
}
function Nt(t) {
  return rn(t) ? Pt(t, Ke) : t;
}
function rn(t) {
  return Gn(t) && t.code == Fr;
}
function Pt(t, n) {
  const e = new Error(n);
  return e.cause = t, e;
}
function Kr(t, n) {
  const e = t.getReader();
  return new ReadableStream({
    async pull(r) {
      try {
        const { value: a, done: s } = await e.read();
        s ? r.close() : r.enqueue(a);
      } catch (a) {
        throw await Ct(e, a), nn(a, n);
      }
    },
    cancel(r) {
      return e.cancel(r);
    }
  });
}
const Gr = 256 * 1024, jr = "deflate", Jr = "inflate";
class ha extends TransformStream {
  constructor(n, e) {
    super({});
    const r = this, { codecType: a } = n;
    let s;
    a.startsWith(jr) ? s = Yr : a.startsWith(Jr) && (s = Vr), r.outputSize = 0;
    let i = 0;
    const o = new s(n, e), p = super.readable, g = new TransformStream({
      transform(y, l) {
        y && y.length && (i += y.length, l.enqueue(y));
      },
      flush() {
        Object.assign(r, {
          inputSize: i
        });
      }
    }), m = new TransformStream({
      transform(y, l) {
        if (y && y.length && (l.enqueue(y), r.outputSize += y.length, n.outputSize !== L && r.outputSize > n.outputSize))
          throw new Error(Wt);
      },
      flush() {
        const { crc32: y } = o;
        Object.assign(r, {
          crc32: y,
          inputSize: i
        });
      }
    });
    Object.defineProperty(r, "readable", {
      get() {
        return p.pipeThrough(g).pipeThrough(o).pipeThrough(m);
      }
    });
  }
}
class pa extends TransformStream {
  constructor(n) {
    const e = [];
    let r = 0, a = 0;
    (!Number.isFinite(n) || n < 1) && (n = Gr), super({
      transform(o, p) {
        for (e.push(o), r += o.length; r > n; )
          a += n, p.enqueue(s());
      },
      flush(o) {
        r && (a += r, o.enqueue(i(e, r)));
      }
    }), Object.defineProperty(this, "outputSize", {
      get: () => a
    });
    function s() {
      const o = new Uint8Array(n);
      let p = 0;
      for (; p < n; ) {
        const g = e[0], m = n - p;
        g.length <= m ? (o.set(g, p), p += g.length, e.shift()) : (o.set(g.subarray(0, m), p), e[0] = g.subarray(m), p += m);
      }
      return r -= n, o;
    }
    function i(o, p) {
      const g = new Uint8Array(p);
      let m = 0;
      for (const y of o)
        g.set(y, m), m += y.length;
      return g;
    }
  }
}
class ma extends TransformStream {
  constructor({ onstart: n, onprogress: e, size: r, onend: a }) {
    let s = 0;
    super({
      async start() {
        n && await zt(n, r);
      },
      async transform(i, o) {
        s += i.length, e && await zt(e, s, r), o.enqueue(i);
      },
      async flush() {
        a && await zt(a, s);
      }
    });
  }
}
async function zt(t, ...n) {
  try {
    await t(...n);
  } catch {
  }
}
BigInt(Number.MAX_SAFE_INTEGER);
BigInt(0);
BigInt("0x7fffffffffffffff");
try {
  Tt({ baseURI: import.meta.url });
} catch {
}
const Qr = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258], _r = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0], $r = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577], ta = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13], ea = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], at = new Uint8Array(288);
at.fill(8, 0, 144), at.fill(9, 144, 256), at.fill(7, 256, 280), at.fill(8, 280, 288);
const na = new Uint8Array(30).fill(5);
function nt(t) {
  const n = new Uint16Array(16);
  for (const a of t) n[a]++;
  n[0] = 0;
  const e = new Uint16Array(17);
  for (let a = 1; a <= 15; a++) e[a + 1] = e[a] + n[a];
  const r = new Uint16Array(t.length);
  for (let a = 0; a < t.length; a++) t[a] && (r[e[t[a]]++] = a);
  return { lengthCounts: n, symbols: r };
}
const B = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function ra(t) {
  let n;
  t({ wasmURI: () => (n || (n = "data:application/wasm;base64," + (function(e) {
    let r = "";
    const a = e.length;
    let s = 0;
    for (; s + 2 < a; s += 3) {
      const o = e[s] << 16 | e[s + 1] << 8 | e[s + 2];
      r += B[o >> 18 & 63] + B[o >> 12 & 63] + B[o >> 6 & 63] + B[63 & o];
    }
    const i = a - s;
    if (i === 1) {
      const o = e[s] << 16;
      r += B[o >> 18 & 63] + B[o >> 12 & 63] + "==";
    } else if (i === 2) {
      const o = e[s] << 16 | e[s + 1] << 8;
      r += B[o >> 18 & 63] + B[o >> 12 & 63] + B[o >> 6 & 63] + "=";
    }
    return r;
  })((function(e) {
    let r = 0, a = 0, s = 0, i = new Uint8Array(1024), o = 0, p = 0;
    for (; !p; ) {
      p = m(1);
      const w = m(2);
      if (w == 0) y();
      else if (w == 1) l(nt(at), nt(na));
      else {
        if (w != 2) throw new Error("invalid deflate block type");
        l(...u());
      }
    }
    return i.subarray(0, o);
    function g() {
      if (r >= e.length) throw new Error("unexpected end of deflate data");
      return e[r++];
    }
    function m(w) {
      for (; s < w; ) a |= g() << s, s += 8;
      const c = a & (1 << w) - 1;
      return a >>>= w, s -= w, c;
    }
    function y() {
      a = 0, s = 0;
      const w = g() | g() << 8;
      r += 2, f(o + w);
      for (let c = 0; c < w; c++) i[o++] = g();
    }
    function l(w, c) {
      let d = h(w);
      for (; d != 256; ) {
        if (d < 256) f(o + 1), i[o++] = d;
        else {
          const b = d - 257, U = Qr[b] + m(_r[b]), x = h(c), E = $r[x] + m(ta[x]);
          f(o + U);
          const C = o - E;
          for (let z = 0; z < U; z++) i[o++] = i[C + z];
        }
        d = h(w);
      }
    }
    function u() {
      const w = m(5) + 257, c = m(5) + 1, d = m(4) + 4, b = new Uint8Array(19);
      for (let C = 0; C < d; C++) b[ea[C]] = m(3);
      const U = nt(b), x = new Uint8Array(w + c);
      let E = 0;
      for (; E < x.length; ) {
        const C = h(U);
        if (C < 16) x[E++] = C;
        else if (C == 16) {
          const z = x[E - 1];
          let Ot = m(2) + 3;
          for (; Ot--; ) x[E++] = z;
        } else E += C == 17 ? m(3) + 3 : m(7) + 11;
      }
      return [nt(x.subarray(0, w)), nt(x.subarray(w))];
    }
    function h(w) {
      const { lengthCounts: c, symbols: d } = w;
      let b = 0, U = 0, x = 0;
      for (let E = 1; E <= 15; E++) {
        b |= m(1);
        const C = c[E];
        if (b - U < C) return d[x + (b - U)];
        x += C, U = U + C << 1, b <<= 1;
      }
      throw new Error("invalid huffman code");
    }
    function f(w) {
      if (i.length < w) {
        let c = 2 * i.length;
        for (; c < w; ) c *= 2;
        const d = new Uint8Array(c);
        d.set(i.subarray(0, o)), i = d;
      }
    }
  })((function(e) {
    const r = (e = String(e).replace(/[^A-Za-z0-9+/=]/g, "")).length, a = [];
    for (let s = 0; s < r; s += 4) {
      const i = B.indexOf(e[s]) << 18 | B.indexOf(e[s + 1]) << 12 | (63 & B.indexOf(e[s + 2])) << 6 | 63 & B.indexOf(e[s + 3]);
      a.push(i >> 16 & 255), e[s + 2] !== "=" && a.push(i >> 8 & 255), e[s + 3] !== "=" && a.push(255 & i);
    }
    return new Uint8Array(a);
  })("zb19kF3HdSfW3bfvx3v3vXl3gAEwwIDAuRcQNZQ4AClRA4qkpWmIg+EQhKh19Ier4ioSAkcS7gMBvvdGIOWlOUPxw5BNaRGHUdEOa43YSqRykRUmy93IDncFr+m1dq3d0BttLROpUqpYZWsTpYrKslysFEOGv3P6vo/5AEAStsMp8N17++v06dOnT58+57Q63rtfK6X0fzp2r1lZUffqFb2CJ71yb7DCP3pF8aO6V+mVe+2KPKp7oxX+T6/cG6/0H63/1Y/olXtD/zX49LFEW6W1jSJtdM3UNf4zxtSM1irQQVAP0yAIlDKN0NjY2liFYRhqYwNjjTEqaupQaaViZZPAhvoBXa+HkdZfMV8xUaJXtHvhO2Ea/5ml6P6l+890v2xU4+Tpz586vrz08XtOLz2okvH+68nTJ5fv6R5/UNWaI99UmvXfH+ieObHU66nGoJal0/ep1vb+66njveV7Tpw53fvS/Uv3qSz1CdJYVUrqHc+GX7npLeMjn77wKycfUFtb1bd+6/1aufFt1dvatu9bGm67euO2J7LhV2572/jIJ257e6v6VrW9o18r2t5pP99dWlJmW/VxDQjR/cdPnTpzQunG8aXePV+8//gJBmau2X9laFzWf6/auWNQAg0tppzz5PFTJ39lSamd99xz8vR9J7tLJ5bv+fyXTp9YPnnm9D3Lxz93akmrnfcs3d870T35wPLS6Xt6y8dPtO/pLvWWz3SXVLR7XdIXlpbvOfGlbnfp9LKKi3vuOfHQ8XtOnj7RXbp/6fTyPUsPnVh6gCvvLn3+xJkvnV5Wd9ZaWjmd1tTU7ubk0UO3fKL+0rPBMaPS735Qpyv7lMvaRX2/MnPr/0i51/UxO+ce3zZtVBG4jJRLS/dG0MHD4lQRueBsoc4W2gUdixLarfSc7pAqC+OC5UK757aVhSI9bV7cVuhpkxThEa6RAvcImQc7s0Y1dEohqVnTIEXhrElS0i4pc0WauBbjgu6ssXgtC43KrNP40khTitxTDF5yrKlJAwpnSKGQItPukia13PkiQFwuFINjSDE4ai04+sFOEfQBMgDIeIAURR4IRVFZWOL6NEXtIhRYSJEukVtRYucocQ910Fqu3TOALzdmhQKnKXHB2eUi7sz7dinuooxGo0BQmgfo6KxJKKhg0PITCCiMG/fMNrKzRrmntnGjjTR15xgR6XxTU/pFZ5anzYs7CgNsPdShqJ1bMrkOeJymTVaoectPE4Wab+oUWPE5C03Atl0s9FSOnhnSU7khlQPMlMy0mcxrZPDQKNSCncNTUuhqFPWsSRp1zjhRaLtCxk2UIV6zQs83AzIuK9M8DOYozGPShXITZR4ChIlCNxUpl/n3DO8pxU6hl7XUreQRKffdlaOcLS0L7R7q5JHvfTzfVG5vnjglPVbu9bffjo/ZOYrctaCrs18oVPssE6nTy233iTJPUk/wSYU0jdFROSgBPxS5nZQ4fbbtFCVu78LUcm4qRFY4C8je3VSk85CCwjaVU7klnatGAPJhPAfEY+uuOetsp+S+HZkiRcFUrsg4vZwbQm9RIOwKDKEzlIB0Fal2l+IORisgVQ1wrlLi8QvmhkfQkF3MNRkMpIxhiIcKpXaFtKA7LRS3GM43FVmZTBS10ZUQw5xQiAc/zOH6YU5SfJVhDnmYw/4whzzMJpgjA7KWYTZrhtkMDXMgwxwP5nUIDiRTSJk5Cpk8XXa3nZOpaEj3J2BYAiQ1mK2YVIrC/tQNR/mHU7lxKtcpZhFKYlYZroEnWaMGOM4zHGbRzrnz28gwAMj77Db3LCcJHCg2DEyfYVRVeUo6WBbWrLgfTU4bZefcT/ALOvvp5OGVQ0a5H08eXr2wurq6avH2o0mqu0bpHui4V3//3/1+2EPLr00ymtxF/7tKaaHLInCKdLuIO2BMx5qJe2mSMWjn3Iv8lJAuixolxyik2mK3WUvNnLs4OaOUs2BIFef3/ULBlydzJZSF4hgMCilhSisXmwFzjURIyKksLIxbOdIMSOeB+zG3qZxuFyGZDpgNmTZYasnE3CnzIKUAoAYeVNUHNaSgLGIKj5GieLHbtCkFWVgoMgtN3QhRzrQxG/CVKUgJUEeamgxPCkCiKXI3lBQAbpWbhk0F4ZgfFLRLXiQ6hclCyW0oKPOAswYpGbey0DQp8HwRpZwFr05J+45yj9FOFzzyWLcZ4hesIHLT5bFmmLoXJ6VD6A6P1Xf4TYGavjOJiaTSPsLtAOHSJUy1aWOLsDzSNANUoxtPC+kBk2SOTYFZPC3Ey4TmvjeJ9UK5lyf5o/vmNreC329vE9LD8ytCPxhfWc5kvQ5nzYvbSGNd+c42sMmyUI4WmirFBAjcdLtQ7iEybQdSayM/ZoNfn3k1o8GqaEo3jbl2YZv7mW+4YVNwpmNYY452pWcNl3TwRAGFJfI/u42se4gst6KkYnd+m0xHoNOQajNOscb75gzZDZoLGCWNSH4q5JE5OoQ0GfqQ8W/msDD5EQDb85jXDQPePKMA7HwzSP1omblqtCwIDWsn02IRLvqFNeG1ZBP8xRvgL74U/shS6D5IISoo3cF2ASKwLisXpwrtplhWct+fvM6oQyYj7V6Wx8R9f5JFK7S3lj48LZB2k6VMeRdX7IuUs5DHwkXwaE32CBY6YaSPdJCLxYV2YTzULMAog3X/bYiQZCpxSJkVL09qx+Ld2eXCVMKQJsPCEEtgioUhjZ5BGNL4abhGblwCdrmXl8y3/eJu3LVkNlzcVUoW02w32cOMDuXMsntxR5lrZnUiNoQOcmIRMCTnIJaFIpaxkAVwjNuJSlkEUCIC8KquRIopKknA8Ex115zFWoslXWaD7ZRFgGUu5GUO1WaATM+aSZfkhmyhc+UalRhYcLcbAkAiXUh4Yk/mxjVSsn6tA8ULG/ELlQJDxUzBGvSeliqbutVt7gYUVJX8IqsikzUFJU+1ioTLIunXoN1DpOVjQBElZWHbeVwxOAogbT/rJdf+XI6FNaKTXq7XqSz5UmAg6nrxZF0BEIlgAfgLwDKVCzpOH8HkhXxYw9dGbnhbIzQZiCxjZAcgVOkeASs8K/sSkwohexE88XVP5pEBgw4WqkpUlUtJLsPfJwplIfNDJApE4G5qClgk0sEcS4qqgGScaxGJVFOxZAzBjQuAVkLn+wVpJaVovqmk/t0FSBmE9+IORhRp0LUMlWlqd26bUDc6VfUIRSmaNhnyR8iboVv8NJGS4Z2AoWjWTHqg7Zx0LBMqmEx93yAvcsJEPyGmWpnHFFCNid3mTOqqzyMqpmYpLglcj2I/FvHG/CF+t/xBJkpDJpbnEwateD4Ru2sp3pBPGMxGM8QnTMUn1BCfYKa1XIQVn9CeT6g+n4jdTojyzCeM3yrw6iBjXlQyegw+ga0ABltEfzBf8ImwLw6HfT6hMCC26qP11KiEhK2I48IpnM86hIeUEpnZPP6JUFAICtKgIMMUhJ0wGaYgnlyKKYhivzGO+/QTUuLpJ2G6ACD8NOF3IqQoAQzSDxbUNeiH9w2T1XYB9MMJE1WCmSPrWiJiWjAqNSy4C/PpMwjsBHxyiLwB+TQw15KHg6ynLrsxddkroq5AqCsAOgPBajBEXdyKpy7rriW72SoUyCoUbLQKYWaw0qKiK1OpBXiRlgYnAZfddBkS8qq2+7a/DOlqGTKevOLBphq1Z6JnwLyuOhl48jLC3IKB+kE2aJOVaoL7hA2gkBdzvpqQl+mTV8jkBTZL4TrySoW8+sRlqOaJq9Ynrtoa4qoBArMJcZnLEpdZS1xmPXGZPnEZ5A37xGWxybTrtDzKb1G1WRnoeChYq+UZIq3A759lbBvkN9VatDxY80Kv3rEinjKKU6q7rNyvSKX/W6qTFSxn3FeXYNuhnG0LdT8EmTkPWSenOxDXnOnw+gP2rSB2BiIGLzY1665yrwSsVl6/ujWgk6ikOFnu7ELTDK+Yur9ihtUCObI8ji6i1i8genRxZH2BLI42mCPLaiFeHK0f02pxtH7sh9RCATMVy4pIFyw0A+CNySwk7ZefoC8ssLJRtTzDB2DMT80GKywTsB2ssHbTFVa/5xVWM2Y9EQ+tsFpWWE/E1RQNvWYGndUdBtVrr3iEbSVqhV7UCkZELeUlpwEyAhnvhSYULqJOeEZ+W14Iw77fi2HBiBi2vjLsyyrkggZJ8bZhlIpYh2TXyV0jVDQ6MjYVXRTIKhxSQw2TVbCpGsp4NdS7JyuTbkg//V7KxnJAMuEakgmvnGTCKyWZcBOSCTcnmXVwU0DJQlNVk6SV9mVi1Vdb91dKi6WJGZqq2Jkiu1Zp7ZeqhFS1iOjBAtESMUz1F0rlrgXLOvuFQstCqYfEsEDEsGCNGGbNipkzK6OCWDwQxITDWqHRSb9NJLWROGbBqpkc+ts21RfHbF8TS3awXtrBeonKSefWcbeDoo+FwkrfBRNuMlfY2TmV5jFrF2Td8JjhwYi9ZuabTBEaeoEVUlNg+OlTqY5XhDOHxqsYLHbYHaZY4eZKdFnayxHIBQWUX4686qKRB/2NeCAy41oWboYnn5K55tcAzm+qUTV+PvJ+xdoVUjzXWINrWTE9pPKNyRaBqHyZo9mmYhYv7xVSR1m4GWbhWli48VNQ9fesIScxC/eADVh40J+PCvPRDOajGsxHEatG56MZmo9qaD4G/fkY8HwMeD4GMh+554Yxi3krctKkR5DBfOSEiSqhz659bzfi2WqEZ2uvFBr0Xr0bnq1GePYGleHcymMTahomJuHZA7LxPDtYw7PNKM8eHooBzw6GePYoHVU8247ybDvg2e+ejphnryeYfi+FZwejPNtsyLMvRyPhldJIuAmNhJvQyEZwY1PlebauFlgZG13xbNPn2Tho1Myz9WB3EzCDNJVgn/LxkJLdjT/QMYNzHebZARrxPFv3z8+M8GxT8WxWEAXg2Up4dlDxbDO0dcY6EgxxbOs5tvH7AV6umJW6nTgpZZYdCMsOALESasA4McvWYNkBWDZ+NHKBd/dZthGW7VUX1iPW91SWJawE/fMs0bGRkh2OqnbVvIFOb9Cahe1CZ7rwIrdt4+QkgBBGvBPB+cubKZ/fpYtYQX824ZX4Li4hkhuWssmw1l6z1p7UJ5XLlo819UDrttJK3c8mBC86jRSp/Sq1ap9Kc61X3Msqs6xbUs7Mmv1YnWcNkQqdStNxRTjYdY/wqv5AVk//y0BHK+5XsIq4byQA+UYQ0iNQP0lHlGdkVAT8Ydrs97/TTrsfHaJgPFCFQbUPt7w2cDd6MWtursbPOC0fX3xLzRoLXGXXiHRK2qk7RGJxDxwpolnz6iE5qtIucy2Kpo7msehYFdKwTz3rwjLHAR1IsNWBZMOkkWC7ovOAYpGJglkzLWJiQxqUSm4iA1K8fvgbSU8TodIJsrx5tE53Zs0NqRS4TbLuf+cNR3APsARy+MW31CFsBQ8/Kt++fwhn3+7FOgvAD7xTZnXVutVVQ9EU702Bks/Kz2ccy1fTDCYwO648ynenFPLgZrV0CxME+sO6fZuNpX9wh8lXzCP7lKN2MbYfAzZZYZVX9aLmB0kV0bws1NYfN+xmPUARuO++pUStc5FHBT+YrtqF7XwvGfcjVeZExr0elvk2Mu5VVeZTZNxrqsx3SRfz7UhXZT6OSTgHWWba3CYnybbYnSeyBDbzLcPGIzgUcb+a240MS/4m/igA4bXH9oZRnNQOHLzhxnraaI61svHATGzThdo/tct+/JZbb2Pmd1eeNor+0xQ/ncobjUyeihZ+7uXz+tbiVJ42xjihkdvGjDwVwfwQXhsHcPwei34hmW9+BNYC7TyhaEYpipcphDVD5HSZR9A/lkzvOO42nXkK3e98wyx058WMYloqbs2aaaxUWMwU/rI9BfPYMeS+VWNDMuZs6Uy2hxfqf8yQyJTY7VQeNw4wqPtxrEgWp383sKZm2a2+FXTwdLZ0ex+YB/PsdJiC3O/VmX7dn1fdotC1Oi5hQdD9PF2fas8WASZoHb2yVHfxMe5FkdoVSkOZm9NkU7J3d5pbKXY4EYAIM1IZBXnYmBnF4o1XiEU20pmg0L2tNwN1BqCuXoSZEin3vyZrExlPAa/QwAvzBMVrvFu1zOANTv3kccwltyhLY5z1FhWKIczu/nDw1Dbun8iUgwmHymPp2l7ftRuutGtDcM0ayxqyGbWNpf9RmDh9BBLbh+R/2ACSCskH3wMkLjkrUhyjHOvjpeACrW6Moe+MwiUb8sCtJhimkHdoFaCsbBuB04LcRuE0qCchm4eNG3kZZuK7XWCv2zmq431CplUgI7tvAO0+GiO7MbSNfRUGkI2VoFlj3+iYzlw5ubrJZVDWW0HHJctdITk/KSfPdrsy0VmmuoGM+2fr0ZTxdKWmyDY1kVQSf5onUlU8y+rUcNbc5kw+2bgx7XOSvWsa+C43kNJeZxabHxLxsJkA5m5epygPKPGDYVjNPd+EIlrDvioY7muAvgZUH+ook4f7o7dUngwx69Dps3w+1x4LlDZBKgrjVw8VdUjikXttoizSacMmapF7c7KE+IdjxtflMZLzsCiYc+c1J5zng/px4Hu5dMmtWnnUA5Rgzq2aPKLErRrJlnC2GrIlyJb4bM8Yru0ZM1xbvLY2StyFkYqS0YpojOpudfyUO7+zhLyzm9AvAC+jM+ZqQIumcXfB0JjbXYKplLSN6hntAhFzGzTcRLimCa7xzcmSxrDeJ1ItrBWdeadaWlcrpbxB8oqkz5A5/NXV1dVX1CHzS2RAO58l4/5UmLF20UIzwPEbeHXoApxmB3lENk8aM6l7GeMp6pXnwGjBSfMklXpsuknBD6R8zpdj+x67uHOWj86tn0BrZrgdnT+Wl5fBDI8bH+YZHrq33w46BVjRSs9lZ4X7/2ltZG1B9g+A/P/50Bp5ezWhpLeqMY0cf+yngpk2t3t2BxV9sjhVBNSkgJp4mm9+kGrY62W5MIvbKWiD0+DoM68hYztH7giwJ3hLmIX4qdYohHU0Peu49l2wjr2dd7Z3j5py1tzH7+FZfLJOl7Pmi/ylfhZrti2LdNbcS7Ebk7EYO8vnAYG75pj1042s27PYZaHR/d4Izlg8cn9ScZ6WyMWnUjZ2SakFRcBWSil1W49NiS6NUtahUQqDoWDWnKJxPC8f1OcbTMEKFBzkaUOlvF/flLskV8ZdWmgokoZaQw1R6OIO2holwyhv9UlRKtguUvp2keHjWZ4J21lmzxtO0bjbSrtoirYJtjIqdjB5/dGo/JADVf/Ckxajyal8B9PQfUWGny+WeSuYowa1YPe1gk+/tOxWevlWPH4mn6Aor1OCbQ2jYoJC2tpxZrksds4oXaRkj4IWgZoAqAmoPjxJ6kBNvZokOgU/3XlQmyKpjrwaQ7gSJDHLspQyhigVDMH+xKywplUMYrP2mFHaYKBNCX6Lw7NFgYWuDJaRRiw1RNL86ugUrUNR5NfuD4I4DIpYZwCXZZ1gmScMOo2XzrQPatYZpvg+CtbedwGWJxBKz7IxO0+6GG2BuaUuXlv3nndTdzxUdyx1v606Li1T2CeneUQtSqhRLl4CISJkJLwOyLhFGDcMZ97wXMNTcwPzs1+Ovx3Ur1tB91ujs5tAsrUBwftZgBWJsg1p/r9O1lcQzZpfFv73wKz5LNYdpnkGE1RPu4jWVfQfN6joTys+s8MzYxhPN65F0vcGDPnVQ8VWSlxrsUtN97hZ7DajK5eBqEbNssjcY6ad78QLbWmXec5GSuCQ10DzjpW0MZibjWlzE28CG9Pm+mIPfm4oCtqzOAWTbf78y3kLP5/N6/j5TN7EzxzI/GPmtnwf3m7m1dy6m7sgAbY6aJs5alJ0HWjo+Sdp3+PFvm9VEz6eUUrEXzn7jmeUuUVBDR6DFbBVe5P2UfT8ufWlaqCL2nBBTTXM3Br0bZuXz2Mhdp71DbNCyqww4XOZEGX2Ufj8uXwfvqginOcT+go23yx0vi6D8B4f1CaXzWMRs0lkzHV8y61QDOx2KC3zlN6pDpWm1Mpjqos8QOFwPu5dCCikBilAIaCIuTGzgl1Cp5jw1pd5TJGYStzcxfMAy/m+Cv8uLjH/xig8qI00N8HNsfXrboppQlqb4NZqlLdhjbzIXi4hxXgrjjUVxvf7h+Bz8Jf1RiRnv/HdbBoTUNwu81CsY/bg7Khd8BeKKb2bt0YpKkqhkqqhUsqyAoZqeUxJHkJ3mS4ymn2aL4H8feEu25fXIAEmecyCYB5SRrW2O3gXvAcobDNO4/lmneuplTNKDUYMdiftPJYFmdvJ9uc1mPTjJRWAYI3Pr5wWpe6H4M8XVacZ7KI6Y5BJKJRqQiSBPJpMBUgSBIf98ZQVHLIQhY46Tb3LfTet5MjUm2BEdA2wVKOdMKJNB1PcD2ERidp4J7r7mCkLzwiuoajtxsqCOUGDLIxsA/CBhoARMBjgCKPqLLac+e5baqF5DQy/Z80rhxrXgAP9G2HIfZlVhNi4sTtl5pFHjT3VE8Ww/eAOXpOybMnywAQ0hIbqy8L5Nt6E/dO3lMfI6kXVmfI7vsZOvzdqFFYcQoCckX3nnisUHhVtoSZbiUybiVKOG8y0IbbnJD7sLOrzYIxHujK9g3bOjHd33hIgJuwctQim+HtEJ98oUCyvY8AkYS/0i4aG+oYO1FktgE11eNndLzc0dYQ1038+oo+iZr6lsSvtC+7NfAsG6H+SlWRHSs35Zo1qLJCDyKvVg5pAULNiUzu8pvmVQ8OiWCaiWGuNKNaikDLhQo1RUcxeoSzQAC/MQIDgWQ2n26yoGkM1ad5yKk8FfRnPjQm3Qik1SgaqwQwR4mCjQ+lZBiMDGC1Ky8V3BweLYbaS9bIZpfIGZQwcRixjTQlk+xKoIUstkV9ayN4AzKJnNu5fC8LH4B1DHf703Ur8lYnDSReVqNu+O6qLgy7V/csq/17Xoq1TFHXACO+qxJeUUhwCDg0F2+Rb4YjBPJ/8XEmnmcRfOUSpdMpv1kLg2PP7Fvo9KgdXMpTdYF5PbvBtxwbftsseMudT1X9V7Ttbs+YHh1Ihu1+WEcbjZzcku0ZnMN7vegcgI9swczzSRSYuU4wMOWxpUYPpbSvTWyb0ljGStzLNV/TWWENvyXuit2oY8pjnQZ7JvGhQK+dhiqshGh2KrE9FP0w3lI/Hgd8/q/CbQRBgQmJ5+I4BPQ2hl1I7SkzR+yCmO4aJCS2Owo89TT2PAOT3vSTbbLLuqtkY96z9jsJ61nyU5Qt4JhVsjnTDMWGbLGIQhIyRmdRKDVMShFS7KMN7M/53va+jXfrT3ptxsNQuUzkjhW6jTpbqi1MFhEELrUZep6Zr3QUtqWMFbI2C65Q6xMJCAmEhwE8AzZP16dNKzXK6lXTr041PP6jUrZxuJN34dBiuGWQYkUZwdl+jgOrZB0SGFSVMpXZhAL1cY3m0RO/gq1on24gOQYQS61pH0eG7eWWrgwe3OqxPGNJKosBYorQ11trAApia0+0blTr86FceP3f+wsVV/Uix75CCvLYPiKljibRe6yOwRJLWz2Jdhiw1mCvUBBjIbQU+mfZBpbJraey6IGEpc+y6IBsq67VJAdWPNGF6OijhG0b+fJ+U3x/MDZreL8OWCR6yNptIgJ/127btaaWyD15R2wENl3hvbQeCzqR9nVIjOBxuyFSV+4z5vuGK921YMRONhaRSz4MAArg9xuPNQ51yLVTDQzLSKpOQlcYtzAdkjte4NgoqGvTvTJOeA4Am66zua1Jd9Hz1hWajL240GhusB2MbfGtu8K0x2MInKSs766yziuHhLep/9weDPfFEUffnJQyYJfgKsbaSWQmfWaRgHikOaRv+aRL8fBpn4O3CgsdYapQEfQS6Lhb0raNT0G5Om4m8ziLcBidh/qAEilB/plMpQws+eBHNp9eDpmSbQKH7wyFV2e39oyN0gn2mk/lmIkoXTGjMUH+Agxbr2KK3vDR5e5HiA93NoKSsAr2dJRgKblHiToyxBcUni1NNtfk5Vb8n1amZrXS3lnsw39TwBq7OgJScAfEp1v+4YXeyoe7El+rO/rXdmf5b6k6yrjv70Z2XhonLYtB5tRycGMZXtt8Q2CqAQiijdotQ//ioPBikI0db/pQR5iQ3gBJdTY5jr0/XnoSvOb/iPf98k0WNiflmOLJJCq9wk2QZXk1cC8ElWLk/HFl1GUibB7yF9YCL4WGS0g6cUQDQVySv0zmMJa9USeUXIqzgTcU7sSa7gtkiQo1HYfvi7EITp1H/mt+9uUcwbW4W6TzwZjuwjJtedlnp2EqUYMETwV4nmm8atjC/vki4AOxebuDYFFwEG+frMXosktQpuZsN3GqUtCnJcqGUm8SP4PpZc4O3eoMUEpdUo3qbEug1IqpTRPXFIpkqoixnHSbARBY4JkZtwmc2kVtTHb/cBMcLxHFIBNj6whRnhA4uofrdbDUH9sl2DbBByZtsk5JzvA6YrdJuStqlWCVzb6J1e9+I974VoQ42vzCwQQSJQPa/dTIiak3wKXJAUbYHkMrj3lQO+XhIb2ADqWl41sMgDGepU6Vb1fIMx0QY5eATlALsxvPP8QHHVpwwC/HN/X2yU+LXy0BNga3T7iNTIIAjU/mkkNm/9WT2cD6JtZ3gGjKZ/nZNN1bEDAwGS2J/dHM+hp/bCJEMzAqN8V4u02J4NXc3Mlden3wK4GB8nZbs1IpwLzlLD+2ihl60oANpmjlqOfZyodStGthmpc6WxOdaNezQoQdnj3unl4/Bl17Jgt0seW+SSlZkKxKXoYIaOJ7Tna4zbAFZoxSRABLvj9OAyq3yxokpyTARvf1s4wjHaMBjsyyalB5j0XCD+hJp0jskwlm2csJOvLPlM4Man6pqTChdbMKFNJHCvKXasP5m39cxgTNkIt6OCTznvMu0yBYoSElVlPPGFA8HqIixVWB/oKb3B4q9pyHwUCTOdJqaHZEA4TgghBI/bedbkKOR1/kcR0xFGzB3jKm+xow3GXZ5jakOLlVHO4lvZ5L1F3VqLAxVMpLL8PeJIrYr1GBT3gYEjhi8tMGmvM1gjpp5QnFRhylvE92cKGIsghDpmlj6MrzDW3Hg8lpPKRNL3Qafc8M+IGZLXYwNxWypWwd266OWusmQpW6DMm+pmyEvW+ry00QK1RRP5AxMXoDmOR6DZXM3J1PfN16xkTDRT9giy6IfyfEBEYyPjqQM94aUuMVT9roylNCWDHIzVsY4ZbiwVDFiMHXZAnCXe9g9BFsV9vyKXdCZYg0l6sJxbHx0ikvWaIziN+uQI8YyQ7W0GPMM4t7KpvM2UjQ2a25OCcbKYzBIlAJsDJtVvh2c1wqPvVmUsCFF43B/41hBYMLtWd7Igi232YQYPh6Ty930Po3TBbviHkHu7BrPbHfDE+NmNpJeaysJ/qu9CaVeY0LJ0VsYjsyQygzp0D2Sppk3gvWml3NrrGJbWX3Nl866L3uzeloXO/lWdlf12Bk87s3uWmu2GWZj6X/4gG6Ko8ojpLJZmFoe7TbVrsqFo+GNNneLW7BFlBU24vQGrvaILBPW/Xa44I/mf47DO4ELpj8iE0xjbYJ18nR/A+vXJ5XdzBllU2ArkWRl1kxXLk32SJd9btyDjr2Oj06VbEPN74Gzd06Vd3abMOu/hMmldR9aYNPC3w4XxBcFlkGNLRIgSlSFP2fJTEJBrWrXWHarr+k2S03WG/1op+8UAfgHugicuaOp3EVIzoGLFpsKS+dF+M1HR6ZyCRxCYbcIHHWJV+eX9FQRuL0PUNB1e3vZJ+WbuK0f1B/BBzzckH0SuPTKdxEcGTrGF1DnZS00Yt3HwSO9uOntz724WZmpaZYjOCkp3V5WOG+c9hv6EonJLarvLytGpRvnU5eo428qzRlxi+OBqS28s2pYZ0WQ4WGbgk7nDj8sG9VC9hItBKKjHx0Epm6h1RaLqftz9hDdnbOQCbU/xMGcpcKM5wBXXpPKGeKabzx2asFBxEqmugx3MNV1HBpsqusyHI9NdRmGabObZfqqstBDGvqKgivLxeagkvGgjq6guhkVXz7X+0U+g924Amg4QAm8crHnvxJcTFwZLkIK0mlzPVssqmlMIcjmKIbN6Q1saDTYQhNHXpJ5yEzmT1R7LDS1Wi1gRd4PFSuk3F+phSar6IVamNcPejFHwUE9wTJ+G36jAFbOEMR6mzfEd8uMT6DukB7xIRCVrB4q+tZdjYINjCXL9fNgQKJIHO6PLRG2oF11afhorU/b4irUziN/jtdny410E0CiCoYJDnIwAgY0XRuBEQyBwRjlA5f+3nX3tNktS8NEHgtCdnsUidaZBavI9zRe30Rc8nm+b6LPPUNfkxdacXgCHYRgwhMIUShaELBxTzJ9sEEvgddq+D7KuoDIefGxploLRTCAYtDRH6rKUJrr2F/V8Tff1/3voa/vpad/NTyU18tQNip9jRFzogpQK9Chss0B6adecipXa2cFxlq+HVTEHPfJOuo/hf0ngYY9Vcy0eRn+1+ykzefvvx0eaepK5lipuJ+sijo71KjSPBM0lXWacT+Bn2zQT+R6TXbrcBuRUMnjB0SJoqXDz4G9qk9bbu2cpqCEH5UIERS0nc78mv+SnjXPMcNQ2c0ucPwRctaU9E7Nmhe0r4Sz90ffTJvXZryJ5mszcgLz05nh5fc9JMvQhexsh/AnwUFEei1hHWak1063Z83LuoKeFYez6BXXiP+/PnM5NOAcyakNUVB1n+PxpVIpq9+uBKuXrnK+GQhOX90KMzcZXbY9FdNE6V8RuccMn2oOcP+SFrspDL2eH8q32GnGFK3PTJEzR5t+3FiTN0wlRyp57GpQSdxHUu3qICn2KmkATkPmIRxgqcApF45+Ez7WhNKQn3T/ySzw5vsrpsybzgwfhYkHF841xPaKEgn3E3IhI09w0pYnu9C08hQuQNOKp2ihGclTvACVMVRlOHsKy6LG4OAY+f/RixTmASujYTnEp4ARnnBgCBIIYd/pLctwyMg+w/AN5NPC0EXe3C2E+Rof0NSo2UafOABZQBHOQqoBf20GgSVdsNjUu8Q9QeYUzyjEpdTDU66fHG44I9clo+Z2Iawd5hIz6sJ5RIOgtHSPJ2vmaMNd+E0NZ8z1s3favKDZpcsTqlAxW5i/LJtNYS8ym5liAZAc7sbMdTALg9HeBWvA7ycHG/ZuXTKFSOaxeZf8Jh1lOOp9Mxw59UOEhsA1Trk3tsInZNyotAjcIx1nxOXxt9ljigL3qx0+cec9cTPaNSwwBk4v9Bcc7IjbY6FCWHfN1rPnDsj8fepAESx3Oe5b4MY+zUwhulWfO7CZ5B1tvu2BsvmrB7xsjIpds51bZ1xGQfsse5iAkEq/1501Tx1wv/uUPqhlLYncBX5BTKLlbuGhYG1t0CZ7x2ADWS31dgOY1qYNYIIFp4csbJ/l2hGR02Vt0czbMgVIZLKD3mWXhYIZ+JsviBDzLGsWOA7qO409rYuwsv3nEFCKAjhJC30/e2CwWnu2y78YdPyCeip9BudhGUI0JbATZtqYBCXdBXNElmRAFqa/sK0fAN2XeTbPUsk8B/VH8stUNKM+ml+2reT9ZRmAU788OOmls/BhVYvnj8vOjqpHZJJNIq7sndY7qrf7cbXmU1aN/YTVUX8/3a31ypDKLNs1pIhL/5nWwQo0YFD1hX0VH7bPHCvlEpo+zURz6QznL5fhnH73ysRfZeXXz9WRqRSO2TozaY31e6cync5zbC/EWfFu89OG1njL75ZgDqwrUn4yWPeDt1Tb3bvIcKXP1ky8Ej9C2qsnzZx7+jHEb0PIzsd4QTj/mOZ1yGkcIUuqBBmdB+eD9ScfLIdwlYQXGluXs98rwiYUNXfhyf/9/3qkB6MYpzswVMd09xtOsG8oss7fKuttyOeYHG86D9yFx7Q846xBi32NoyPcRno4+UU7d/hVQ+nh4Mlfzeuc86E8cBJMp/4Ztq05rB/jB+v2djhG+YXHNAXZNCx/BA7kOcc2oyml33L15YJjXJ7/1Du85/wfI2xZv2lx14MHCMyILSxHg2xaYvv1u5Qe1g+zDWUKbOHgWEkJHCRm01j+AcOgBAeH7slRvDu42OSAy/OkXdyZFzdsnBUbwnBQ0GNzTfTk/K28GepxUAKESRk6AwZvmj5d1AC4tyVix2t9XUAUPf9E0fzWoJ5P5RESJkk9/0QxNpKgkJBR/PwTRWskIUbCOwLV808U2UhCiARFwfNPFOlIQnBY53UMzOHk78G0BqhmBPPxV/1w8GTROFeVKDnue49tBMZozXfVyyEzttZ+j3uwVads7fewl0MMTNd+D4C6OoarLqZQDDn6lY9xv/MW4yXPGG852Pw0wtHU3C+dIsMBX55/IrvueVjuP/8EP7WAK37KgE5+SoHxJ7Lr8oCDuHId3GCAkMTJooVzA9jDZUfYk4L31l/phZsWKRDQCqma1HDqIMFslhBslmA3Swg3S4g2S4jXJHAPE+lh4nuY/tOQmTb7VOYcy8nHwzrClgXoOgIn/vztoA0NhXvt7eAoTqktbmHIcOnG6uptJa8snESqi0A1fAEEzsk81v30qioMxJd7MKXIookHXLYMdozGEBqQa+y2wP5+aDguwgsfxu5Pc7jqACufr0xe4IXoH83gMRg82sFjOHiMBo/x4DEZPNYGj/XBYzp4bAwem4PHscFjC498OUXG8fE4RH5TVf3mow9+wBi98GEZpBc+XNGhsStMx9mAjq8Qo/2aw8FocuRkptuyUP7RDB6DwaMdPIaDx2jwGA8ek8FjbfBYHzymg8fG4LE5eBwbPFb40j42MkwqGRXQLMMUcLkbOp2m/7Kmt+NOmzk2LvCb2Njh4FdUv8SrZMNRSVrcqnkTs8znroP9zJCXNYeKi10Lx+hgpVXxui8Mvgrcy2oWwZRYAmwiZLrcJHHRzEL23fCz0/kYNrcxzpVhj5vHTrMpaY1P6akuG11us1a1qSuDWbC0UBLjgYttjEQxZ4rhpEW1o1P5mNNct3iWZwvibr2cp763XAFJS2gE9g3q003dsKgGXquI2jGP3i50m2LvRA00aFCzWIitQfQAx3wC3RAgPa5hfMHYDuUzO6SmQ7h3E/k4hcXWfKIKbTdmjEKYpJZbbVI0lU+4i2PuYgOPW92jJh/Hyfhq5lbHfGrLXWxKqsrHYYyFwCP6iPufI/eDiKKpYtJpGlsuWoudJqajOeL+3LpXLJJ2knxtYXh3ydnTFhpjna9xK1BHOU3Rcr49wGmvonEKaVvV36bT5dGm2kVNGl9kxUzT/ZjNNrbiU9vp5SJCzrxJEU1g057msVuhGmXtYsdyPkVbYM/OJvj5btrOA7ebEpoq2QiiLCJq3qoNRbQDXn4RxRD/E9zSwPTRXpZRKSKnz3IEwqgDHjMgpT7Rt4sqwkGbTIeiko/IcoPuIC5QzAuC+ASxObAe6qr/EeXLrg6MZI7A2OBYt8lOZXA8qx+doozGKJsqMhzHbKHt3K8tABUdjpdhH8I2JjFlZZEeZasghjX1LbSL1Kk7m5riPBoaS4wBtcqiRZNHOzyG1KKdRzvdZixTLiXBV0xjQFQsG+GYtsA2yZwFDpOcNQpoKW9W8weTC9MrlmnC1FsWQquDecK+Oge1Ail77gzTOfZ7wzYK1SsZIhxrix0nA0Yt5OGQDBZmF0pMIONW6lbSDytUFMwJA1Sif9d8KdZALuEQZ2n6n2tctRCQaov9vhH7fQhWYr/vF3rlQwgbsd9H3Gix39dQrWl/y0PKwSUl3dvva6jjkG44nYN9wUpy1xro2I5Ek8k+kKb3m2BFPyI3H6kCRt2BhGlqHZV4d9NGwYbPwkAbfrzWG2grig5VigpfOmxLLGwtdmR8SRcHBZdbNUil37Em6AfLCnCfGew2jgIYOanjqJu7fahrRp53ABiKUCX6n2EHAO7WWgeAaARK2+bI7UAg7yKaEWniLNpn4dXKr10i9YoiFPj05vwBJGCOuOmN8H31Ui9agQMADDeqEr5h5MfBOMpjtvebjmXc++slkwrHXq7arsz5r6TtQIxGfIn31nYg6BQHgGiThkxVufYOANFwxdGGFRsOPwiH2MBNltk+tpqExUCbg1FnH2ARiNhUpw3izFnDxraSOv2ywTWPPFUkJnefDAMZPezjnD3rA8Iy0RQyXQC3qjYSm5T30HpJb2gzodJCaxbfIMdx3NaS9K3cJDY6LI9vlGWWs9gqy906WPEbcbmSTFV3LfFmCy2S6njjIn22sJV2gMXDzpSwkrPVFie9UZrUPpBWtX37GPY56nBy7ok+C5JufCt9Tmu7IjPP7mfw27yDNwL5EY54oTkI4BRrHJyP5ChxQZXnlRHiVWi5PodXJ1ExswqLVyfM4ezDLCQY1GO8YIuBDEnC9hYRRGxcCACWzLyCFdT9/OlNOliR+5VgiVcEPtav00c5rr70rp3728jeZtO19Pc1W63xMZRh7PxDI1eL4ICK7xDjr3vk4/e3DX/cuuBjH5pKQBvGn9O36p/URAO1ekBiE74xI++vzYSbFdw0If1vDcMKnR7rbhXrcqErDlmbi7XCihJb+TC+fWWwYiUhK/o3SVOVopgjsPrKg0pR7Jpt8bwPvJZYZQeqmgaqSKnJDLWyLq3Sd26W/PbbQU9OWjaBs29/4iMYi+E3L065Nw+fIATRmUi/pX1sT+6LdrUh1GhfrR50/9yBoWY3SGf0iIZa3dVUl6uJbdJkYNA+8woluGNKRDgSlDx/IP1vKkDNSh9YNmp9n8BWEDgPdnIHXwlw2TpRfAC5S9o85mn6Vl3HUJXGg5tEcY4vKmWOV1mfNtdDRR/4OVVzb6++/TsrrPSLJOyVZfUnoiyByrHrYbM8fbYf9Y33CBpL10F9zjRZi/2U/33GNI2jvhIRCwsrBL0CsoYK56tzJA41Km4oESyBI3Y2AVp+ur3MbuSn1/tPP9ElOvGz7dlH+P3Vrfz+RvW+uoNzun+zDaxuC1Ywg14F2AYYOd8J4YbyytaqZyJ6S48E8W/MoMSpsgjdeDnLDGHavDnj6iWuXIWt6RQ/hcdE8/wqzqo5bEqMyCEwf8HpN2zx7VFv1MJHh9kMr4XgDXLr0FMHcov9HWcInOn6gyWzCbNYSxDmigiMT5U8zXpmodczC3fhce0ufE1nH2VChCGqB4cvbuoD4mF7PwD56dNkD2WXkW7LEsjgiM+OFaAw1EUNAQr8jaRvbMfWgxHT8PDQCM7eB1wSzmwYV7w4pW25lMTjgqwLyxSBvJ+SIdIDSGLSVwWS+NKQcDP8ZQBJ5P7ftwVJDFJzgJyrA9JG6CkST0yNtgh5VXPVd1umhfXgsT93NTNFtoyoLkJIsmZS4obIfjWXnwbJlXXAbAj70EQYhrXPD8BzCkO17KaK4xSaYn6DWdRHcfh2PZ+uquxAmv6rmh5fkUuBEn/YxjETJYRt8I6MAXnxlT9Vh8yF69ipMHDqTr4l1n37Oh5A99wOcOWVvN4X1qycAqlpc+E6XENwl5fdNF8od+E6WN3yKU2dJWQH0xJzRxFPyX1zCacWjRICj/K3gPaR9sYMGw+8AfOmOsXw9Y7mq1XozRmKeJNt2rPmzRkWf9gJRwRH6DCqgblwHRqve3jqDI+/7q5qz0i0kpi35iOipIZPh/XiMAuv6i7re8wfRIDnytW0eWEHb5t8t/lmxhd2EGsPs48JON+8jrcPs+abVQnYp8hhVtS/UW84V5XqccbGXf2eWugbElkRudssGON4nkVeGPvwFSn8hK1UtAiJG722FEATEcsPm7IPAetD6/XH9s6mSodhMx42GWDuiSgxn9oB/0k+120IxcV9isvkGrsk9+a8mQRxbyKoNxT2ooTk2Av94IAMhz9Vs6y9FBgEwZW8a9xLVhLQS/eSvWsqH+dl1khHDI3D1TTmI1ApW+Dgs9hSFnBriWnMhybCpgOFsDreVZipogX8GNGfBzm4SQM6p4gjDI7avXB08pDST7NfUcjqJG5LIuLLMj4mthoBtcpTspI3hwkb0Q22AIqSQqQLeRsOJYA9D2+FoGsk2VBFZAo+LzAMThO1j0GSoSaNOd2WnVLIiQYmLFDa3MpqqlR0fRz2z5k78b92Dhd6VD7PfdSVMs/Itpb10IiNUQzQCHxwYH0xBEL4J9yHvlBNwTdmEBKKr85s+x6HpKu5Vm1/ZZMl6hDYhkXZh0Lmwib72FC+9J8YXVshjVAhfK0ok8Dbbwe36shZF5CFxjx2v67xlPi9lzCuFQ7S7jedqedjlo+rQ7nhlS8USo/wrVjas7KKKOwRLAn4FB6F3tSsQFEt8bgCr3+N0M9QJiFbx7CiiReUKlPIyBB6SWVX9tR2fn1qOxdi2bB2TLB3UJ+XxPPbvcrioH5avjy9PUXMwLqLHG5YtEeKYKrqtgucpWDKo4Px9oNE1/ym5rUZlv9Y5Au9yBc0qgvDfzoDLzQ7owxHB+WV7qDyIeV1Ze0l+O9vKkF1UbX5q3aWLuPoAXcMFsm1+7bwEnu6oUUyGt5Y+l0rTrRgg2TEBknkw5At7IoaZnbCUD6ZjIL5eFLUfV3xchfKAFnNBdZ4CNbYwxNXG8grg7XehzVun/X1wwjP20vhsVrTa25325262/obFC98HX5QHphk2qyOF4k34GKezuKHHRaa1oJhr2SfvkZksu2zbCaYDCy6RKiUjxWsirgrchGebhcJJS4+61ZN+c77o2ZxakZd+E2P+ViYgOgQmdwRXGZY3+Ayivpdez8qh/pwP3z9cOToYzsqU2iHGdsWnrAJ/Ckv/ANEgnEZnle3wPPcUynURsGALqT9gf37u6IEuw7R6wEctFhRdR9gCWVapDJjcdFyCrb3lYTVyyGeV3FVSTCgCnHRvvSUs1eGWN2HW/ntGV88nXlp3+/Q0n+U6vqKsFuw5CKeyi2z4XiKzQU88x1lvCscplthC8e3+YRUF6arRVSsVyw3ofiI6PHKwgjT5TsHhenGfGIUeEZmPSODXVRQUZ8VztSgcA2SojaFQ0haO8LDSFqbNoSkRh9JYfusrz8cDG7IgxmKdWR1OoPDqsGOO6h23IhZyQFaIorZWlUCRfpesi40l8vQI+G1tqJSMyeDfqnZdEUUayoeW0qEosgboAYy5HZ4F8y3yGHlEkhgOQVcHNRf314MYBmZRVcBJrMBTMa7Kj91gMJqu2lc69N9rmnWbjUj31i0wVbTVN4wl91qGj8tDGLFGor9qYM06FPYPinm2AkUypoeyJq+Fm2/+XeKtrcqtI39LaKt2d4IZRJoORA5Zy2WvvF3iqW/rrBU/1vEUs0vE6NYQrBaIxGjPXwpi4ExJUcKw2JgAk4MMdBADEymOKq6iIJva52uyNYeQhu29kXY37QWNShFOErwsvexkZOUajto75TrUMl+usl32WND0C1sVT6uFCaJT/TfG9X3psTDbS7wFoP9E3g/P6MkgI3Fdilli5DRGmy/5kXezLETioTok90uLs0i3xV/uaLfXlQfazhef0yL6a65pOku352pK9NdKFAlWssPFe6p2n7MwdhcL7tHL6yazpTcLyi+qdoYw9K9+9ARUvBh63Kco48vNKtb2036Zo1HYdo0XNgumCYehoE8BYtTOW9zOXYNn7MuiLWRKLf5+JzvM/N69g+x5jfmWCmgI3x+SYvk8JwuGpDWcPs6wkQZROLh/SyiQIhS7+6pwhyFerhO8XwHaQvdbocjHSmJBnCE1T2dIspmhg5PnG17+h58CtqDs5rBV4OvK9UBzeC7bg+cCcWjI5WQItL7Bn7PaekHaz1gSHR0ih1xGQ8W9lgN9qrla9DhJwu3mExeJjhlQibgc5rfnmO1d5sHoTp+YPuLBpns47tGP5T+/mv2v23L3djB4KSI7wxM5Tb3gE8L5J5gWxi5N5BHgkmQw0QbhHHkgWY3Nb6ubfWA7yWbgABT6JzPxf4PPMVf0lIJhlz7EYZ/x1E+UQpQdcC+fFwZ5jO0QB5RqwfAfI71FXRoNa0qwe/jB+6WetBgWgFU+nFAeEWyFVgvaZh3GmlMOO7DUkcRtKGdpxDx0EtfFYB/jhnqO2P+9IGjAsSsefoAb3Wt+O/psVArpbTHJvxBYQsXSLHncLXfoPfGBy1GtrubfnCLUHBm7+CewGygDyT8sHnkK+Twrd3mMsh5mAKvBHtJy2Sr0GSkb4EnQo7aARYtYfYEJ3D6xACApDzaggHagmG02XZVnKxH2wbYqlBRRO0irOZ5Y5gHAC2Bn9G2YigBprpYnAWY5H46Rwvd+W7T9LEtN6UKqOc0Rey8DjwdnSoMm7OJg80u8ZuSEdrFnu9pocEX/BwzZYVpzGfokZwJXcAXnLuEzy0pSH9DvEHYRSI76EOVFFqujoPyJVic8re2e1/mjHRFgQ3Spdz0LN9LiUXDR7h6MOFxiCO3a3Llil+Rpvs+Z+/Ak6Xp1zQ7rvANecxjYMRs/CKPac/I3I2wR4Eo8eFKnLP1kjkycBDHYfIeH7LMF3Dc1lD6Xh8QTCop+zrfhF8Qgi/9rYQv+mVTgtgfiEZyg151ePqydk/w5SgKbq3ypTDuSTFuEm8eccCGa6NXHL2ks9vEIQWk4Z40bU+Xpr0oQJLJfgEk+oL2XXhB5yYVB1sX3F31dNQbUIk3oFSlps1F3R46iR/1VFaVX+TQcf6GOQw8J43EAxn2nIzEc9JrMsUQJGaNpNz7g42m10sgmtriFLwqy8qtcqSYErRJNwvTxk5NXl+fkWn/2gwfBgaLMvVe0dXJqWj9X9DBXDW3/akHz222Ruhkt/mJ/4L2GnO4bvb16MNFArILzZANoryLZ8UxTL/WafPMgUpNzKyl4BsPklnzjP/6TdZ/QcOhps239TJi2j/jK+eIP/3F1Huim81Hc+gk5j0ki1QQ+UOKjZBeeYauxx47hipxDA28h+HCCHd6TuMwCX6i0iHrnaTJip+or3OYC6m+Y7phExvTZ+rGmbunhp27qyb0cBO6akKLY/f6Jtix2zcz1fJKG890L1vlpaGGqRaWQrDNP450fUU4e4wJLILiy3IU4BdH3zdbQpvI6Q+XchOGrH4cA6yEvr5dMdSLmq+RuDggvLjtQwNUbD2WBdTKkiXWZ7YvLTzNQD+r5RRCZs/DbO4UiN+n1xBDcwhbYkrunvJ2WF4touDC5083An+2ccVl4eL1LHQvcZmHXk5QfOXpvBcG+lOdCaakMPu4fGPCkyQIMPAp0lLBMwf4kmPWGvr1uy1dQnQKxTchD03zxw/wsYinJTbJ9WwZntaQU1KxpgkWqxXhnBdauOpCs9adg3IOpnSRkJ1ha26e1EW03OtgZJ7R4hMfCjyarTX4nA97oeUeJVU2QSwA1KQ7bKwsA2b5TKh+UPNJW520zM9gXTe4A+YoayCNe8IcbQ5EADmbYsoTmezpA4VhGxSxSXq5YjiFJnPUzrmvsFMK70HcVwy2HvNY7ftBNnlqIKgRuwSD0QnW4MCvyRxjNaFpQ/EpcqAXFeyKXLnsuWN187KAFBK8vqCzfPpAmt7Dq71nmVWT7I017RHG3BOEcSn8yYGbYtMAQZ0cZKc/NKa1Yh5Btu97HnMWL9/zKPqRhluHn6Yitbbdk2D1js+lj/n934+91ImAFXJ2m9c92aQU8tGUBMPQ7aJJQXlQKbl893EtoT3Pa9zThs+ZD4SCLXlaCklqWA6zJHRQKcr4iUmKj1oDf99Po4R57jhLzHja8ot89dSWJ37lWy44i0MYU2Jxse4Nvehj48Pl4CsmLcynmdI1cxZDrDcx4oJnqOnhNTlHAm+RprFO5S2hIWfH7IjAd730Qzek/64+EI6SgXDkxaOV9cLR/JB0tNhBOJL5JiNaoj4MyUZpbqsVG2P/PV0xx1nzokY8DNmwvaBxUzRrolkouHu9QGX7ApXNfsFHmwhceLRvm6XFOTdYaGoXVHsMLzy5Rwky23CDqZAP71lFHAkWB5GJhpdgmXKjQlnBtPaidiu9clQyG4pYsYlktj7Hu5HMkvchmX2PY/+1h0fiZYmsUjLDjqFsELX/6zMynV6bGRXIgv5myx7DwiubI2HZaABswctm36tkMz/CLIh9Z0RAkfUwXgD1VLLTIGaF2jBmxSVkEcPy3rT5zoBtCaeUKC1/N9LZQPoaloXMcBeNdLHaOWzSzWEpdyBHDAl+fSzYUNbvEWRvUKRh+H7P/79hTOhkWKjEHvxdCJXBexEqzeWrvCKhEgylBTuCT/bXxPV6aj1qfL0uGUbLsXLfDjKb/vtIx7D9/7FqF/X9Ck6ClZKVHTRClx1lzU7kNC4Ae/QrHA6ew6Zd+AZ8h7B/rbwSJ5fd3i+5qQ7HK+6AGS33KOwV8lrj23gp6rEpD76HzvpfKVnryI3URdgrOG/o4rNdtpdCqKCz3R6sapf50lR+RnFn+bnn/kL1blEvfIOd5xawpqk8ci98Q7u/ALmwZbKEI0B9RUrR9chd8ME4w6yXe0UNIQoq8DO53Wq5i8jO7H3dxa7zhWc0x9GZfHDWvHBBnjM8f1ueEzy/oIfNnC98Q2JCiPOVvb9A5KNZ85rmeCohm+8lwYooyVf4ki2z7HZDhtIU3jGVY/Q1heISSOkChxI2y4RgABI6mKPbxBSeKWpy63LyYHaYg/YiKIC+6LsJkb0nHjU1ZxfIuN13QN0dZYdhPQ3HF2w1BhEFoPIY8kiFg0PwhpbfVZiy/pES5ehrf/xn//DhWfOMIXX4rT/4P//kP3z9v/it7FBwHu+P/oun//AbP/8//vLMoeCckbIX5HzUZp+CYUB2u5tAZAk2vXI/hVgPImO31ItqgWdRBHMMvkXJR0mCtTf7zsKqYbYHotfy8iPVEyPYAdzvCT5U7y6q7FMOLvuM8qIGY7Namc2PYga+f3X3YwW3pDj9JHgNr7egSDji99/gFq/c5Fl5mVzuQtE2lJwsd7vp7+jK/05dF1wwkCifPxw8+TDDFUGWc5/s8P7HXfT4/zYLgxcV394hF70DUutDQLtzHFMrzI7A+Zys+2R5zK6gXxDKbZkdIevm2hJhQy6Bg0pW1GolaudsPqR0+m915bGXsceewMk2ueHh5O9B4nKrycDsMvuU++kEGCGyHX4jeOzwxeAXRb0ClzaXgA4AY24rk1U3IVYGpmSrgoc7TJE4mXDBsniHiPGn+HmG3+KaSooO30whQpycuw0GNAhXEXpfo4lsQTCFQV3oD3TgsnK/SqfBMhWcvCcxRP0b7lT/hjvFN9yl/0uuP70iDpg3FQFHNRnkDvq5A38bPPJRYZDPDPKZfj4j+WrIl1w+31Z2/Lx8voler+f0g4VB/usLjr5iB/ltP7+V/C3km7h8vjryNS6fr+Hbt8h/c3G5ewOLEPn2FxHyRYN8UT9fJPmaBFtVZS+fc9JDECGYjp5Wk0WMIvGgSNwvEkuRbVixyHIx3H/QwtrCb2M9VDFdJLJE9KtI+lUkUkVKtR4Zzn3b5XPDxFtlRYZ82SBf1s+XSb7ttLVHqYCSoczuYhxlxgdlxvtlxqXMEar3KJAy4/z/nbBkRf/4jYPo9SiWtyn+/27UfUMBzkR6ULfu162lbkfbaHuPV179YKGpSUd6lEhN10Dt0+tRSK5Hukdj/HUP/39vD0y6R3t6tJs/EI3RNT3aK0XzHqUolfXoGv5Q4Pr2Ho1L8j441fdop7ztJ0vjPdolbx+gmHb2aErerqUx2oU2+O2DNIUWSd6m+f/XkUZdBdrG+4doHIDskzwfpr14pD3I8KEe5fz1ev7/TI8I367v0XX84QDl9OEezUjRgz3aiVL7e/Rh/nAD7aJ9PfqAJN9IU0i6Vt4+QrvpAz36oLx9lIiu7dG0vN1EOX0QbfDbx2gaLR6Qt1n+/yHaD0BuQNt4v5k+AEBulDwfpxk80vXIcHOPDvLXW/j/t/boAL7d0qND/OEwHaSP9+hWKbrQo2tR6iM9+jh/uI0+SDf26KOS/As0jaSb5O0TdB19tEcfk7dP0gG6qUez8nYHHaSPoQ1+W6RZtHhY3o7x/z9NHwEgt6FtvM/RLXRbr0cL/HYnfRRg/UKP5vj9U/QJ+hgdoBm6gT5AU3zNAUIV1eUw6m6aEHXi7S58sCzlmOgoH0MVrFtIioleh+Z7pfut//jVH4RlscPtebDYUlKDjuKpXtIkzZdUp4ke3d6hiV5JO1BXlX+SttDtyNnodajRK2krTZS0A9dr9DpU75U0OZx9pOxdxK3VaRI/W3sd2tpDy9tRwRbChy29ku4aLtMYftnuga3RXXhK0fo21FCn1Le+fTj/VtpCDeSs9TpU66FbR0rajrsrcIczoN+0rW1SMqWtDLOvHne/cHtbPLDbhss0h1+2cMPw6N2GpwStt0pqYrx861uG87dQOXIGvQ4FPYRpcCVtYQbQoaRXUmvTtlIpmVALP61eh1q9UmSgJvRVvvvpcJnaaG1ouOQriVAEr7gOZ8+DRdjrUNhDXKRWyVcpV+CMQGCGXyIBxgjqcR9nKQEvex3SPYiowyV7XraC1qzm+z5SneaX/+rf/9VfI7wRKrU4EuDdHgCUhkyPS+IiElhe9LilYLjo+noiqSHukaFrIGiFGxXr4Xx5J8fSljbWVDT0Yjx0Ee1CLQwdN6GxKALqAr2NekO93LSeSGqIsWbs8dCtKybQ7fPQmSuEbv8m0O19b9DtvjR0H3pX0F3rYQI8tBk8bIos7YOg6MOlLKxoIhytdRgcIZUA8teeB4uxDoiy00VLOWAc2wBGqeCbT/5nv4ZzJkZaSTf2YfS4GKMPshtOlyAkkEGldrikobALe6UQKQFdj+aiLukOfvFtpB09/BJIY7brCb2DnSOKRDTtGw37jQabVsNdjkq6WRAX+OmD4DofQTVBl2wfIeFINRR1kcJwWroOYxpzT0OK8W0U3NFuBx52QRibbAnGP+objfqNmk2rqWA/6FHgyRc2dx/HdBfYzeVhv8nDbt4f7Le9B9gt/YInF8OGgoC/OwCDbrlMR0YbGExeC+41yxOlS3G/r6OEwLP7Vr5egaH2FLRB53//zdefg9bcQx3S3ADZQ7zC0iE0OTLpfdH19fi5Cu5KnwTdxhsUExgPszvg8DzctFbG6cKG0IV0B68q7xq6myCJfaJHn5Jdz6VhXXyXsB7bBNaPQcD7ZLVTSN4L5Leiik/16M5qi3RpyGfRxzuwZeHd0bvoB93tLZjmKaRP0Bygpkx2jJ6jbAy9cNxS7uCaoEPo8CK2Nk4/yGEPmSmRHubhQy37mxCP0hwdRjfp01xQg6SjnkgoI/0s5Zqv2+mTwEuCjZ7TD5bEUs7Y+s7C2JYj4rDG3q2JWtX2AUp+N9dbV0Tvk3KkJlYXB1WMguxTUDb9WJd5hohZuszHERlAl/kW3B1qynwrdCumzCdIuTc5QJlyb+gy304mH2NfZb5UMJBje9QYih7sDX1YP8zax+3ZPG3L5vOYJrJ58YpTvcK6sbPuzbgzzWpZtjzbms1Dl7y9+v6M7omLmO0VsYuqz9/WPe8xAm10FWbzhRd0jy3DoBdeU/UkjHEH+cgOV0bRSPZwpP1eDxrxEYjY+i0aqS8cqS8eqc+uq68+2hU2rbMj9UUj9YUj9cXr6rPrcDANNK7BwX6qj7RRG2kjuQzM8TocXC+a901wWh+pr7auvnAdDggG1kP1JSP1jVJL/QpwcNMGdHADhZfA8+XGbT0d3HxJuhodt+gK6OC2NXQVXwIH4RXgYG4DOrjrKtPB7VeZDu64ynTwyxvQwS9dZTr4zFWmg89eZTr44gZ0cN9VpoNTV5kO7r3KdLC8AR08cJXp4KGrTAcPX2U6WNXA9BokPKXfFyU01mHhcf2+SKG1Dg3n9Puihdo6PDyre2Ld8oym1iVW8salQRWPoaf1GipqjNQxSnStdXXE3gqucYkxaF16pPOQ4Aa5hY0YdNFw6R3wH+gbPjEtb95Lexm6HMW9t4a+Ynkq3mDeDOeG45u+pPwTX4bO62sp+jl9yXkTXoai1+PXimnMGrKuX6LWTWjlxbVzLbwErSQb08oLa7F/qfla34BWxqnhmoueQn6kxV7r6lLIy1eZQi5eZQr5/t8Ihbx6FSjkB1eBQl55vxSSpbh4XvVxPqNknKTcjPrvX2DDiAoNM+offVuMI6phmVH/3TNiHNG77KEqLDNSwkX3failvWhte/G69ux7as9Ke0mf5qU9u7a9aF174XtqL5H2Gn2ak/bCte3Zde3FG7R3uaN8aCw0NUu5+JRtaZttl8HuJIXpkcWPzWP8JHlIER4aFE2rRm9WNRDRCC9Jb1YlUMrgxfZmlSXY9ETTSvVmOegm2zCPwewDLsLweBUT+RT2PmzS42+B4cBDY3AEH6Mm3z8vF8OkYsnxiNY+pK2BaYr1Kg0y2e3v0RKIjZLYFIjtWSb4V2e3Q9nx7QC2JBmb+yKabZpwmypNA6XSp5o6HNyzNIilmwcCYbRfuUcYq8q70MFIcZI3sIXyXs3wc3Z8OYFbOTKVB7hc06k7YMBDph36EMNOwxwcF0TJBRtZG47nfM1XcqSIO3x5CgWudrTbbSr3MGIyTZtpp92FA6TGAyXtIdC4U+6ZA2+mUMDgbiVSDpceSjS4VXbSZBjdh0THpCWemCazjBwPkzr89tuPrr6iDrHV/uHV1a+svqYPmWd13x/rcS3RxacBVdfBSsXQeKBm2VJUUthQeyjlvO5/f1YPEmBXBKQ97b1v4d/iVlf1rPnZjK8Kr85WBQBjIhaSP5txZnnWNCpfPXh5eKe785VH49P8YOQ2d76XDi4OCTCgs127+q6+D8Px3risZAMs669Ls5VngyRzLGfTb6LvPME9eFWLW+8PONz7LWp/BWTh7TdnEfGJzeFPOWjsXp8B8ZDOZpsc6H3WXA/yQvc0YhFPoMu7YfYsQRUC8aLk0NoFk9AchxAU0+1JBE3+uPsQbGePFGqKewoz/cFl6rijwV/CnuI+9cA9wrfx5cY98/XKIlT50K27JRSsWS54XC58XTteLFfHlxFcH32+cwpOPErsxDjUsrtwXleXXw8HiubQr0pe3e/8pna7/RXn/gonE8y5jO9jQVRdvghnzxExcYPVOg7MXLw8i3BCDK6mEPGEXNzmG6y8GWY4CG1t3YWnES12AMnwtVWiGWVrOR8qW+LhmUE8vAH4bAQcHdSZRBx353Eljzuv5esWRhfs7Pk6Y7LuNcQG3OJWjWQY8xme6WeYLG/VY+4Z49u+4FFnll1yq/7dx/Uw6hA14hkYQGccofV3DMK19a3s9lQlC+XCW/Xvfk2maIhY3Re+NlwRBpjNWCU8g4vXtuS/1zb5nqz/Hg5o4x9UtLHlkrTxm9qHmxrqoNyEVtFGSgEo/6kD4hnjwzMH7qfZrDm3gwL3g2zWvLmdAncxmzWvbWeu+v1t8CTfwc+vbi1nzevy/SfQov90OwXZ9TKTVDWTZ71nf/+6RC2sojBVUG9/A58eTO9nD8gvwgRwFE86xOb1gPc7evDtOe/SUHmW/UC7xqlCu9e3wt9m1vyYOaR7zb/+SF7/b//6irz+tX/9vk4RlRmGqTZN/xLG36tJ+o/tqjp5uvelz3/+5ImTS6eX6f6l+890v6xuPPDRAzceuHHm/jPLp5a+rE6ePnv81Mn76NTJ5aXu8VMHTy2d/sLyF3vUW1rup504c98SDSd86XT79JkHT9MXl47ft9Slz586/oXREved7C0fP31iafTr504u+2qou/TA0vFltXzmDN1//PSXq89nuv2i1Pvy/Z87c6rXL91bPtNduo8+d+rMiXYFjfrclz7/+aUuLXW7Z7qqt9xdOn6/fxkBfmaG7j/Z6508/QVaOn3fzJnPz3A16uTpE2e63aUTy1VXTnxxaeSzh2vt5/uOLx/vfxztMqFPnz/epc8dP9FWVbXdEwDg/uPLJ77YL/HgydP3nXmQeid/ZWmAIu7d8pcfWNpkZLg/6xvlr9WwnDhz/wPdpV7v5JnTdP/S8hfP3KfwX6bG1RalVKJiVVORqqtQpcqqhgpUUxk1prRqKXexkf6BDZRVoYpUrBJVU3WVqqZqqXG1Ve1QU2qv2qc+rD6qblWfUv+JOqF66jH1e+qP1V8oo5Vva/Rv3P9t8X9b/d+E/9vm/zK1qL7HkSeMEhgAa1ONq50qVzcqp46rR9UfKa0fxS2wgbY60olu6ExPatI36Dl973D7VZtVW2hju9qudqgdalJNqp1qp9qldqkpNaV2q93qGnWNmlNz6r32P5Duq9U1f4/6v6/4v8f83+P+7wn/d/4q9F+v6ovD7VbtVe08qZ5Uv6Z+TZ1T59RX1VfVr6tfV7+hfkM9pZ5SX1NfU19XX1d0WKnVRCmtldqjlWoppS4cUUrVpH97lHzjvvpvW5VSsXIXxtNjEjxk8M+s+Res+WfX/AtH/rnzW9KltVWtLVplj/y/2P9L/L+a/1f3/1L/r+H/Nfmfu7g13VdVH/sOZuNbVBLXonqY2kbQNGO6pdwbW9P7Y27bqoT/KR6vTCX+OWIfncTnATXWGJaMv1fPGCV5pneelcYznoxWVp6NNlplNeV+NpHWbvhlLVj9/wA=")))), n) });
}
const kt = "deflate", an = "deflate-raw", aa = "deflate64-raw", sn = "gzip", on = [kt, an, sn], cn = [kt, an, sn, aa];
let sa;
function ln(t, n, e = {}) {
  if (!(t ? on : cn).includes(n))
    throw new TypeError("Unsupported format: " + n);
  {
    const r = new Error("WASM module not loaded");
    throw r.cause = sa, r;
  }
}
class _t {
  constructor(n = kt, e) {
    return ln(!0, n, e);
  }
}
class $t {
  constructor(n = kt, e) {
    return ln(!1, n, e);
  }
}
_t.requiresModule = !0;
$t.requiresModule = !0;
_t.supportedFormats = on;
$t.supportedFormats = cn;
function ia(t, n) {
  return Jt(t, n);
}
Er(ia);
Tt({
  CompressionStreamFallback: _t,
  DecompressionStreamFallback: $t
});
ra(Tt);
Kn(Tt);
class ht extends Error {
  constructor() {
    super("ZIP cache could not be written. Free some disk space, then Resume.");
  }
}
let Bt;
async function T(t, n = {}) {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length || (Bt ||= chrome.offscreen.createDocument({ url: "offscreen/index.html", reasons: [chrome.offscreen.Reason.BLOBS], justification: "Validate archived image bytes, decode dimensions, and create local blob URLs for browser downloads and exports." }).finally(() => {
    Bt = void 0;
  }), await Bt);
  const e = await chrome.runtime.sendMessage({ target: "offscreen", action: t, ...n });
  if (!e?.ok)
    throw e?.error === new W().message ? new W() : e?.error === new ht().message ? new ht() : new Error(e?.error || "Image validator did not respond");
  return e.data;
}
async function P(t) {
  t && await T("release", { url: t }).catch(() => {
  });
}
async function Xt(t, n, e = "application/json", r = !1) {
  const { blobUrl: a } = await T("export", { text: t, mime: e });
  try {
    return { id: await chrome.downloads.download({ url: a, filename: n, conflictAction: r ? "overwrite" : "uniquify", saveAs: !1 }), blobUrl: a };
  } catch (s) {
    throw await P(a), s;
  }
}
const lt = 3;
function tt(t, n = 0) {
  return Math.max(2e3 * 2 ** Math.max(0, t - 1), n);
}
async function oa(t, n) {
  const e = En(t, n);
  if (!e.length)
    return t.status = "skipped", t.errorMessage = n.mode === "original" ? "No original URL was exposed by the archive. No URL was invented." : "No observed or supported thumbnail URL is available.", await O(t), 0;
  t.status = "transferring", t.attempts++, await O(t);
  let r = 0, a = !1;
  for (const s of e)
    if (!t.candidateFailures.some((i) => i.url === s.url && /Image HTTP (400|401|403|404|410|422)\b/.test(i.reason)))
      try {
        const i = new URL(s.url).hostname;
        if (!H.includes(new URL(s.url).origin) && !ge.includes(i) && !await chrome.permissions.contains({ origins: [`https://${i}/*`] })) {
          t.candidateFailures.push({ url: s.url, reason: "Optional permission for this original host was not granted" });
          continue;
        }
        const o = await T("image", { url: s.url });
        if (o.failure) {
          if (t.candidateFailures.push({ url: s.url, reason: o.failure }), o.status === 429) {
            r = tt(t.attempts, o.retryAfterMs), a = !0;
            break;
          }
          (!o.status || o.status >= 500) && (a = !0);
          continue;
        }
        if (t.resolvedUrl = s.url, t.quality = s.quality, t.bytes = o.bytes, t.sha256 = o.sha256, t.mime = o.mime, t.width = o.width, t.height = o.height, t.blobUrl = o.blobUrl, t.savedPath = Un(t, o.ext), await O(t), n.destination?.kind === "zip")
          return await T("stage-image", { jobId: n.id, recordId: t.id, url: o.blobUrl }), t.status = "staged", t.downloadId = null, await P(t.blobUrl), t.blobUrl = null, t.errorMessage = null, await O(t), 0;
        if (n.destination?.kind === "folder") {
          const p = await T("save-image", { jobId: K(n), path: t.savedPath, url: o.blobUrl });
          return t.savedPath = p.path, t.status = "downloaded", t.downloadId = null, await P(t.blobUrl), t.blobUrl = null, t.errorMessage = null, await O(t), 0;
        }
        return t.downloadId = await chrome.downloads.download({ url: o.blobUrl, filename: t.savedPath, conflictAction: "uniquify", saveAs: !1 }), t.errorMessage = null, await O(t), 0;
      } catch (i) {
        if (i instanceof W || i instanceof ht)
          throw t.status = "queued", t.attempts--, t.errorMessage = i.message, await P(t.blobUrl), t.blobUrl = null, await O(t), i;
        a = !0, t.candidateFailures.push({ url: s.url, reason: "Image fetch, decoding, or browser download failed" }), await P(t.blobUrl), t.blobUrl = null, t.downloadId = null;
      }
  return t.errorMessage = t.candidateFailures.at(-1)?.reason || "All allowed image candidates failed", a && t.attempts < lt ? (t.status = "queued", t.nextAttemptAt = Date.now() + (r || tt(t.attempts))) : t.status = "failed", await O(t), r;
}
async function te(t, n = !1, e) {
  if (e?.destination?.kind === "zip") {
    const { ids: a } = await T("zip-matches", { jobId: e.id, records: [t] });
    t.status = a.includes(t.id) ? "staged" : t.attempts < lt ? "queued" : "failed", t.errorMessage = t.status === "staged" ? null : "ZIP image collection was interrupted", await P(t.blobUrl), t.blobUrl = null, t.downloadId = null, await O(t);
    return;
  }
  if (e?.destination?.kind === "folder") {
    t.savedPath && t.sha256 && t.bytes !== null && await be(K(e), t.savedPath, t.sha256, t.bytes) ? (t.status = "downloaded", t.errorMessage = null) : (t.status = t.attempts < lt ? "queued" : "failed", t.errorMessage = "Folder write was interrupted before completion", t.nextAttemptAt = Date.now() + tt(t.attempts)), await P(t.blobUrl), t.blobUrl = null, t.downloadId = null, await O(t);
    return;
  }
  let r;
  if (t.downloadId !== null ? [r] = await chrome.downloads.search({ id: t.downloadId }) : t.savedPath && t.blobUrl && (r = (await chrome.downloads.search({ query: [t.savedPath.split("/").at(-1)], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === t.blobUrl), r && (t.downloadId = r.id)), r?.state === "complete") {
    if (r.exists === !1 ? (t.status = "failed", t.errorMessage = "The completed file was removed outside the extension") : (t.status = "downloaded", t.errorMessage = null), r.filename) {
      const a = r.filename.replaceAll("\\", "/"), s = a.lastIndexOf("/ArchiveRoot/");
      s >= 0 && (t.savedPath = a.slice(s + 1));
    }
    await P(t.blobUrl), t.blobUrl = null;
  } else (r?.state === "interrupted" || !r && n) && (t.errorMessage = r?.error || "Worker/browser interrupted an uncommitted transfer", t.status = t.attempts < lt ? "queued" : "failed", t.nextAttemptAt = Date.now() + tt(t.attempts), await P(t.blobUrl), t.blobUrl = null, t.downloadId = null);
  await O(t);
}
function vt(t) {
  return { state: "pending", filename: `kemono-discord_${t.serverId}_${Kt(t.serverName, "server")}_${t.id.slice(0, 8)}.zip`, blobUrl: null, downloadId: null, bytes: 0, entries: 0, progress: 0, total: 0, error: null };
}
async function un(t) {
  const n = t.archive;
  if (!n || !["ready", "saved", "saving"].includes(n.state)) throw new Error("The ZIP is still being prepared");
  if (n.state === "saving") return;
  await P(n.blobUrl);
  const e = await T("zip-open", { jobId: t.id });
  n.blobUrl = e.blobUrl, n.bytes = e.bytes, n.downloadId = null, n.state = "saving", n.error = null, t.manifestState = "saving", await R(t);
  try {
    n.downloadId = await chrome.downloads.download({ url: e.blobUrl, filename: n.filename, conflictAction: "uniquify", saveAs: !0 });
  } catch {
    n.state = "ready", n.error = "ZIP saving was cancelled or blocked. Click Save ZIP to try again; images remain cached.", t.manifestState = "pending", await P(n.blobUrl), n.blobUrl = null;
  }
  await R(t);
}
async function ca(t, n) {
  t.archive ||= vt(t);
  const e = t.archive;
  if (e.state === "pending") {
    e.state = "building", e.error = null, t.manifestState = "pending", await R(t), await T("zip-build-start", { job: t, records: n });
    return;
  }
  if (e.state !== "building") return;
  const r = await T("zip-build-status", { jobId: t.id });
  if (!r) {
    e.state = "pending", await R(t);
    return;
  }
  Object.assign(e, r), r.state === "ready" ? (t.status = "finished", await R(t), await un(t)) : r.state === "failed" ? (t.status = "finished", t.manifestState = "failed", await R(t)) : await R(t);
}
async function dn(t, n = !1) {
  const e = t.archive;
  if (!e || e.state !== "saving") return;
  let r;
  if (e.downloadId !== null ? [r] = await chrome.downloads.search({ id: e.downloadId }) : e.blobUrl && (r = (await chrome.downloads.search({ query: [e.filename], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === e.blobUrl), r && (e.downloadId = r.id)), r?.state === "complete" && r.exists !== !1) {
    e.state = "saved", e.error = null, t.manifestState = "saved", await P(e.blobUrl), e.blobUrl = null;
    const a = await D(t.id);
    for (const s of a) s.status === "staged" && (s.status = "downloaded");
    await st(t, a);
  } else (r?.state === "interrupted" || r?.exists === !1 || !r && n) && (e.state = "ready", e.error = "ZIP download was interrupted. Click Save ZIP to retry without fetching images again.", t.manifestState = "pending", await P(e.blobUrl), e.blobUrl = null, e.downloadId = null, await R(t));
}
const fn = new yn();
function k(t) {
  return t.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), t;
}
async function he(t) {
  const n = await xn(t);
  if (!n) throw new Error("Archive job was not found");
  return n;
}
async function pe(t) {
  const n = St(t);
  if (!n) throw new Error("Open or paste a Kemono or Pawchive Discord server or channel URL");
  const e = new URL(t).origin, a = (await chrome.tabs.query({ url: `${e}/discord/server/*` })).filter((y) => y.id !== void 0 && St(y.url || "")?.serverId === n.serverId && new URL(y.url).origin === e).map(async (y) => {
    try {
      const l = await chrome.tabs.sendMessage(y.id, { type: "DISCOVER_CHANNELS" });
      return l?.serverId === n.serverId && Array.isArray(l.channels) ? l : null;
    } catch {
      return null;
    }
  }), [s, ...i] = await Promise.allSettled([fn.server(n.serverId, e), ...a]), o = s.status === "fulfilled" ? s.value : null, p = i.flatMap((y) => y.status === "fulfilled" && y.value ? [y.value] : []), g = bn(n.serverId, o, p);
  n.serverName = g?.name || null, n.channelName = g?.channels.find((y) => y.id === n.channelId)?.name || null;
  let m = null;
  return o || (m = `${s.status === "rejected" && s.reason instanceof Error ? s.reason.message : "Server metadata is unavailable."} ${g?.channels.length ? "Using channel links from the open page; hidden or unloaded channels may be missing." : n.channelId ? "Current-channel scanning is still available." : "Open the server page, reload it, and discover its channel links again."}`), { scope: n, server: g, warning: m, apiChannelCount: o?.channels.length || 0, domChannelCount: g?.channels.filter((y) => y.sources?.includes("dom")).length || 0 };
}
async function la(t, n) {
  if (t.type === "DISCOVER") return pe(t.url);
  if (t.type === "LIST") {
    const r = (await Q()).sort((a, s) => s.createdAt.localeCompare(a.createdAt));
    return Promise.all(r.map(async (a) => ({ job: a, totals: Ft(a, await D(a.id)) })));
  }
  if (t.type === "DETAIL") {
    const r = await he(t.jobId), a = await D(r.id);
    return { job: r, media: a, totals: Ft(r, a) };
  }
  if (t.type === "DASHBOARD")
    return await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") }), null;
  if (t.type === "START") {
    if (!["thumbnail", "best", "original"].includes(t.mode)) throw new Error("Invalid quality mode");
    const { scope: r, server: a, warning: s, apiChannelCount: i, domChannelCount: o } = await pe(t.url), p = new URL(t.url).origin, g = !!t.allChannels || !r.channelId && !t.channelIds.length, m = [...new Set(g ? a?.channels.map((u) => u.id) || [] : t.channelIds.length ? t.channelIds.map(Z) : r.channelId ? [r.channelId] : [])];
    if (!m.length) throw new Error(s || "No channels were discovered in this server. Open the server page and try Discover channels again.");
    if (m.some((u) => u !== r.channelId && !a?.channels.some((h) => h.id === u))) throw new Error("Selected channel was not discovered in this server");
    for (const u of await Q()) ["scanning", "downloading"].includes(u.status) && (u.resumeStatus = u.status, u.status = "paused", await R(k(u)));
    const y = {
      id: crypto.randomUUID(),
      serverId: r.serverId,
      serverName: r.serverName,
      mode: t.mode,
      tryOriginal: !!t.tryOriginal,
      channels: m.map((u) => {
        const h = a?.channels.find((f) => f.id === u);
        return { channelId: u, channelName: h?.name || null, postCount: h?.postCount ?? null, offset: 0, pages: 0, messageIds: [], pageFingerprints: [], coverage: "pending", terminal: null, failures: [], attempts: 0, nextAttemptAt: 0, error: null, domMessages: 0 };
      }),
      status: "scanning",
      resumeStatus: "scanning",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      warnings: s ? [s] : [],
      autoManifest: !1,
      manifestState: "pending",
      manifestDownloads: [],
      apiNextAt: 0,
      mediaNextAt: 0,
      scope: g ? "server" : m.length === 1 ? "channel" : "selected",
      sourceUrl: `${p}/discord/server/${r.serverId}${r.channelId ? "/" + r.channelId : ""}`,
      discoveredChannelCount: a?.channels.length || m.length,
      channelDiscovery: i ? o ? "api+dom" : "api" : o ? "dom" : "current-channel",
      destination: { kind: "zip" }
    };
    await R(y);
    const l = await chrome.tabs.query({ url: `${p}/discord/server/*` });
    for (const u of l) u.id && St(u.url || "")?.serverId === y.serverId && new URL(u.url).origin === p && chrome.tabs.sendMessage(u.id, { type: "SCAN_DOM" }).catch(() => {
    });
    return { jobId: y.id };
  }
  if (t.type === "DOM") {
    const r = ee(t.url), a = ee(n.tab?.url || "");
    if (!r || !a || a.channelId !== r.channelId || a.serverId !== r.serverId || new URL(t.url).origin !== new URL(n.tab.url).origin) return null;
    const s = new URL(t.url).origin;
    for (const i of await Q()) {
      if (i.serverId !== r.serverId || new URL(i.sourceUrl || H[0]).origin !== s || !["scanning", "indexed", "paused"].includes(i.status)) continue;
      const o = i.channels.find((g) => g.channelId === r.channelId);
      if (!o) continue;
      const p = t.records.slice(0, 1e4).filter((g) => g.serverId === r.serverId && g.channelId === r.channelId).map((g) => ({
        ...g,
        jobId: i.id,
        serverName: i.serverName,
        channelName: o.channelName,
        originalUrl: G(g.originalUrl),
        discordCdnUrl: G(g.discordCdnUrl),
        thumbnailUrl: G(g.thumbnailUrl)
      }));
      o.domMessages = Math.max(o.domMessages, t.messageCount), await st(k(i), ye(await D(i.id), p));
    }
    return null;
  }
  const e = await he(t.jobId);
  if (e.archive?.state === "saving" && (t.type === "DESTINATION" || t.type === "ACTION" && ["download", "retry"].includes(t.action))) throw new Error("Finish or cancel the current ZIP save before starting another");
  if (t.type === "DESTINATION") {
    if (e.status === "downloading") throw new Error("Pause the job before choosing its save destination");
    const r = await D(e.id);
    if (t.kind === "folder") {
      const a = t.directoryId || e.id, s = await it(a);
      for (const i of r)
        ["downloaded", "staged"].includes(i.status) && (!i.savedPath || !i.sha256 || i.bytes === null || !await be(a, i.savedPath, i.sha256, i.bytes)) || i.status === "transferring" ? (i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await P(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = e.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null) : i.status === "staged" && (i.status = "downloaded");
      for (const i of e.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await P(i.blobUrl);
      e.destination = { kind: "folder", name: s.name, ...t.directoryId ? { directoryId: a } : {} }, e.manifestState = "pending", e.manifestPaths = [], e.manifestDownloads = [], e.archive = void 0;
    } else if (t.kind === "zip") {
      const a = r.filter((i) => ["downloaded", "staged", "transferring"].includes(i.status)), s = new Set((await T("zip-matches", { jobId: e.id, records: a })).ids);
      for (const i of a)
        i.status === "transferring" && i.downloadId !== null && await chrome.downloads.cancel(i.downloadId).catch(() => {
        }), await P(i.blobUrl), i.blobUrl = null, i.downloadId = null, i.status = s.has(i.id) ? "staged" : e.autoManifest ? "queued" : "discovered", i.attempts = 0, i.nextAttemptAt = 0, i.errorMessage = null;
      for (const i of e.manifestDownloads)
        i.state === "in_progress" && await chrome.downloads.cancel(i.id).catch(() => {
        }), await P(i.blobUrl);
      e.destination = { kind: "zip" }, e.archive = vt(e), e.manifestState = "pending", e.manifestDownloads = [], e.manifestPaths = [];
    } else if (t.kind === "browser") {
      if (r.some((a) => ["downloaded", "staged"].includes(a.status)) && e.destination?.kind !== "browser" && e.destination) throw new Error("Create a new job to switch collected files to individual Browser downloads.");
      e.destination = { kind: "browser" }, e.archive = void 0;
    } else throw new Error("Unsupported save destination");
    return e.destinationError = null, await st(k(e), r), null;
  }
  if (t.type === "EXPORT") {
    const r = await D(e.id), a = Ut(e), s = e.id.slice(0, 8), i = `${a}/${t.format === "csv" ? "links" : t.format === "failures" ? "failures" : "manifest"}-${s}.${t.format === "csv" ? "csv" : "json"}`, o = t.format === "csv" ? Rn(r) : rt(e, t.format === "failures" ? r.filter((g) => g.status === "failed" || g.status === "skipped") : r), p = t.format === "csv" ? "text/csv;charset=utf-8" : "application/json";
    return e.destination?.kind === "folder" ? await T("save-text", { jobId: K(e), path: i, text: o, mime: p }) : await Xt(o, i, p), null;
  }
  if (t.action === "pause") {
    ["scanning", "downloading"].includes(e.status) && (e.resumeStatus = e.status, e.status = "paused");
    for (const r of await D(e.id)) r.status === "transferring" && r.downloadId !== null && await chrome.downloads.pause(r.downloadId).catch(() => {
    });
    e.destination?.kind === "zip" && e.archive?.state === "building" && (await T("zip-stop", { jobId: e.id }), e.archive.state = "pending");
  } else if (t.action === "cancel") {
    e.status = "cancelled", e.destination?.kind === "zip" && (await T("zip-stop", { jobId: e.id }), e.archive?.state === "saving" && e.archive.downloadId !== null && await chrome.downloads.cancel(e.archive.downloadId).catch(() => {
    }), e.archive?.state === "building" && (e.archive.state = "pending"));
    for (const r of await D(e.id))
      r.status === "transferring" && r.downloadId !== null && await chrome.downloads.cancel(r.downloadId).catch(() => {
      }), ["queued", "transferring"].includes(r.status) && (r.status = "skipped", r.errorMessage = "Cancelled by user", await P(r.blobUrl), r.blobUrl = null, await O(r));
  } else if (t.action === "resume") {
    if (e.status !== "paused") throw new Error("Only paused jobs can be resumed");
    e.destination?.kind === "folder" && e.resumeStatus === "downloading" && await it(K(e)), e.destinationError = null, e.status = e.resumeStatus;
    for (const r of await D(e.id)) r.status === "transferring" && r.downloadId !== null && await chrome.downloads.resume(r.downloadId).catch(() => {
    });
  } else if (t.action === "retry") {
    for (const r of e.channels) r.coverage === "incomplete" && (r.coverage = "pending", r.attempts = 0, r.error = null, r.nextAttemptAt = 0);
    for (const r of await D(e.id)) (r.status === "failed" || r.status === "skipped") && (r.status = e.autoManifest ? "queued" : "discovered", r.attempts = 0, r.nextAttemptAt = 0, r.errorMessage = null, r.candidateFailures = [], await O(r));
    e.status = e.channels.some((r) => r.coverage !== "complete") ? "scanning" : e.autoManifest ? "downloading" : "indexed", e.manifestState = "pending", e.destination?.kind === "zip" && (e.archive = vt(e));
  } else if (t.action === "save-zip") {
    if (e.destination?.kind !== "zip") throw new Error("Select ZIP output first");
    return await un(e), null;
  } else if (t.action === "clear-cache") {
    if (e.destination?.kind !== "zip" || ["scanning", "downloading"].includes(e.status) || e.archive?.state === "saving") throw new Error("Finish or cancel ZIP saving before clearing its cache");
    await P(e.archive?.blobUrl || null), await T("zip-clear", { jobId: e.id });
    const r = await D(e.id);
    for (const a of r) ["downloaded", "staged"].includes(a.status) && (a.status = "discovered", a.attempts = 0, a.nextAttemptAt = 0);
    return e.archive = void 0, e.status = "indexed", e.autoManifest = !1, e.manifestState = "pending", await st(k(e), r), null;
  } else if (t.action === "download") {
    if (e.status === "scanning" || e.channels.some((s) => ["pending", "scanning"].includes(s.coverage))) throw new Error("Pause or finish the scan before downloading the indexed results");
    if (!e.destination) throw new Error("Choose a save folder or explicitly select Browser downloads before starting the batch");
    e.destination.kind === "folder" && await it(K(e));
    const r = await D(e.id);
    let a;
    e.destination.kind === "zip" && (a = new Set((await T("zip-matches", { jobId: e.id, records: r.filter((s) => ["downloaded", "staged"].includes(s.status)) })).ids), e.archive = vt(e));
    for (const s of r) (s.status === "discovered" || a && ["staged", "downloaded"].includes(s.status) && !a.has(s.id)) && (s.status = "queued", s.attempts = 0, s.nextAttemptAt = 0, await O(s));
    e.status = "downloading", e.autoManifest = !0, e.manifestState = "pending";
  }
  return await R(k(e)), null;
}
async function ua(t) {
  if (!t.channels.some((e) => ["pending", "scanning"].includes(e.coverage))) {
    t.status = t.autoManifest ? "downloading" : "indexed", await R(k(t));
    return;
  }
  if (Date.now() < t.apiNextAt) return;
  const n = t.channels.find((e) => ["pending", "scanning"].includes(e.coverage) && e.nextAttemptAt <= Date.now());
  if (!n) {
    t.channels.some((e) => ["pending", "scanning"].includes(e.coverage)) || (t.status = t.autoManifest ? "downloading" : "indexed", await R(k(t)));
    return;
  }
  try {
    const e = new URL(t.sourceUrl || H[0]).origin, r = await fn.channel(n.channelId, n.offset, e), a = An(n, r), s = In(r, { serverId: t.serverId, serverName: t.serverName, channelId: n.channelId, channelName: n.channelName }, t.id, e);
    if (t.autoManifest) for (const i of s) i.status = "queued";
    t.channels[t.channels.indexOf(n)] = a, a.coverage === "complete" && a.postCount !== null && a.postCount !== a.messageIds.length && t.warnings.push(`Channel ${a.channelId}: metadata post_count=${a.postCount}; API unique messages=${a.messageIds.length}.`), t.apiNextAt = Date.now() + 1100, await st(k(t), ye(await D(t.id), s));
  } catch (e) {
    n.attempts++, n.error = e instanceof Error ? e.message : "Page scan failed", n.failures.push({ offset: n.offset, reason: n.error, at: (/* @__PURE__ */ new Date()).toISOString() });
    const r = e instanceof q && e.retryable;
    if (e instanceof q && e.status === 429 && (t.apiNextAt = Date.now() + tt(n.attempts, e.retryAfterMs)), r && n.attempts < lt) {
      const a = tt(n.attempts, e.retryAfterMs);
      n.nextAttemptAt = Date.now() + a, t.apiNextAt = n.nextAttemptAt;
    } else n.coverage = "incomplete";
    await R(k(t));
  }
}
async function da(t, n) {
  t.manifestState = "saving", t.manifestDownloads = [], await R(k(t));
  try {
    if (t.destination?.kind === "folder") {
      t.manifestPaths = [];
      for (const s of t.channels) {
        const i = `${Ht({ ...t, channelId: s.channelId, channelName: s.channelName })}/channel-manifest.json`;
        await T("save-text", { jobId: K(t), path: i, text: rt(t, n, s.channelId), overwrite: !0 }), t.manifestPaths.push(i), await R(t);
      }
      const a = `${Ut(t)}/manifest.json`;
      await T("save-text", { jobId: K(t), path: a, text: rt(t, n), overwrite: !0 }), t.manifestPaths.push(a), t.manifestState = "saved", await R(k(t));
      return;
    }
    for (const a of t.channels) {
      const s = `${Ht({ ...t, channelId: a.channelId, channelName: a.channelName })}/channel-manifest.json`, i = await Xt(rt(t, n, a.channelId), s, "application/json", !0);
      t.manifestDownloads.push({ ...i, path: s, state: "in_progress" }), await R(t);
    }
    const e = `${Ut(t)}/manifest.json`, r = await Xt(rt(t, n), e, "application/json", !0);
    t.manifestDownloads.push({ ...r, path: e, state: "in_progress" }), await R(t);
  } catch (e) {
    e instanceof W ? (t.manifestState = "pending", await Dt(t, e)) : (t.manifestState = "failed", t.warnings.push("One or more manifest saves failed. Use Export JSON to save the current state."), await R(k(t)));
  }
}
async function Dt(t, n) {
  t.resumeStatus = "downloading", t.status = "paused", t.destinationError = n.message, await R(k(t));
}
async function fa() {
  const t = await Q(), n = Math.max(0, ...t.map((r) => r.apiNextAt)), e = Math.max(0, ...t.map((r) => r.mediaNextAt));
  for (const r of t) {
    if (r.status === "scanning") {
      (Date.now() >= n || r.channels.every((o) => !["pending", "scanning"].includes(o.coverage))) && await ua(r);
      return;
    }
    if (r.status !== "downloading") continue;
    if (r.destination?.kind === "folder")
      try {
        await it(K(r));
      } catch (o) {
        await Dt(r, o instanceof Error ? o : new W());
        return;
      }
    let a = await D(r.id);
    for (const o of a) o.status === "transferring" && (o.downloadId !== null || ["folder", "zip"].includes(r.destination?.kind || "")) && await te(o, !0, r);
    a = await D(r.id);
    const s = a.filter((o) => o.status === "transferring").length, i = a.filter((o) => o.status === "queued" && o.nextAttemptAt <= Date.now()).slice(0, Math.max(0, 2 - s));
    if (i.length && Date.now() >= e) {
      const o = await Promise.allSettled(i.map((m) => oa(m, r))), p = o.find((m) => m.status === "rejected");
      if (p?.status === "rejected") {
        if (p.reason instanceof W || p.reason instanceof ht) {
          await Dt(r, p.reason);
          return;
        }
        throw p.reason;
      }
      const g = o.flatMap((m) => m.status === "fulfilled" ? [m.value] : []);
      r.mediaNextAt = Date.now() + Math.max(r.destination?.kind === "zip" ? 250 : 1100, ...g), await R(r);
    }
    if (a = await D(r.id), !a.some((o) => o.status === "queued" || o.status === "transferring")) {
      if (r.destination?.kind === "zip") {
        await ca(r, a);
        return;
      }
      r.status = "finished", await R(k(r)), r.autoManifest && r.manifestState === "pending" && await da(r, a);
    }
    if (r.destination?.kind === "zip") {
      const o = a.filter((p) => p.status === "queued");
      if (o.length) {
        const p = Math.max(e, r.mediaNextAt, Math.min(...o.map((g) => g.nextAttemptAt)));
        return Math.max(100, Math.min(1200, p - Date.now()));
      }
    }
    return;
  }
}
async function wn() {
  for (const t of await Q()) {
    t.destination?.kind === "zip" && await dn(t, !0);
    try {
      for (const n of await D(t.id)) n.status === "transferring" && await te(n, !0, t);
    } catch (n) {
      if (!(n instanceof W || n instanceof ht)) throw n;
      t.status === "downloading" && await Dt(t, n);
    }
    if (t.manifestState === "saving") {
      if (t.destination?.kind === "zip") continue;
      if (t.destination?.kind === "folder") {
        t.manifestState = "pending", t.status === "finished" && (t.status = "downloading"), await R(t);
        continue;
      }
      for (const n of t.manifestDownloads) {
        const [e] = await chrome.downloads.search({ id: n.id });
        n.state = e?.state === "complete" ? "complete" : e?.state === "in_progress" ? "in_progress" : "interrupted";
      }
      t.manifestDownloads.length !== t.channels.length + 1 ? (t.manifestState = "pending", t.status === "finished" && (t.status = "downloading")) : t.manifestDownloads.every((n) => n.state === "complete") ? t.manifestState = "saved" : t.manifestDownloads.some((n) => n.state === "interrupted") && (t.manifestState = "failed"), await R(t);
    }
  }
}
async function wa(t) {
  if (!t.state || !["complete", "interrupted"].includes(t.state.current || "")) return;
  for (const e of await Q()) {
    e.destination?.kind === "zip" && e.archive?.downloadId === t.id && await dn(e);
    for (const a of await D(e.id)) a.downloadId === t.id && a.status === "transferring" && await te(a);
    const r = e.manifestDownloads.find((a) => a.id === t.id);
    r && (r.state = t.state.current === "complete" ? "complete" : "interrupted", await P(r.blobUrl), e.manifestDownloads.length === e.channels.length + 1 && e.manifestDownloads.every((a) => a.state === "complete") && (e.manifestState = "saved"), r.state === "interrupted" && (e.manifestState = "failed"), await R(k(e)));
  }
  const [n] = await chrome.downloads.search({ id: t.id });
  n?.url.startsWith(`blob:chrome-extension://${chrome.runtime.id}/`) && await P(n.url);
}
let me = Promise.resolve(), Mt, It = !1;
function pt(t) {
  const n = me.then(t);
  return me = n.catch(() => {
  }), n;
}
function hn() {
  It || (It = !0, pt(fa).then((t) => t || 1200, () => 1200).then((t) => {
    It = !1, mt(t);
  }));
}
function mt(t = 1200) {
  Mt || It || (Mt = setTimeout(() => {
    Mt = void 0, hn();
  }, t));
}
chrome.runtime.onMessage.addListener((t, n, e) => {
  if (!(n.id !== chrome.runtime.id || t.target === "offscreen"))
    return pt(() => la(t, n)).then((r) => e({ ok: !0, data: r }), (r) => e({ ok: !1, error: r instanceof Error ? r.message : "Archive operation failed" })).finally(mt), !0;
});
chrome.downloads.onChanged.addListener((t) => {
  pt(() => wa(t)).catch(() => {
  }).finally(mt);
});
chrome.alarms.onAlarm.addListener((t) => {
  t.name === "archive-tick" && hn();
});
chrome.runtime.onStartup.addListener(() => {
  pt(wn).finally(mt);
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
});
chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
pt(wn).catch(() => {
}).finally(mt);
