function M(e) {
  try {
    const a = new URL(e), t = /^\/discord\/server\/(\d+)(?:\/(\d+))?\/?$/.exec(a.pathname);
    return a.origin !== "https://kemono.cr" || a.username || a.password || !t ? null : { serverId: t[1], channelId: t[2] || null, serverName: null, channelName: null };
  } catch {
    return null;
  }
}
function H(e) {
  const a = M(e);
  return a?.channelId ? { ...a, channelId: a.channelId } : null;
}
function g(e) {
  if (typeof e != "string" || !/^\d+$/.test(e)) throw new Error("Expected a Discord ID encoded as a string");
  return e;
}
const ae = /^\/([0-9a-f]{2})\/([0-9a-f]{2})\/([0-9a-f]{64})\.(png|jpe?g|webp|gif|avif)$/i;
function T(e) {
  if (typeof e != "string") return null;
  const a = ae.exec(e);
  return a ? { path: e, hash: a[3].toLowerCase() } : null;
}
function se(e) {
  const a = T(e);
  return a ? `https://img.kemono.cr/thumbnail/data${a.path}` : null;
}
function b(e) {
  if (typeof e != "string") return null;
  try {
    const a = new URL(e);
    if (a.protocol !== "https:" || a.username || a.password || a.port) return null;
    const t = a.hostname;
    return t === "img.kemono.cr" && a.pathname.startsWith("/thumbnail/data/") && T(a.pathname.slice(15)) || (t === "kemono.cr" || /^n[1-4]\.kemono\.cr$/.test(t)) && a.pathname.startsWith("/data/") && T(a.pathname.slice(5)) || (t === "cdn.discordapp.com" || t === "media.discordapp.net") && /^\/attachments\/\d+\/\d+\/[^/]+\.(png|jpe?g|webp|gif|avif)$/i.test(a.pathname) ? (a.hash = "", a.href) : null;
  } catch {
    return null;
  }
}
class v extends Error {
  constructor(a, t, n = 0) {
    super(a), this.status = t, this.retryAfterMs = n, this.name = "RequestError";
  }
  status;
  retryAfterMs;
  get retryable() {
    return this.status === 0 || this.status === 429 || this.status >= 500;
  }
}
function ie(e, a = Date.now()) {
  if (!e) return 0;
  const t = Number(e);
  return Math.max(0, Number.isFinite(t) ? t * 1e3 : Date.parse(e) - a || 0);
}
class re {
  constructor(a = (t, n) => fetch(t, n)) {
    this.transport = a;
  }
  transport;
  async json(a) {
    let t;
    try {
      t = await this.transport(`https://kemono.cr/api/v1${a}`, {
        headers: { Accept: "text/css" },
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(2e4)
      });
    } catch {
      throw new v("API network request failed or timed out. Open the channel to check site access.", 0);
    }
    if (!t.ok) {
      const n = t.status === 403 ? " Access denied; the required Accept: text/css header was sent. Check access in the site tab." : "";
      throw new v(`API HTTP ${t.status}.${n}`, t.status, ie(t.headers.get("retry-after")));
    }
    try {
      return JSON.parse(await t.text());
    } catch {
      throw new v("API returned invalid JSON; this page is incomplete.", 422);
    }
  }
  async channel(a, t) {
    if (g(a), !Number.isSafeInteger(t) || t < 0) throw new Error("Invalid page offset");
    const n = await this.json(`/discord/channel/${a}?o=${t}`);
    if (!Array.isArray(n)) throw new v("Channel response is not an array", 422);
    for (const s of n) {
      if (!s || typeof s != "object") throw new v("Invalid message object", 422);
      if (g(s.id), s.channel !== void 0 && g(s.channel) !== a) throw new v("Channel response contains a different channel", 422);
      if (s.server !== void 0 && g(s.server), s.attachments != null && (!Array.isArray(s.attachments) || s.attachments.some((i) => !i || typeof i != "object" || Array.isArray(i)))) throw new v("Invalid attachment list", 422);
    }
    return n;
  }
  async server(a) {
    g(a);
    const t = await this.json(`/discord/server/${a}`);
    if (!t || g(t.id) !== a || !Array.isArray(t.channels)) throw new v("Invalid server metadata", 422);
    return {
      id: a,
      name: typeof t.name == "string" ? t.name : a,
      channels: t.channels.map((n) => ({
        id: g(n.id),
        name: typeof n.name == "string" ? n.name : n.id,
        parentId: typeof n.parent_channel_id == "string" ? g(n.parent_channel_id) : null,
        type: typeof n.type == "number" ? n.type : null,
        postCount: Number.isSafeInteger(n.post_count) && n.post_count >= 0 ? n.post_count : null
      }))
    };
  }
}
function oe(e, a, t) {
  const n = /* @__PURE__ */ new Map();
  for (const i of a?.channels || []) n.set(i.id, { ...i, sources: ["api"] });
  let s = a?.name || null;
  for (const i of t)
    if (i.serverId === e) {
      s ||= typeof i.serverName == "string" ? i.serverName : null;
      for (const r of i.channels) {
        try {
          g(r.id);
        } catch {
          continue;
        }
        const o = n.get(r.id);
        o ? o.sources = [.../* @__PURE__ */ new Set([...o.sources || [], "dom"])] : n.set(r.id, { id: r.id, name: typeof r.name == "string" ? r.name : r.id, parentId: null, type: null, postCount: null, sources: ["dom"] });
      }
    }
  return a || n.size ? { id: e, name: s || e, channels: [...n.values()] } : null;
}
function O(e) {
  let a = 0xcbf29ce484222325n;
  for (const t of e) a = BigInt.asUintN(64, (a ^ BigInt(t.codePointAt(0))) * 0x100000001b3n);
  return a.toString(16).padStart(16, "0");
}
function le(e) {
  if (typeof e != "string") return null;
  const a = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})?$/.exec(e);
  if (!a) return null;
  const [, t, n, s, i, r, o, l, c] = a, u = Number(t), m = Number(n), d = Number(s);
  if (m < 1 || m > 12 || d < 1 || d > new Date(Date.UTC(u, m, 0)).getUTCDate() || Number(i) > 23 || Number(r) > 59 || Number(o) > 59) return null;
  const p = `${t}-${n}-${s}T${i}:${r}:${o}.${(l || "").padEnd(3, "0").slice(0, 3)}${c || "Z"}`, N = Date.parse(p);
  return Number.isFinite(N) ? new Date(N).toISOString() : null;
}
function J(e, a, t, n, s) {
  return {
    ...e,
    jobId: a,
    id: `${e.serverId}:${e.channelId}:${t || "dom"}:${n}:${O(s)}`,
    messageId: t,
    attachmentIndex: n,
    attachmentId: null,
    publishedRaw: null,
    publishedAtUtc: null,
    originalFilename: null,
    kemonoPath: null,
    kemonoFileHash: null,
    originalUrl: null,
    discordCdnUrl: null,
    thumbnailUrl: null,
    resolvedUrl: null,
    mediaType: "unknown",
    sourceType: "api",
    provenance: [],
    warnings: [],
    status: "discovered",
    savedPath: null,
    errorMessage: null,
    attempts: 0,
    nextAttemptAt: 0,
    downloadId: null,
    blobUrl: null,
    quality: null,
    bytes: null,
    sha256: null,
    mime: null,
    width: null,
    height: null,
    candidateFailures: []
  };
}
function ce(e, a, t) {
  const n = [];
  for (const s of e) {
    if (s.server && s.server !== a.serverId) throw new Error("Message belongs to a different server");
    const i = (c) => (c.publishedRaw = typeof s.published == "string" ? s.published : null, c.publishedAtUtc = le(c.publishedRaw), c.provenance = ["api"], c.publishedAtUtc ? /(Z|[+-]\d\d:\d\d)$/.test(c.publishedRaw) || c.warnings.push("Archive timestamp has no timezone; interpreted as UTC") : c.warnings.push("Missing or invalid publication timestamp"), c), r = s.attachments || [];
    r.forEach((c, u) => {
      const m = typeof c.path == "string" ? c.path : null, d = i(J(a, t, s.id, u + 1, m || c.name || `attachment-${u}`));
      d.originalFilename = typeof c.name == "string" ? c.name : null;
      const p = T(m);
      p ? (d.kemonoPath = p.path, d.kemonoFileHash = p.hash, d.thumbnailUrl = se(p.path), d.mediaType = "image") : (d.discordCdnUrl = b(m), d.discordCdnUrl?.includes("discordapp.") ? d.mediaType = "image" : (d.discordCdnUrl = null, d.warnings.push("Unsupported attachment path; needs an observed image URL"))), n.push(d);
    });
    const o = typeof s.content == "string" ? s.content.match(/https:\/\/(?:cdn\.discordapp\.com|media\.discordapp\.net)\/attachments\/[^\s<>"')]+/g) || [] : [];
    [...new Set(o.map(b).filter((c) => !!c))].forEach((c, u) => {
      const m = i(J(a, t, s.id, r.length + u + 1, c));
      m.discordCdnUrl = c, m.mediaType = "image", m.originalFilename = new URL(c).pathname.split("/").at(-1);
      try {
        m.originalFilename = decodeURIComponent(m.originalFilename);
      } catch {
      }
      m.provenance.push("inline-content"), n.push(m);
    });
  }
  return n;
}
function X(e, a) {
  const t = new Map(e.map((n) => [n.id, n]));
  for (const n of a) {
    let s = t.get(n.id);
    if (!s && n.messageId) {
      const o = [...t.values()].filter((l) => (l.sourceType === "dom" || n.sourceType === "dom") && l.sourceType !== n.sourceType && l.serverId === n.serverId && l.channelId === n.channelId && l.messageId === n.messageId && (l.kemonoPath && l.kemonoPath === n.kemonoPath || l.discordCdnUrl && l.discordCdnUrl === n.discordCdnUrl));
      s = o.find((l) => l.attachmentIndex === n.attachmentIndex) || (o.length === 1 ? o[0] : void 0);
    }
    if (!s) {
      t.set(n.id, n);
      continue;
    }
    const i = n.sourceType === "api" && s.sourceType === "dom" ? n : s, r = {
      ...s,
      id: i.id,
      attachmentIndex: i.attachmentIndex,
      publishedRaw: i.publishedRaw || s.publishedRaw || n.publishedRaw,
      publishedAtUtc: i.publishedAtUtc || s.publishedAtUtc || n.publishedAtUtc,
      originalFilename: i.originalFilename || s.originalFilename || n.originalFilename,
      kemonoPath: s.kemonoPath || n.kemonoPath,
      kemonoFileHash: s.kemonoFileHash || n.kemonoFileHash,
      thumbnailUrl: s.thumbnailUrl || n.thumbnailUrl,
      originalUrl: s.originalUrl || n.originalUrl,
      discordCdnUrl: s.discordCdnUrl || n.discordCdnUrl,
      mediaType: s.mediaType === "unknown" ? n.mediaType : s.mediaType,
      sourceType: s.sourceType === n.sourceType ? s.sourceType : "merged",
      provenance: [.../* @__PURE__ */ new Set([...s.provenance, ...n.provenance])],
      warnings: [.../* @__PURE__ */ new Set([...s.warnings, ...n.warnings])]
    };
    t.delete(s.id), t.set(r.id, r);
  }
  return [...t.values()];
}
const de = 150;
function ue(e, a) {
  const t = structuredClone(e);
  if (t.attempts = 0, t.nextAttemptAt = 0, t.error = null, !a.length)
    return t.pages++, t.coverage = "complete", t.terminal = "empty-page", t;
  const n = O(a.map((s) => s.id).join(","));
  if (t.pageFingerprints.includes(n)) throw new Error("API repeated an earlier page; pagination stopped with incomplete coverage");
  if (t.pages >= 1e4) throw new Error("Safety page limit reached; coverage is incomplete");
  return t.pageFingerprints.push(n), t.pages++, t.messageIds = [.../* @__PURE__ */ new Set([...t.messageIds, ...a.map((s) => s.id)])], t.offset += de, t.coverage = "scanning", t;
}
function G(e, a = "unnamed") {
  let t = (e || a).normalize("NFKC").replace(/[<>:"/\\|?*\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "_").replace(/^[. ]+|[. ]+$/g, "").slice(0, 40).trim().replace(/[. ]+$/g, "");
  return (!t || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(t)) && (t = "_" + (t || a)), t;
}
function q(e) {
  return `ArchiveRoot/${e.serverId}_${G(e.serverName, "server")}`;
}
function Q(e) {
  return `${q(e)}/${e.channelId}_${G(e.channelName, "channel")}`;
}
function me(e, a) {
  if (!/^(png|jpg|webp|gif|avif)$/.test(a)) throw new Error("Unvalidated image format");
  const t = e.publishedAtUtc ? e.publishedAtUtc.slice(0, 19).replace("T", "_").replace(/:(\d{2})/g, "$1") + "Z" : "unknown-date";
  return `${Q(e)}/${t}_${e.messageId || "unknown-message"}_${String(e.attachmentIndex).padStart(3, "0")}_${O(e.id).slice(0, 8)}.${a}`;
}
let $;
function U() {
  return $ || ($ = new Promise((e, a) => {
    const t = indexedDB.open("kemono-archive", 1);
    t.onupgradeneeded = () => {
      t.result.createObjectStore("jobs", { keyPath: "id" }), t.result.createObjectStore("media", { keyPath: ["jobId", "id"] }).createIndex("jobId", "jobId");
    }, t.onsuccess = () => e(t.result), t.onerror = () => {
      $ = void 0, a(t.error);
    };
  })), $;
}
function _(e) {
  return new Promise((a, t) => {
    e.onsuccess = () => a(e.result), e.onerror = () => t(e.error);
  });
}
function L(e) {
  return new Promise((a, t) => {
    e.oncomplete = () => a(), e.onerror = e.onabort = () => t(e.error || new Error("Database transaction aborted"));
  });
}
async function A() {
  return _((await U()).transaction("jobs").objectStore("jobs").getAll());
}
async function he(e) {
  return _((await U()).transaction("jobs").objectStore("jobs").get(e));
}
async function h(e) {
  return _((await U()).transaction("media").objectStore("media").index("jobId").getAll(e));
}
async function f(e) {
  const a = (await U()).transaction("jobs", "readwrite"), t = L(a);
  a.objectStore("jobs").put(e), await t;
}
async function y(e) {
  const a = (await U()).transaction("media", "readwrite"), t = L(a);
  a.objectStore("media").put(e), await t;
}
async function Y(e, a) {
  const t = (await U()).transaction(["jobs", "media"], "readwrite"), n = L(t);
  t.objectStore("jobs").put(e);
  const s = t.objectStore("media"), i = s.index("jobId").openKeyCursor(IDBKeyRange.only(e.id));
  i.onsuccess = () => {
    const r = i.result;
    if (r)
      s.delete(r.primaryKey), r.continue();
    else for (const o of a) s.put(o);
  }, await n;
}
function R(e, a) {
  return {
    discovered: a.length,
    downloaded: a.filter((t) => t.status === "downloaded").length,
    failed: a.filter((t) => t.status === "failed").length,
    skipped: a.filter((t) => t.status === "skipped").length,
    queued: a.filter((t) => t.status === "queued" || t.status === "transferring").length,
    pages: e.channels.reduce((t, n) => t + n.pages, 0),
    messages: e.channels.reduce((t, n) => t + n.messageIds.length, 0),
    incomplete: e.scope === "server" && e.channelDiscovery === "dom" || e.channels.some((t) => t.coverage !== "complete") || a.some((t) => ["failed", "skipped", "queued", "transferring"].includes(t.status) || t.mediaType === "unknown" || !t.messageId || !(t.thumbnailUrl || t.originalUrl || t.discordCdnUrl)) || e.status === "cancelled"
  };
}
function P(e, a, t) {
  const n = t ? a.filter((i) => i.channelId === t) : a, s = t ? { ...e, channels: e.channels.filter((i) => i.channelId === t) } : e;
  return JSON.stringify({
    schemaVersion: 1,
    exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
    job: { ...s, manifestDownloads: s.manifestDownloads.map(({ blobUrl: i, ...r }) => r) },
    totals: R(s, n),
    coverageNote: "Complete means every requested API page reached a validated empty array. DOM coverage is limited to observed messages. Indexed links are not a claim that every image is available.",
    timestampPolicy: "Timezone-less archive publication times are interpreted as UTC; raw values are retained.",
    media: n.map(({ blobUrl: i, ...r }) => r)
  }, null, 2);
}
const K = ["serverId", "serverName", "channelId", "channelName", "messageId", "publishedRaw", "publishedAtUtc", "attachmentIndex", "originalFilename", "kemonoPath", "kemonoFileHash", "originalUrl", "discordCdnUrl", "thumbnailUrl", "resolvedUrl", "quality", "sourceType", "status", "savedPath", "sha256", "errorMessage"];
function fe(e) {
  const a = (t) => {
    let n = t == null ? "" : String(t);
    return /^[\s]*[=+\-@\t\r]/.test(n) && (n = "'" + n), '"' + n.replaceAll('"', '""') + '"';
  };
  return "\uFEFF" + [K.join(","), ...e.map((t) => K.map((n) => a(t[n])).join(","))].join(`\r
`);
}
function pe(e, a) {
  const t = [e.originalUrl, e.discordCdnUrl].map(b).filter((r) => !!r).map((r) => ({ url: r, quality: "original" })), n = b(e.thumbnailUrl), s = n ? [{ url: n, quality: "thumbnail" }] : [], i = a.mode === "original" ? t : a.mode === "best" && a.tryOriginal ? [...t, ...s] : s;
  return i.filter((r, o) => i.findIndex((l) => l.url === r.url) === o);
}
let E;
async function j(e, a = {}) {
  (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] })).length || (E ||= chrome.offscreen.createDocument({ url: "offscreen/index.html", reasons: [chrome.offscreen.Reason.BLOBS], justification: "Validate archived image bytes, decode dimensions, and create local blob URLs for browser downloads and exports." }).finally(() => {
    E = void 0;
  }), await E);
  const t = await chrome.runtime.sendMessage({ target: "offscreen", action: e, ...a });
  if (!t?.ok) throw new Error(t?.error || "Image validator did not respond");
  return t.data;
}
async function I(e) {
  e && await j("release", { url: e }).catch(() => {
  });
}
async function x(e, a, t = "application/json", n = !1) {
  const { blobUrl: s } = await j("export", { text: e, mime: t });
  try {
    return { id: await chrome.downloads.download({ url: s, filename: a, conflictAction: n ? "overwrite" : "uniquify", saveAs: !1 }), blobUrl: s };
  } catch (i) {
    throw await I(s), i;
  }
}
const z = 3;
function S(e, a = 0) {
  return Math.max(2e3 * 2 ** Math.max(0, e - 1), a);
}
async function we(e, a) {
  const t = pe(e, a);
  if (!t.length)
    return e.status = "skipped", e.errorMessage = a.mode === "original" ? "No original URL was exposed by the archive. No URL was invented." : "No observed or supported thumbnail URL is available.", await y(e), 0;
  e.status = "transferring", e.attempts++, await y(e);
  let n = 0, s = !1;
  for (const i of t)
    if (!e.candidateFailures.some((r) => r.url === i.url && /Image HTTP (400|401|403|404|410|422)\b/.test(r.reason)))
      try {
        const r = new URL(i.url).hostname;
        if (!["kemono.cr", "img.kemono.cr"].includes(r) && !await chrome.permissions.contains({ origins: [`https://${r}/*`] })) {
          e.candidateFailures.push({ url: i.url, reason: "Optional permission for this original host was not granted" });
          continue;
        }
        const o = await j("image", { url: i.url });
        if (o.failure) {
          if (e.candidateFailures.push({ url: i.url, reason: o.failure }), o.status === 429) {
            n = S(e.attempts, o.retryAfterMs), s = !0;
            break;
          }
          (!o.status || o.status >= 500) && (s = !0);
          continue;
        }
        return e.resolvedUrl = i.url, e.quality = i.quality, e.bytes = o.bytes, e.sha256 = o.sha256, e.mime = o.mime, e.width = o.width, e.height = o.height, e.blobUrl = o.blobUrl, e.savedPath = me(e, o.ext), await y(e), e.downloadId = await chrome.downloads.download({ url: o.blobUrl, filename: e.savedPath, conflictAction: "uniquify", saveAs: !1 }), e.errorMessage = null, await y(e), 0;
      } catch {
        s = !0, e.candidateFailures.push({ url: i.url, reason: "Image fetch, decoding, or browser download failed" }), await I(e.blobUrl), e.blobUrl = null, e.downloadId = null;
      }
  return e.errorMessage = e.candidateFailures.at(-1)?.reason || "All allowed image candidates failed", s && e.attempts < z ? (e.status = "queued", e.nextAttemptAt = Date.now() + (n || S(e.attempts))) : e.status = "failed", await y(e), n;
}
async function B(e, a = !1) {
  let t;
  if (e.downloadId !== null ? [t] = await chrome.downloads.search({ id: e.downloadId }) : e.savedPath && e.blobUrl && (t = (await chrome.downloads.search({ query: [e.savedPath.split("/").at(-1)], limit: 20, orderBy: ["-startTime"] })).find((s) => s.url === e.blobUrl), t && (e.downloadId = t.id)), t?.state === "complete") {
    if (t.exists === !1 ? (e.status = "failed", e.errorMessage = "The completed file was removed outside the extension") : (e.status = "downloaded", e.errorMessage = null), t.filename) {
      const n = t.filename.replaceAll("\\", "/"), s = n.lastIndexOf("/ArchiveRoot/");
      s >= 0 && (e.savedPath = n.slice(s + 1));
    }
    await I(e.blobUrl), e.blobUrl = null;
  } else (t?.state === "interrupted" || !t && a) && (e.errorMessage = t?.error || "Worker/browser interrupted an uncommitted transfer", e.status = e.attempts < z ? "queued" : "failed", e.nextAttemptAt = Date.now() + S(e.attempts), await I(e.blobUrl), e.blobUrl = null, e.downloadId = null);
  await y(e);
}
const ee = new re();
function w(e) {
  return e.updatedAt = (/* @__PURE__ */ new Date()).toISOString(), e;
}
async function Z(e) {
  const a = await he(e);
  if (!a) throw new Error("Archive job was not found");
  return a;
}
async function V(e) {
  const a = M(e);
  if (!a) throw new Error("Open or paste a Kemono Discord server or channel URL");
  const n = (await chrome.tabs.query({ url: "https://kemono.cr/discord/server/*" })).filter((u) => u.id !== void 0 && M(u.url || "")?.serverId === a.serverId).map(async (u) => {
    try {
      const m = await chrome.tabs.sendMessage(u.id, { type: "DISCOVER_CHANNELS" });
      return m?.serverId === a.serverId && Array.isArray(m.channels) ? m : null;
    } catch {
      return null;
    }
  }), [s, ...i] = await Promise.allSettled([ee.server(a.serverId), ...n]), r = s.status === "fulfilled" ? s.value : null, o = i.flatMap((u) => u.status === "fulfilled" && u.value ? [u.value] : []), l = oe(a.serverId, r, o);
  a.serverName = l?.name || null, a.channelName = l?.channels.find((u) => u.id === a.channelId)?.name || null;
  let c = null;
  return r || (c = `${s.status === "rejected" && s.reason instanceof Error ? s.reason.message : "Server metadata is unavailable."} ${l?.channels.length ? "Using channel links from the open page; hidden or unloaded channels may be missing." : a.channelId ? "Current-channel scanning is still available." : "Open the server page, reload it, and discover its channel links again."}`), { scope: a, server: l, warning: c, apiChannelCount: r?.channels.length || 0, domChannelCount: l?.channels.filter((u) => u.sources?.includes("dom")).length || 0 };
}
async function ge(e, a) {
  if (e.type === "DISCOVER") return V(e.url);
  if (e.type === "LIST") {
    const n = (await A()).sort((s, i) => i.createdAt.localeCompare(s.createdAt));
    return Promise.all(n.map(async (s) => ({ job: s, totals: R(s, await h(s.id)) })));
  }
  if (e.type === "DETAIL") {
    const n = await Z(e.jobId), s = await h(n.id);
    return { job: n, media: s, totals: R(n, s) };
  }
  if (e.type === "DASHBOARD")
    return await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") }), null;
  if (e.type === "START") {
    if (!["thumbnail", "best", "original"].includes(e.mode)) throw new Error("Invalid quality mode");
    const { scope: n, server: s, warning: i, apiChannelCount: r, domChannelCount: o } = await V(e.url), l = !!e.allChannels || !n.channelId && !e.channelIds.length, c = [...new Set(l ? s?.channels.map((d) => d.id) || [] : e.channelIds.length ? e.channelIds.map(g) : n.channelId ? [n.channelId] : [])];
    if (!c.length) throw new Error(i || "No channels were discovered in this server. Open the server page and try Discover channels again.");
    if (c.some((d) => d !== n.channelId && !s?.channels.some((p) => p.id === d))) throw new Error("Selected channel was not discovered in this server");
    for (const d of await A()) ["scanning", "downloading"].includes(d.status) && (d.resumeStatus = d.status, d.status = "paused", await f(w(d)));
    const u = {
      id: crypto.randomUUID(),
      serverId: n.serverId,
      serverName: n.serverName,
      mode: e.mode,
      tryOriginal: !!e.tryOriginal,
      channels: c.map((d) => {
        const p = s?.channels.find((N) => N.id === d);
        return { channelId: d, channelName: p?.name || null, postCount: p?.postCount ?? null, offset: 0, pages: 0, messageIds: [], pageFingerprints: [], coverage: "pending", terminal: null, failures: [], attempts: 0, nextAttemptAt: 0, error: null, domMessages: 0 };
      }),
      status: "scanning",
      resumeStatus: "scanning",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      warnings: i ? [i] : [],
      autoManifest: !1,
      manifestState: "pending",
      manifestDownloads: [],
      apiNextAt: 0,
      mediaNextAt: 0,
      scope: l ? "server" : c.length === 1 ? "channel" : "selected",
      sourceUrl: `https://kemono.cr/discord/server/${n.serverId}${n.channelId ? "/" + n.channelId : ""}`,
      discoveredChannelCount: s?.channels.length || c.length,
      channelDiscovery: r ? o ? "api+dom" : "api" : o ? "dom" : "current-channel"
    };
    await f(u);
    const m = await chrome.tabs.query({ url: "https://kemono.cr/discord/server/*" });
    for (const d of m) d.id && M(d.url || "")?.serverId === u.serverId && chrome.tabs.sendMessage(d.id, { type: "SCAN_DOM" }).catch(() => {
    });
    return { jobId: u.id };
  }
  if (e.type === "DOM") {
    const n = H(e.url), s = H(a.tab?.url || "");
    if (!n || !s || s.channelId !== n.channelId || s.serverId !== n.serverId) return null;
    for (const i of await A()) {
      if (i.serverId !== n.serverId || !["scanning", "indexed", "paused"].includes(i.status)) continue;
      const r = i.channels.find((l) => l.channelId === n.channelId);
      if (!r) continue;
      const o = e.records.slice(0, 1e4).filter((l) => l.serverId === n.serverId && l.channelId === n.channelId).map((l) => ({
        ...l,
        jobId: i.id,
        serverName: i.serverName,
        channelName: r.channelName,
        originalUrl: b(l.originalUrl),
        discordCdnUrl: b(l.discordCdnUrl),
        thumbnailUrl: b(l.thumbnailUrl)
      }));
      r.domMessages = Math.max(r.domMessages, e.messageCount), await Y(w(i), X(await h(i.id), o));
    }
    return null;
  }
  const t = await Z(e.jobId);
  if (e.type === "EXPORT") {
    const n = await h(t.id), s = q(t), i = t.id.slice(0, 8);
    return e.format === "csv" ? await x(fe(n), `${s}/links-${i}.csv`, "text/csv;charset=utf-8") : e.format === "failures" ? await x(P(t, n.filter((r) => r.status === "failed" || r.status === "skipped")), `${s}/failures-${i}.json`) : await x(P(t, n), `${s}/manifest-${i}.json`), null;
  }
  if (e.action === "pause") {
    ["scanning", "downloading"].includes(t.status) && (t.resumeStatus = t.status, t.status = "paused");
    for (const n of await h(t.id)) n.status === "transferring" && n.downloadId !== null && await chrome.downloads.pause(n.downloadId).catch(() => {
    });
  } else if (e.action === "cancel") {
    t.status = "cancelled";
    for (const n of await h(t.id))
      n.status === "transferring" && n.downloadId !== null && await chrome.downloads.cancel(n.downloadId).catch(() => {
      }), ["queued", "transferring"].includes(n.status) && (n.status = "skipped", n.errorMessage = "Cancelled by user", await I(n.blobUrl), n.blobUrl = null, await y(n));
  } else if (e.action === "resume") {
    if (t.status !== "paused") throw new Error("Only paused jobs can be resumed");
    t.status = t.resumeStatus;
    for (const n of await h(t.id)) n.status === "transferring" && n.downloadId !== null && await chrome.downloads.resume(n.downloadId).catch(() => {
    });
  } else if (e.action === "retry") {
    for (const n of t.channels) n.coverage === "incomplete" && (n.coverage = "pending", n.attempts = 0, n.error = null, n.nextAttemptAt = 0);
    for (const n of await h(t.id)) (n.status === "failed" || n.status === "skipped") && (n.status = t.autoManifest ? "queued" : "discovered", n.attempts = 0, n.nextAttemptAt = 0, n.errorMessage = null, n.candidateFailures = [], await y(n));
    t.status = t.channels.some((n) => n.coverage !== "complete") ? "scanning" : t.autoManifest ? "downloading" : "indexed", t.manifestState = "pending";
  } else if (e.action === "download") {
    if (t.status === "scanning" || t.channels.some((n) => ["pending", "scanning"].includes(n.coverage))) throw new Error("Pause or finish the scan before downloading the indexed results");
    for (const n of await h(t.id)) n.status === "discovered" && (n.status = "queued", await y(n));
    t.status = "downloading", t.autoManifest = !0, t.manifestState = "pending";
  }
  return await f(w(t)), null;
}
async function ve(e) {
  if (!e.channels.some((t) => ["pending", "scanning"].includes(t.coverage))) {
    e.status = e.autoManifest ? "downloading" : "indexed", await f(w(e));
    return;
  }
  if (Date.now() < e.apiNextAt) return;
  const a = e.channels.find((t) => ["pending", "scanning"].includes(t.coverage) && t.nextAttemptAt <= Date.now());
  if (!a) {
    e.channels.some((t) => ["pending", "scanning"].includes(t.coverage)) || (e.status = e.autoManifest ? "downloading" : "indexed", await f(w(e)));
    return;
  }
  try {
    const t = await ee.channel(a.channelId, a.offset), n = ue(a, t), s = ce(t, { serverId: e.serverId, serverName: e.serverName, channelId: a.channelId, channelName: a.channelName }, e.id);
    if (e.autoManifest) for (const i of s) i.status = "queued";
    e.channels[e.channels.indexOf(a)] = n, n.coverage === "complete" && n.postCount !== null && n.postCount !== n.messageIds.length && e.warnings.push(`Channel ${n.channelId}: metadata post_count=${n.postCount}; API unique messages=${n.messageIds.length}.`), e.apiNextAt = Date.now() + 1100, await Y(w(e), X(await h(e.id), s));
  } catch (t) {
    a.attempts++, a.error = t instanceof Error ? t.message : "Page scan failed", a.failures.push({ offset: a.offset, reason: a.error, at: (/* @__PURE__ */ new Date()).toISOString() });
    const n = t instanceof v && t.retryable;
    if (t instanceof v && t.status === 429 && (e.apiNextAt = Date.now() + S(a.attempts, t.retryAfterMs)), n && a.attempts < z) {
      const s = S(a.attempts, t.retryAfterMs);
      a.nextAttemptAt = Date.now() + s, e.apiNextAt = a.nextAttemptAt;
    } else a.coverage = "incomplete";
    await f(w(e));
  }
}
async function ye(e, a) {
  e.manifestState = "saving", e.manifestDownloads = [], await f(w(e));
  try {
    for (const s of e.channels) {
      const i = `${Q({ ...e, channelId: s.channelId, channelName: s.channelName })}/channel-manifest.json`, r = await x(P(e, a, s.channelId), i, "application/json", !0);
      e.manifestDownloads.push({ ...r, path: i, state: "in_progress" }), await f(e);
    }
    const t = `${q(e)}/manifest.json`, n = await x(P(e, a), t, "application/json", !0);
    e.manifestDownloads.push({ ...n, path: t, state: "in_progress" }), await f(e);
  } catch {
    e.manifestState = "failed", e.warnings.push("One or more manifest downloads failed. Use Export JSON to save the current state."), await f(w(e));
  }
}
async function be() {
  const e = await A(), a = Math.max(0, ...e.map((n) => n.apiNextAt)), t = Math.max(0, ...e.map((n) => n.mediaNextAt));
  for (const n of e) {
    if (n.status === "scanning") {
      (Date.now() >= a || n.channels.every((o) => !["pending", "scanning"].includes(o.coverage))) && await ve(n);
      return;
    }
    if (n.status !== "downloading") continue;
    let s = await h(n.id);
    for (const o of s) o.status === "transferring" && o.downloadId !== null && await B(o);
    s = await h(n.id);
    const i = s.filter((o) => o.status === "transferring").length, r = s.filter((o) => o.status === "queued" && o.nextAttemptAt <= Date.now()).slice(0, Math.max(0, 2 - i));
    if (r.length && Date.now() >= t) {
      const o = await Promise.all(r.map((l) => we(l, n)));
      n.mediaNextAt = Date.now() + Math.max(1100, ...o), await f(n);
    }
    s = await h(n.id), s.some((o) => o.status === "queued" || o.status === "transferring") || (n.status = "finished", await f(w(n)), n.autoManifest && n.manifestState === "pending" && await ye(n, s));
    return;
  }
}
async function te() {
  for (const e of await A()) {
    for (const a of await h(e.id)) a.status === "transferring" && await B(a, !0);
    if (e.manifestState === "saving") {
      for (const a of e.manifestDownloads) {
        const [t] = await chrome.downloads.search({ id: a.id });
        a.state = t?.state === "complete" ? "complete" : t?.state === "in_progress" ? "in_progress" : "interrupted";
      }
      e.manifestDownloads.length !== e.channels.length + 1 ? (e.manifestState = "pending", e.status === "finished" && (e.status = "downloading")) : e.manifestDownloads.every((a) => a.state === "complete") ? e.manifestState = "saved" : e.manifestDownloads.some((a) => a.state === "interrupted") && (e.manifestState = "failed"), await f(e);
    }
  }
}
async function Ie(e) {
  if (!e.state || !["complete", "interrupted"].includes(e.state.current || "")) return;
  for (const t of await A()) {
    for (const s of await h(t.id)) s.downloadId === e.id && s.status === "transferring" && await B(s);
    const n = t.manifestDownloads.find((s) => s.id === e.id);
    n && (n.state = e.state.current === "complete" ? "complete" : "interrupted", await I(n.blobUrl), t.manifestDownloads.length === t.channels.length + 1 && t.manifestDownloads.every((s) => s.state === "complete") && (t.manifestState = "saved"), n.state === "interrupted" && (t.manifestState = "failed"), await f(w(t)));
  }
  const [a] = await chrome.downloads.search({ id: e.id });
  a?.url.startsWith(`blob:chrome-extension://${chrome.runtime.id}/`) && await I(a.url);
}
let W = Promise.resolve(), F, D = !1;
function k(e) {
  const a = W.then(e);
  return W = a.catch(() => {
  }), a;
}
function ne() {
  D || (D = !0, k(be).catch(() => {
  }).finally(() => {
    D = !1, C();
  }));
}
function C() {
  F || D || (F = setTimeout(() => {
    F = void 0, ne();
  }, 1200));
}
chrome.runtime.onMessage.addListener((e, a, t) => {
  if (!(a.id !== chrome.runtime.id || e.target === "offscreen"))
    return k(() => ge(e, a)).then((n) => t({ ok: !0, data: n }), (n) => t({ ok: !1, error: n instanceof Error ? n.message : "Archive operation failed" })).finally(C), !0;
});
chrome.downloads.onChanged.addListener((e) => {
  k(() => Ie(e)).catch(() => {
  }).finally(C);
});
chrome.alarms.onAlarm.addListener((e) => {
  e.name === "archive-tick" && ne();
});
chrome.runtime.onStartup.addListener(() => {
  k(te).finally(C);
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
});
chrome.alarms.create("archive-tick", { periodInMinutes: 0.5 });
k(te).catch(() => {
}).finally(C);
